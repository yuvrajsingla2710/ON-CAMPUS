# ON-CAMPUS FULL CODEBASE

Generated for complete offline export.


---

## File: `README.md`

```markdown
# ON-CAMPUS

On Campus — A university ecosystem connecting students with campus resources, skills, knowledge, projects, communities and opportunities.

# ON CAMPUS
### Everything your campus has. Connected.

On Campus is a digital ecosystem for university students that connects the people, knowledge, skills, resources, projects and opportunities already available within their campus.

## Core Services

- 🛠️ **Borrow** — Borrow useful items from other students.
- 🧭 **Guidance** — Learn from students who have already experienced courses, professors and campus processes.
- 🤝 **Skill Exchange** — Exchange skills with other students.
- 🛒 **Marketplace** — Buy and sell books, notes, furniture, electronics and other student items.
- 🌟 **Impact** — Create projects, communities, events and shared work that can benefit the campus.
- 🧭 **COMPASS** — An intelligent assistant that helps students navigate the On Campus ecosystem.

## Key Features

- Campus Impact scoring & karma engine
- Competitive leaderboard & Top-3 rank nametags
- Zero-Knowledge student credentials & cryptographic passport
- Interactive 3D Campus Digital Twin (Three.js)
- Real-time Campus Pulse & live feed
- Student projects, research collaboration & talent recruitment
- Verified peer-to-peer equipment borrowing & lockers
- Skill matching & peer mentorship squads
- COMPASS AI assistant & ecosystem navigation

## Technology

- React 18+ / Next.js architecture
- TypeScript
- Tailwind CSS
- Three.js / WebGL 3D Campus Engine
- Express & Vite Full-Stack integration

## Goal

Create a connected digital ecosystem where students can discover, share, learn, collaborate and contribute within their university.

> **Everything your campus has. Connected.**

```

---

## File: `index.html`

```html
<!doctype html>
<html lang="en" class="dark">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>ON CAMPUS — Everything Your Campus Has. Connected.</title>
    <meta name="description" content="A futuristic digital ecosystem for university students connecting people, knowledge, skills, resources, projects, opportunities and activities." />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=Outfit:wght@400;500;600;700;800&family=Inter:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500;600&display=swap" rel="stylesheet">
  </head>
  <body class="bg-[#050608] text-[#F3F4F6] antialiased selection:bg-cyan-500/25 selection:text-cyan-200">
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"></script>
  </body>
</html>


```

---

## File: `metadata.json`

```json
{
  "name": "ON CAMPUS",
  "description": "A futuristic digital ecosystem for university students connecting people, knowledge, skills, resources, projects, opportunities and activities.",
  "requestFramePermissions": [],
  "majorCapabilities": ["MAJOR_CAPABILITY_SERVER_SIDE_GEMINI_API"]
}


```

---

## File: `package.json`

```json
{
  "name": "react-example",
  "private": true,
  "version": "0.0.0",
  "type": "module",
  "scripts": {
    "dev": "tsx server.ts",
    "build": "vite build && esbuild server.ts --bundle --platform=node --format=cjs --packages=external --sourcemap --outfile=dist/server.cjs",
    "start": "node dist/server.cjs",
    "preview": "vite preview",
    "clean": "rm -rf dist server.js",
    "lint": "tsc --noEmit"
  },
  "dependencies": {
    "@google/genai": "^2.4.0",
    "@tailwindcss/vite": "^4.1.14",
    "@types/three": "^0.185.4",
    "@vitejs/plugin-react": "^5.0.4",
    "dotenv": "^17.2.3",
    "express": "^4.21.2",
    "lucide-react": "^0.546.0",
    "motion": "^12.23.24",
    "react": "^19.0.1",
    "react-dom": "^19.0.1",
    "three": "^0.185.1",
    "vite": "^6.2.3"
  },
  "devDependencies": {
    "@types/node": "^22.14.0",
    "autoprefixer": "^10.4.21",
    "esbuild": "^0.25.0",
    "tailwindcss": "^4.1.14",
    "tsx": "^4.21.0",
    "typescript": "~5.8.2",
    "vite": "^6.2.3",
    "@types/express": "^4.17.21"
  }
}

```

---

## File: `server.ts`

```tsx
import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Lazy-initialized Gemini AI client
let aiClient: GoogleGenAI | null = null;
function getGeminiClient() {
  if (!aiClient && process.env.GEMINI_API_KEY) {
    aiClient = new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiClient;
}

// Health check
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", app: "ON CAMPUS", timestamp: new Date().toISOString() });
});

// COMPASS AI campus assistant query endpoint
app.post("/api/compass/ask", async (req, res) => {
  const prompt = req.body.prompt || req.body.query || "";
  const campusContext = req.body.campusContext || req.body.userContext || {};

  if (!prompt || typeof prompt !== "string") {
    res.status(400).json({ error: "Missing prompt or query parameter" });
    return;
  }

  const p = prompt.toLowerCase();

  // Smart dynamic card catalog
  const catalogCards: Record<string, {
    type: "borrow" | "project" | "marketplace" | "skill" | "guidance" | "pulse";
    title: string;
    subtitle: string;
    targetId: string;
    tag: string;
    actionLabel: string;
    keywords: string[];
  }> = {
    calc: {
      type: "borrow",
      title: "Casio fx-991EX Scientific Calculator",
      subtitle: "Available • North Block H4 • Aman T.",
      targetId: "b-2",
      tag: "Hardware",
      actionLabel: "Borrow (Free)",
      keywords: ["calc", "calculator", "casio", "fx-991", "scientific", "math", "exam calc"],
    },
    arduino: {
      type: "borrow",
      title: "Arduino Mega + 37 Sensor Kit",
      subtitle: "Available • Central Lab • Yash P.",
      targetId: "b-1",
      tag: "Electronics",
      actionLabel: "Borrow",
      keywords: ["arduino", "sensor", "iot", "mega", "microcontroller", "breadboard", "components"],
    },
    scope: {
      type: "borrow",
      title: "Rigol 50MHz Digital Oscilloscope",
      subtitle: "Available • Electronics Wing Lab 3",
      targetId: "b-3",
      tag: "Lab Gear",
      actionLabel: "Reserve Gear",
      keywords: ["oscilloscope", "scope", "rigol", "signal", "waveform", "electronics lab", "circuits"],
    },
    labcoat: {
      type: "borrow",
      title: "Lab Coat & UV Protection Eyewear",
      subtitle: "Available • Biotech Block B • Sneha R.",
      targetId: "b-4",
      tag: "Lab Safety",
      actionLabel: "Borrow",
      keywords: ["lab coat", "coat", "goggles", "eyewear", "chemistry", "biotech", "safety"],
    },
    camera: {
      type: "borrow",
      title: "Sony Alpha A6400 4K Camera + Gimbal",
      subtitle: "Available • Media Center • Tanvi S.",
      targetId: "b-6",
      tag: "Media Gear",
      actionLabel: "Borrow Camera",
      keywords: ["camera", "sony", "dslr", "video", "photos", "gimbal", "shoot", "recording"],
    },
    campusvision: {
      type: "project",
      title: "CampusVision Attendance System",
      subtitle: "Devansh Iyer • Recruiting Python/OpenCV (91% Acc)",
      targetId: "p-1",
      tag: "AI / Vision",
      actionLabel: "Join Squad",
      keywords: ["campusvision", "vision", "attendance", "facial", "opencv", "pytorch", "ai project", "computer vision"],
    },
    soilsense: {
      type: "project",
      title: "SoilSense IoT Agricultural Sensor",
      subtitle: "Ananya Sharma • Recruiting Embedded C / LoRa",
      targetId: "p-2",
      tag: "IoT & Hardware",
      actionLabel: "Join Squad",
      keywords: ["soilsense", "soil", "iot", "agriculture", "embedded", "lora", "hardware project"],
    },
    lecturerewind: {
      type: "project",
      title: "Lecture Rewind AI Transcripts",
      subtitle: "Siddharth Verma • Recruiting Whisper / FastAPI",
      targetId: "p-3",
      tag: "AI / NLP",
      actionLabel: "View Project",
      keywords: ["lecture", "rewind", "transcript", "audio", "whisper", "fastapi", "nlp", "speech"],
    },
    figma: {
      type: "skill",
      title: "Figma UI/UX & Design Systems",
      subtitle: "Sana K. (Design Lead) • 92% Match Score",
      targetId: "match-1",
      tag: "Skill Swap",
      actionLabel: "Connect Mentor",
      keywords: ["figma", "ui", "ux", "design", "wireframe", "prototype", "sana"],
    },
    pcb: {
      type: "skill",
      title: "PCB Design, KiCAD & Soldering",
      subtitle: "Yuvraj Sen (4th Yr ECE) • 88% Match",
      targetId: "match-2",
      tag: "Hardware Skill",
      actionLabel: "Exchange Skill",
      keywords: ["pcb", "kicad", "soldering", "circuit design", "hardware mentor", "yuvraj"],
    },
    ros: {
      type: "skill",
      title: "ROS 2, Gazebo & Autonomous Navigation",
      subtitle: "Neha Choudhury (Robotics Lead) • 91% Match",
      targetId: "match-5",
      tag: "Robotics",
      actionLabel: "Connect",
      keywords: ["ros", "ros2", "robotics", "gazebo", "navigation", "slam", "robot"],
    },
    notes_dsa: {
      type: "marketplace",
      title: "Handwritten DSA & OS Complete Notes",
      subtitle: "₹150 • Rohit V. • Verified Sem 3 Topper",
      targetId: "m-4",
      tag: "Marketplace",
      actionLabel: "Get Notes",
      keywords: ["dsa", "notes", "handwritten", "algorithms", "data structures", "exam notes", "pyq notes"],
    },
    book_griffiths: {
      type: "marketplace",
      title: "Introduction to Electrodynamics (Griffiths)",
      subtitle: "₹450 • Like New • Aman V. (Hostel C)",
      targetId: "m-1",
      tag: "Textbook",
      actionLabel: "Buy Book",
      keywords: ["griffiths", "electrodynamics", "physics book", "textbook", "edynamics"],
    },
    guidance_os: {
      type: "guidance",
      title: "Cracking Operating Systems & Kernel Midterms",
      subtitle: "Blueprint by Aditya R. • 340 Reads",
      targetId: "g-1",
      tag: "Academic Guide",
      actionLabel: "Read Blueprint",
      keywords: ["operating systems", "os", "kernel", "scheduling", "deadlock", "memory management", "aditya"],
    },
    guidance_menon: {
      type: "guidance",
      title: "Navigating Prof. Menon's Signals Course",
      subtitle: "Blueprint by Kavya N. (ECE) • 512 Reads",
      targetId: "g-2",
      tag: "Course Advice",
      actionLabel: "View Tips",
      keywords: ["signals", "systems", "menon", "fourier", "laplace", "ece advice"],
    },
    guidance_intern: {
      type: "guidance",
      title: "Summer Research Internships & Cold Emailing",
      subtitle: "Guide by Meera Sen (IIT/MIT Alumni) • 890 Reads",
      targetId: "g-3",
      tag: "Career Prep",
      actionLabel: "Read Guide",
      keywords: ["internship", "research", "cold email", "summer intern", "mit", "fellowship", "resume"],
    },
  };

  // Determine matching action cards
  let suggestedCards: Array<{
    type: "borrow" | "project" | "marketplace" | "skill" | "guidance" | "pulse";
    title: string;
    subtitle: string;
    targetId: string;
    tag: string;
    actionLabel: string;
  }> = [];

  Object.values(catalogCards).forEach((card) => {
    if (card.keywords.some((kw) => p.includes(kw))) {
      suggestedCards.push({
        type: card.type as any,
        title: card.title,
        subtitle: card.subtitle,
        targetId: card.targetId,
        tag: card.tag,
        actionLabel: card.actionLabel,
      });
    }
  });

  // Limit suggested cards to max 3
  suggestedCards = suggestedCards.slice(0, 3);

  // Fallback cards if none matched
  if (suggestedCards.length === 0) {
    if (p.includes("project") || p.includes("research") || p.includes("team")) {
      suggestedCards.push(
        { type: catalogCards.campusvision.type as any, title: catalogCards.campusvision.title, subtitle: catalogCards.campusvision.subtitle, targetId: catalogCards.campusvision.targetId, tag: catalogCards.campusvision.tag, actionLabel: catalogCards.campusvision.actionLabel },
        { type: catalogCards.soilsense.type as any, title: catalogCards.soilsense.title, subtitle: catalogCards.soilsense.subtitle, targetId: catalogCards.soilsense.targetId, tag: catalogCards.soilsense.tag, actionLabel: catalogCards.soilsense.actionLabel }
      );
    } else if (p.includes("exam") || p.includes("study") || p.includes("guide")) {
      suggestedCards.push(
        { type: catalogCards.guidance_os.type as any, title: catalogCards.guidance_os.title, subtitle: catalogCards.guidance_os.subtitle, targetId: catalogCards.guidance_os.targetId, tag: catalogCards.guidance_os.tag, actionLabel: catalogCards.guidance_os.actionLabel },
        { type: catalogCards.notes_dsa.type as any, title: catalogCards.notes_dsa.title, subtitle: catalogCards.notes_dsa.subtitle, targetId: catalogCards.notes_dsa.targetId, tag: catalogCards.notes_dsa.tag, actionLabel: catalogCards.notes_dsa.actionLabel }
      );
    } else {
      suggestedCards.push(
        { type: catalogCards.calc.type as any, title: catalogCards.calc.title, subtitle: catalogCards.calc.subtitle, targetId: catalogCards.calc.targetId, tag: catalogCards.calc.tag, actionLabel: catalogCards.calc.actionLabel },
        { type: catalogCards.campusvision.type as any, title: catalogCards.campusvision.title, subtitle: catalogCards.campusvision.subtitle, targetId: catalogCards.campusvision.targetId, tag: catalogCards.campusvision.tag, actionLabel: catalogCards.campusvision.actionLabel },
        { type: catalogCards.figma.type as any, title: catalogCards.figma.title, subtitle: catalogCards.figma.subtitle, targetId: catalogCards.figma.targetId, tag: catalogCards.figma.tag, actionLabel: catalogCards.figma.actionLabel }
      );
    }
  }

  // Dynamic Follow-Up Queries
  let followUpQueries: string[] = [];
  if (p.includes("calc") || p.includes("borrow") || p.includes("hardware") || p.includes("scope")) {
    followUpQueries = [
      "Where is the Central Lab pickup point?",
      "What is the maximum borrow duration?",
      "Are there soldering kits available to borrow?",
    ];
  } else if (p.includes("project") || p.includes("vision") || p.includes("squad") || p.includes("ai")) {
    followUpQueries = [
      "What tech stack does CampusVision need?",
      "How do I submit an application to a squad?",
      "Show me other active Robotics & IoT projects",
    ];
  } else if (p.includes("exam") || p.includes("notes") || p.includes("paper") || p.includes("dsa") || p.includes("os")) {
    followUpQueries = [
      "Where can I find PYQ papers for 3rd semester?",
      "Are Prof. Menon's exams open-notes?",
      "Who is top-ranked for Data Structures mentoring?",
    ];
  } else if (p.includes("figma") || p.includes("skill") || p.includes("teach") || p.includes("mentor")) {
    followUpQueries = [
      "How does the peer skill swap score work?",
      "Find students who want to learn Python",
      "Connect me with Sana K. for design review",
    ];
  } else if (p.includes("hostel") || p.includes("mess") || p.includes("library") || p.includes("wifi") || p.includes("timing")) {
    followUpQueries = [
      "What are the Central Library 24/7 timings?",
      "How do I configure the campus Wi-Fi proxy?",
      "Where is the nearest 24/7 printing shop?",
    ];
  } else {
    followUpQueries = [
      "Where can I borrow lab equipment?",
      "Which student projects are recruiting right now?",
      "Find study guides and handwritten notes",
    ];
  }

  // Determine query category
  let queryCategory: "Academic" | "Lab & Gear" | "Projects" | "Skill Swap" | "Marketplace" | "Campus Life" | "General" = "General";
  if (p.includes("exam") || p.includes("notes") || p.includes("paper") || p.includes("syllabus") || p.includes("prof") || p.includes("guide")) {
    queryCategory = "Academic";
  } else if (p.includes("borrow") || p.includes("calc") || p.includes("scope") || p.includes("arduino") || p.includes("gear") || p.includes("lab")) {
    queryCategory = "Lab & Gear";
  } else if (p.includes("project") || p.includes("squad") || p.includes("vision") || p.includes("robot") || p.includes("recruit")) {
    queryCategory = "Projects";
  } else if (p.includes("skill") || p.includes("figma") || p.includes("teach") || p.includes("learn") || p.includes("swap") || p.includes("mentor")) {
    queryCategory = "Skill Swap";
  } else if (p.includes("market") || p.includes("buy") || p.includes("sell") || p.includes("price") || p.includes("book")) {
    queryCategory = "Marketplace";
  } else if (p.includes("hostel") || p.includes("mess") || p.includes("library") || p.includes("event") || p.includes("wifi") || p.includes("sports")) {
    queryCategory = "Campus Life";
  }

  // 1. Try Gemini with Model Fallback (gemini-2.5-flash -> gemini-2.5-flash-lite)
  try {
    const ai = getGeminiClient();
    if (ai) {
      const systemInstruction = `You are COMPASS, the intelligent futuristic campus operating system and AI co-pilot for "ON CAMPUS".
Your role is to connect university students with existing campus resources, people, peer knowledge, research projects, marketplace listings, skill exchanges, borrow inventory, hostel logistics, and live pulse activities.

Guidelines:
1. Speak with a sleek, precise, hyper-helpful, futuristic tone (concise, clear, high-signal, zero fluff).
2. Cite REAL campus entities from the knowledge base below whenever relevant:
   - Borrow Inventory: Casio fx-991EX Calculator (Aman T., North Block H4), Arduino Mega Sensor Kit (Yash P., Central Lab), Rigol 50MHz Oscilloscope (Lab 3), Sony A6400 4K Camera (Tanvi S.), Lab Coat & UV Goggles (Sneha R., Biotech B), Drafting Board (Arjun M.).
   - Research Squads: CampusVision (Facial attendance, Devansh Iyer, needs Python/OpenCV, 91% acc), SoilSense (IoT moisture, Ananya Sharma, needs Embedded C), Lecture Rewind (AI transcripts, Siddharth Verma, needs Whisper/FastAPI), EcoSort (Trash robot, Tarun K., needs ROS 2).
   - Skill Mentors: Sana K. (Figma UI/UX, Design Society Lead), Yuvraj Sen (PCB & KiCAD), Tanvi S. (Video Editing & Blender), Neha Choudhury (ROS 2 Robotics), Kshitij Rao (Public Speaking).
   - Marketplace: David Griffiths Electrodynamics (₹450, Hostel C), Casio fx-991 (₹500), Foldable hostel study desk (₹1,600, Hostel 3), DSA & OS handwritten notes (₹150, Rohit V.), Canon 200D DSLR (₹18,500).
   - Blueprint Guides: Cracking OS & Kernel Midterms (Aditya R.), Prof. Menon Signals & Systems (Kavya N.), Summer Research Internships (Meera Sen), Hostel Survival & Hacks (Rahul Verma).
   - Campus Logistics & Pulse: Central Library open 24/7 during exam weeks (Proxy: proxy.campus.edu:8080), HackNITC 3.0 registrations live (₹2.5L pool), Robotics Club ROS 2 workshop this Saturday at 2 PM in Lab 402, 24/7 Medical Center (Ext 4444), Printing shop at Central Library basement (₹1.5/page).
3. Format your answers beautifully using Markdown with clear bold highlights, bullet points, and actionable next steps.
4. Keep the answer between 2 to 4 crisp paragraphs/bullet points. Always give direct, high-value assistance.`;

      const candidateModels = ["gemini-2.5-flash", "gemini-2.5-flash-lite"];
      let generatedText: string | null = null;
      let usedModel: string = "gemini-2.5-flash";

      for (const modelName of candidateModels) {
        try {
          const response = await ai.models.generateContent({
            model: modelName,
            contents: prompt,
            config: {
              systemInstruction,
              temperature: 0.6,
            },
          });

          if (response.text && response.text.trim()) {
            generatedText = response.text;
            usedModel = modelName;
            break;
          }
        } catch (modelErr: any) {
          console.warn(`[COMPASS AI] Model ${modelName} unavailable (${modelErr?.status || modelErr?.code || 'transient error'}). Trying fallback...`);
        }
      }

      if (generatedText) {
        res.json({
          reply: generatedText,
          answer: generatedText,
          source: usedModel,
          category: queryCategory,
          confidenceScore: 98,
          followUpQueries,
          suggestedCards,
        });
        return;
      }
    }
  } catch (error: any) {
    console.warn("[COMPASS AI] Remote AI service currently busy; utilizing instant campus neural engine.", error?.message || "");
  }

  // 2. High-precision Multi-Domain Fallback Reasoning Engine
  let fallbackAnswer = "I scanned the ON CAMPUS neural network across all 6 core layers (Borrow, Guidance, Skills, Marketplace, Projects, Pulse).";

  if (p.includes("calculator") || p.includes("calc") || p.includes("casio")) {
    fallbackAnswer = `**Scientific Calculator Availability:**
• **Free Borrow Protocol**: Casio fx-991EX ClassWiz is available in **North Block H4** (Lender: Aman T., 5-day max loan, ₹0 deposit).
• **Marketplace Buy Option**: A like-new Casio fx-991 is listed for **₹500** by Aman T.
• **Central Lab Pool**: You can also check out backup calculators from the Central Lab inventory desk on Ground Floor.`;
  } else if (p.includes("oscilloscope") || p.includes("scope") || p.includes("signal") || p.includes("waveform")) {
    fallbackAnswer = `**Oscilloscope & Measurement Gear:**
• **Rigol 50MHz Digital Oscilloscope** is available for 48-hour student reservation in **Electronics Wing Lab 3** (Faculty in charge: Dr. Nair).
• Includes dual probes, BNC connectors, and USB waveform export.
• Check the **Borrow Gear** section to lock your slot.`;
  } else if (p.includes("lab coat") || p.includes("goggles") || p.includes("chemistry") || p.includes("biotech")) {
    fallbackAnswer = `**Lab Safety Gear:**
• **Borrow**: Sneha R. in **Biotech Block B** has a 100% cotton Lab Coat (Size M/L) and UV safety eyewear available for free borrowing up to 7 days.
• **Marketplace**: Verified university lab coats are also listed for **₹220** under the Marketplace Equipment category.`;
  } else if (p.includes("ai project") || p.includes("robot") || p.includes("project") || p.includes("recruit") || p.includes("vision") || p.includes("squad")) {
    fallbackAnswer = `**Active Campus Squads Recruiting Right Now:**
• **CampusVision** (Computer Vision Attendance): Led by Devansh Iyer. Currently at **91% accuracy** and actively recruiting Python / OpenCV / PyTorch developers.
• **SoilSense** (IoT Agricultural Moisture Network): Led by Ananya Sharma. Recruiting Embedded C & LoRa engineers.
• **Lecture Rewind** (AI Audio Summarizer): Led by Siddharth Verma. Looking for Whisper API & FastAPI contributors.
• **EcoSort** (Autonomous Waste Classifier): Led by Tarun K. Recruiting ROS 2 & TensorFlow developers.`;
  } else if (p.includes("figma") || p.includes("ui") || p.includes("ux") || p.includes("design") || p.includes("wireframe")) {
    fallbackAnswer = `**Figma UI/UX Mentorship & Skill Exchange:**
• **Sana K.** (Design Society Lead, 4th Year) is offering hands-on design system & Figma wireframing guidance (**92% compatibility match**).
• She is looking to learn **Python & Excel** in exchange.
• You can send a direct Skill Swap request to initiate a peer session.`;
  } else if (p.includes("pcb") || p.includes("kicad") || p.includes("soldering") || p.includes("circuit")) {
    fallbackAnswer = `**Hardware & PCB Design Exchange:**
• **Yuvraj Sen** (4th Year ECE) is mentoring on KiCAD schematic capture, 2-layer PCB layout, and surface-mount soldering (**88% match score**).
• Looking for **React & TypeScript** frontend basics in return.`;
  } else if (p.includes("ros") || p.includes("ros2") || p.includes("robotics") || p.includes("gazebo")) {
    fallbackAnswer = `**Robotics & ROS 2 Hub:**
• **Neha Choudhury** (Robotics Club Lead) mentors on ROS 2 Humble, Gazebo simulation, and SLAM navigation (**91% match**).
• The **Robotics Club** is also hosting a live hands-on ROS 2 workshop this Saturday at **2:00 PM in Lab 402**.`;
  } else if (p.includes("past year") || p.includes("paper") || p.includes("pyq") || p.includes("notes") || p.includes("dsa") || p.includes("dbms")) {
    fallbackAnswer = `**Academic Notes & Previous Year Exam Papers:**
• **Handwritten DSA & OS Notes**: Topper-verified Sem 3 notes compiled by Rohit V. are available in the **Marketplace for ₹150**.
• **Operating Systems Blueprint**: Aditya R. published a 340-read guide on kernel scheduling, memory management, and deadlock questions in the **Guidance Portal**.
• **Central Library Digital Repository**: Access past 5 years of exam papers at \`repository.campus.edu\` via campus intranet.`;
  } else if (p.includes("menon") || p.includes("signals") || p.includes("fourier")) {
    fallbackAnswer = `**Prof. Menon's Signals & Systems Course Insights:**
• **Midterm Format**: Confirmed on Campus Pulse as **Open-Notes** (Handwritten cheat sheets allowed, no electronic devices).
• **High-Yield Topics**: Focus heavily on Fourier Transform duality, DTFS proofs, and ROC conditions for Laplace transforms.
• Read Kavya N.'s comprehensive blueprint guide in the **Guidance section** (512 reads).`;
  } else if (p.includes("internship") || p.includes("resume") || p.includes("cold email") || p.includes("career")) {
    fallbackAnswer = `**Internship & Research Placement Blueprint:**
• **Research Guide**: Meera Sen's blueprint *"Securing Summer Research Internships & Cold Emailing Strategies"* covers email templates that got students into IIT Bombay, IISc, and MIT labs.
• **Upcoming Events**: HackNITC 3.0 registrations are live on Campus Pulse with direct interview fast-tracks from sponsor tech companies.`;
  } else if (p.includes("library") || p.includes("timing") || p.includes("study room") || p.includes("24/7")) {
    fallbackAnswer = `**Central Library Hours & Facilities:**
• **Standard Hours**: Monday - Saturday: 8:00 AM - 11:00 PM.
• **Exam Period Hours**: **Open 24/7** with air-conditioned night reading halls in the 2nd Floor annex.
• **Intranet Wi-Fi Proxy**: \`proxy.campus.edu\` on port \`8080\` (Credentials: Student LDAP ID).
• **Printing**: Basement Xerox counter opens at 8:30 AM (₹1.50 per B&W page).`;
  } else if (p.includes("wifi") || p.includes("proxy") || p.includes("internet") || p.includes("network")) {
    fallbackAnswer = `**Campus Wi-Fi & Proxy Configuration:**
• **SSID**: \`Campus-HighSpeed-5G\` / \`Hostel-Mesh\`
• **HTTP/HTTPS Proxy**: \`proxy.campus.edu\` | **Port**: \`8080\`
• **Bypass Domains**: \`*.campus.edu, localhost, 127.0.0.1\`
• For device MAC registration, visit the Computer Center Helpdesk (Room 102).`;
  } else if (p.includes("hostel") || p.includes("mess") || p.includes("food") || p.includes("room")) {
    fallbackAnswer = `**Hostel & Dining Information:**
• **Mess Timings**: Breakfast (7:30–9:30 AM) | Lunch (12:00–2:00 PM) | Dinner (7:30–9:30 PM).
• **Special Dinner**: Wednesday & Sunday nights (Ice cream / Special gravy).
• **Hostel Wings Portal**: Access Wing H4, Block B, and Central Hostel common rooms via the **Hostel Wings modal**.`;
  } else if (p.includes("emergency") || p.includes("medical") || p.includes("doctor") || p.includes("security") || p.includes("help")) {
    fallbackAnswer = `**Campus Emergency Contacts:**
• **24/7 Medical Dispensary**: Ext. \`4444\` / Emergency Ambulance: \`+91-98765-43210\`
• **Campus Main Security Gate**: Ext. \`1001\`
• **Dean of Student Welfare (DSW)**: \`dsw@campus.edu\` (Admin Block 2nd Floor).`;
  } else if (p.includes("marketplace") || p.includes("buy") || p.includes("sell") || p.includes("book")) {
    fallbackAnswer = `**Marketplace Exchange:**
• Verified student listings available:
  - *Introduction to Electrodynamics (Griffiths)* – **₹450** (Hostel C)
  - *Casio fx-991EX Calculator* – **₹500** (North Block H4)
  - *Foldable Study Table* – **₹1,600** (Hostel 3)
  - *Canon EOS 200D DSLR* – **₹18,500** (Media Wing)
• Safe handoffs take place in public hostel common rooms or library lobby.`;
  }

  res.json({
    reply: fallbackAnswer,
    answer: fallbackAnswer,
    source: "compass-engine-v2",
    category: queryCategory,
    confidenceScore: 95,
    followUpQueries,
    suggestedCards,
  });
});

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`ON CAMPUS server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();

```

---

## File: `src/App.tsx`

```tsx
import React, { useState } from 'react';
import { 
  mockMarketplaceItems, 
  mockProjects, 
  mockUsers, 
  mockPulsePosts, 
  mockBorrowItems, 
  mockSkillMatches, 
  mockGuidanceTopics, 
  initialCompassMessages,
  mockNotifications
} from './data/mockData';
import { 
  MarketplaceItem, 
  ProjectItem, 
  UserProfile, 
  PulsePost, 
  BorrowItem, 
  SkillMatch, 
  GuidanceTopic, 
  CompassMessage,
  CampusNotification,
  DirectMessage
} from './types';

// Scrollable Website Components
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { TutorialVideoSection } from './components/TutorialVideoSection';
import { ServicesSection } from './components/ServicesSection';
import { ImpactLeaderboard } from './components/ImpactLeaderboard';
import { CompassSection } from './components/CompassSection';
import { CampusChatSection } from './components/CampusChatSection';
import { CampusPulseSection } from './components/CampusPulseSection';
import { ProjectsSection } from './components/ProjectsSection';
import { MarketplaceSection } from './components/MarketplaceSection';
import { FinalCinematicSection } from './components/FinalCinematicSection';
import { Footer } from './components/Footer';
import { FloatingCompassWidget } from './components/FloatingCompassWidget';
import { MobileSectionNavigator, MobileNextSectionFooter } from './components/MobileSectionNavigator';

// Detail & Creation Modals
import { MarketplaceDetailModal } from './components/MarketplaceDetailModal';
import { CreateListingModal } from './components/CreateListingModal';
import { ProjectDetailModal } from './components/ProjectDetailModal';
import { CreateProjectModal } from './components/CreateProjectModal';
import { CreatePostModal } from './components/CreatePostModal';
import { BorrowModal } from './components/BorrowModal';
import { SkillExchangeModal } from './components/SkillExchangeModal';
import { GuidanceModal } from './components/GuidanceModal';
import { AuthModal } from './components/AuthModal';
import { CommandPaletteModal } from './components/CommandPaletteModal';
import { FullLeaderboardModal } from './components/FullLeaderboardModal';
import { StudentPassportModal } from './components/StudentPassportModal';
import { CampusAnalyticsModal } from './components/CampusAnalyticsModal';
import { PeerSquadsModal } from './components/PeerSquadsModal';
import { HostelWingsModal } from './components/HostelWingsModal';
import { ShareModal, ShareData } from './components/ShareModal';
import { NotificationsModal } from './components/NotificationsModal';
import { DirectMessageModal } from './components/DirectMessageModal';
import { PresentationModal } from './components/PresentationModal';

export function App() {
  // Global App Data State
  const [users, setUsers] = useState<UserProfile[]>(mockUsers);
  const [currentUser, setCurrentUser] = useState<UserProfile>(() => {
    try {
      const saved = localStorage.getItem('oncampus_current_user');
      if (saved) {
        return JSON.parse(saved);
      }
    } catch (e) {
      console.warn('Failed to load user from localStorage', e);
    }
    return mockUsers[2]; // Yuvraj Sen (#03)
  });
  const [marketplaceItems, setMarketplaceItems] = useState<MarketplaceItem[]>(mockMarketplaceItems);
  const [projects, setProjects] = useState<ProjectItem[]>(mockProjects);
  const [pulsePosts, setPulsePosts] = useState<PulsePost[]>(mockPulsePosts);
  const [borrowItems, setBorrowItems] = useState<BorrowItem[]>(mockBorrowItems);
  const [skillMatches, setSkillMatches] = useState<SkillMatch[]>(mockSkillMatches);
  const [guidanceTopics, setGuidanceTopics] = useState<GuidanceTopic[]>(mockGuidanceTopics);
  const [compassMessages, setCompassMessages] = useState<CompassMessage[]>(initialCompassMessages);
  const [isCompassLoading, setIsCompassLoading] = useState<boolean>(false);

  // Notifications & Direct Messaging State
  const [notifications, setNotifications] = useState<CampusNotification[]>(() => {
    try {
      const saved = localStorage.getItem('oncampus_notifications');
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return mockNotifications;
  });

  const [directMessages, setDirectMessages] = useState<DirectMessage[]>(() => {
    try {
      const saved = localStorage.getItem('oncampus_direct_messages');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {}
    return [
      {
        id: 'dm-1',
        senderId: 'u1',
        senderName: 'Ananya Rao',
        senderAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80',
        receiverId: 'u3',
        receiverName: 'Yuvraj Sen',
        text: 'Hey Yuvraj! Thanks for the Raspberry Pi 4 loan last week, the lab demo went super well.',
        timestamp: 'Yesterday at 5:12 PM',
        read: true,
      },
      {
        id: 'dm-2',
        senderId: 'u3',
        senderName: 'Yuvraj Sen',
        senderAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80',
        receiverId: 'u1',
        receiverName: 'Ananya Rao',
        text: 'Glad to help Ananya! Anytime you need gear from North Block H4 just let me know.',
        timestamp: 'Yesterday at 5:20 PM',
        read: true,
      },
      {
        id: 'dm-3',
        senderId: 'u1',
        senderName: 'Ananya Rao',
        senderAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80',
        receiverId: 'u3',
        receiverName: 'Yuvraj Sen',
        text: 'Are you free this Thursday to do a quick review on the Distributed Systems assignment? 💻',
        timestamp: '10:14 AM',
        read: true,
      },
      {
        id: 'dm-4',
        senderId: 'u2',
        senderName: 'Devansh Iyer',
        senderAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80',
        receiverId: 'u3',
        receiverName: 'Yuvraj Sen',
        text: 'Hey Yuvraj! Saw your post about the autonomous rover testing. Do you need an extra LiDAR sensor for the weekend hackathon?',
        timestamp: 'Yesterday at 8:30 PM',
        read: true,
      },
      {
        id: 'dm-5',
        senderId: 'u3',
        senderName: 'Yuvraj Sen',
        senderAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80',
        receiverId: 'u2',
        receiverName: 'Devansh Iyer',
        text: 'That would be huge Devansh! Which hostel wing are you in?',
        timestamp: 'Yesterday at 8:45 PM',
        read: true,
      },
      {
        id: 'dm-6',
        senderId: 'u2',
        senderName: 'Devansh Iyer',
        senderAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80',
        receiverId: 'u3',
        receiverName: 'Yuvraj Sen',
        text: 'Tech Tower (H7), Room 304. Swing by anytime after 6 PM! ⚡',
        timestamp: 'Yesterday at 8:50 PM',
        read: true,
      }
    ];
  });

  // Share Modal State (WhatsApp, Telegram, X, LinkedIn, Reddit, Email, Native Sheet)
  const [shareModalData, setShareModalData] = useState<ShareData | null>(null);
  const handleOpenShare = (data: ShareData) => setShareModalData(data);

  // Modal Visibility States
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [isPresentationOpen, setIsPresentationOpen] = useState(false);
  const [directMessageTargetUser, setDirectMessageTargetUser] = useState<UserProfile | null>(null);
  const [isBorrowOpen, setIsBorrowOpen] = useState(false);
  const [isSkillOpen, setIsSkillOpen] = useState(false);
  const [isGuidanceOpen, setIsGuidanceOpen] = useState(false);
  const [isCreateListingOpen, setIsCreateListingOpen] = useState(false);
  const [isCreateProjectOpen, setIsCreateProjectOpen] = useState(false);
  const [isCreatePostOpen, setIsCreatePostOpen] = useState(false);
  const [isCommandPaletteOpen, setIsCommandPaletteOpen] = useState(false);
  const [isFloatingCompassOpen, setIsFloatingCompassOpen] = useState(false);
  const [isLeaderboardOpen, setIsLeaderboardOpen] = useState(false);
  const [isAnalyticsOpen, setIsAnalyticsOpen] = useState(false);
  const [isSquadsOpen, setIsSquadsOpen] = useState(false);
  const [isWingsOpen, setIsWingsOpen] = useState(false);
  const [selectedPassportUser, setSelectedPassportUser] = useState<UserProfile | null>(null);
  const [chatSelectedUserId, setChatSelectedUserId] = useState<string>('u1');

  // Active Detail Selection States
  const [selectedMarketplaceItem, setSelectedMarketplaceItem] = useState<MarketplaceItem | null>(null);
  const [selectedProject, setSelectedProject] = useState<ProjectItem | null>(null);

  // Active Navigation Section Tracking
  const [activeSection, setActiveSection] = useState<string>('hero');
  const [mobileActiveSection, setMobileActiveSection] = useState<string>('overview');
  const [mobileTabbedMode, setMobileTabbedMode] = useState<boolean>(true);

  const handleNavigateToSection = (sectionId: string) => {
    const normalized = sectionId === 'hero' ? 'overview' : sectionId;
    setMobileActiveSection(normalized);
    setActiveSection(sectionId);
    
    // In continuous mode on mobile or on desktop, scroll to element
    const targetElement = document.getElementById(sectionId === 'overview' ? 'hero' : sectionId);
    if (targetElement) {
      targetElement.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleOpenChatWithUser = (user: UserProfile) => {
    setChatSelectedUserId(user.id);
    setMobileActiveSection('chat');
    setActiveSection('chat');
    // Close overlays so the section is in direct focus
    setSelectedPassportUser(null);
    setIsNotificationsOpen(false);
    setIsLeaderboardOpen(false);
    setIsSquadsOpen(false);
    setIsWingsOpen(false);
    setDirectMessageTargetUser(null);

    // Smooth scroll to chat section
    setTimeout(() => {
      document.getElementById('chat')?.scrollIntoView({ behavior: 'smooth' });
    }, 60);
  };

  // Global Keyboard Shortcuts (Cmd+K / Ctrl+K)
  React.useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setIsCommandPaletteOpen((prev) => !prev);
      }
      if (e.key === 'Escape') {
        setIsCommandPaletteOpen(false);
        setIsAuthOpen(false);
        setIsBorrowOpen(false);
        setIsSkillOpen(false);
        setIsGuidanceOpen(false);
        setIsCreateListingOpen(false);
        setIsCreateProjectOpen(false);
        setIsCreatePostOpen(false);
        setIsLeaderboardOpen(false);
        setIsAnalyticsOpen(false);
        setIsSquadsOpen(false);
        setIsWingsOpen(false);
        setSelectedPassportUser(null);
        setSelectedMarketplaceItem(null);
        setSelectedProject(null);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // ==================== USER ACTIONS ====================

  const handleOpenLeaderboard = () => {
    console.log(`[App] Opening Full Leaderboard Modal -> setting isLeaderboardOpen = true (Total users: ${users.length})`);
    setIsLeaderboardOpen(true);
  };

  const handleCloseLeaderboard = () => {
    console.log('[App] Closing Full Leaderboard Modal -> setting isLeaderboardOpen = false');
    setIsLeaderboardOpen(false);
  };

  const handleGiveKudos = (userId: string) => {
    setUsers((prevUsers) =>
      prevUsers.map((u) => {
        if (u.id === userId) {
          return {
            ...u,
            impactScore: u.impactScore + 5,
            kudosCount: (u.kudosCount || 0) + 1,
          };
        }
        return u;
      })
    );

    // Also update currentUser if it's the target
    if (currentUser.id === userId) {
      setCurrentUser((prev) => ({
        ...prev,
        impactScore: prev.impactScore + 5,
        kudosCount: (prev.kudosCount || 0) + 1,
      }));
    }
  };

  const handleSwitchUser = (user: UserProfile) => {
    setCurrentUser(user);
    try {
      localStorage.setItem('oncampus_current_user', JSON.stringify(user));
    } catch (e) {
      console.warn('Failed to persist user to localStorage', e);
    }
  };

  const handleUpdateProfile = (updatedUser: UserProfile) => {
    setCurrentUser(updatedUser);
    setUsers((prevUsers) => {
      const exists = prevUsers.some((u) => u.id === updatedUser.id);
      if (exists) {
        return prevUsers.map((u) => (u.id === updatedUser.id ? updatedUser : u));
      }
      return [updatedUser, ...prevUsers];
    });
    try {
      localStorage.setItem('oncampus_current_user', JSON.stringify(updatedUser));
    } catch (e) {
      console.warn('Failed to persist user to localStorage', e);
    }
  };

  // Privacy & Friend Request Logic
  const handleTogglePrivacy = (userId?: string) => {
    const targetId = userId || currentUser.id;
    const target = users.find((u) => u.id === targetId) || currentUser;
    const nextPrivacy = !target.isPrivate;

    const updatedUser: UserProfile = {
      ...target,
      isPrivate: nextPrivacy,
    };

    if (currentUser.id === targetId) {
      setCurrentUser(updatedUser);
      try {
        localStorage.setItem('oncampus_current_user', JSON.stringify(updatedUser));
      } catch (e) {}
    }

    if (selectedPassportUser && selectedPassportUser.id === targetId) {
      setSelectedPassportUser(updatedUser);
    }

    setUsers((prev) => prev.map((u) => (u.id === targetId ? updatedUser : u)));
  };

  const handleSendFriendRequest = (targetUserId: string) => {
    const targetUser = users.find((u) => u.id === targetUserId);
    if (!targetUser) return;

    // Update currentUser outgoing list
    const updatedCurrent: UserProfile = {
      ...currentUser,
      outgoingFriendRequestUserIds: Array.from(new Set([...(currentUser.outgoingFriendRequestUserIds || []), targetUserId])),
    };
    setCurrentUser(updatedCurrent);

    // Update targetUser pending list
    const updatedTarget: UserProfile = {
      ...targetUser,
      pendingFriendRequestUserIds: Array.from(new Set([...(targetUser.pendingFriendRequestUserIds || []), currentUser.id])),
    };

    setUsers((prev) =>
      prev.map((u) => {
        if (u.id === currentUser.id) return updatedCurrent;
        if (u.id === targetUserId) return updatedTarget;
        return u;
      })
    );

    if (selectedPassportUser && selectedPassportUser.id === targetUserId) {
      setSelectedPassportUser(updatedTarget);
    }

    // Add a campus notification for this request
    const newNotif: CampusNotification = {
      id: `notif-${Date.now()}`,
      type: 'friend_request',
      title: `Friend Request to ${targetUser.name}`,
      description: `Sent a connection request to ${targetUser.name} (${targetUser.department}) to unlock peer chat.`,
      senderId: currentUser.id,
      senderName: currentUser.name,
      senderAvatar: currentUser.avatar,
      senderDepartment: currentUser.department,
      senderRank: currentUser.rank,
      timestamp: 'Just now',
      read: false,
      status: 'pending',
    };

    setNotifications((prev) => [newNotif, ...prev]);

    // Simulated peer auto-approval so direct messaging is immediately unlocked
    setTimeout(() => {
      setUsers((prev) =>
        prev.map((u) => {
          if (u.id === currentUser.id) {
            return {
              ...u,
              friendIds: Array.from(new Set([...(u.friendIds || []), targetUserId])),
              outgoingFriendRequestUserIds: (u.outgoingFriendRequestUserIds || []).filter((id) => id !== targetUserId),
            };
          }
          if (u.id === targetUserId) {
            return {
              ...u,
              friendIds: Array.from(new Set([...(u.friendIds || []), currentUser.id])),
              pendingFriendRequestUserIds: (u.pendingFriendRequestUserIds || []).filter((id) => id !== currentUser.id),
            };
          }
          return u;
        })
      );

      setCurrentUser((prev) => ({
        ...prev,
        friendIds: Array.from(new Set([...(prev.friendIds || []), targetUserId])),
        outgoingFriendRequestUserIds: (prev.outgoingFriendRequestUserIds || []).filter((id) => id !== targetUserId),
        impactScore: prev.impactScore + 15,
      }));

      // Send greeting DM from the peer
      const welcomeMsg: DirectMessage = {
        id: `dm-${Date.now() + 2}`,
        senderId: targetUserId,
        senderName: targetUser.name,
        senderAvatar: targetUser.avatar,
        receiverId: currentUser.id,
        receiverName: currentUser.name,
        text: `Hey ${currentUser.name.split(' ')[0]}! I accepted your friend request. Great to connect with you! 🤝 Feel free to ask about courses, gear, or projects anytime.`,
        timestamp: 'Just now',
        read: false,
      };
      setDirectMessages((prev) => [...prev, welcomeMsg]);
    }, 1000);
  };

  const handleClearConversation = (targetUserId: string) => {
    setDirectMessages((prev) =>
      prev.filter(
        (m) =>
          !(
            (m.senderId === currentUser.id && m.receiverId === targetUserId) ||
            (m.senderId === targetUserId && m.receiverId === currentUser.id)
          )
      )
    );
  };

  const handleAcceptFriendRequest = (notificationId: string, senderId: string) => {
    // 1. Mark notification accepted
    setNotifications((prev) =>
      prev.map((n) => (n.id === notificationId ? { ...n, read: true, status: 'accepted' } : n))
    );

    // 2. Mutual friendship
    const updatedCurrent: UserProfile = {
      ...currentUser,
      friendIds: Array.from(new Set([...(currentUser.friendIds || []), senderId])),
      pendingFriendRequestUserIds: (currentUser.pendingFriendRequestUserIds || []).filter((id) => id !== senderId),
      impactScore: currentUser.impactScore + 15,
    };
    setCurrentUser(updatedCurrent);

    setUsers((prev) =>
      prev.map((u) => {
        if (u.id === currentUser.id) return updatedCurrent;
        if (u.id === senderId) {
          return {
            ...u,
            friendIds: Array.from(new Set([...(u.friendIds || []), currentUser.id])),
            outgoingFriendRequestUserIds: (u.outgoingFriendRequestUserIds || []).filter((id) => id !== currentUser.id),
          };
        }
        return u;
      })
    );
  };

  const handleDeclineNotification = (notificationId: string) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === notificationId ? { ...n, read: true, status: 'declined' } : n))
    );
  };

  const handleApproveBorrowRequest = (notificationId: string) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === notificationId ? { ...n, read: true, status: 'accepted' } : n))
    );
    setCurrentUser((prev) => ({
      ...prev,
      impactScore: prev.impactScore + 20,
    }));
  };

  const handleAcceptProjectInvite = (notificationId: string) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === notificationId ? { ...n, read: true, status: 'accepted' } : n))
    );
    setCurrentUser((prev) => ({
      ...prev,
      impactScore: prev.impactScore + 25,
    }));
  };

  const handleAcceptSkillSwap = (notificationId: string) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === notificationId ? { ...n, read: true, status: 'accepted' } : n))
    );
    setCurrentUser((prev) => ({
      ...prev,
      impactScore: prev.impactScore + 20,
    }));
  };

  const handleMarkAllNotificationsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
  };

  const handleSendDirectMessage = (targetUserId: string, text: string) => {
    if (!text || !text.trim()) return;
    const recipient = users.find((u) => u.id === targetUserId);
    const newMsg: DirectMessage = {
      id: `dm-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      senderId: currentUser.id,
      senderName: currentUser.name,
      senderAvatar: currentUser.avatar,
      receiverId: targetUserId,
      receiverName: recipient?.name || 'Student Peer',
      text: text.trim(),
      timestamp: 'Just now',
      read: true,
    };

    setDirectMessages((prev) => {
      const updated = [...prev, newMsg];
      try {
        localStorage.setItem('oncampus_direct_messages', JSON.stringify(updated));
      } catch (e) {}
      return updated;
    });

    // Auto-connect peer friendship if not yet connected
    if (recipient && !(currentUser.friendIds || []).includes(targetUserId)) {
      setCurrentUser((prev) => ({
        ...prev,
        friendIds: Array.from(new Set([...(prev.friendIds || []), targetUserId])),
      }));
      setUsers((prev) =>
        prev.map((u) => {
          if (u.id === currentUser.id) {
            return {
              ...u,
              friendIds: Array.from(new Set([...(u.friendIds || []), targetUserId])),
            };
          }
          if (u.id === targetUserId) {
            return {
              ...u,
              friendIds: Array.from(new Set([...(u.friendIds || []), currentUser.id])),
            };
          }
          return u;
        })
      );
    }

    // Simulated context-aware peer reply
    if (recipient) {
      setTimeout(() => {
        let replyText = `Hey ${currentUser.name.split(' ')[0]}! Got your message. Let's catch up in the campus lab or library soon! 🚀`;
        const lowerText = text.toLowerCase();
        
        if (lowerText.includes('borrow') || lowerText.includes('gear') || lowerText.includes('equipment') || lowerText.includes('pi') || lowerText.includes('arduino') || lowerText.includes('calculator')) {
          replyText = `Hey ${currentUser.name.split(' ')[0]}! Absolutely, I have it ready in ${recipient.hostelWing || 'my hostel room'}. When do you want to swing by to pick it up? 🛠️`;
        } else if (lowerText.includes('note') || lowerText.includes('textbook') || lowerText.includes('course') || lowerText.includes('exam') || lowerText.includes('study')) {
          replyText = `Sure thing! I uploaded my verified handwritten notes and study guide to the shared drive. Let me know if you need any specific lecture breakdown! 📚`;
        } else if (lowerText.includes('hackathon') || lowerText.includes('project') || lowerText.includes('team') || lowerText.includes('collaborat')) {
          replyText = `That sounds awesome! I was looking for a teammate with your skill profile. Let's sync up over Discord or in the lab tomorrow! ⚡`;
        } else if (lowerText.includes('skill') || lowerText.includes('swap') || lowerText.includes('teach') || lowerText.includes('learn')) {
          replyText = `I'd love to do a peer skill exchange! I can walk you through ${recipient.skillsOffered?.[0] || 'the core concepts'} whenever you are free. 💡`;
        } else if (lowerText.includes('coffee') || lowerText.includes('food') || lowerText.includes('lunch') || lowerText.includes('canteen')) {
          replyText = `Sounds great! Meet you at the Student Center Canteen in 15 mins! ☕`;
        } else if (lowerText.includes('hello') || lowerText.includes('hi') || lowerText.includes('hey')) {
          replyText = `Hey ${currentUser.name.split(' ')[0]}! Great to connect with you. How is your project coming along? ✨`;
        }

        const replyMsg: DirectMessage = {
          id: `dm-${Date.now() + 1}-${Math.random().toString(36).slice(2, 7)}`,
          senderId: targetUserId,
          senderName: recipient.name,
          senderAvatar: recipient.avatar,
          receiverId: currentUser.id,
          receiverName: currentUser.name,
          text: replyText,
          timestamp: 'Just now',
          read: false,
        };
        setDirectMessages((prev) => {
          const updated = [...prev, replyMsg];
          try {
            localStorage.setItem('oncampus_direct_messages', JSON.stringify(updated));
          } catch (e) {}
          return updated;
        });
      }, 1200);
    }
  };

  const handleSelectService = (serviceId: string) => {
    const s = serviceId.toLowerCase();
    if (s === 'borrow') {
      setIsBorrowOpen(true);
    } else if (s === 'guidance' || s === 'mentorship') {
      setIsGuidanceOpen(true);
    } else if (s === 'skills' || s === 'skill') {
      setIsSkillOpen(true);
    } else if (s === 'marketplace') {
      handleNavigateToSection('marketplace');
    } else if (s === 'connect' || s === 'chat') {
      handleNavigateToSection('chat');
    } else if (s === 'pulse') {
      handleNavigateToSection('pulse');
    } else if (s === 'compass') {
      handleNavigateToSection('compass');
    } else if (s === 'projects' || s === 'project') {
      handleNavigateToSection('projects');
    } else if (s === 'leaderboard' || s === 'impact') {
      setIsLeaderboardOpen(true);
    } else if (s === 'analytics') {
      setIsAnalyticsOpen(true);
    } else if (s === 'squads') {
      setIsSquadsOpen(true);
    } else if (s === 'wings') {
      setIsWingsOpen(true);
    } else if (s === 'auth' || s === 'profile') {
      setIsAuthOpen(true);
    } else if (s === 'presentation' || s === 'pitch' || s === 'deck' || s === 'slides' || s === 'manifesto') {
      setIsPresentationOpen(true);
    }
  };

  // Marketplace Handlers
  const handleCreateMarketplaceItem = (
    itemData: Omit<MarketplaceItem, 'id' | 'createdAt' | 'available'>
  ) => {
    const newItem: MarketplaceItem = {
      ...itemData,
      id: `m-${Date.now()}`,
      createdAt: 'Just now',
      available: true,
      sellerName: currentUser.name,
      sellerVerified: currentUser.verified,
      sellerDepartment: currentUser.department,
    };
    setMarketplaceItems([newItem, ...marketplaceItems]);
    
    // Reward impact points
    setCurrentUser((prev) => ({
      ...prev,
      impactScore: prev.impactScore + 30,
      resourceScore: prev.resourceScore + 2,
    }));
  };

  const handleContactSeller = (itemId: string, message: string) => {
    console.log(`Sent message to seller for item ${itemId}:`, message);
  };

  // Projects Handlers
  const handleCreateProject = (
    projData: Omit<ProjectItem, 'id' | 'membersCount' | 'followersCount' | 'updatesCount'>
  ) => {
    const newProj: ProjectItem = {
      ...projData,
      id: `p-${Date.now()}`,
      membersCount: 1,
      followersCount: 1,
      updatesCount: 1,
      creator: currentUser.name,
      creatorTitle: currentUser.title,
    };
    setProjects([newProj, ...projects]);

    // Reward impact points
    setCurrentUser((prev) => ({
      ...prev,
      impactScore: prev.impactScore + 60,
      projectScore: prev.projectScore + 5,
    }));
  };

  const handleToggleFollowProject = (projectId: string) => {
    setProjects((prev) =>
      prev.map((p) => {
        if (p.id === projectId) {
          const isFollowing = !p.isFollowing;
          return {
            ...p,
            isFollowing,
            followersCount: isFollowing ? p.followersCount + 1 : p.followersCount - 1,
          };
        }
        return p;
      })
    );
  };

  const handleJoinProject = (projectId: string) => {
    setProjects((prev) =>
      prev.map((p) => (p.id === projectId ? { ...p, hasApplied: true } : p))
    );
  };

  const handlePostProjectUpdate = (projectId: string, text: string) => {
    setProjects((prev) =>
      prev.map((p) =>
        p.id === projectId
          ? {
              ...p,
              recentUpdate: text,
              updatesCount: p.updatesCount + 1,
            }
          : p
      )
    );
  };

  // Campus Pulse Handlers
  const handleToggleLikePost = (postId: string) => {
    setPulsePosts((prev) =>
      prev.map((post) => {
        if (post.id === postId) {
          const isLiked = !post.isLiked;
          return {
            ...post,
            isLiked,
            likesCount: isLiked ? post.likesCount + 1 : post.likesCount - 1,
          };
        }
        return post;
      })
    );
  };

  const handleAddCommentToPost = (postId: string, text: string) => {
    setPulsePosts((prev) =>
      prev.map((post) => {
        if (post.id === postId) {
          const newComment = {
            id: `c-${Date.now()}`,
            author: currentUser.name,
            text,
            time: 'Just now',
          };
          return {
            ...post,
            commentsCount: post.commentsCount + 1,
            comments: [...(post.comments || []), newComment],
          };
        }
        return post;
      })
    );
  };

  const handleCreatePulsePost = (
    postData: Omit<PulsePost, 'id' | 'likesCount' | 'commentsCount' | 'timestamp' | 'comments'>
  ) => {
    const newPost: PulsePost = {
      ...postData,
      id: `pulse-${Date.now()}`,
      author: currentUser.name,
      authorDepartment: currentUser.department,
      likesCount: 1,
      commentsCount: 0,
      timestamp: 'Just now',
      comments: [],
    };
    setPulsePosts([newPost, ...pulsePosts]);

    setCurrentUser((prev) => ({
      ...prev,
      impactScore: prev.impactScore + 10,
    }));
  };

  // Borrow Handlers
  const handleRequestBorrow = (itemId: string, duration: number) => {
    setBorrowItems((prev) =>
      prev.map((item) =>
        item.id === itemId ? { ...item, available: false } : item
      )
    );
    setCurrentUser((prev) => ({
      ...prev,
      impactScore: prev.impactScore + 15,
    }));
  };

  const handleAddBorrowItem = (itemData: Omit<BorrowItem, 'id' | 'available'>) => {
    const newItem: BorrowItem = {
      ...itemData,
      id: `b-${Date.now()}`,
      available: true,
      ownerName: currentUser.name,
      ownerVerified: currentUser.verified,
    };
    setBorrowItems([newItem, ...borrowItems]);
    setCurrentUser((prev) => ({
      ...prev,
      impactScore: prev.impactScore + 40,
      resourceScore: prev.resourceScore + 3,
    }));
  };

  // Skill Exchange Handlers
  const handleConnectSkillMatch = (matchId: string) => {
    setSkillMatches((prev) =>
      prev.map((m) => (m.id === matchId ? { ...m, status: 'connected' } : m))
    );
  };

  const handleAddSkills = (offered: string, wanted: string) => {
    const newMatch: SkillMatch = {
      id: `match-${Date.now()}`,
      studentA: {
        name: currentUser.name,
        year: currentUser.year || 'Current Student',
        teaches: offered,
        avatar: currentUser.avatar,
      },
      studentB: {
        name: 'Aarav Patel',
        year: '4th Year Physics',
        teaches: wanted,
        avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=150&auto=format&fit=crop&q=80',
      },
      matchScore: 94,
      status: 'available',
    };
    setSkillMatches([newMatch, ...skillMatches]);
    setCurrentUser((prev) => ({
      ...prev,
      impactScore: prev.impactScore + 30,
      skillScore: prev.skillScore + 2,
    }));
  };

  // Guidance Handlers
  const handleAddGuidanceTopic = (topicData: Omit<GuidanceTopic, 'id' | 'reads'>) => {
    const newTopic: GuidanceTopic = {
      ...topicData,
      id: `g-${Date.now()}`,
      reads: 1,
      mentorName: currentUser.name,
      mentorTitle: currentUser.title,
    };
    setGuidanceTopics([newTopic, ...guidanceTopics]);
    setCurrentUser((prev) => ({
      ...prev,
      impactScore: prev.impactScore + 50,
      knowledgeScore: prev.knowledgeScore + 3,
    }));
  };

  // COMPASS AI Assistant Handler
  const handleSendCompassMessage = async (text: string) => {
    const userMsg: CompassMessage = {
      id: `msg-${Date.now()}`,
      sender: 'user',
      text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setCompassMessages((prev) => [...prev, userMsg]);
    setIsCompassLoading(true);

    try {
      const response = await fetch('/api/compass/ask', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: text,
          query: text,
          userContext: {
            name: currentUser.name,
            department: currentUser.department,
            impactScore: currentUser.impactScore,
          },
          campusContext: {
            name: currentUser.name,
            department: currentUser.department,
            impactScore: currentUser.impactScore,
          },
        }),
      });

      if (!response.ok) {
        throw new Error(`Server returned ${response.status}`);
      }

      const data = await response.json();
      const compassMsg: CompassMessage = {
        id: `msg-${Date.now() + 1}`,
        sender: 'compass',
        text: data.reply || data.answer,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        suggestedCards: data.suggestedCards,
        category: data.category,
        confidenceScore: data.confidenceScore,
        followUpQueries: data.followUpQueries,
      };

      setCompassMessages((prev) => [...prev, compassMsg]);
    } catch (err) {
      console.error('COMPASS query error:', err);
      // Fallback
      const fallbackMsg: CompassMessage = {
        id: `msg-${Date.now() + 1}`,
        sender: 'compass',
        text: `Here is what I indexed across the campus network:\n\n• **Borrow Inventory**: 4 scientific calculators & 2 FPGA kits available in Hostel B.\n• **Senior Guidance**: Check the OS Lab notes and syllabus breakdown.\n• **Research Squads**: Autonomous Rover Team is recruiting 2 firmware members.\n\nClick any shortcut card below to request or connect directly.`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        category: 'Campus Network',
        confidenceScore: 0.95,
        followUpQueries: [
          'Who has Casio scientific calculators?',
          'Find open AI/ML research squads',
          'Where are PYQs for Operating Systems?'
        ],
        suggestedCards: [
          {
            type: 'borrow',
            title: 'Casio fx-991EX Calculator',
            subtitle: 'Available • Arya Hostel • Aman T.',
            targetId: 'b-2',
            tag: 'Hardware',
            actionLabel: 'Borrow Now',
          },
          {
            type: 'project',
            title: 'CampusVision Attendance System',
            subtitle: 'Looking for OpenCV / Python Devs',
            targetId: 'p-1',
            tag: 'Research',
            actionLabel: 'Join Squad',
          },
        ],
      };
      setCompassMessages((prev) => [...prev, fallbackMsg]);
    } finally {
      setIsCompassLoading(false);
    }
  };

  const handleSelectActionCard = (type: string, targetId?: string) => {
    if (type === 'marketplace') {
      const found = marketplaceItems.find((m) => m.id === targetId) || marketplaceItems[0];
      setSelectedMarketplaceItem(found);
    } else if (type === 'project') {
      const found = projects.find((p) => p.id === targetId) || projects[0];
      setSelectedProject(found);
    } else if (type === 'borrow') {
      setIsBorrowOpen(true);
    } else if (type === 'skill') {
      setIsSkillOpen(true);
    } else if (type === 'guidance') {
      setIsGuidanceOpen(true);
    }
  };

  return (
    <div className="min-h-screen bg-[#050505] text-white selection:bg-[#00f2ff] selection:text-black font-sans antialiased flex flex-col">
      {/* 1. Header / Navbar matching Screenshot 1 */}
      <Navbar
        currentUser={currentUser}
        onOpenAuth={() => setIsAuthOpen(true)}
        onOpenCompass={() => setIsFloatingCompassOpen(true)}
        onOpenSearch={() => setIsCommandPaletteOpen(true)}
        onOpenNotifications={() => setIsNotificationsOpen(true)}
        unreadNotificationsCount={notifications.filter((n) => !n.read).length}
        onOpenServiceModal={(srv) => handleSelectService(srv)}
        onNavigateSection={handleNavigateToSection}
        onOpenPresentation={() => setIsPresentationOpen(true)}
        activeSection={mobileActiveSection}
      />

      {/* Mobile Sticky Section Switcher & Mode Toggle (Visible on mobile/tablet <lg) */}
      <MobileSectionNavigator
        activeSection={mobileActiveSection}
        onSelectSection={(secId) => {
          setMobileActiveSection(secId);
          setActiveSection(secId);
        }}
        isTabbedMode={mobileTabbedMode}
        onToggleTabbedMode={setMobileTabbedMode}
      />

      {/* SECTION 1: Overview (Hero & Showcase Walkthrough) */}
      <div className={!mobileTabbedMode || mobileActiveSection === 'overview' ? 'block' : 'hidden lg:block'}>
        <Hero
          onOpenCompass={() => setIsFloatingCompassOpen(true)}
          onExplore={() => handleNavigateToSection('services')}
          onExploreServices={() => handleNavigateToSection('services')}
          onEnterNetwork={() => handleNavigateToSection('services')}
          onOpenPresentation={() => setIsPresentationOpen(true)}
        />
        <TutorialVideoSection />
      </div>

      {/* SECTION 2: The Platform / Six Services */}
      <div className={!mobileTabbedMode || mobileActiveSection === 'services' ? 'block' : 'hidden lg:block'}>
        <ServicesSection
          onSelectService={handleSelectService}
          onOpenServiceModal={handleSelectService}
          borrowItems={borrowItems}
          guidanceTopics={guidanceTopics}
          skillMatches={skillMatches}
          marketplaceItems={marketplaceItems}
          projects={projects}
          onSelectMarketplaceItem={(item) => setSelectedMarketplaceItem(item)}
          onSelectProject={(proj) => setSelectedProject(proj)}
          onAskCompassWithQuery={(query) => {
            handleSendCompassMessage(query);
            handleNavigateToSection('compass');
          }}
        />
      </div>

      {/* SECTION 3: Impact Engine & Leaderboard */}
      <div className={!mobileTabbedMode || mobileActiveSection === 'impact' ? 'block' : 'hidden lg:block'}>
        <ImpactLeaderboard
          users={users}
          onSelectUser={(u) => setSelectedPassportUser(u)}
          onOpenFullLeaderboard={handleOpenLeaderboard}
          onOpenAnalytics={() => setIsAnalyticsOpen(true)}
          onOpenSquads={() => setIsSquadsOpen(true)}
          onOpenWings={() => setIsWingsOpen(true)}
          onOpenPassport={(u) => setSelectedPassportUser(u)}
        />
      </div>

      {/* SECTION 4: COMPASS AI Section */}
      <div className={!mobileTabbedMode || mobileActiveSection === 'compass' ? 'block' : 'hidden lg:block'}>
        <CompassSection
          messages={compassMessages}
          onSendMessage={handleSendCompassMessage}
          isLoading={isCompassLoading}
          onSelectActionCard={handleSelectActionCard}
        />
      </div>

      {/* SECTION 5: Campus Peer Chatbox (P2P Messaging) */}
      <div className={!mobileTabbedMode || mobileActiveSection === 'chat' ? 'block' : 'hidden lg:block'}>
        <CampusChatSection
          users={users}
          currentUser={currentUser}
          messages={directMessages}
          onSendMessage={handleSendDirectMessage}
          onSendFriendRequest={handleSendFriendRequest}
          onClearConversation={handleClearConversation}
          onOpenPassport={(u) => setSelectedPassportUser(u)}
          selectedUserId={chatSelectedUserId}
          onSelectUser={(u) => setChatSelectedUserId(u.id)}
        />
      </div>

      {/* SECTION 6: Live Campus Pulse Stream */}
      <div className={!mobileTabbedMode || mobileActiveSection === 'pulse' ? 'block' : 'hidden lg:block'}>
        <CampusPulseSection
          posts={pulsePosts}
          onToggleLike={handleToggleLikePost}
          onAddComment={handleAddCommentToPost}
          onOpenCreatePost={() => setIsCreatePostOpen(true)}
          onOpenShare={handleOpenShare}
        />
      </div>

      {/* SECTION 6: Research & Project Collaborations */}
      <div className={!mobileTabbedMode || mobileActiveSection === 'projects' ? 'block' : 'hidden lg:block'}>
        <ProjectsSection
          projects={projects}
          onSelectProject={(proj) => setSelectedProject(proj)}
          onOpenCreateProject={() => setIsCreateProjectOpen(true)}
          onToggleFollow={handleToggleFollowProject}
          onJoinProject={handleJoinProject}
        />
      </div>

      {/* SECTION 7: Peer Marketplace */}
      <div className={!mobileTabbedMode || mobileActiveSection === 'marketplace' ? 'block' : 'hidden lg:block'}>
        <MarketplaceSection
          items={marketplaceItems}
          onSelectItem={(item) => setSelectedMarketplaceItem(item)}
          onOpenCreateModal={() => setIsCreateListingOpen(true)}
        />
      </div>

      {/* Final Ecosystem Manifesto */}
      <div className={!mobileTabbedMode || mobileActiveSection === 'overview' ? 'block' : 'hidden lg:block'}>
        <FinalCinematicSection
          onEnterApp={() => handleNavigateToSection('services')}
        />
      </div>

      {/* Mobile Next Section Footer (Only shown when Tabbed Mode is active on mobile) */}
      {mobileTabbedMode && (
        <MobileNextSectionFooter
          currentSectionId={mobileActiveSection}
          onNavigateNext={(nextId) => {
            setMobileActiveSection(nextId);
            setActiveSection(nextId);
          }}
          onNavigateSection={(secId) => {
            setMobileActiveSection(secId);
            setActiveSection(secId);
          }}
        />
      )}

      {/* Footer */}
      <Footer />

      {/* ==================== GLOBAL MODALS & DIALOGS ==================== */}

      {/* Universal Multi-Platform Share Modal */}
      <ShareModal
        isOpen={!!shareModalData}
        shareData={shareModalData}
        onClose={() => setShareModalData(null)}
      />

      {/* Command Palette (⌘K) */}
      <CommandPaletteModal
        isOpen={isCommandPaletteOpen}
        onClose={() => setIsCommandPaletteOpen(false)}
        onNavigateTab={(tab) => {
          handleSelectService(tab);
        }}
        marketplaceItems={marketplaceItems}
        projects={projects}
        borrowItems={borrowItems}
        guidanceTopics={guidanceTopics}
        onSelectItem={(item) => setSelectedMarketplaceItem(item)}
        onSelectProject={(proj) => setSelectedProject(proj)}
      />

      {/* Borrow Modal & Inventory Sheet */}
      <BorrowModal
        isOpen={isBorrowOpen}
        onClose={() => setIsBorrowOpen(false)}
        items={borrowItems}
        onRequestBorrow={handleRequestBorrow}
        onAddBorrowItem={handleAddBorrowItem}
      />

      {/* Guidance & Mentorship Modal */}
      <GuidanceModal
        isOpen={isGuidanceOpen}
        onClose={() => setIsGuidanceOpen(false)}
        topics={guidanceTopics}
        onAddTopic={handleAddGuidanceTopic}
      />

      {/* Skill Exchange Match Modal */}
      <SkillExchangeModal
        isOpen={isSkillOpen}
        onClose={() => setIsSkillOpen(false)}
        matches={skillMatches}
        onConnectMatch={handleConnectSkillMatch}
        onAddSkills={handleAddSkills}
      />

      {/* Marketplace Detail Modal */}
      <MarketplaceDetailModal
        item={selectedMarketplaceItem}
        onClose={() => setSelectedMarketplaceItem(null)}
        onContactSeller={handleContactSeller}
        onOpenShare={handleOpenShare}
      />

      {/* Create Listing Modal */}
      <CreateListingModal
        isOpen={isCreateListingOpen}
        onClose={() => setIsCreateListingOpen(false)}
        onCreateListing={handleCreateMarketplaceItem}
      />

      {/* Project Detail Modal */}
      <ProjectDetailModal
        project={selectedProject}
        onClose={() => setSelectedProject(null)}
        onToggleFollow={handleToggleFollowProject}
        onJoinProject={handleJoinProject}
        onPostUpdate={handlePostProjectUpdate}
        onOpenShare={handleOpenShare}
      />

      {/* Create Project Modal */}
      <CreateProjectModal
        isOpen={isCreateProjectOpen}
        onClose={() => setIsCreateProjectOpen(false)}
        onCreateProject={handleCreateProject}
      />

      {/* Create Post Modal */}
      <CreatePostModal
        isOpen={isCreatePostOpen}
        onClose={() => setIsCreatePostOpen(false)}
        onCreatePost={handleCreatePulsePost}
      />

      {/* Persona & Auth Switcher Modal */}
      <AuthModal
        isOpen={isAuthOpen}
        onClose={() => setIsAuthOpen(false)}
        users={users}
        currentUser={currentUser}
        onSelectUser={handleSwitchUser}
        onSwitchUser={handleSwitchUser}
        onUpdateUser={handleUpdateProfile}
      />

      {/* Full Leaderboard Modal (50+ Campus Leaders, Filters, Badges & Proofs) */}
      <FullLeaderboardModal
        isOpen={isLeaderboardOpen}
        onClose={handleCloseLeaderboard}
        users={users}
        currentUser={currentUser}
        onSelectUserForPassport={(user) => {
          setSelectedPassportUser(user);
        }}
        onGiveKudos={handleGiveKudos}
        onOpenShare={handleOpenShare}
      />

      {/* Student Passport & Cryptographic Credentials Modal */}
      <StudentPassportModal
        isOpen={!!selectedPassportUser}
        user={selectedPassportUser}
        currentUser={currentUser}
        onClose={() => setSelectedPassportUser(null)}
        onGiveKudos={handleGiveKudos}
        onOpenEditProfile={() => {
          setSelectedPassportUser(null);
          setIsAuthOpen(true);
        }}
        onOpenDirectMessage={(user) => {
          handleOpenChatWithUser(user);
        }}
        onSendFriendRequest={handleSendFriendRequest}
        onTogglePrivacy={handleTogglePrivacy}
      />

      {/* Campus Notifications Modal (Friend Requests, Borrow Approvals, Project Invites) */}
      <NotificationsModal
        isOpen={isNotificationsOpen}
        onClose={() => setIsNotificationsOpen(false)}
        notifications={notifications}
        currentUser={currentUser}
        onAcceptFriendRequest={handleAcceptFriendRequest}
        onDeclineRequest={handleDeclineNotification}
        onApproveBorrowRequest={handleApproveBorrowRequest}
        onAcceptProjectInvite={handleAcceptProjectInvite}
        onAcceptSkillSwap={handleAcceptSkillSwap}
        onMarkAllAsRead={handleMarkAllNotificationsRead}
        onOpenPassport={(user) => {
          setIsNotificationsOpen(false);
          setSelectedPassportUser(user);
        }}
        onOpenDirectMessage={(user) => {
          handleOpenChatWithUser(user);
        }}
        users={users}
      />

      {/* Direct Messaging Modal (Public instant chat or Private friend-gated) */}
      <DirectMessageModal
        isOpen={!!directMessageTargetUser}
        targetUser={directMessageTargetUser}
        currentUser={currentUser}
        messages={directMessages}
        onClose={() => setDirectMessageTargetUser(null)}
        onSendMessage={handleSendDirectMessage}
        onSendFriendRequest={handleSendFriendRequest}
        onOpenInPageChat={handleOpenChatWithUser}
        onOpenPassport={(user) => {
          setDirectMessageTargetUser(null);
          setSelectedPassportUser(user);
        }}
      />

      {/* Campus Telemetry & Impact Analytics Modal */}
      <CampusAnalyticsModal
        isOpen={isAnalyticsOpen}
        onClose={() => setIsAnalyticsOpen(false)}
      />

      {/* Peer Squads & Study Teams Modal */}
      <PeerSquadsModal
        isOpen={isSquadsOpen}
        onClose={() => setIsSquadsOpen(false)}
        currentUser={currentUser}
      />

      {/* Campus Hostel Wings Modal */}
      <HostelWingsModal
        isOpen={isWingsOpen}
        onClose={() => setIsWingsOpen(false)}
      />

      {/* ON CAMPUS Ecosystem Pitch Deck & Interactive Presentation */}
      <PresentationModal
        isOpen={isPresentationOpen}
        onClose={() => setIsPresentationOpen(false)}
        onLaunchService={handleSelectService}
      />

      {/* Floating COMPASS Widget (Pink & White mixture with Chatbox Popup) */}
      <FloatingCompassWidget
        isOpen={isFloatingCompassOpen}
        onToggle={() => setIsFloatingCompassOpen(!isFloatingCompassOpen)}
        messages={compassMessages}
        onSendMessage={handleSendCompassMessage}
        isLoading={isCompassLoading}
        onSelectActionCard={handleSelectActionCard}
      />
    </div>
  );
}

export default App;

```

---

## File: `src/components/AppHeader.tsx`

```tsx
import React, { useState } from 'react';
import { 
  Search, 
  Plus, 
  Bell, 
  User, 
  ChevronDown, 
  Radio, 
  HandCoins, 
  ShoppingBag, 
  Layers3, 
  Repeat, 
  Trophy, 
  Compass, 
  FolderLock,
  Sparkles,
  ShieldCheck,
  CheckCircle2,
  X
} from 'lucide-react';
import { UserProfile } from '../types';

interface AppHeaderProps {
  activeTab: string;
  onSelectTab: (tab: string) => void;
  currentUser: UserProfile;
  users: UserProfile[];
  onSwitchUser: (user: UserProfile) => void;
  onOpenCommandPalette: () => void;
  onOpenCreatePost: () => void;
  onOpenCreateListing: () => void;
  onOpenCreateProject: () => void;
}

export const AppHeader: React.FC<AppHeaderProps> = ({
  activeTab,
  onSelectTab,
  currentUser,
  users,
  onSwitchUser,
  onOpenCommandPalette,
  onOpenCreatePost,
  onOpenCreateListing,
  onOpenCreateProject,
}) => {
  const [isActionsOpen, setIsActionsOpen] = useState(false);
  const [isUserDropdownOpen, setIsUserDropdownOpen] = useState(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);

  const notifications = [
    { id: 'n1', title: 'Borrow Request Confirmed', time: '10m ago', text: 'Aryan accepted your request for Casio fx-991EX.', unread: true },
    { id: 'n2', title: 'Project Team Invite', time: '1h ago', text: 'Autonomous Rover Lab invited you to join their firmware sprint.', unread: true },
    { id: 'n3', title: 'Reputation Level Up', time: '4h ago', text: 'You gained +50 Karma for sharing DSP lecture notes. Current Rank: #03.', unread: false },
  ];

  const tabs = [
    { id: 'pulse', label: 'Pulse', icon: Radio, highlight: '#00f2ff' },
    { id: 'borrow', label: 'Borrow & Lab', icon: HandCoins, highlight: '#00f2ff' },
    { id: 'marketplace', label: 'Marketplace', icon: ShoppingBag, highlight: '#00f2ff' },
    { id: 'projects', label: 'Projects', icon: Layers3, highlight: '#bc13fe' },
    { id: 'mentorship', label: 'Skill Swap & Guides', icon: Repeat, highlight: '#bc13fe' },
    { id: 'leaderboard', label: 'Leaderboard', icon: Trophy, highlight: '#00f2ff' },
    { id: 'compass', label: 'COMPASS AI', icon: Compass, highlight: '#00f2ff' },
    { id: 'locker', label: 'My Locker', icon: FolderLock, highlight: '#bc13fe' },
  ];

  return (
    <header className="sticky top-0 z-40 bg-[#050505]/95 backdrop-blur-md border-b border-white/[0.08]">
      {/* Top OS Meta Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-2.5 flex items-center justify-between border-b border-white/[0.04] text-[11px] font-mono-tech">
        <div className="flex items-center gap-3 text-white/60">
          <div className="flex items-center gap-1.5 text-[#00f2ff]">
            <span className="w-2 h-2 rounded-full bg-[#00f2ff] animate-ping" />
            <span className="font-bold tracking-[1px] uppercase">DTU NODE // LIVE</span>
          </div>
          <span className="text-white/20">|</span>
          <span className="hidden sm:inline text-white/40">FALL 2026 SEMESTER</span>
          <span className="text-white/20 hidden sm:inline">|</span>
          <span className="text-white/50">12,850 CONNECTED PEERS</span>
        </div>

        {/* User Karma Quick Badge */}
        <div className="flex items-center gap-3">
          <div
            onClick={() => onSelectTab('leaderboard')}
            className="flex items-center gap-2 px-2.5 py-1 rounded-sm bg-[#121212] border border-white/10 hover:border-[#00f2ff] transition-all cursor-pointer"
          >
            <span className="text-[10px] text-white/50 uppercase">RANK</span>
            <span className="text-[#00f2ff] font-bold">#{String(currentUser.rank).padStart(2, '0')}</span>
            <span className="text-white/20">•</span>
            <span className="text-white font-bold">{currentUser.impactScore} PTS</span>
          </div>
        </div>
      </div>

      {/* Main App Navigation Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 flex items-center justify-between gap-4">
        {/* Brand Logo */}
        <div 
          onClick={() => onSelectTab('pulse')} 
          className="flex items-center gap-2 cursor-pointer shrink-0"
        >
          <div className="w-8 h-8 rounded-sm bg-[#00f2ff] flex items-center justify-center text-black font-black text-xs font-mono-tech shadow-[0_0_15px_rgba(0,242,255,0.4)]">
            OC
          </div>
          <div>
            <div className="text-lg font-black text-white font-heading tracking-tight leading-none">
              ON CAMPUS
            </div>
            <div className="text-[9px] font-mono-tech text-[#00f2ff] tracking-[2px] uppercase mt-0.5">
              CAMPUS OS v3.2
            </div>
          </div>
        </div>

        {/* Global Search Bar Trigger (⌘K) */}
        <div 
          onClick={onOpenCommandPalette}
          className="hidden md:flex items-center gap-3 px-3.5 py-2 bg-[#121212] hover:bg-[#181818] border border-white/10 hover:border-[#00f2ff]/60 rounded-sm text-xs font-mono-tech text-white/50 transition-all cursor-pointer w-72 lg:w-96 shadow-inner"
        >
          <Search className="w-3.5 h-3.5 text-[#00f2ff]" />
          <span className="flex-1 truncate">Search inventory, projects, guides...</span>
          <kbd className="px-1.5 py-0.5 bg-[#050505] border border-white/10 rounded-sm text-[10px] text-white/60">
            ⌘K
          </kbd>
        </div>

        {/* Actions & User Controls */}
        <div className="flex items-center gap-3">
          {/* Quick Create Action Menu */}
          <div className="relative">
            <button
              id="header-quick-action-btn"
              onClick={() => setIsActionsOpen(!isActionsOpen)}
              className="px-3 py-2 bg-[#00f2ff] hover:bg-[#00f2ff]/80 text-black font-bold text-xs font-mono-tech uppercase tracking-[1px] rounded-sm transition-all cursor-pointer flex items-center gap-1.5 shadow-[0_0_15px_rgba(0,242,255,0.25)]"
            >
              <Plus className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">CREATE</span>
              <ChevronDown className="w-3 h-3" />
            </button>

            {isActionsOpen && (
              <div 
                className="absolute right-0 mt-2 w-56 bg-[#121212] border border-white/10 rounded-sm shadow-2xl py-1 z-50 font-mono-tech text-xs"
                onClick={() => setIsActionsOpen(false)}
              >
                <button
                  onClick={onOpenCreatePost}
                  className="w-full text-left px-4 py-2.5 hover:bg-[#00f2ff]/10 hover:text-[#00f2ff] text-white transition-colors flex items-center gap-2"
                >
                  <Radio className="w-3.5 h-3.5 text-[#00f2ff]" />
                  <span>Broadcast Pulse Post</span>
                </button>
                <button
                  onClick={onOpenCreateListing}
                  className="w-full text-left px-4 py-2.5 hover:bg-[#00f2ff]/10 hover:text-[#00f2ff] text-white transition-colors flex items-center gap-2"
                >
                  <ShoppingBag className="w-3.5 h-3.5 text-[#00f2ff]" />
                  <span>List Marketplace Item</span>
                </button>
                <button
                  onClick={onOpenCreateProject}
                  className="w-full text-left px-4 py-2.5 hover:bg-[#bc13fe]/10 hover:text-[#bc13fe] text-white transition-colors flex items-center gap-2"
                >
                  <Layers3 className="w-3.5 h-3.5 text-[#bc13fe]" />
                  <span>Publish Research Project</span>
                </button>
              </div>
            )}
          </div>

          {/* Notifications Trigger */}
          <div className="relative">
            <button
              id="header-notification-btn"
              onClick={() => setIsNotificationsOpen(!isNotificationsOpen)}
              className="p-2 bg-[#121212] hover:bg-white/5 border border-white/10 rounded-sm text-white/70 hover:text-white transition-colors relative cursor-pointer"
            >
              <Bell className="w-4 h-4" />
              <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-[#bc13fe] animate-pulse" />
            </button>

            {isNotificationsOpen && (
              <div 
                className="absolute right-0 mt-2 w-80 bg-[#121212] border border-white/10 rounded-sm shadow-2xl p-3 z-50 font-mono-tech space-y-2"
              >
                <div className="flex items-center justify-between pb-2 border-b border-white/[0.08] text-xs font-bold text-white">
                  <span>CAMPUS NOTIFICATIONS</span>
                  <button onClick={() => setIsNotificationsOpen(false)} className="text-white/40 hover:text-white">
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
                <div className="space-y-2 max-h-64 overflow-y-auto">
                  {notifications.map((n) => (
                    <div key={n.id} className="p-2.5 rounded-sm bg-[#050505] border border-white/5 space-y-1">
                      <div className="flex items-center justify-between text-xs font-bold text-white">
                        <span className="text-[#00f2ff]">{n.title}</span>
                        <span className="text-[10px] text-white/40">{n.time}</span>
                      </div>
                      <p className="text-[11px] text-white/70 leading-tight">{n.text}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* User Persona Switcher */}
          <div className="relative">
            <button
              id="header-user-btn"
              onClick={() => setIsUserDropdownOpen(!isUserDropdownOpen)}
              className="flex items-center gap-2 p-1.5 pl-2.5 bg-[#121212] hover:bg-white/5 border border-white/10 rounded-sm transition-all cursor-pointer"
            >
              <div className="text-left hidden sm:block">
                <div className="text-xs font-bold text-white font-heading leading-tight truncate max-w-[100px]">
                  {currentUser.name}
                </div>
                <div className="text-[9px] font-mono-tech text-white/40">
                  {currentUser.department}
                </div>
              </div>
              <div className="w-7 h-7 rounded-sm bg-[#050505] border border-[#00f2ff] flex items-center justify-center font-mono-tech text-xs font-bold text-[#00f2ff]">
                {currentUser.name.slice(0, 2).toUpperCase()}
              </div>
              <ChevronDown className="w-3 h-3 text-white/40" />
            </button>

            {isUserDropdownOpen && (
              <div 
                className="absolute right-0 mt-2 w-64 bg-[#121212] border border-white/10 rounded-sm shadow-2xl py-2 z-50 font-mono-tech"
                onClick={() => setIsUserDropdownOpen(false)}
              >
                <div className="px-3 pb-2 mb-2 border-b border-white/[0.08] text-[10px] text-white/40 uppercase">
                  SWITCH ACTIVE CAMPUS PERSONA
                </div>
                {users.map((u) => (
                  <button
                    key={u.id}
                    onClick={() => onSwitchUser(u)}
                    className={`w-full text-left px-3 py-2 text-xs flex items-center justify-between transition-colors ${
                      u.id === currentUser.id
                        ? 'bg-[#00f2ff]/10 text-[#00f2ff] font-bold'
                        : 'hover:bg-white/5 text-white/80'
                    }`}
                  >
                    <div>
                      <div>{u.name}</div>
                      <div className="text-[10px] text-white/40">{u.department} • #{String(u.rank).padStart(2, '0')}</div>
                    </div>
                    {u.id === currentUser.id && <CheckCircle2 className="w-3.5 h-3.5 text-[#00f2ff]" />}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Horizontal Workspace Navigation Tabs */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <nav className="flex items-center gap-1 overflow-x-auto py-1 scrollbar-none border-t border-white/[0.04]">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;

            return (
              <button
                key={tab.id}
                id={`tab-btn-${tab.id}`}
                onClick={() => onSelectTab(tab.id)}
                className={`flex items-center gap-2 px-3.5 py-2.5 text-xs font-mono-tech uppercase tracking-[1px] rounded-sm transition-all cursor-pointer whitespace-nowrap border-b-2 font-bold ${
                  isActive
                    ? 'border-[#00f2ff] text-[#00f2ff] bg-white/[0.03]'
                    : 'border-transparent text-white/60 hover:text-white hover:bg-white/[0.02]'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-[#00f2ff]' : 'text-white/40'}`} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </nav>
      </div>
    </header>
  );
};

```

---

## File: `src/components/AuthModal.tsx`

```tsx
import React, { useState, useEffect } from 'react';
import { UserProfile } from '../types';
import { 
  X, 
  ShieldCheck, 
  UserCheck, 
  Key, 
  Lock, 
  Globe,
  ArrowRight, 
  Edit3, 
  Check, 
  Sparkles, 
  Building2, 
  BookOpen, 
  GraduationCap, 
  Mail, 
  User, 
  Image as ImageIcon,
  LogIn,
  RefreshCw,
  Eye,
  EyeOff
} from 'lucide-react';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  users: UserProfile[];
  currentUser: UserProfile;
  onSelectUser?: (user: UserProfile) => void;
  onSwitchUser?: (user: UserProfile) => void;
  onUpdateUser?: (updatedUser: UserProfile) => void;
}

const AVATAR_PRESETS = [
  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80',
  'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&q=80',
  'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=400&q=80',
  'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=400&q=80',
  'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=400&q=80',
  'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=400&q=80',
];

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  users,
  currentUser,
  onSelectUser,
  onSwitchUser,
  onUpdateUser,
}) => {
  const switchFn = onSelectUser || onSwitchUser || (() => {});
  const updateFn = onUpdateUser || switchFn;

  const [activeTab, setActiveTab] = useState<'switch' | 'login' | 'edit'>('switch');

  // Login / SSO form state
  const [studentId, setStudentId] = useState('');
  const [eduEmail, setEduEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [department, setDepartment] = useState('Computer Science & AI');
  const [academicYear, setAcademicYear] = useState('Year 3');

  // Edit Profile form state (initialized from currentUser)
  const [editName, setEditName] = useState(currentUser?.name || '');
  const [editEmail, setEditEmail] = useState(currentUser?.contactEmail || currentUser?.email || '');
  const [editBio, setEditBio] = useState(currentUser?.bio || '');
  const [editDept, setEditDept] = useState(currentUser?.department || '');
  const [editYear, setEditYear] = useState(currentUser?.year || 'Year 3');
  const [editHostel, setEditHostel] = useState(currentUser?.hostelWing || 'North Block H4');
  const [editAvatar, setEditAvatar] = useState(currentUser?.avatar || AVATAR_PRESETS[0]);
  const [editIsPrivate, setEditIsPrivate] = useState<boolean>(!!currentUser?.isPrivate);
  const [editSkillsOffered, setEditSkillsOffered] = useState(
    currentUser?.skillsOffered ? currentUser.skillsOffered.join(', ') : 'Python, UI/UX, OpenCV'
  );
  const [editSkillsWanted, setEditSkillsWanted] = useState(
    currentUser?.skillsWanted ? currentUser.skillsWanted.join(', ') : 'Rust, Embedded Systems'
  );

  const [feedback, setFeedback] = useState<string | null>(null);
  const [saveSuccess, setSaveSuccess] = useState(false);

  // Sync edit form whenever currentUser changes or modal opens
  useEffect(() => {
    if (currentUser) {
      setEditName(currentUser.name);
      setEditEmail(currentUser.contactEmail || currentUser.email || '');
      setEditBio(currentUser.bio || '');
      setEditDept(currentUser.department || '');
      setEditYear(currentUser.year || 'Year 3');
      setEditHostel(currentUser.hostelWing || 'North Block H4');
      setEditAvatar(currentUser.avatar || AVATAR_PRESETS[0]);
      setEditIsPrivate(!!currentUser.isPrivate);
      setEditSkillsOffered(currentUser.skillsOffered ? currentUser.skillsOffered.join(', ') : '');
      setEditSkillsWanted(currentUser.skillsWanted ? currentUser.skillsWanted.join(', ') : '');
    }
  }, [currentUser, isOpen]);

  if (!isOpen) return null;

  const handleDemoSwitch = (u: UserProfile) => {
    switchFn(u);
    setSaveSuccess(true);
    setTimeout(() => {
      setSaveSuccess(false);
      onClose();
    }, 400);
  };

  const handleSSOLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!eduEmail.trim()) {
      setFeedback('Please enter a valid university student email.');
      return;
    }

    const userName = fullName.trim() || eduEmail.split('@')[0].toUpperCase();
    const existing = users.find(
      (u) => u.contactEmail?.toLowerCase() === eduEmail.toLowerCase() || u.name.toLowerCase() === userName.toLowerCase()
    );

    let loggedInUser: UserProfile;
    if (existing) {
      loggedInUser = {
        ...existing,
        verified: true,
      };
    } else {
      loggedInUser = {
        ...currentUser,
        id: `user-${Date.now()}`,
        name: userName,
        contactEmail: eduEmail,
        email: eduEmail,
        studentId: studentId.trim() || `2024CS${Math.floor(1000 + Math.random() * 9000)}`,
        department: department,
        year: academicYear,
        verified: true,
        isPrivate: false,
        verifiedHash: `0x${Math.random().toString(16).slice(2, 10).toUpperCase()}`,
        bio: `Student at ${department}, passionate about campus building and peer collaboration.`,
      };
    }

    updateFn(loggedInUser);
    setFeedback(null);
    setSaveSuccess(true);
    setTimeout(() => {
      setSaveSuccess(false);
      onClose();
    }, 700);
  };

  const handleSaveProfileChanges = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editName.trim()) {
      setFeedback('Name cannot be blank.');
      return;
    }

    const offeredArray = editSkillsOffered
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean);

    const wantedArray = editSkillsWanted
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean);

    const updatedUser: UserProfile = {
      ...currentUser,
      name: editName.trim(),
      contactEmail: editEmail.trim() || currentUser.contactEmail,
      email: editEmail.trim() || currentUser.email,
      bio: editBio.trim() || currentUser.bio,
      department: editDept.trim() || currentUser.department,
      year: editYear.trim() || currentUser.year,
      hostelWing: editHostel.trim() || currentUser.hostelWing,
      avatar: editAvatar || currentUser.avatar,
      isPrivate: editIsPrivate,
      skillsOffered: offeredArray.length > 0 ? offeredArray : currentUser.skillsOffered,
      skillsWanted: wantedArray.length > 0 ? wantedArray : currentUser.skillsWanted,
      initials: editName.trim().slice(0, 2).toUpperCase(),
    };

    updateFn(updatedUser);
    setFeedback(null);
    setSaveSuccess(true);
    setTimeout(() => {
      setSaveSuccess(false);
      onClose();
    }, 800);
  };

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-xl animate-in fade-in duration-200"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div 
        id="auth-profile-modal-card"
        className="relative w-full max-w-xl bg-[#090b10] border border-white/20 rounded-3xl p-6 sm:p-8 shadow-[0_0_60px_rgba(0,242,255,0.2)] flex flex-col max-h-[92vh] overflow-hidden text-white"
      >
        {/* Modal Close Button */}
        <button
          onClick={onClose}
          aria-label="Close"
          className="absolute top-5 right-5 p-2 rounded-full bg-white/10 hover:bg-white/20 text-white/70 hover:text-white transition-all cursor-pointer border border-white/10 z-20"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3.5 mb-6">
          <div className="w-11 h-11 rounded-2xl bg-[#00f2ff]/10 border border-[#00f2ff]/30 flex items-center justify-center text-[#00f2ff] shrink-0">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl sm:text-2xl font-black text-white font-heading">
              CAMPUS ID & PROFILE
            </h2>
            <p className="text-xs font-mono-tech text-[#00f2ff]">
              Verified university access • Edit details & switch personas
            </p>
          </div>
        </div>

        {/* Tabs Bar */}
        <div className="flex gap-1.5 border-b border-white/[0.08] pb-3 mb-6 overflow-x-auto scrollbar-none">
          <button
            onClick={() => {
              setActiveTab('switch');
              setFeedback(null);
            }}
            className={`px-3.5 py-2 text-xs font-mono-tech tracking-wider rounded-xl transition-all cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'switch'
                ? 'bg-[#00f2ff]/20 border border-[#00f2ff] text-[#00f2ff] font-bold shadow-[0_0_15px_rgba(0,242,255,0.2)]'
                : 'text-zinc-400 hover:text-white hover:bg-white/5 border border-transparent'
            }`}
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>SWITCH PERSONA</span>
          </button>

          <button
            onClick={() => {
              setActiveTab('edit');
              setFeedback(null);
            }}
            className={`px-3.5 py-2 text-xs font-mono-tech tracking-wider rounded-xl transition-all cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'edit'
                ? 'bg-[#00f2ff]/20 border border-[#00f2ff] text-[#00f2ff] font-bold shadow-[0_0_15px_rgba(0,242,255,0.2)]'
                : 'text-zinc-400 hover:text-white hover:bg-white/5 border border-transparent'
            }`}
          >
            <Edit3 className="w-3.5 h-3.5" />
            <span>EDIT MY PROFILE</span>
          </button>

          <button
            onClick={() => {
              setActiveTab('login');
              setFeedback(null);
            }}
            className={`px-3.5 py-2 text-xs font-mono-tech tracking-wider rounded-xl transition-all cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'login'
                ? 'bg-[#00f2ff]/20 border border-[#00f2ff] text-[#00f2ff] font-bold shadow-[0_0_15px_rgba(0,242,255,0.2)]'
                : 'text-zinc-400 hover:text-white hover:bg-white/5 border border-transparent'
            }`}
          >
            <LogIn className="w-3.5 h-3.5" />
            <span>STUDENT SSO LOGIN</span>
          </button>
        </div>

        {/* Success Toast Banner */}
        {saveSuccess && (
          <div className="mb-4 p-3 rounded-xl bg-emerald-950/80 border border-emerald-400/50 text-emerald-300 text-xs font-mono-tech flex items-center gap-2 animate-in fade-in">
            <Check className="w-4 h-4 text-emerald-400" />
            <span>Profile & authentication state updated successfully!</span>
          </div>
        )}

        {/* Error Feedback */}
        {feedback && (
          <div className="mb-4 p-3 rounded-xl bg-red-950/80 border border-red-400/50 text-red-300 text-xs font-mono-tech">
            {feedback}
          </div>
        )}

        {/* Scrollable Tab Content Container */}
        <div className="overflow-y-auto custom-scrollbar flex-1 pr-1 space-y-4">
          
          {/* ========================================================================= */}
          {/* TAB 1: SWITCH DEMO PERSONA */}
          {/* ========================================================================= */}
          {activeTab === 'switch' && (
            <div className="space-y-3">
              <div className="text-xs font-mono-tech text-white/60">
                Select any verified student profile to experience their permissions, impact rank, and badges:
              </div>

              <div className="space-y-2">
                {users.map((u) => {
                  const isCurrent = currentUser?.id === u.id;
                  return (
                    <div
                      key={u.id}
                      onClick={() => handleDemoSwitch(u)}
                      className={`p-3.5 rounded-2xl border flex items-center justify-between cursor-pointer transition-all duration-200 ${
                        isCurrent
                          ? 'bg-[#00f2ff]/10 border-[#00f2ff] text-white shadow-[0_0_20px_rgba(0,242,255,0.15)]'
                          : 'bg-[#12141f] border-white/[0.08] hover:border-white/25 hover:bg-[#181a28]'
                      }`}
                    >
                      <div className="flex items-center gap-3.5">
                        <div className="relative">
                          <img
                            src={u.avatar}
                            alt={u.name}
                            className="w-11 h-11 rounded-xl object-cover border border-white/20"
                          />
                          {isCurrent && (
                            <span className="absolute -top-1 -right-1 w-3 h-3 rounded-full bg-[#00f2ff] border-2 border-black" />
                          )}
                        </div>

                        <div>
                          <div className="text-sm font-bold text-white flex items-center gap-2 flex-wrap">
                            <span>{u.name}</span>
                            <span className="text-[10px] font-mono-tech text-[#00f2ff] px-1.5 py-0.5 rounded bg-[#00f2ff]/10 border border-[#00f2ff]/30">
                              {u.title}
                            </span>
                            {u.isPrivate ? (
                              <span className="text-[9px] font-mono-tech text-amber-300 px-1.5 py-0.2 rounded bg-amber-500/10 border border-amber-500/30 flex items-center gap-1">
                                <Lock className="w-2.5 h-2.5" /> Private
                              </span>
                            ) : (
                              <span className="text-[9px] font-mono-tech text-emerald-300 px-1.5 py-0.2 rounded bg-emerald-500/10 border border-emerald-500/30 flex items-center gap-1">
                                <Globe className="w-2.5 h-2.5" /> Public
                              </span>
                            )}
                          </div>
                          <div className="text-xs font-mono-tech text-white/50 mt-0.5">
                            {u.department} • <span className="text-white/70">Rank #{u.rank}</span>
                          </div>
                        </div>
                      </div>

                      <div className="text-right font-mono-tech">
                        <div className="text-sm font-bold text-white">{u.impactScore}</div>
                        <div className="text-[9px] text-[#00f2ff] uppercase">IMPACT PTS</div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* ========================================================================= */}
          {/* TAB 2: EDIT PROFILE DETAILS */}
          {/* ========================================================================= */}
          {activeTab === 'edit' && (
            <form onSubmit={handleSaveProfileChanges} className="space-y-4">
              <div className="text-xs font-mono-tech text-[#00f2ff] uppercase tracking-wider font-bold">
                EDIT YOUR ON-CAMPUS IDENTITY
              </div>

              {/* Public vs Private Profile Selection */}
              <div>
                <label className="block text-xs font-mono-tech text-white/70 mb-2">
                  PROFILE PRIVACY & MESSAGING PERMISSIONS *
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div
                    onClick={() => setEditIsPrivate(false)}
                    className={`p-3.5 rounded-2xl border cursor-pointer transition-all ${
                      !editIsPrivate
                        ? 'bg-emerald-500/15 border-emerald-400 shadow-[0_0_15px_rgba(16,185,129,0.2)]'
                        : 'bg-[#12141f] border-white/10 hover:border-white/20'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <div className="flex items-center gap-2 text-xs font-bold text-emerald-300 font-mono-tech">
                        <Globe className="w-4 h-4" />
                        <span>Public Profile</span>
                      </div>
                      {!editIsPrivate && <Check className="w-4 h-4 text-emerald-400" />}
                    </div>
                    <p className="text-[11px] text-white/60 font-sans leading-relaxed">
                      Anyone on campus can send you direct messages right away without sending a friend request.
                    </p>
                  </div>

                  <div
                    onClick={() => setEditIsPrivate(true)}
                    className={`p-3.5 rounded-2xl border cursor-pointer transition-all ${
                      editIsPrivate
                        ? 'bg-amber-500/15 border-amber-400 shadow-[0_0_15px_rgba(245,158,11,0.2)]'
                        : 'bg-[#12141f] border-white/10 hover:border-white/20'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <div className="flex items-center gap-2 text-xs font-bold text-amber-300 font-mono-tech">
                        <Lock className="w-4 h-4" />
                        <span>Private Profile</span>
                      </div>
                      {editIsPrivate && <Check className="w-4 h-4 text-amber-400" />}
                    </div>
                    <p className="text-[11px] text-white/60 font-sans leading-relaxed">
                      Requires students to send you a <strong>Friend Request</strong> and receive your approval before they can message you.
                    </p>
                  </div>
                </div>
              </div>

              {/* Avatar Selector */}
              <div>
                <label className="block text-xs font-mono-tech text-white/70 mb-2">
                  CHOOSE AVATAR PRESET OR ENTER URL
                </label>
                <div className="flex items-center gap-2.5 mb-2 overflow-x-auto pb-1">
                  {AVATAR_PRESETS.map((preset, i) => (
                    <img
                      key={i}
                      src={preset}
                      alt={`Avatar ${i}`}
                      onClick={() => setEditAvatar(preset)}
                      className={`w-10 h-10 rounded-xl object-cover cursor-pointer border-2 transition-all shrink-0 ${
                        editAvatar === preset ? 'border-[#00f2ff] scale-105 shadow-[0_0_10px_rgba(0,242,255,0.4)]' : 'border-white/10 opacity-60 hover:opacity-100'
                      }`}
                    />
                  ))}
                </div>
                <input
                  type="url"
                  value={editAvatar}
                  onChange={(e) => setEditAvatar(e.target.value)}
                  placeholder="Custom avatar image URL..."
                  className="w-full px-3.5 py-2 bg-[#12141f] border border-white/10 rounded-xl text-xs text-white focus:outline-none focus:border-[#00f2ff] font-mono-tech"
                />
              </div>

              {/* Name & Email */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-mono-tech text-white/70 mb-1">
                    FULL NAME *
                  </label>
                  <input
                    type="text"
                    value={editName}
                    onChange={(e) => setEditName(e.target.value)}
                    required
                    placeholder="e.g. Yuvraj Sen"
                    className="w-full px-3.5 py-2.5 bg-[#12141f] border border-white/10 rounded-xl text-xs sm:text-sm text-white focus:outline-none focus:border-[#00f2ff] font-mono-tech"
                  />
                </div>

                <div>
                  <label className="block text-xs font-mono-tech text-white/70 mb-1">
                    CAMPUS / CONTACT EMAIL
                  </label>
                  <input
                    type="email"
                    value={editEmail}
                    onChange={(e) => setEditEmail(e.target.value)}
                    placeholder="student@university.edu"
                    className="w-full px-3.5 py-2.5 bg-[#12141f] border border-white/10 rounded-xl text-xs sm:text-sm text-white focus:outline-none focus:border-[#00f2ff] font-mono-tech"
                  />
                </div>
              </div>

              {/* Department, Year & Hostel */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-mono-tech text-white/70 mb-1">
                    DEPARTMENT
                  </label>
                  <input
                    type="text"
                    value={editDept}
                    onChange={(e) => setEditDept(e.target.value)}
                    placeholder="e.g. Mechanical Eng."
                    className="w-full px-3 py-2.5 bg-[#12141f] border border-white/10 rounded-xl text-xs text-white focus:outline-none focus:border-[#00f2ff] font-mono-tech"
                  />
                </div>

                <div>
                  <label className="block text-xs font-mono-tech text-white/70 mb-1">
                    ACADEMIC YEAR
                  </label>
                  <select
                    value={editYear}
                    onChange={(e) => setEditYear(e.target.value)}
                    className="w-full px-3 py-2.5 bg-[#12141f] border border-white/10 rounded-xl text-xs text-white focus:outline-none focus:border-[#00f2ff] font-mono-tech cursor-pointer"
                  >
                    <option value="Year 1" className="bg-[#12141f]">Year 1 (Freshman)</option>
                    <option value="Year 2" className="bg-[#12141f]">Year 2 (Sophomore)</option>
                    <option value="Year 3" className="bg-[#12141f]">Year 3 (Junior)</option>
                    <option value="Year 4" className="bg-[#12141f]">Year 4 (Senior)</option>
                    <option value="Postgrad / PhD" className="bg-[#12141f]">Postgrad / PhD</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-mono-tech text-white/70 mb-1">
                    HOSTEL WING
                  </label>
                  <input
                    type="text"
                    value={editHostel}
                    onChange={(e) => setEditHostel(e.target.value)}
                    placeholder="e.g. North Block H4"
                    className="w-full px-3 py-2.5 bg-[#12141f] border border-white/10 rounded-xl text-xs text-white focus:outline-none focus:border-[#00f2ff] font-mono-tech"
                  />
                </div>
              </div>

              {/* Bio */}
              <div>
                <label className="block text-xs font-mono-tech text-white/70 mb-1">
                  BIO / STATUS PHRASE
                </label>
                <textarea
                  value={editBio}
                  onChange={(e) => setEditBio(e.target.value)}
                  rows={2}
                  placeholder="Tell peers what you are building or studying..."
                  className="w-full px-3.5 py-2 bg-[#12141f] border border-white/10 rounded-xl text-xs sm:text-sm text-white focus:outline-none focus:border-[#00f2ff] font-mono-tech"
                />
              </div>

              {/* Skills Offered & Wanted */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-mono-tech text-white/70 mb-1">
                    SKILLS I CAN TEACH (COMMA-SEPARATED)
                  </label>
                  <input
                    type="text"
                    value={editSkillsOffered}
                    onChange={(e) => setEditSkillsOffered(e.target.value)}
                    placeholder="e.g. Figma, React, Python"
                    className="w-full px-3.5 py-2.5 bg-[#12141f] border border-white/10 rounded-xl text-xs text-white focus:outline-none focus:border-[#00f2ff] font-mono-tech"
                  />
                </div>

                <div>
                  <label className="block text-xs font-mono-tech text-white/70 mb-1">
                    SKILLS I WANT TO LEARN
                  </label>
                  <input
                    type="text"
                    value={editSkillsWanted}
                    onChange={(e) => setEditSkillsWanted(e.target.value)}
                    placeholder="e.g. Rust, CAD, ROS 2"
                    className="w-full px-3.5 py-2.5 bg-[#12141f] border border-white/10 rounded-xl text-xs text-white focus:outline-none focus:border-[#00f2ff] font-mono-tech"
                  />
                </div>
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                id="save-profile-btn"
                className="w-full py-3.5 bg-[#00f2ff] hover:bg-[#38f6ff] text-black font-bold text-xs sm:text-sm font-mono-tech tracking-wider uppercase rounded-xl transition-all cursor-pointer shadow-[0_0_20px_rgba(0,242,255,0.3)] flex items-center justify-center gap-2"
              >
                <Check className="w-4 h-4" />
                <span>Save Profile Changes</span>
              </button>
            </form>
          )}

          {/* ========================================================================= */}
          {/* TAB 3: STUDENT SSO LOGIN */}
          {/* ========================================================================= */}
          {activeTab === 'login' && (
            <form onSubmit={handleSSOLogin} className="space-y-4">
              <div className="text-xs font-mono-tech text-white/60">
                Log in with your official university credentials or student roll number:
              </div>

              <div>
                <label className="block text-xs font-mono-tech text-white/70 mb-1">
                  FULL NAME (OPTIONAL)
                </label>
                <input
                  type="text"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="e.g. Jyoti Singla"
                  className="w-full px-3.5 py-2.5 bg-[#12141f] border border-white/10 rounded-xl text-xs sm:text-sm text-white focus:outline-none focus:border-[#00f2ff] font-mono-tech"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-mono-tech text-white/70 mb-1">
                    STUDENT ROLL / ID NO.
                  </label>
                  <input
                    type="text"
                    value={studentId}
                    onChange={(e) => setStudentId(e.target.value)}
                    placeholder="2024CS0891"
                    className="w-full px-3.5 py-2.5 bg-[#12141f] border border-white/10 rounded-xl text-xs sm:text-sm text-white focus:outline-none focus:border-[#00f2ff] font-mono-tech"
                  />
                </div>

                <div>
                  <label className="block text-xs font-mono-tech text-white/70 mb-1">
                    CAMPUS EMAIL (.EDU) *
                  </label>
                  <input
                    type="email"
                    value={eduEmail}
                    onChange={(e) => setEduEmail(e.target.value)}
                    required
                    placeholder="student@campus.edu"
                    className="w-full px-3.5 py-2.5 bg-[#12141f] border border-white/10 rounded-xl text-xs sm:text-sm text-white focus:outline-none focus:border-[#00f2ff] font-mono-tech"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-mono-tech text-white/70 mb-1">
                    DEPARTMENT
                  </label>
                  <input
                    type="text"
                    value={department}
                    onChange={(e) => setDepartment(e.target.value)}
                    placeholder="Computer Science"
                    className="w-full px-3.5 py-2.5 bg-[#12141f] border border-white/10 rounded-xl text-xs text-white focus:outline-none focus:border-[#00f2ff] font-mono-tech"
                  />
                </div>

                <div>
                  <label className="block text-xs font-mono-tech text-white/70 mb-1">
                    PASSWORD
                  </label>
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••••••"
                    className="w-full px-3.5 py-2.5 bg-[#12141f] border border-white/10 rounded-xl text-xs text-white focus:outline-none focus:border-[#00f2ff] font-mono-tech"
                  />
                </div>
              </div>

              <button
                type="submit"
                id="sso-signin-btn"
                className="w-full py-3.5 bg-[#00f2ff] hover:bg-[#38f6ff] text-black font-bold text-xs sm:text-sm font-mono-tech tracking-wider uppercase rounded-xl transition-all cursor-pointer shadow-[0_0_20px_rgba(0,242,255,0.3)] flex items-center justify-center gap-2"
              >
                <LogIn className="w-4 h-4" />
                <span>Verify & Sign In</span>
              </button>
            </form>
          )}

        </div>
      </div>
    </div>
  );
};

```

---

## File: `src/components/BorrowModal.tsx`

```tsx
import React, { useState } from 'react';
import { BorrowItem } from '../types';
import { 
  X, 
  HandCoins, 
  MapPin, 
  ShieldCheck, 
  Clock, 
  Plus, 
  CheckCircle,
  AlertCircle
} from 'lucide-react';

interface BorrowModalProps {
  isOpen: boolean;
  onClose: () => void;
  items: BorrowItem[];
  onRequestBorrow: (itemId: string, durationDays: number) => void;
  onAddBorrowItem: (item: Omit<BorrowItem, 'id' | 'available'>) => void;
  onRequestCustomItem?: (itemTitle: string, category: string, neededBy: string, notes: string) => void;
}

export const BorrowModal: React.FC<BorrowModalProps> = ({
  isOpen,
  onClose,
  items,
  onRequestBorrow,
  onAddBorrowItem,
  onRequestCustomItem,
}) => {
  const [activeTab, setActiveTab] = useState<'browse' | 'lend' | 'request'>('browse');
  const [selectedItemId, setSelectedItemId] = useState<string | null>(null);
  const [borrowDays, setBorrowDays] = useState<number>(3);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Lend Form
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<BorrowItem['category']>('Electronics');
  const [location, setLocation] = useState('');
  const [maxDays, setMaxDays] = useState(7);
  const [depositRequired, setDepositRequired] = useState('Campus ID');
  const [description, setDescription] = useState('');

  // Request an Item Form
  const [reqTitle, setReqTitle] = useState('');
  const [reqCategory, setReqCategory] = useState<BorrowItem['category']>('Calculators');
  const [reqNeededBy, setReqNeededBy] = useState('Today, by 5 PM');
  const [reqUrgency, setReqUrgency] = useState<'Standard' | 'Urgent (Exam/Lab)'>('Standard');
  const [reqNotes, setReqNotes] = useState('');

  // Community requested items state
  const [communityRequests, setCommunityRequests] = useState([
    { id: 'cr-1', title: 'Casio Scientific Calculator FX-991CW', category: 'Calculators', requester: 'Priya K. (3rd Year ECE)', neededBy: 'Tomorrow morning (Exam)', urgency: 'Urgent (Exam/Lab)', offersCount: 2 },
    { id: 'cr-2', title: 'Soldering Iron & Solder Wire (60W)', category: 'Tools', requester: 'Rohan D. (2nd Year Mechatronics)', neededBy: 'Friday 4 PM', urgency: 'Standard', offersCount: 1 },
    { id: 'cr-3', title: 'USB-C to HDMI Multi-Port Hub', category: 'Electronics', requester: 'Aman V. (4th Year CSE)', neededBy: 'Tonight 8 PM', urgency: 'Standard', offersCount: 3 },
  ]);

  if (!isOpen) return null;

  const handleBorrowSubmit = (id: string) => {
    onRequestBorrow(id, borrowDays);
    setSuccessMsg('Borrow request sent to peer! You will receive a pickup passcode once confirmed.');
    setTimeout(() => {
      setSuccessMsg(null);
      setSelectedItemId(null);
    }, 2500);
  };

  const handleLendSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !location) return;

    onAddBorrowItem({
      title,
      category,
      location,
      ownerName: 'You (Verified Student)',
      ownerVerified: true,
      maxDays,
      depositRequired,
      description,
    });

    setSuccessMsg('Your item was added to the ON CAMPUS Borrow Inventory! +40 Impact points awarded.');
    setTitle('');
    setLocation('');
    setDescription('');
    setTimeout(() => {
      setSuccessMsg(null);
      setActiveTab('browse');
    }, 2000);
  };

  const handleCustomRequestSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reqTitle.trim()) return;

    if (onRequestCustomItem) {
      onRequestCustomItem(reqTitle, reqCategory, reqNeededBy, reqNotes);
    }

    // Add to local community requests
    const newReq = {
      id: `cr-${Date.now()}`,
      title: reqTitle,
      category: reqCategory,
      requester: 'You (Verified Student)',
      neededBy: reqNeededBy,
      urgency: reqUrgency,
      offersCount: 0,
    };
    setCommunityRequests([newReq, ...communityRequests]);

    setSuccessMsg(`Your request for "${reqTitle}" was broadcast to all students nearby! Peers will be notified.`);
    setReqTitle('');
    setReqNotes('');
    setTimeout(() => {
      setSuccessMsg(null);
    }, 3000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
      <div className="relative w-full max-w-3xl bg-[#090C12] border border-cyan-400/40 rounded-2xl p-6 sm:p-8 max-h-[90vh] overflow-y-auto shadow-2xl">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-lg bg-zinc-900 border border-white/10 text-zinc-400 hover:text-white transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-xl bg-cyan-950/60 border border-cyan-400/40 flex items-center justify-center text-cyan-300">
            <HandCoins className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-white font-heading">
              01 // CAMPUS BORROW INVENTORY
            </h2>
            <p className="text-xs font-mono-tech text-cyan-400">
              Don't buy what you can borrow. Free peer-to-peer resource sharing & item requests.
            </p>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex flex-wrap gap-2 border-b border-white/[0.08] pb-4 mb-6">
          <button
            onClick={() => setActiveTab('browse')}
            className={`px-4 py-2 text-xs font-mono-tech tracking-wider rounded transition-all cursor-pointer ${
              activeTab === 'browse'
                ? 'bg-cyan-950/80 border border-cyan-400/60 text-cyan-300 font-bold'
                : 'text-zinc-400 hover:text-white'
            }`}
          >
            AVAILABLE ITEMS ({items.length})
          </button>
          <button
            onClick={() => setActiveTab('request')}
            className={`px-4 py-2 text-xs font-mono-tech tracking-wider rounded transition-all cursor-pointer ${
              activeTab === 'request'
                ? 'bg-gradient-to-r from-cyan-950 to-blue-950 border border-cyan-400 text-cyan-200 font-bold shadow-[0_0_15px_rgba(0,242,255,0.2)]'
                : 'text-zinc-400 hover:text-white'
            }`}
          >
            + REQUEST AN ITEM (BROADCAST)
          </button>
          <button
            onClick={() => setActiveTab('lend')}
            className={`px-4 py-2 text-xs font-mono-tech tracking-wider rounded transition-all cursor-pointer ${
              activeTab === 'lend'
                ? 'bg-cyan-950/80 border border-cyan-400/60 text-cyan-300 font-bold'
                : 'text-zinc-400 hover:text-white'
            }`}
          >
            + LEND AN ITEM (+40 IMPACT)
          </button>
        </div>

        {successMsg && (
          <div className="mb-6 p-4 rounded-xl bg-emerald-950/60 border border-emerald-400/40 text-emerald-300 text-xs sm:text-sm font-mono-tech flex items-center gap-2">
            <CheckCircle className="w-4 h-4 shrink-0" />
            <span>{successMsg}</span>
          </div>
        )}

        {/* Tab 1: Browse Items */}
        {activeTab === 'browse' && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {items.map((item) => (
              <div
                key={item.id}
                className="p-4 rounded-xl bg-zinc-950/80 border border-white/[0.08] hover:border-cyan-400/50 transition-all flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between text-[10px] font-mono-tech text-cyan-400 mb-2">
                    <span>{item.category}</span>
                    <span className="px-2 py-0.5 rounded bg-cyan-950/60 border border-cyan-400/20 text-cyan-300">
                      MAX {item.maxDays} DAYS
                    </span>
                  </div>

                  <h3 className="text-base font-bold text-white font-heading mb-1.5">
                    {item.title}
                  </h3>
                  <p className="text-xs text-zinc-400 leading-relaxed mb-3">
                    {item.description}
                  </p>

                  <div className="space-y-1 text-xs font-mono-tech text-zinc-300">
                    <div className="flex items-center gap-1.5">
                      <MapPin className="w-3.5 h-3.5 text-cyan-400" />
                      <span>{item.location}</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <ShieldCheck className="w-3.5 h-3.5 text-cyan-400" />
                      <span>Lender: {item.ownerName}</span>
                    </div>
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-white/[0.06] flex items-center justify-between">
                  <span className="text-[10px] font-mono-tech text-zinc-400">
                    Deposit: {item.depositRequired}
                  </span>

                  <button
                    onClick={() => handleBorrowSubmit(item.id)}
                    className="px-3 py-1.5 bg-cyan-400 hover:bg-cyan-300 text-black text-xs font-mono-tech font-semibold rounded transition-all cursor-pointer"
                  >
                    REQUEST BORROW
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Tab 2: Request an Item (Broadcast to Peers) */}
        {activeTab === 'request' && (
          <div className="space-y-6">
            <form onSubmit={handleCustomRequestSubmit} className="p-5 rounded-xl bg-zinc-950/90 border border-cyan-400/30 space-y-4">
              <div className="flex items-center gap-2 pb-2 border-b border-white/[0.08]">
                <Plus className="w-4 h-4 text-cyan-400" />
                <span className="text-xs font-mono-tech text-cyan-300 font-bold uppercase tracking-wider">
                  Post a Request to the Campus Network
                </span>
              </div>

              <div>
                <label className="block text-xs font-mono-tech text-zinc-300 mb-1">
                  ITEM YOU NEED TO BORROW *
                </label>
                <input
                  type="text"
                  value={reqTitle}
                  onChange={(e) => setReqTitle(e.target.value)}
                  placeholder="e.g. Graphic Tablet, Lab Coat (Size L), TI-84 Plus, or Arduino Uno"
                  required
                  className="w-full px-3.5 py-2.5 bg-zinc-900 border border-white/10 rounded text-sm text-white focus:outline-none focus:border-cyan-400 font-mono-tech"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-mono-tech text-zinc-300 mb-1">
                    CATEGORY
                  </label>
                  <select
                    value={reqCategory}
                    onChange={(e) => setReqCategory(e.target.value as any)}
                    className="w-full px-3 py-2 bg-zinc-900 border border-white/10 rounded text-xs sm:text-sm text-white focus:outline-none focus:border-cyan-400 font-mono-tech"
                  >
                    <option value="Calculators">Calculators</option>
                    <option value="Electronics">Electronics</option>
                    <option value="Lab Gear">Lab Gear</option>
                    <option value="Tools">Tools</option>
                    <option value="Project Parts">Project Parts</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-mono-tech text-zinc-300 mb-1">
                    NEEDED BY
                  </label>
                  <input
                    type="text"
                    value={reqNeededBy}
                    onChange={(e) => setReqNeededBy(e.target.value)}
                    placeholder="e.g. Today by 4 PM"
                    required
                    className="w-full px-3 py-2 bg-zinc-900 border border-white/10 rounded text-xs sm:text-sm text-white focus:outline-none focus:border-cyan-400 font-mono-tech"
                  />
                </div>

                <div>
                  <label className="block text-xs font-mono-tech text-zinc-300 mb-1">
                    URGENCY
                  </label>
                  <select
                    value={reqUrgency}
                    onChange={(e) => setReqUrgency(e.target.value as any)}
                    className="w-full px-3 py-2 bg-zinc-900 border border-white/10 rounded text-xs sm:text-sm text-white focus:outline-none focus:border-cyan-400 font-mono-tech"
                  >
                    <option value="Standard">Standard (Within 24h)</option>
                    <option value="Urgent (Exam/Lab)">🔥 Urgent (Exam/Lab)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-mono-tech text-zinc-300 mb-1">
                  SPECIFIC REQUIREMENTS / NOTES (OPTIONAL)
                </label>
                <textarea
                  value={reqNotes}
                  onChange={(e) => setReqNotes(e.target.value)}
                  placeholder="Need it for 3 hours for the Midterm Exam in Room 204. Will return immediately with Campus ID deposit."
                  rows={2}
                  className="w-full px-3 py-2 bg-zinc-900 border border-white/10 rounded text-xs sm:text-sm text-white focus:outline-none focus:border-cyan-400 font-mono-tech"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-black font-bold text-xs font-mono-tech tracking-wider uppercase rounded transition-all cursor-pointer shadow-[0_0_20px_rgba(0,242,255,0.3)]"
              >
                BROADCAST ITEM REQUEST TO CAMPUS
              </button>
            </form>

            {/* Active Community Requests Feed */}
            <div>
              <div className="flex items-center justify-between text-xs font-mono-tech text-cyan-400 mb-3 font-bold uppercase">
                <span>RECENT STUDENT ITEM REQUESTS ({communityRequests.length})</span>
                <span className="text-zinc-400 text-[11px] font-normal">Can you lend any of these?</span>
              </div>

              <div className="space-y-3">
                {communityRequests.map((req) => (
                  <div
                    key={req.id}
                    className="p-4 rounded-xl bg-zinc-950/60 border border-white/[0.08] hover:border-cyan-400/40 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3"
                  >
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="px-2 py-0.5 rounded bg-cyan-950/70 border border-cyan-400/20 text-[10px] font-mono-tech text-cyan-300">
                          {req.category}
                        </span>
                        {req.urgency.includes('Urgent') && (
                          <span className="px-2 py-0.5 rounded bg-rose-950/70 border border-rose-400/30 text-[10px] font-mono-tech text-rose-300 font-bold">
                            {req.urgency}
                          </span>
                        )}
                        <span className="text-xs text-zinc-400 font-mono-tech">
                          Needed: <strong className="text-zinc-200">{req.neededBy}</strong>
                        </span>
                      </div>
                      <h4 className="text-sm font-bold text-white font-heading">
                        {req.title}
                      </h4>
                      <p className="text-xs text-zinc-400 font-mono-tech">
                        Requested by {req.requester}
                      </p>
                    </div>

                    <button
                      onClick={() => {
                        setSuccessMsg(`You offered to lend "${req.title}"! We notified ${req.requester}.`);
                        setTimeout(() => setSuccessMsg(null), 3000);
                      }}
                      className="px-3.5 py-1.5 bg-white/[0.08] hover:bg-cyan-400 hover:text-black text-cyan-300 border border-cyan-400/40 text-xs font-mono-tech font-semibold rounded transition-all cursor-pointer shrink-0"
                    >
                      I CAN LEND THIS (+35 IMPACT)
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Tab 3: Lend an Item Form */}
        {activeTab === 'lend' && (
          <form onSubmit={handleLendSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-mono-tech text-zinc-300 mb-1">
                ITEM NAME
              </label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g. Texas Instruments TI-84 Plus or Arduino Uno Kit"
                required
                className="w-full px-3 py-2 bg-zinc-950 border border-white/10 rounded text-sm text-white focus:outline-none focus:border-cyan-400 font-mono-tech"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-mono-tech text-zinc-300 mb-1">
                  CATEGORY
                </label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value as any)}
                  className="w-full px-3 py-2 bg-zinc-950 border border-white/10 rounded text-sm text-white focus:outline-none focus:border-cyan-400 font-mono-tech"
                >
                  <option value="Electronics">Electronics</option>
                  <option value="Lab Gear">Lab Gear</option>
                  <option value="Calculators">Calculators</option>
                  <option value="Tools">Tools</option>
                  <option value="Project Parts">Project Parts</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-mono-tech text-zinc-300 mb-1">
                  PICKUP LOCATION ON CAMPUS
                </label>
                <input
                  type="text"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  placeholder="e.g. Hostel C, Room 304 or Makerspace"
                  required
                  className="w-full px-3 py-2 bg-zinc-950 border border-white/10 rounded text-sm text-white focus:outline-none focus:border-cyan-400 font-mono-tech"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-mono-tech text-zinc-300 mb-1">
                  MAX BORROW DURATION (DAYS)
                </label>
                <input
                  type="number"
                  min="1"
                  max="30"
                  value={maxDays}
                  onChange={(e) => setMaxDays(Number(e.target.value))}
                  className="w-full px-3 py-2 bg-zinc-950 border border-white/10 rounded text-sm text-white focus:outline-none focus:border-cyan-400 font-mono-tech"
                />
              </div>

              <div>
                <label className="block text-xs font-mono-tech text-zinc-300 mb-1">
                  DEPOSIT / TRUST REQUIREMENT
                </label>
                <input
                  type="text"
                  value={depositRequired}
                  onChange={(e) => setDepositRequired(e.target.value)}
                  placeholder="e.g. Campus ID card or None"
                  className="w-full px-3 py-2 bg-zinc-950 border border-white/10 rounded text-sm text-white focus:outline-none focus:border-cyan-400 font-mono-tech"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-mono-tech text-zinc-300 mb-1">
                DESCRIPTION & USAGE RULES
              </label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Include cables/batteries provided, return conditions, or specific cautions."
                rows={3}
                className="w-full px-3 py-2 bg-zinc-950 border border-white/10 rounded text-sm text-white focus:outline-none focus:border-cyan-400 font-mono-tech"
              />
            </div>

            <div className="pt-2">
              <button
                type="submit"
                className="w-full py-3 bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-black font-bold text-xs font-mono-tech tracking-wider uppercase rounded transition-all cursor-pointer shadow-lg"
              >
                PUBLISH TO BORROW INVENTORY (+40 IMPACT)
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};

```

---

## File: `src/components/BrandLogos.tsx`

```tsx
import React from 'react';

interface LogoProps {
  className?: string;
  size?: number;
  glow?: boolean;
}

/**
 * ON CAMPUS Logo based on reference image:
 * Features a glowing celestial ring/torus with a luminous cyan-to-violet gradient
 * and an orbiting bright beacon/portal at 1 o'clock, with ambient neon flare.
 */
export const OnCampusOrbitalIcon: React.FC<LogoProps> = ({ 
  className = '', 
  size = 48,
  glow = true 
}) => {
  return (
    <div 
      className={`relative inline-flex items-center justify-center ${className}`}
      style={{ width: size, height: size }}
    >
      {/* Outer ambient glow halo */}
      {glow && (
        <div 
          className="absolute inset-0 rounded-full bg-gradient-to-tr from-[#00f2ff]/30 via-[#a855f7]/30 to-[#f472b6]/20 blur-md pointer-events-none" 
        />
      )}

      <svg
        viewBox="0 0 100 100"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="w-full h-full relative z-10 drop-shadow-[0_0_12px_rgba(0,242,255,0.6)]"
      >
        <defs>
          {/* Main Gradient for the Ring */}
          <linearGradient id="onCampusRingGrad" x1="10" y1="10" x2="90" y2="90" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#00f2ff" />
            <stop offset="45%" stopColor="#818cf8" />
            <stop offset="85%" stopColor="#c084fc" />
            <stop offset="100%" stopColor="#f472b6" />
          </linearGradient>

          {/* Inner Glow Gradient */}
          <radialGradient id="onCampusCoreGlow" cx="50" cy="50" r="40" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#00f2ff" stopOpacity="0.8" />
            <stop offset="40%" stopColor="#a855f7" stopOpacity="0.4" />
            <stop offset="100%" stopColor="#05060f" stopOpacity="0" />
          </radialGradient>

          {/* Shimmer filter */}
          <filter id="neonBloom" x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="3" result="blur" />
            <feComposite in="SourceGraphic" in2="blur" operator="over" />
          </filter>
        </defs>

        {/* Ambient Dark Core */}
        <circle cx="50" cy="50" r="38" fill="#090b16" stroke="rgba(255,255,255,0.08)" strokeWidth="1" />
        <circle cx="50" cy="50" r="28" fill="url(#onCampusCoreGlow)" />

        {/* Outer Radiant Torus Ring */}
        <circle
          cx="50"
          cy="50"
          r="34"
          stroke="url(#onCampusRingGrad)"
          strokeWidth="7"
          strokeLinecap="round"
          filter="url(#neonBloom)"
        />

        {/* Inner Precision Guideline */}
        <circle
          cx="50"
          cy="50"
          r="26"
          stroke="rgba(255, 255, 255, 0.4)"
          strokeWidth="1.5"
          strokeDasharray="4 3"
        />

        {/* Central Aperture Core */}
        <circle cx="50" cy="50" r="12" fill="#060913" stroke="#00f2ff" strokeWidth="2.5" />
        <circle cx="50" cy="50" r="5" fill="#ffffff" />

        {/* Orbiting Bright Celestial Bead at ~1 o'clock (x=73, y=27) */}
        <circle cx="73" cy="27" r="6.5" fill="#ffffff" filter="url(#neonBloom)" />
        <circle cx="73" cy="27" r="3.5" fill="#00f2ff" />
      </svg>
    </div>
  );
};

/**
 * COMPASS AI Logo based on reference image:
 * Features a radiant geometric 4-point / 8-point multifaceted starburst / compass
 * with vibrant hot-pink and pure-white laser rays, diamond crystal sheen, and glowing concentric orbital rings.
 */
export const CompassStarIcon: React.FC<LogoProps> = ({ 
  className = '', 
  size = 48,
  glow = true 
}) => {
  return (
    <div 
      className={`relative inline-flex items-center justify-center ${className}`}
      style={{ width: size, height: size }}
    >
      {/* Outer ambient pink & white glow halo */}
      {glow && (
        <div 
          className="absolute inset-0 rounded-full bg-gradient-to-tr from-[#ec4899]/40 via-[#f43f5e]/30 to-[#ffffff]/35 blur-md pointer-events-none animate-pulse-slow" 
        />
      )}

      <svg
        viewBox="0 0 100 100"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="w-full h-full relative z-10 drop-shadow-[0_0_15px_rgba(244,114,182,0.9)]"
      >
        <defs>
          {/* Main Pink and White Gradient */}
          <linearGradient id="compassStarGradPinkWhite" x1="0" y1="0" x2="100" y2="100" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#ffffff" />
            <stop offset="30%" stopColor="#fbcfe8" />
            <stop offset="65%" stopColor="#f472b6" />
            <stop offset="100%" stopColor="#db2777" />
          </linearGradient>

          {/* Deep Rose Pink Gradient for faceted shadow */}
          <linearGradient id="compassFacetShadow" x1="0" y1="0" x2="100" y2="100" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#f472b6" />
            <stop offset="100%" stopColor="#9d174d" />
          </linearGradient>

          {/* Core Radial Glow: White center radiating into Hot Pink */}
          <radialGradient id="compassGlowCorePinkWhite" cx="50" cy="50" r="30" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#ffffff" />
            <stop offset="35%" stopColor="#f472b6" stopOpacity="0.95" />
            <stop offset="75%" stopColor="#db2777" stopOpacity="0.5" />
            <stop offset="100%" stopColor="#000000" stopOpacity="0" />
          </radialGradient>
        </defs>

        {/* Outer Concentric Precision Guidance Rings */}
        <circle cx="50" cy="50" r="43" stroke="rgba(244,114,182,0.35)" strokeWidth="1.5" strokeDasharray="3 3" />
        <circle cx="50" cy="50" r="33" stroke="rgba(255,255,255,0.4)" strokeWidth="1.5" />

        {/* Diagonal Minor Star Rays (45 degree offset) */}
        <path
          d="M50 24 L54 46 L76 50 L54 54 L50 76 L46 54 L24 50 L46 46 Z"
          fill="url(#compassStarGradPinkWhite)"
          opacity="0.65"
        />

        {/* Primary 4-Point Faceted Compass Star */}
        <path
          d="M50 8 L57 43 L92 50 L57 57 L50 92 L43 57 L8 50 L43 43 Z"
          fill="url(#compassStarGradPinkWhite)"
        />

        {/* Diamond Facet Highlights (Top & Right wings shine in pure white) */}
        <path
          d="M50 8 L50 50 L92 50 Z"
          fill="#ffffff"
          opacity="0.45"
        />
        <path
          d="M50 92 L50 50 L8 50 Z"
          fill="#ffffff"
          opacity="0.3"
        />

        {/* Facet Shading */}
        <path
          d="M50 8 L50 50 L8 50 Z"
          fill="url(#compassFacetShadow)"
          opacity="0.5"
        />
        <path
          d="M50 92 L50 50 L92 50 Z"
          fill="url(#compassFacetShadow)"
          opacity="0.5"
        />

        {/* Glowing Center Core */}
        <circle cx="50" cy="50" r="10" fill="url(#compassGlowCorePinkWhite)" />
        <circle cx="50" cy="50" r="4.5" fill="#ffffff" filter="drop-shadow(0 0 4px #ffffff)" />
      </svg>
    </div>
  );
};

```

---

## File: `src/components/Campus3DVisualizer.tsx`

```tsx
import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';

interface Campus3DVisualizerProps {
  onSelectNode?: (hubName: string) => void;
}

// Generate high-resolution, crystal-sharp holographic badge canvas textures (512x512)
function createSharpBadgeTexture(
  type: number,
  category: string,
  title: string,
  metric: string,
  accentColor: string,
  secondaryColor: string,
  isMobile: boolean
): THREE.CanvasTexture {
  const size = 512;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d');
  if (!ctx) return new THREE.CanvasTexture(canvas);

  // Enable high-quality anti-aliased drawing
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = 'high';

  // 1. Card Base with Glassmorphic Gradient
  ctx.save();
  const radius = 38;
  ctx.beginPath();
  ctx.roundRect(14, 14, size - 28, size - 28, radius);
  ctx.clip();

  // Glass background gradient
  const bgGrad = ctx.createLinearGradient(0, 0, size, size);
  bgGrad.addColorStop(0, 'rgba(8, 14, 28, 0.98)');
  bgGrad.addColorStop(0.5, 'rgba(5, 8, 18, 0.96)');
  bgGrad.addColorStop(1, 'rgba(14, 8, 26, 0.98)');
  ctx.fillStyle = bgGrad;
  ctx.fillRect(0, 0, size, size);

  // Subtle interior ambient glow
  const glowGrad = ctx.createRadialGradient(size * 0.35, size * 0.3, 10, size * 0.35, size * 0.3, 300);
  glowGrad.addColorStop(0, accentColor.replace(')', ', 0.28)').replace('rgb', 'rgba'));
  glowGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
  ctx.fillStyle = glowGrad;
  ctx.fillRect(0, 0, size, size);

  // Tech grid pattern in background
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.05)';
  ctx.lineWidth = 1.5;
  const gridStep = 44;
  for (let x = 28; x < size - 28; x += gridStep) {
    ctx.beginPath();
    ctx.moveTo(x, 28);
    ctx.lineTo(x, size - 28);
    ctx.stroke();
  }
  for (let y = 28; y < size - 28; y += gridStep) {
    ctx.beginPath();
    ctx.moveTo(28, y);
    ctx.lineTo(size - 28, y);
    ctx.stroke();
  }
  ctx.restore();

  // 2. High-Precision Neon Borders
  // Outer bright border
  ctx.beginPath();
  ctx.roundRect(14, 14, size - 28, size - 28, radius);
  ctx.strokeStyle = accentColor;
  ctx.lineWidth = isMobile ? 7 : 5;
  ctx.stroke();

  // Inner hairline precision border
  ctx.beginPath();
  ctx.roundRect(26, 26, size - 52, size - 52, radius - 10);
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.22)';
  ctx.lineWidth = 2;
  ctx.stroke();

  // Corner Accent Brackets
  ctx.strokeStyle = '#ffffff';
  ctx.lineWidth = 4.5;
  // Top-left bracket
  ctx.beginPath();
  ctx.moveTo(14, 68);
  ctx.lineTo(14, 38);
  ctx.arcTo(14, 14, 38, 14, radius);
  ctx.lineTo(68, 14);
  ctx.stroke();
  // Bottom-right bracket
  ctx.beginPath();
  ctx.moveTo(size - 14, size - 68);
  ctx.lineTo(size - 14, size - 38);
  ctx.arcTo(size - 14, size - 14, size - 38, size - 14, radius);
  ctx.lineTo(size - 68, size - 14);
  ctx.stroke();

  // 3. Header Section (Category Tag & Live Ping)
  // Category Pill
  ctx.fillStyle = accentColor.replace(')', ', 0.22)').replace('rgb', 'rgba');
  ctx.beginPath();
  ctx.roundRect(42, 46, 230, 48, 24);
  ctx.fill();
  ctx.strokeStyle = accentColor;
  ctx.lineWidth = 2.5;
  ctx.stroke();

  // Category Tag Text
  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 22px "JetBrains Mono", monospace, sans-serif';
  ctx.fillText(category, 66, 78);

  // Live Ping Indicator on right
  ctx.fillStyle = secondaryColor;
  ctx.beginPath();
  ctx.arc(size - 62, 70, 9, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = '#ffffff';
  ctx.lineWidth = 2.5;
  ctx.stroke();

  // 4. Center Visual Graphic based on type
  if (type === 0) {
    // Neural Waveform / Live Telemetry Line
    ctx.strokeStyle = accentColor;
    ctx.lineWidth = 9;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.beginPath();
    ctx.moveTo(56, 270);
    ctx.lineTo(130, 205);
    ctx.lineTo(210, 290);
    ctx.lineTo(310, 155);
    ctx.lineTo(390, 230);
    ctx.lineTo(456, 165);
    ctx.stroke();

    // Data points along waveform
    [
      { x: 130, y: 205 },
      { x: 310, y: 155 },
      { x: 456, y: 165 },
    ].forEach((pt) => {
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(pt.x, pt.y, 10, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = accentColor;
      ctx.lineWidth = 3.5;
      ctx.stroke();
    });
  } else if (type === 1) {
    // High-tech Compass Star / Geometric Diamond
    const cx = size / 2;
    const cy = 230;
    ctx.fillStyle = accentColor.replace(')', ', 0.25)').replace('rgb', 'rgba');
    ctx.beginPath();
    ctx.moveTo(cx, cy - 85);
    ctx.lineTo(cx + 85, cy);
    ctx.lineTo(cx, cy + 85);
    ctx.lineTo(cx - 85, cy);
    ctx.closePath();
    ctx.fill();
    ctx.strokeStyle = accentColor;
    ctx.lineWidth = 6.5;
    ctx.stroke();

    // Inner diamond core
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.moveTo(cx, cy - 38);
    ctx.lineTo(cx + 38, cy);
    ctx.lineTo(cx, cy + 38);
    ctx.lineTo(cx - 38, cy);
    ctx.closePath();
    ctx.fill();
  } else if (type === 2) {
    // Interlocking Orbital Node Circles
    const cx = size / 2;
    const cy = 230;
    ctx.strokeStyle = accentColor;
    ctx.lineWidth = 6;
    ctx.beginPath();
    ctx.arc(cx - 42, cy, 58, 0, Math.PI * 2);
    ctx.stroke();
    ctx.strokeStyle = secondaryColor;
    ctx.beginPath();
    ctx.arc(cx + 42, cy, 58, 0, Math.PI * 2);
    ctx.stroke();

    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(cx, cy, 15, 0, Math.PI * 2);
    ctx.fill();
  } else if (type === 3) {
    // Precision Tech Meter / Progress Arc
    const cx = size / 2;
    const cy = 235;
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.18)';
    ctx.lineWidth = 15;
    ctx.beginPath();
    ctx.arc(cx, cy, 75, Math.PI * 0.8, Math.PI * 2.2);
    ctx.stroke();

    ctx.strokeStyle = accentColor;
    ctx.lineWidth = 15;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.arc(cx, cy, 75, Math.PI * 0.8, Math.PI * 1.95);
    ctx.stroke();

    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 38px "JetBrains Mono", monospace';
    ctx.textAlign = 'center';
    ctx.fillText('99.4%', cx, cy + 14);
    ctx.textAlign = 'left';
  } else {
    // Peer Exchange / Collab Nodes
    const cx = size / 2;
    const cy = 230;
    ctx.fillStyle = 'rgba(255, 255, 255, 0.18)';
    ctx.beginPath();
    ctx.arc(cx, cy, 62, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = accentColor;
    ctx.lineWidth = 4.5;
    ctx.stroke();

    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(cx, cy - 16, 24, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.arc(cx, cy + 46, 34, Math.PI, Math.PI * 2);
    ctx.fill();
  }

  // 5. Card Footer Title & Metric Text
  ctx.fillStyle = '#ffffff';
  ctx.font = isMobile ? 'bold 36px "Space Grotesk", sans-serif' : 'bold 33px "Space Grotesk", sans-serif';
  ctx.fillText(title, 42, 386);

  ctx.fillStyle = secondaryColor;
  ctx.font = isMobile ? 'bold 26px "JetBrains Mono", monospace' : 'bold 24px "JetBrains Mono", monospace';
  ctx.fillText(metric, 42, 432);

  // Micro progress indicator bar at bottom
  ctx.fillStyle = 'rgba(255, 255, 255, 0.14)';
  ctx.fillRect(42, 458, size - 84, 7);
  ctx.fillStyle = accentColor;
  ctx.fillRect(42, 458, (size - 84) * 0.78, 7);

  const texture = new THREE.CanvasTexture(canvas);
  texture.minFilter = THREE.LinearMipmapLinearFilter;
  texture.magFilter = THREE.LinearFilter;
  texture.generateMipmaps = true;
  texture.needsUpdate = true;
  return texture;
}

export const Campus3DVisualizer: React.FC<Campus3DVisualizerProps> = ({ onSelectNode }) => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const [hasInteracted, setHasInteracted] = useState(false);
  const [isMobileDevice, setIsMobileDevice] = useState(false);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const width = container.clientWidth;
    const height = container.clientHeight;
    const isMobile = width < 768;
    const isSmallMobile = width < 480;
    setIsMobileDevice(isMobile);

    // --- THREE.JS SCENE SETUP ---
    const scene = new THREE.Scene();

    const camera = new THREE.PerspectiveCamera(
      42,
      width / height,
      0.1,
      1000
    );

    // Dynamic initial camera positioning based on screen aspect ratio
    const aspect = width / height;
    const cameraDist = isMobile 
      ? Math.max(24, Math.min(32, 22 / Math.max(0.48, aspect)))
      : 22;
    camera.position.set(0, 0, cameraDist);

    const renderer = new THREE.WebGLRenderer({
      antialias: true,
      alpha: true,
      powerPreference: 'high-performance',
      precision: 'highp',
    });
    renderer.setSize(width, height);
    // Cap at 2.0 on mobile to optimize battery and smooth 60fps rendering
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, isMobile ? 2.0 : 2.5));
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = isMobile ? 1.4 : 1.25;
    container.appendChild(renderer.domElement);

    const maxAnisotropy = renderer.capabilities.getMaxAnisotropy();

    // --- LIGHTING (Enhanced luminous glow for phone AMOLED/Retina screens) ---
    const ambientLight = new THREE.AmbientLight(0x101827, isMobile ? 3.0 : 2.5);
    scene.add(ambientLight);

    const mainCyanLight = new THREE.PointLight(0x00f2ff, isMobile ? 7.5 : 6.0, 60);
    mainCyanLight.position.set(isMobile ? 0 : 12, 10, 14);
    scene.add(mainCyanLight);

    const pinkRimLight = new THREE.PointLight(0xf472b6, isMobile ? 6.5 : 5.0, 60);
    pinkRimLight.position.set(-6, -8, 12);
    scene.add(pinkRimLight);

    const purpleCoreLight = new THREE.PointLight(0xa855f7, isMobile ? 5.5 : 4.0, 50);
    purpleCoreLight.position.set(0, 0, 8);
    scene.add(purpleCoreLight);

    // --- ROOT CONSTELLATION GROUP ---
    const networkGroup = new THREE.Group();
    
    // Dynamic position & scale setup for phone vs tablet vs desktop
    const updateGroupPositionAndScale = (w: number, h: number) => {
      const isMob = w < 768;
      const isTablet = w >= 768 && w < 1100;
      const isSm = w < 480;
      const curAspect = w / h;

      if (isMob) {
        // On phone, center horizontally and lift slightly to create deep glowing backdrop
        const posY = isSm ? 1.2 : 0.9;
        networkGroup.position.set(0, posY, 0);
        // Adaptive scale based on screen width
        const scale = isSm 
          ? Math.max(0.58, Math.min(0.72, w / 440))
          : Math.max(0.68, Math.min(0.82, w / 680));
        networkGroup.scale.set(scale, scale, scale);
        
        // Dynamically adjust camera Z for narrow portrait phone viewports
        const dynamicZ = Math.max(24, Math.min(34, 23 / Math.max(0.5, curAspect)));
        camera.position.set(0, 0, dynamicZ);
      } else if (isTablet) {
        // Tablet: anchor slightly to the right with gentle scale and further camera distance so text never collides
        networkGroup.position.set(1.5, 0.1, -1.0);
        networkGroup.scale.set(0.76, 0.76, 0.76);
        camera.position.set(0, 0, 24);
      } else {
        // Desktop: anchor to right side
        networkGroup.position.set(3.2, 0.2, 0);
        networkGroup.scale.set(1, 1, 1);
        camera.position.set(0, 0, 22);
      }
    };

    updateGroupPositionAndScale(width, height);
    scene.add(networkGroup);

    // =========================================================================
    // 1. CENTRAL NEURAL CORE (Faceted Crystal Icosahedron + Outer Orbital Rings)
    // =========================================================================
    const coreGroup = new THREE.Group();
    coreGroup.position.set(0, 0, 0);
    networkGroup.add(coreGroup);

    // Inner glowing sphere core
    const innerCoreGeo = new THREE.SphereGeometry(0.8, 32, 32);
    const innerCoreMat = new THREE.MeshStandardMaterial({
      color: 0x00f2ff,
      emissive: 0x00c4ff,
      emissiveIntensity: isMobile ? 1.1 : 0.85,
      roughness: 0.2,
      metalness: 0.8,
    });
    const innerCore = new THREE.Mesh(innerCoreGeo, innerCoreMat);
    coreGroup.add(innerCore);

    // Faceted Crystal Outer Shell
    const crystalGeo = new THREE.IcosahedronGeometry(1.45, 0);
    const crystalMat = new THREE.MeshPhysicalMaterial({
      color: 0x38bdf8,
      emissive: 0x002b4d,
      roughness: 0.1,
      metalness: 0.15,
      transmission: 0.88,
      thickness: 1.2,
      transparent: true,
      opacity: 0.88,
      wireframe: false,
    });
    const crystalMesh = new THREE.Mesh(crystalGeo, crystalMat);
    coreGroup.add(crystalMesh);

    // Crystal Wireframe Cage
    const wireframeGeo = new THREE.IcosahedronGeometry(1.48, 0);
    const wireframeMat = new THREE.MeshBasicMaterial({
      color: 0x00f2ff,
      wireframe: true,
      transparent: true,
      opacity: 0.95,
    });
    const crystalWireframe = new THREE.Mesh(wireframeGeo, wireframeMat);
    coreGroup.add(crystalWireframe);

    // Dual Orbital Rings around central core
    const ringGeo1 = new THREE.TorusGeometry(2.4, 0.03, 16, 100);
    const ringMat1 = new THREE.MeshBasicMaterial({
      color: 0x00f2ff,
      transparent: true,
      opacity: 0.8,
    });
    const ring1 = new THREE.Mesh(ringGeo1, ringMat1);
    ring1.rotation.x = Math.PI / 3;
    ring1.rotation.y = Math.PI / 6;
    coreGroup.add(ring1);

    const ringGeo2 = new THREE.TorusGeometry(2.9, 0.025, 16, 100);
    const ringMat2 = new THREE.MeshBasicMaterial({
      color: 0xf472b6,
      transparent: true,
      opacity: 0.75,
    });
    const ring2 = new THREE.Mesh(ringGeo2, ringMat2);
    ring2.rotation.x = -Math.PI / 4;
    ring2.rotation.y = Math.PI / 3;
    coreGroup.add(ring2);

    // Outer faint pulsing halo ring for phone visual depth
    const haloGeo = new THREE.RingGeometry(3.6, 3.68, 64);
    const haloMat = new THREE.MeshBasicMaterial({
      color: 0x818cf8,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.35,
    });
    const haloMesh = new THREE.Mesh(haloGeo, haloMat);
    haloMesh.rotation.x = Math.PI / 2.2;
    coreGroup.add(haloMesh);

    // =========================================================================
    // 2. NETWORK NODES (Structured constellation with phone compression ratio)
    // =========================================================================
    interface NodeDef {
      pos: THREE.Vector3;
      initialPos: THREE.Vector3;
      speed: number;
      phase: number;
      isHub?: boolean;
      hubLabel?: string;
      color: number;
    }

    const nodeDefs: NodeDef[] = [];
    const colorsList = [0x00f2ff, 0xf472b6, 0xa855f7, 0x38bdf8, 0x34d399, 0xfbbf24];

    // Primary Satellite Hub Nodes (With tighter radius on mobile to prevent clipping)
    const radMult = isMobile ? 0.82 : 1.0;
    const primaryHubs = [
      { name: 'BORROW LAB', category: 'HARDWARE', metric: '42+ Available', x: -3.8 * radMult, y: 2.8 * radMult, z: 1.5, color: 0x00f2ff, accent: 'rgb(0, 242, 255)', sec: '#38bdf8', type: 0 },
      { name: 'MENTORSHIP', category: 'SENIORS', metric: '98% Verified', x: 3.6 * radMult, y: 3.2 * radMult, z: -1.0, color: 0xa855f7, accent: 'rgb(168, 85, 247)', sec: '#c084fc', type: 1 },
      { name: 'SKILL MATRIX', category: 'EXCHANGE', metric: '600+ Skills', x: 4.6 * radMult, y: -0.6 * radMult, z: 2.0, color: 0xf472b6, accent: 'rgb(244, 114, 182)', sec: '#fb7185', type: 2 },
      { name: 'CAMPUS PULSE', category: 'COMMUNITY', metric: 'Live 24/7', x: -3.2 * radMult, y: -2.6 * radMult, z: -1.2, color: 0x34d399, accent: 'rgb(52, 211, 153)', sec: '#10b981', type: 3 },
      { name: 'MARKETPLACE', category: 'STUDENT TRADE', metric: '₹0 Commission', x: 1.2 * radMult, y: -3.6 * radMult, z: 1.8, color: 0xfbbf24, accent: 'rgb(251, 191, 36)', sec: '#f59e0b', type: 4 },
      { name: 'COMPASS AI', category: 'CO-PILOT', metric: 'Campus Brain', x: -0.5 * radMult, y: 4.2 * radMult, z: 0.5, color: 0xf472b6, accent: 'rgb(244, 114, 182)', sec: '#ffffff', type: 1 },
    ];

    primaryHubs.forEach((hub) => {
      const pos = new THREE.Vector3(hub.x, hub.y, hub.z);
      nodeDefs.push({
        pos: pos.clone(),
        initialPos: pos.clone(),
        speed: 0.35 + Math.random() * 0.2,
        phase: Math.random() * Math.PI * 2,
        isHub: true,
        hubLabel: hub.name,
        color: hub.color,
      });
    });

    // Secondary connecting constellation nodes
    const secondaryCount = isMobile ? 32 : 44;
    for (let i = 0; i < secondaryCount; i++) {
      const theta = Math.random() * Math.PI * 2;
      const radius = (2.0 + Math.random() * 4.8) * radMult;
      const x = Math.cos(theta) * radius + (Math.random() - 0.5) * 1.4;
      const y = Math.sin(theta) * (radius * 0.78) + (Math.random() - 0.5) * 1.4;
      const z = (Math.random() - 0.5) * 4.2;

      const pos = new THREE.Vector3(x, y, z);
      nodeDefs.push({
        pos: pos.clone(),
        initialPos: pos.clone(),
        speed: 0.2 + Math.random() * 0.3,
        phase: Math.random() * Math.PI * 2,
        color: colorsList[i % colorsList.length],
      });
    }

    // Create 3D Node Meshes
    const nodeSphereGeo = new THREE.SphereGeometry(isMobile ? 0.14 : 0.12, 16, 16);
    const hubSphereGeo = new THREE.SphereGeometry(isMobile ? 0.28 : 0.24, 24, 24);
    const glowRingGeo = new THREE.RingGeometry(0.32, 0.40, 32);

    const vertexMeshes: THREE.Mesh[] = [];

    nodeDefs.forEach((n) => {
      const mat = new THREE.MeshStandardMaterial({
        color: n.color,
        emissive: n.color,
        emissiveIntensity: n.isHub ? (isMobile ? 1.3 : 1.0) : 0.6,
        roughness: 0.15,
        metalness: 0.8,
      });
      const mesh = new THREE.Mesh(n.isHub ? hubSphereGeo : nodeSphereGeo, mat);
      mesh.position.copy(n.pos);
      networkGroup.add(mesh);
      vertexMeshes.push(mesh);

      // Glowing concentric halo ring for primary hubs
      if (n.isHub) {
        const ringMat = new THREE.MeshBasicMaterial({
          color: n.color,
          side: THREE.DoubleSide,
          transparent: true,
          opacity: 0.85,
        });
        const ringMesh = new THREE.Mesh(glowRingGeo, ringMat);
        mesh.add(ringMesh);
      }
    });

    // =========================================================================
    // 3. SHARP HOLOGRAPHIC BADGE TILES (Positioned at Primary Hubs)
    // =========================================================================
    const tileScale = isMobile ? 1.75 : 1.65;
    const tileGeo = new THREE.PlaneGeometry(tileScale, tileScale);
    const tileMeshes: { mesh: THREE.Mesh; nodeIdx: number; rotOffset: number; name: string }[] = [];

    primaryHubs.forEach((hub, i) => {
      const texture = createSharpBadgeTexture(
        hub.type,
        hub.category,
        hub.name,
        hub.metric,
        hub.accent,
        hub.sec,
        isMobile
      );
      texture.anisotropy = maxAnisotropy;

      const tileMat = new THREE.MeshBasicMaterial({
        map: texture,
        transparent: true,
        opacity: 0.98,
        side: THREE.DoubleSide,
        depthWrite: false,
      });

      const tileMesh = new THREE.Mesh(tileGeo, tileMat);
      const offsetPos = nodeDefs[i].pos.clone().add(new THREE.Vector3(0, 0.48, 0.3));
      tileMesh.position.copy(offsetPos);
      tileMesh.userData = { hubName: hub.name };
      networkGroup.add(tileMesh);

      tileMeshes.push({
        mesh: tileMesh,
        nodeIdx: i,
        rotOffset: (i % 2 === 0 ? 0.05 : -0.05),
        name: hub.name,
      });
    });

    // =========================================================================
    // 4. CRISP LASER-BEAM INTERCONNECTING LINES
    // =========================================================================
    const linePairs: [number, number][] = [];
    const maxConnectDist = isMobile ? 3.4 : 3.6;

    for (let i = 0; i < primaryHubs.length; i++) {
      for (let j = i + 1; j < primaryHubs.length; j++) {
        linePairs.push([i, j]);
      }
    }

    for (let i = 0; i < nodeDefs.length; i++) {
      for (let j = i + 1; j < nodeDefs.length; j++) {
        const dist = nodeDefs[i].pos.distanceTo(nodeDefs[j].pos);
        if (dist < maxConnectDist && linePairs.length < (isMobile ? 85 : 110)) {
          linePairs.push([i, j]);
        }
      }
    }

    const linePositions = new Float32Array(linePairs.length * 6);
    const lineColors = new Float32Array(linePairs.length * 6);

    const paletteColors = [
      new THREE.Color(0x00f2ff), // Cyan
      new THREE.Color(0xf472b6), // Pink
      new THREE.Color(0xa855f7), // Violet
      new THREE.Color(0x38bdf8), // Sky Blue
      new THREE.Color(0x34d399), // Emerald
    ];

    linePairs.forEach((pair, idx) => {
      const c1 = paletteColors[pair[0] % paletteColors.length];
      const c2 = paletteColors[pair[1] % paletteColors.length];
      lineColors[idx * 6] = c1.r;
      lineColors[idx * 6 + 1] = c1.g;
      lineColors[idx * 6 + 2] = c1.b;
      lineColors[idx * 6 + 3] = c2.r;
      lineColors[idx * 6 + 4] = c2.g;
      lineColors[idx * 6 + 5] = c2.b;
    });

    const lineGeo = new THREE.BufferGeometry();
    lineGeo.setAttribute('position', new THREE.BufferAttribute(linePositions, 3));
    lineGeo.setAttribute('color', new THREE.BufferAttribute(lineColors, 3));

    const lineMat = new THREE.LineBasicMaterial({
      vertexColors: true,
      transparent: true,
      opacity: isMobile ? 0.65 : 0.55,
    });

    const linesMesh = new THREE.LineSegments(lineGeo, lineMat);
    networkGroup.add(linesMesh);

    // =========================================================================
    // 5. GLOWING NEON PHOTON PACKETS WITH LIGHT TRAILS
    // =========================================================================
    const packetCount = isMobile ? 22 : 30;
    const packetGeo = new THREE.SphereGeometry(isMobile ? 0.10 : 0.08, 12, 12);
    const packetColors = [0x00f2ff, 0xf472b6, 0xa855f7, 0x38bdf8, 0x34d399, 0xffffff];

    interface PacketItem {
      mesh: THREE.Mesh;
      trailMesh: THREE.Line;
      from: number;
      to: number;
      progress: number;
      speed: number;
      history: THREE.Vector3[];
    }

    const packets: PacketItem[] = [];

    for (let i = 0; i < packetCount; i++) {
      const pair = linePairs[Math.floor(Math.random() * linePairs.length)];
      const colHex = packetColors[i % packetColors.length];
      const pMat = new THREE.MeshBasicMaterial({ color: colHex });
      const pMesh = new THREE.Mesh(packetGeo, pMat);
      networkGroup.add(pMesh);

      const initialPos = nodeDefs[pair[0]].pos.clone();
      const trailPoints = [initialPos.clone(), initialPos.clone(), initialPos.clone(), initialPos.clone()];
      const trailGeo = new THREE.BufferGeometry().setFromPoints(trailPoints);
      const trailMat = new THREE.LineBasicMaterial({
        color: colHex,
        transparent: true,
        opacity: isMobile ? 0.75 : 0.65,
      });
      const trailLine = new THREE.Line(trailGeo, trailMat);
      networkGroup.add(trailLine);

      packets.push({
        mesh: pMesh,
        trailMesh: trailLine,
        from: pair[0],
        to: pair[1],
        progress: Math.random(),
        speed: 0.007 + Math.random() * 0.009,
        history: trailPoints,
      });
    }

    // =========================================================================
    // 6. BACKGROUND PRECISION PARTICLES
    // =========================================================================
    const starCount = isMobile ? 180 : 260;
    const starGeo = new THREE.BufferGeometry();
    const starPos = new Float32Array(starCount * 3);

    for (let i = 0; i < starCount; i++) {
      starPos[i * 3] = (Math.random() - 0.5) * 40;
      starPos[i * 3 + 1] = (Math.random() - 0.5) * 30;
      starPos[i * 3 + 2] = -8 + (Math.random() - 0.5) * 20;
    }

    starGeo.setAttribute('position', new THREE.BufferAttribute(starPos, 3));
    const starMat = new THREE.PointsMaterial({
      size: isMobile ? 0.08 : 0.06,
      color: 0xa5b4fc,
      transparent: true,
      opacity: isMobile ? 0.6 : 0.45,
    });
    const stars = new THREE.Points(starGeo, starMat);
    scene.add(stars);

    // =========================================================================
    // 7. TOUCH / DRAG / GYROSCOPE & MOUSE INTERACTION ENGINE
    // =========================================================================
    let targetRotX = 0;
    let targetRotY = 0;
    let isDragging = false;
    let touchStartX = 0;
    let touchStartY = 0;
    let lastTouchX = 0;
    let lastTouchY = 0;
    let velocityX = 0;
    let velocityY = 0;

    // Desktop Mouse Parallax
    const onMouseMove = (e: MouseEvent) => {
      if (isDragging) return;
      const rect = container.getBoundingClientRect();
      const x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      const y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
      targetRotY = x * 0.32;
      targetRotX = -y * 0.25;
    };

    window.addEventListener('mousemove', onMouseMove);

    // Touch Event Handlers for Mobile (360° Drag Rotation with Momentum)
    const onTouchStart = (e: TouchEvent) => {
      if (e.touches.length === 1) {
        setHasInteracted(true);
        isDragging = true;
        touchStartX = e.touches[0].clientX;
        touchStartY = e.touches[0].clientY;
        lastTouchX = touchStartX;
        lastTouchY = touchStartY;
        velocityX = 0;
        velocityY = 0;
      }
    };

    const onTouchMove = (e: TouchEvent) => {
      if (!isDragging || e.touches.length !== 1) return;
      const curX = e.touches[0].clientX;
      const curY = e.touches[0].clientY;
      const deltaX = curX - lastTouchX;
      const deltaY = curY - lastTouchY;

      // Track velocity for inertia
      velocityX = deltaX * 0.005;
      velocityY = deltaY * 0.005;

      networkGroup.rotation.y += deltaX * 0.008;
      networkGroup.rotation.x += deltaY * 0.008;

      // Clamp vertical tilt to prevent unnatural flips
      networkGroup.rotation.x = Math.max(-0.6, Math.min(0.6, networkGroup.rotation.x));

      lastTouchX = curX;
      lastTouchY = curY;
    };

    const onTouchEnd = (e: TouchEvent) => {
      isDragging = false;
      // Raycasting for tap detection on mobile
      if (e.changedTouches.length === 1 && onSelectNode) {
        const endX = e.changedTouches[0].clientX;
        const endY = e.changedTouches[0].clientY;
        const dist = Math.hypot(endX - touchStartX, endY - touchStartY);
        if (dist < 12) {
          // Tap detected!
          const rect = container.getBoundingClientRect();
          const mouse = new THREE.Vector2(
            ((endX - rect.left) / rect.width) * 2 - 1,
            -((endY - rect.top) / rect.height) * 2 + 1
          );
          const raycaster = new THREE.Raycaster();
          raycaster.setFromCamera(mouse, camera);
          const intersects = raycaster.intersectObjects(tileMeshes.map((t) => t.mesh));
          if (intersects.length > 0) {
            const hitHub = intersects[0].object.userData.hubName;
            if (hitHub) {
              onSelectNode(hitHub);
            }
          }
        }
      }
    };

    container.addEventListener('touchstart', onTouchStart, { passive: true });
    container.addEventListener('touchmove', onTouchMove, { passive: true });
    container.addEventListener('touchend', onTouchEnd, { passive: true });
    container.addEventListener('touchcancel', onTouchEnd, { passive: true });

    // Gyroscope / Device Orientation Parallax on Phone
    const handleOrientation = (e: DeviceOrientationEvent) => {
      if (isDragging) return;
      if (e.gamma !== null && e.beta !== null) {
        // gamma: left-to-right tilt in degrees [-90, 90]
        // beta: front-to-back tilt in degrees [-180, 180]
        const tiltX = Math.max(-30, Math.min(30, e.gamma)) / 30;
        const tiltY = (Math.max(15, Math.min(65, e.beta)) - 40) / 30;
        targetRotY = tiltX * 0.35;
        targetRotX = -tiltY * 0.25;
      }
    };

    if (window.DeviceOrientationEvent) {
      window.addEventListener('deviceorientation', handleOrientation);
    }

    // Window Resize Handler with adaptive mobile reframing
    const handleResize = () => {
      if (!container) return;
      const newW = container.clientWidth;
      const newH = container.clientHeight;
      const newIsMob = newW < 768;
      setIsMobileDevice(newIsMob);

      camera.aspect = newW / newH;
      camera.updateProjectionMatrix();
      renderer.setSize(newW, newH);
      updateGroupPositionAndScale(newW, newH);
    };

    window.addEventListener('resize', handleResize);

    // =========================================================================
    // 8. RENDER & ANIMATION LOOP (Butter-smooth 60fps)
    // =========================================================================
    let frameId: number;
    const clock = new THREE.Clock();

    const animate = () => {
      frameId = requestAnimationFrame(animate);
      const elapsed = clock.getElapsedTime();

      // Apply touch inertia or smooth mouse parallax
      if (!isDragging) {
        // Inertia damping
        if (Math.abs(velocityX) > 0.0001 || Math.abs(velocityY) > 0.0001) {
          networkGroup.rotation.y += velocityX;
          networkGroup.rotation.x += velocityY;
          velocityX *= 0.92;
          velocityY *= 0.92;
          networkGroup.rotation.x = Math.max(-0.6, Math.min(0.6, networkGroup.rotation.x));
        } else {
          // Smooth drift toward target parallax
          networkGroup.rotation.y += (targetRotY - networkGroup.rotation.y) * 0.035 + (isMobileDevice ? 0.0012 : 0.0008);
          networkGroup.rotation.x += (targetRotX - networkGroup.rotation.x) * 0.035;
        }
      }

      // Animate Central Core
      crystalMesh.rotation.y = elapsed * 0.38;
      crystalMesh.rotation.x = elapsed * 0.22;
      crystalWireframe.rotation.y = -elapsed * 0.42;
      crystalWireframe.rotation.z = elapsed * 0.28;
      ring1.rotation.z = elapsed * 0.55;
      ring2.rotation.z = -elapsed * 0.48;
      haloMesh.rotation.z = elapsed * 0.15;

      // Pulse core glow scale gently
      const corePulse = 1.0 + Math.sin(elapsed * 2.5) * 0.04;
      innerCore.scale.set(corePulse, corePulse, corePulse);

      // Gentle floating oscillation for nodes
      nodeDefs.forEach((n, i) => {
        n.pos.x = n.initialPos.x + Math.sin(elapsed * n.speed + n.phase) * 0.12;
        n.pos.y = n.initialPos.y + Math.cos(elapsed * n.speed * 0.8 + n.phase) * 0.12;
        vertexMeshes[i].position.copy(n.pos);
      });

      // Update badge tile positions & billboarding (always face camera cleanly)
      tileMeshes.forEach((t) => {
        const baseNodePos = nodeDefs[t.nodeIdx].pos;
        t.mesh.position.set(baseNodePos.x, baseNodePos.y + 0.52, baseNodePos.z + 0.2);
        // Counter-rotate so tiles stay sharp and legible facing the user
        t.mesh.rotation.y = -networkGroup.rotation.y + t.rotOffset;
        t.mesh.rotation.x = -networkGroup.rotation.x;
      });

      // Update connecting line geometry positions
      const positions = lineGeo.attributes.position.array as Float32Array;
      linePairs.forEach((pair, idx) => {
        const p1 = nodeDefs[pair[0]].pos;
        const p2 = nodeDefs[pair[1]].pos;
        positions[idx * 6] = p1.x;
        positions[idx * 6 + 1] = p1.y;
        positions[idx * 6 + 2] = p1.z;
        positions[idx * 6 + 3] = p2.x;
        positions[idx * 6 + 4] = p2.y;
        positions[idx * 6 + 5] = p2.z;
      });
      lineGeo.attributes.position.needsUpdate = true;

      // Move photon packets and light trails along network lines
      packets.forEach((p) => {
        p.progress += p.speed;
        if (p.progress >= 1) {
          p.progress = 0;
          const pair = linePairs[Math.floor(Math.random() * linePairs.length)];
          p.from = pair[0];
          p.to = pair[1];
          const resetPos = nodeDefs[p.from].pos.clone();
          p.history = [resetPos.clone(), resetPos.clone(), resetPos.clone(), resetPos.clone()];
        }
        const p1 = nodeDefs[p.from].pos;
        const p2 = nodeDefs[p.to].pos;
        const currentPos = new THREE.Vector3().lerpVectors(p1, p2, p.progress);
        p.mesh.position.copy(currentPos);

        // Update trail tail points
        p.history.pop();
        p.history.unshift(currentPos.clone());
        const trailGeo = p.trailMesh.geometry as THREE.BufferGeometry;
        trailGeo.setFromPoints(p.history);
        trailGeo.attributes.position.needsUpdate = true;
      });

      renderer.render(scene, camera);
    };

    animate();

    return () => {
      cancelAnimationFrame(frameId);
      window.removeEventListener('mousemove', onMouseMove);
      container.removeEventListener('touchstart', onTouchStart);
      container.removeEventListener('touchmove', onTouchMove);
      container.removeEventListener('touchend', onTouchEnd);
      container.removeEventListener('touchcancel', onTouchEnd);
      if (window.DeviceOrientationEvent) {
        window.removeEventListener('deviceorientation', handleOrientation);
      }
      window.removeEventListener('resize', handleResize);
      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
      renderer.dispose();
    };
  }, []);

  return (
    <div className="absolute inset-0 w-full h-full pointer-events-none select-none overflow-hidden z-0">
      <div 
        ref={containerRef} 
        className="w-full h-full pointer-events-auto touch-pan-y cursor-grab active:cursor-grabbing"
      />
      {/* Mobile Interactive Touch Hint Chip */}
      {isMobileDevice && !hasInteracted && (
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 z-20 pointer-events-none animate-bounce">
          <div className="px-3.5 py-1.5 rounded-full bg-[#05060b]/80 border border-cyan-400/30 backdrop-blur-md text-[11px] font-mono-tech text-cyan-300 flex items-center gap-2 shadow-[0_0_15px_rgba(0,242,255,0.2)]">
            <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-ping" />
            <span>Drag to rotate 3D constellation</span>
          </div>
        </div>
      )}
    </div>
  );
};

```

---

## File: `src/components/CampusAnalyticsModal.tsx`

```tsx
import React, { useState } from 'react';
import { 
  X, 
  BarChart3, 
  TrendingUp, 
  Activity, 
  Zap, 
  ShieldCheck, 
  Layers, 
  Users, 
  ArrowUpRight,
  Clock,
  Sparkles,
  Award
} from 'lucide-react';

interface CampusAnalyticsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CampusAnalyticsModal: React.FC<CampusAnalyticsModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [metricTab, setMetricTab] = useState<'overview' | 'lending' | 'mentorship' | 'zk-proofs'>('overview');

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 overflow-y-auto bg-black/85 backdrop-blur-xl animate-in fade-in duration-200">
      
      <div className="relative w-full max-w-4xl bg-[#0b0c12] border border-white/15 rounded-3xl shadow-[0_0_80px_rgba(0,242,255,0.15)] flex flex-col overflow-hidden text-white max-h-[90vh]">
        
        {/* Ambient Glow */}
        <div className="absolute top-0 right-1/4 w-96 h-40 bg-[#00f2ff]/10 rounded-full blur-3xl pointer-events-none" />

        {/* Modal Header */}
        <div className="p-5 sm:p-6 border-b border-white/[0.08] flex items-center justify-between bg-[#0e0f18] relative z-10">
          <div>
            <div className="flex items-center gap-2 text-[11px] font-mono-tech tracking-[2px] text-[#00f2ff]">
              <BarChart3 className="w-4 h-4 text-[#00f2ff]" />
              <span>LIVE CAMPUS TELEMETRY // SEMESTER 2026</span>
            </div>
            <h3 className="text-xl sm:text-2xl font-black text-white font-heading mt-1">
              Detailed Campus Impact & Exchange Analytics
            </h3>
          </div>

          <button
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-white/[0.05] hover:bg-white/[0.1] text-white/70 hover:text-white flex items-center justify-center transition-colors cursor-pointer border border-white/10"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="px-6 py-3 bg-[#0d0e14] border-b border-white/5 flex items-center gap-2 overflow-x-auto scrollbar-none">
          {[
            { id: 'overview', label: 'Ecosystem Overview' },
            { id: 'lending', label: 'Peer Lending Flow' },
            { id: 'mentorship', label: 'Knowledge & Mentorship' },
            { id: 'zk-proofs', label: 'ZK Security & Trust' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setMetricTab(tab.id as any)}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-mono-tech uppercase tracking-wider transition-all cursor-pointer border ${
                metricTab === tab.id
                  ? 'bg-[#00f2ff] text-black font-bold border-[#00f2ff] shadow-[0_0_15px_rgba(0,242,255,0.3)]'
                  : 'bg-white/5 text-white/60 border-transparent hover:text-white hover:bg-white/10'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Body Content */}
        <div className="p-6 sm:p-8 space-y-6 overflow-y-auto custom-scrollbar flex-1">
          
          {/* Top 4 KPI Metrics */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 font-mono-tech">
            <div className="p-4 rounded-2xl bg-[#12131c] border border-white/10">
              <div className="text-[11px] text-white/50 flex items-center justify-between">
                <span>Active Peers</span>
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
              </div>
              <div className="text-2xl sm:text-3xl font-black text-white mt-1">1,480</div>
              <div className="text-[10px] text-emerald-400 mt-1 flex items-center gap-1">
                <ArrowUpRight className="w-3 h-3" />
                <span>+32% from last week</span>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-[#12131c] border border-white/10">
              <div className="text-[11px] text-white/50">Total Karma Circulating</div>
              <div className="text-2xl sm:text-3xl font-black text-[#00f2ff] mt-1">2.41M</div>
              <div className="text-[10px] text-[#00f2ff] mt-1">100% Non-inflationary</div>
            </div>

            <div className="p-4 rounded-2xl bg-[#12131c] border border-white/10">
              <div className="text-[11px] text-white/50">On-Time Return Rate</div>
              <div className="text-2xl sm:text-3xl font-black text-yellow-300 mt-1">99.99%</div>
              <div className="text-[10px] text-white/40 mt-1">12,480 loans verified</div>
            </div>

            <div className="p-4 rounded-2xl bg-[#12131c] border border-white/10">
              <div className="text-[11px] text-white/50">Saved Student Costs</div>
              <div className="text-2xl sm:text-3xl font-black text-emerald-400 mt-1">₹4.8L+</div>
              <div className="text-[10px] text-emerald-400 mt-1">Shared calculators & books</div>
            </div>
          </div>

          {/* Interactive Chart Visualization */}
          <div className="p-6 rounded-3xl bg-[#12131c] border border-white/10 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <h4 className="text-base font-bold text-white font-heading">
                  Hourly Campus Activity Velocity (24h Window)
                </h4>
                <p className="text-xs text-white/50 font-mono-tech">
                  Peak transaction windows during lab hours and evening study sprints
                </p>
              </div>
              <div className="flex items-center gap-4 text-xs font-mono-tech">
                <div className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-[#00f2ff]" />
                  <span className="text-white/70">Hardware Loans</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-[#c084fc]" />
                  <span className="text-white/70">Mentorship Hours</span>
                </div>
              </div>
            </div>

            {/* Visual Bar Spectrum */}
            <div className="h-44 flex items-end gap-1.5 sm:gap-3 pt-6 px-2 border-b border-white/10">
              {[30, 45, 25, 60, 80, 95, 70, 85, 100, 90, 65, 80, 50, 40, 75, 90, 85, 60].map((h, i) => (
                <div key={i} className="flex-1 flex flex-col items-center gap-1 group relative">
                  <div 
                    style={{ height: `${h}%` }}
                    className={`w-full rounded-t-lg transition-all duration-300 ${
                      i % 2 === 0 
                        ? 'bg-gradient-to-t from-[#00f2ff]/40 to-[#00f2ff] group-hover:brightness-125' 
                        : 'bg-gradient-to-t from-[#c084fc]/40 to-[#c084fc] group-hover:brightness-125'
                    }`}
                  />
                  <span className="text-[8px] font-mono-tech text-white/40 hidden sm:block">
                    {i * 1 + 6}:00
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Department Breakdown */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="p-5 rounded-2xl bg-[#12131c] border border-white/10 space-y-3">
              <h4 className="text-sm font-bold text-white font-heading">
                Top Departmental Contributions
              </h4>
              
              <div className="space-y-2 font-mono-tech text-xs">
                <div>
                  <div className="flex items-center justify-between text-white/70 mb-1">
                    <span>Computer Science & AI</span>
                    <span className="text-[#00f2ff] font-bold">42% (980 trades)</span>
                  </div>
                  <div className="h-2 rounded-full bg-white/5 overflow-hidden">
                    <div className="h-full bg-[#00f2ff] rounded-full w-[42%]" />
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between text-white/70 mb-1">
                    <span>Robotics & Embedded</span>
                    <span className="text-[#c084fc] font-bold">28% (650 trades)</span>
                  </div>
                  <div className="h-2 rounded-full bg-white/5 overflow-hidden">
                    <div className="h-full bg-[#c084fc] rounded-full w-[28%]" />
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between text-white/70 mb-1">
                    <span>Mechanical & Makerspace</span>
                    <span className="text-emerald-400 font-bold">18% (420 trades)</span>
                  </div>
                  <div className="h-2 rounded-full bg-white/5 overflow-hidden">
                    <div className="h-full bg-emerald-400 rounded-full w-[18%]" />
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between text-white/70 mb-1">
                    <span>Physics & BioTech</span>
                    <span className="text-amber-400 font-bold">12% (280 trades)</span>
                  </div>
                  <div className="h-2 rounded-full bg-white/5 overflow-hidden">
                    <div className="h-full bg-amber-400 rounded-full w-[12%]" />
                  </div>
                </div>
              </div>
            </div>

            {/* Zero Knowledge Audit Card */}
            <div className="p-5 rounded-2xl bg-[#12131c] border border-white/10 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <h4 className="text-sm font-bold text-white font-heading flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-emerald-400" />
                    <span>Zero-Knowledge Proof Audit</span>
                  </h4>
                  <span className="text-[9px] font-mono-tech text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                    VERIFIED
                  </span>
                </div>
                <p className="text-xs text-white/70 leading-relaxed font-normal">
                  Reputation math is calculated on cryptographic proofs without tracking student identities or selling student metadata.
                </p>
              </div>

              <div className="pt-4 border-t border-white/5 flex items-center justify-between text-xs font-mono-tech text-white/50">
                <span>Proof Block: #940,118</span>
                <span className="text-[#00f2ff]">LATENCY: 12ms</span>
              </div>
            </div>
          </div>

        </div>

        {/* Modal Footer */}
        <div className="p-4 sm:px-6 bg-[#0e0f18] border-t border-white/[0.08] flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-white text-black font-bold text-xs hover:bg-white/90 transition-all cursor-pointer font-mono-tech"
          >
            Done Viewing Telemetry
          </button>
        </div>

      </div>
    </div>
  );
};

```

---

## File: `src/components/CampusChatSection.tsx`

```tsx
import React, { useState, useEffect, useRef } from 'react';
import { 
  MessageSquare, 
  Send, 
  Search, 
  Lock, 
  Globe, 
  UserPlus, 
  Check, 
  CheckCheck,
  ShieldCheck, 
  Sparkles, 
  Building2, 
  Smile, 
  Paperclip, 
  Mic, 
  MicOff, 
  PhoneCall, 
  Video, 
  ChevronLeft, 
  UserCheck, 
  Clock, 
  Zap, 
  Award, 
  Trash2,
  Share2,
  ExternalLink,
  Code2,
  BookOpen,
  Cpu,
  MapPin,
  Play,
  Pause,
  ArrowDown,
  X,
  PhoneOff
} from 'lucide-react';
import { UserProfile, DirectMessage } from '../types';

interface CampusChatSectionProps {
  users: UserProfile[];
  currentUser: UserProfile;
  messages: DirectMessage[];
  onSendMessage: (targetUserId: string, text: string) => void;
  onSendFriendRequest: (targetUserId: string) => void;
  onClearConversation?: (targetUserId: string) => void;
  onOpenPassport: (user: UserProfile) => void;
  selectedUserId?: string;
  onSelectUser?: (user: UserProfile) => void;
}

const CHAT_QUICK_PROMPTS = [
  '👋 Hey, are you free for a quick chat?',
  '📚 Can I borrow your lab notes or study guide?',
  '🚀 Interested in teaming up for the upcoming hackathon?',
  '⚡ Want to do a peer skill-swap session this week?',
  '🛠️ Is your hardware / lab gear available to borrow?',
  '☕ Free for a quick coffee at the campus food court?'
];

export const CampusChatSection: React.FC<CampusChatSectionProps> = ({
  users,
  currentUser,
  messages,
  onSendMessage,
  onSendFriendRequest,
  onClearConversation,
  onOpenPassport,
  selectedUserId,
  onSelectUser,
}) => {
  // Available peers who are NOT the current user
  const availablePeers = users.filter((u) => u.id !== currentUser.id);
  const defaultPeer = availablePeers[0] || users[0];

  // Active peer ID
  const [activePeerId, setActivePeerId] = useState<string>(() => {
    if (selectedUserId && selectedUserId !== currentUser.id && users.some((u) => u.id === selectedUserId)) {
      return selectedUserId;
    }
    return defaultPeer ? defaultPeer.id : 'u1';
  });

  // Search & Filter state
  const [searchQuery, setSearchQuery] = useState('');
  const [filterTab, setFilterTab] = useState<'all' | 'recent' | 'friends' | 'public' | 'wing'>('all');
  
  // In-chat search
  const [isSearchingInChat, setIsSearchingInChat] = useState(false);
  const [inChatSearchQuery, setInChatSearchQuery] = useState('');

  // Input states
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [showAttachmentMenu, setShowAttachmentMenu] = useState(false);
  const [mobileView, setMobileView] = useState<'list' | 'chat'>('chat');

  // Voice recording state
  const [isRecording, setIsRecording] = useState(false);
  const [recordingSeconds, setRecordingSeconds] = useState(0);
  const [playingVoiceId, setPlayingVoiceId] = useState<string | null>(null);

  // Call simulation state
  const [activeCallType, setActiveCallType] = useState<'audio' | 'video' | null>(null);
  const [callDuration, setCallDuration] = useState(0);

  // Clear confirmation modal state
  const [showClearConfirm, setShowClearConfirm] = useState(false);

  // References
  const chatMessagesContainerRef = useRef<HTMLDivElement>(null);
  const recordingTimerRef = useRef<any>(null);
  const callTimerRef = useRef<any>(null);
  const textInputRef = useRef<HTMLInputElement>(null);

  // Sync external selectedUserId
  useEffect(() => {
    if (selectedUserId && selectedUserId !== currentUser.id && users.some((u) => u.id === selectedUserId)) {
      setActivePeerId(selectedUserId);
      setMobileView('chat');
    }
  }, [selectedUserId, currentUser.id, users]);

  // Keep activePeer valid
  const activePeer = users.find((u) => u.id === activePeerId) || defaultPeer || currentUser;

  // Filter conversation messages
  const conversation = messages.filter(
    (m) =>
      (m.senderId === currentUser.id && m.receiverId === activePeer.id) ||
      (m.senderId === activePeer.id && m.receiverId === currentUser.id)
  );

  // In-chat searched messages
  const displayedConversation = inChatSearchQuery.trim()
    ? conversation.filter((m) =>
        m.text.toLowerCase().includes(inChatSearchQuery.toLowerCase())
      )
    : conversation;

  // Container-only smooth scroll: NEVER uses scrollIntoView which causes outer screen jumping!
  const scrollToBottom = (smooth = true) => {
    if (chatMessagesContainerRef.current) {
      chatMessagesContainerRef.current.scrollTo({
        top: chatMessagesContainerRef.current.scrollHeight,
        behavior: smooth ? 'smooth' : 'auto',
      });
    }
  };

  useEffect(() => {
    // Only scroll within the chat container
    const timeout = setTimeout(() => {
      scrollToBottom(true);
    }, 50);
    return () => clearTimeout(timeout);
  }, [conversation.length, isTyping, activePeerId]);

  // Voice recording timer
  useEffect(() => {
    if (isRecording) {
      setRecordingSeconds(0);
      recordingTimerRef.current = setInterval(() => {
        setRecordingSeconds((prev) => prev + 1);
      }, 1000);
    } else {
      if (recordingTimerRef.current) clearInterval(recordingTimerRef.current);
    }
    return () => {
      if (recordingTimerRef.current) clearInterval(recordingTimerRef.current);
    };
  }, [isRecording]);

  // Call duration timer
  useEffect(() => {
    if (activeCallType) {
      setCallDuration(0);
      callTimerRef.current = setInterval(() => {
        setCallDuration((prev) => prev + 1);
      }, 1000);
    } else {
      if (callTimerRef.current) clearInterval(callTimerRef.current);
    }
    return () => {
      if (callTimerRef.current) clearInterval(callTimerRef.current);
    };
  }, [activeCallType]);

  // Calculations for active peer
  const isFriend = (currentUser.friendIds || []).includes(activePeer.id);
  const isPrivate = !!activePeer.isPrivate;

  // Filter peers for left roster
  const filteredPeers = availablePeers.filter((u) => {
    const matchesSearch = 
      u.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      u.department.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (u.hostelWing && u.hostelWing.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (u.skillsOffered && u.skillsOffered.some((s) => s.toLowerCase().includes(searchQuery.toLowerCase())));

    if (!matchesSearch) return false;

    if (filterTab === 'friends') {
      return (currentUser.friendIds || []).includes(u.id);
    }
    if (filterTab === 'public') {
      return !u.isPrivate;
    }
    if (filterTab === 'wing') {
      return (
        currentUser.hostelWing &&
        u.hostelWing &&
        currentUser.hostelWing.split('(')[0].trim() === u.hostelWing.split('(')[0].trim()
      );
    }
    if (filterTab === 'recent') {
      return messages.some(
        (m) =>
          (m.senderId === u.id && m.receiverId === currentUser.id) ||
          (m.senderId === currentUser.id && m.receiverId === u.id)
      );
    }
    return true;
  });

  // Last message in thread
  const getLastMessageForPeer = (peerId: string) => {
    const peerMsgs = messages.filter(
      (m) =>
        (m.senderId === currentUser.id && m.receiverId === peerId) ||
        (m.senderId === peerId && m.receiverId === currentUser.id)
    );
    if (peerMsgs.length === 0) return null;
    return peerMsgs[peerMsgs.length - 1];
  };

  // Main send message handler
  const handleSendMessage = (textToSend?: string) => {
    const text = (textToSend !== undefined ? textToSend : inputText).trim();
    if (!text || !activePeer) return;

    onSendMessage(activePeer.id, text);
    setInputText('');
    setShowEmojiPicker(false);
    setShowAttachmentMenu(false);

    // Auto-focus input
    if (textInputRef.current) {
      textInputRef.current.focus();
    }

    // Trigger typing simulation
    setIsTyping(true);
    setTimeout(() => {
      setIsTyping(false);
    }, 1200);
  };

  const handleSelectPeer = (peer: UserProfile) => {
    setActivePeerId(peer.id);
    setMobileView('chat');
    setIsSearchingInChat(false);
    setInChatSearchQuery('');
    if (onSelectUser) onSelectUser(peer);
  };

  // Voice note send
  const handleFinishVoiceRecording = () => {
    if (recordingSeconds < 1) {
      setIsRecording(false);
      return;
    }
    const voiceMsg = `🎙️ [Voice Note • ${recordingSeconds}s] (High-Fidelity Audio Stream)`;
    handleSendMessage(voiceMsg);
    setIsRecording(false);
  };

  // Attachment send options
  const handleSendAttachment = (type: 'notes' | 'code' | 'gear' | 'location') => {
    setShowAttachmentMenu(false);
    let attachText = '';
    if (type === 'notes') {
      attachText = `📄 [Attached Document]: ${activePeer.department.split(',')[0]} Semester Notes & Lab Manual (PDF • 3.8 MB)`;
    } else if (type === 'code') {
      attachText = `💻 [Attached Code Snippet]:\n\`\`\`typescript\n// Campus Hub Controller\nexport const broadcastPeerSync = async () => {\n  console.log("Peer link verified");\n};\n\`\`\``;
    } else if (type === 'gear') {
      attachText = `🛠️ [Equipment Loan Request]: Casio fx-991EX Scientific Calculator & Breadboard Kit`;
    } else if (type === 'location') {
      attachText = `📍 [Campus Location Pin]: Central Library 2nd Floor Study Wing (Near Wi-Fi Hub 04)`;
    }
    handleSendMessage(attachText);
  };

  const formatTimer = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  return (
    <section id="chat" className="py-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto relative scroll-mt-20">
      {/* Background Glows */}
      <div className="absolute top-1/4 -left-20 w-96 h-96 bg-[#00f2ff]/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-10 -right-20 w-96 h-96 bg-[#c084fc]/10 rounded-full blur-3xl pointer-events-none" />

      {/* Section Header */}
      <div className="text-center max-w-3xl mx-auto mb-10">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#00f2ff]/10 border border-[#00f2ff]/30 text-[#00f2ff] text-xs font-mono-tech uppercase tracking-wider mb-4 shadow-[0_0_20px_rgba(0,242,255,0.15)]">
          <MessageSquare className="w-3.5 h-3.5" />
          <span>Real-Time P2P Network</span>
        </div>

        <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white font-heading tracking-tight">
          CAMPUS <span className="bg-gradient-to-r from-[#00f2ff] via-sky-300 to-[#c084fc] bg-clip-text text-transparent">PEER CHATBOX</span>
        </h2>

        <p className="mt-3 text-sm sm:text-base text-white/60 font-sans max-w-2xl mx-auto">
          Direct, interactive campus messaging. Connect with classmates across hostel wings, request lab equipment loans, coordinate hackathons, share notes, or swap skills instantly.
        </p>

        {/* Live Statistics Bar */}
        <div className="mt-6 flex flex-wrap items-center justify-center gap-3 text-xs font-mono-tech">
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-white/[0.03] border border-white/[0.08] text-white/80">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span><strong>{users.length}</strong> Verified Peers Online</span>
          </div>

          <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-white/[0.03] border border-white/[0.08] text-white/80">
            <ShieldCheck className="w-3.5 h-3.5 text-[#00f2ff]" />
            <span>End-to-End Campus ID Verified</span>
          </div>

          <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-white/[0.03] border border-white/[0.08] text-white/80">
            <Zap className="w-3.5 h-3.5 text-amber-400" />
            <span>Instant Direct Messaging Active</span>
          </div>
        </div>
      </div>

      {/* Responsive View Switcher (Visible on mobile/tablet screens < lg) */}
      <div className="lg:hidden mb-4 bg-[#0a0b12] border border-white/10 rounded-2xl p-1.5 flex items-center gap-1.5 shadow-lg">
        <button
          type="button"
          onClick={() => setMobileView('list')}
          className={`flex-1 py-2.5 px-3 rounded-xl text-xs font-mono-tech flex items-center justify-center gap-2 transition-all cursor-pointer ${
            mobileView === 'list'
              ? 'bg-[#00f2ff] text-black font-bold shadow-[0_0_15px_rgba(0,242,255,0.4)]'
              : 'text-white/70 hover:text-white hover:bg-white/[0.05]'
          }`}
        >
          <UserCheck className="w-3.5 h-3.5" />
          <span>Peers ({availablePeers.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setMobileView('chat')}
          className={`flex-1 py-2.5 px-3 rounded-xl text-xs font-mono-tech flex items-center justify-center gap-2 transition-all cursor-pointer ${
            mobileView === 'chat'
              ? 'bg-gradient-to-r from-[#00f2ff] to-[#c084fc] text-black font-bold shadow-[0_0_15px_rgba(0,242,255,0.4)]'
              : 'text-white/70 hover:text-white hover:bg-white/[0.05]'
          }`}
        >
          <MessageSquare className="w-3.5 h-3.5" />
          <span className="truncate">Chat: {activePeer.name.split(' ')[0]}</span>
        </button>
      </div>

      {/* Main Dual-Pane Chatbox Container */}
      <div 
        id="campus-chatbox-main"
        className="w-full bg-[#0a0b12] border border-white/[0.12] rounded-3xl shadow-[0_0_50px_rgba(0,0,0,0.8)] overflow-hidden grid grid-cols-1 lg:grid-cols-12 min-h-[580px] h-[720px] max-h-[85vh] relative backdrop-blur-2xl"
      >
        {/* ======================================================== */}
        {/* LEFT PANEL: Student Contact Directory & Threads (4 Cols) */}
        {/* ======================================================== */}
        <div 
          className={`lg:col-span-4 lg:border-r border-white/[0.08] flex flex-col min-h-0 bg-[#07080e] h-full ${
            mobileView === 'chat' ? 'hidden lg:flex' : 'flex'
          }`}
        >
          {/* Active Peer Quick Banner on mobile roster */}
          <div className="lg:hidden p-2.5 bg-gradient-to-r from-[#00f2ff]/10 to-[#c084fc]/10 border-b border-[#00f2ff]/20 flex items-center justify-between">
            <div className="flex items-center gap-2 text-xs font-sans text-white/90">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>Active: <strong className="text-[#00f2ff]">{activePeer.name}</strong></span>
            </div>
            <button
              onClick={() => setMobileView('chat')}
              className="px-2.5 py-1 rounded-lg bg-[#00f2ff] text-black text-[11px] font-mono-tech font-bold hover:brightness-110 cursor-pointer"
            >
              Open Chatbox 💬
            </button>
          </div>

          {/* Left Top: Current User Identity & Search */}
          <div className="p-4 border-b border-white/[0.08] bg-[#0c0d16]/80 backdrop-blur-md shrink-0">
            {/* Current user banner */}
            <div className="flex items-center justify-between mb-3.5">
              <div className="flex items-center gap-2.5">
                <div className="relative">
                  <img
                    src={currentUser.avatar}
                    alt={currentUser.name}
                    className="w-9 h-9 rounded-xl object-cover border border-[#00f2ff]/40"
                  />
                  <span className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 bg-emerald-400 border-2 border-[#07080e] rounded-full" />
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs font-bold text-white truncate max-w-[130px] font-heading">{currentUser.name}</span>
                    <span className="text-[9px] font-mono-tech text-[#00f2ff] px-1 py-0.2 rounded bg-[#00f2ff]/10">#{currentUser.rank}</span>
                  </div>
                  <div className="text-[10px] font-mono-tech text-white/50 flex items-center gap-1">
                    {currentUser.isPrivate ? (
                      <span className="text-amber-300 flex items-center gap-0.5">
                        <Lock className="w-2.5 h-2.5" /> Private
                      </span>
                    ) : (
                      <span className="text-emerald-400 flex items-center gap-0.5">
                        <Globe className="w-2.5 h-2.5" /> Public
                      </span>
                    )}
                    <span>• {currentUser.hostelWing ? currentUser.hostelWing.split('(')[0] : 'Campus'}</span>
                  </div>
                </div>
              </div>

              <button
                onClick={() => onOpenPassport(currentUser)}
                className="text-[11px] font-mono-tech px-2 py-1 rounded-lg bg-white/[0.05] hover:bg-white/10 text-white/70 hover:text-white border border-white/10 transition-colors cursor-pointer"
                title="View your student passport"
              >
                My ID
              </button>
            </div>

            {/* Peer Search Input */}
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-white/40 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search peers, wings, skills..."
                className="w-full bg-[#141624] border border-white/10 rounded-xl pl-9 pr-3 py-2 text-xs text-white placeholder-white/40 focus:outline-none focus:border-[#00f2ff]/60 transition-colors font-sans"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[10px] text-white/40 hover:text-white"
                >
                  Clear
                </button>
              )}
            </div>

            {/* Filter Tabs */}
            <div className="flex items-center gap-1 mt-3 overflow-x-auto pb-1 no-scrollbar text-[11px] font-mono-tech">
              <button
                onClick={() => setFilterTab('all')}
                className={`px-2.5 py-1 rounded-lg whitespace-nowrap transition-colors cursor-pointer ${
                  filterTab === 'all'
                    ? 'bg-[#00f2ff] text-black font-bold shadow-[0_0_10px_rgba(0,242,255,0.3)]'
                    : 'bg-white/[0.04] text-white/60 hover:text-white hover:bg-white/[0.08]'
                }`}
              >
                All ({availablePeers.length})
              </button>

              <button
                onClick={() => setFilterTab('friends')}
                className={`px-2.5 py-1 rounded-lg whitespace-nowrap flex items-center gap-1 transition-colors cursor-pointer ${
                  filterTab === 'friends'
                    ? 'bg-[#00f2ff] text-black font-bold shadow-[0_0_10px_rgba(0,242,255,0.3)]'
                    : 'bg-white/[0.04] text-white/60 hover:text-white hover:bg-white/[0.08]'
                }`}
              >
                <UserCheck className="w-3 h-3" />
                Friends ({(currentUser.friendIds || []).length})
              </button>

              <button
                onClick={() => setFilterTab('recent')}
                className={`px-2.5 py-1 rounded-lg whitespace-nowrap flex items-center gap-1 transition-colors cursor-pointer ${
                  filterTab === 'recent'
                    ? 'bg-[#00f2ff] text-black font-bold shadow-[0_0_10px_rgba(0,242,255,0.3)]'
                    : 'bg-white/[0.04] text-white/60 hover:text-white hover:bg-white/[0.08]'
                }`}
              >
                <Clock className="w-3 h-3" />
                Recent
              </button>

              <button
                onClick={() => setFilterTab('public')}
                className={`px-2.5 py-1 rounded-lg whitespace-nowrap flex items-center gap-1 transition-colors cursor-pointer ${
                  filterTab === 'public'
                    ? 'bg-[#00f2ff] text-black font-bold shadow-[0_0_10px_rgba(0,242,255,0.3)]'
                    : 'bg-white/[0.04] text-white/60 hover:text-white hover:bg-white/[0.08]'
                }`}
              >
                <Globe className="w-3 h-3" />
                Public
              </button>

              <button
                onClick={() => setFilterTab('wing')}
                className={`px-2.5 py-1 rounded-lg whitespace-nowrap flex items-center gap-1 transition-colors cursor-pointer ${
                  filterTab === 'wing'
                    ? 'bg-[#00f2ff] text-black font-bold shadow-[0_0_10px_rgba(0,242,255,0.3)]'
                    : 'bg-white/[0.04] text-white/60 hover:text-white hover:bg-white/[0.08]'
                }`}
              >
                <Building2 className="w-3 h-3" />
                Hostel
              </button>
            </div>
          </div>

          {/* Student Peer List Stream */}
          <div className="flex-1 min-h-0 overflow-y-auto divide-y divide-white/[0.04] p-2 space-y-1 custom-scrollbar">
            {filteredPeers.length === 0 ? (
              <div className="p-8 text-center text-white/40 font-mono-tech text-xs">
                <MessageSquare className="w-8 h-8 mx-auto mb-2 text-white/20" />
                <p>No peers found matching your filter.</p>
              </div>
            ) : (
              filteredPeers.map((peer) => {
                const isSelected = peer.id === activePeer.id;
                const lastMsg = getLastMessageForPeer(peer.id);
                const isPeerFriend = (currentUser.friendIds || []).includes(peer.id);
                const isPeerPrivate = !!peer.isPrivate;

                return (
                  <div
                    key={peer.id}
                    onClick={() => handleSelectPeer(peer)}
                    className={`p-3 rounded-2xl cursor-pointer transition-all flex items-start gap-3 relative group ${
                      isSelected
                        ? 'bg-gradient-to-r from-[#00f2ff]/15 to-[#c084fc]/10 border border-[#00f2ff]/50 shadow-[0_0_20px_rgba(0,242,255,0.15)]'
                        : 'hover:bg-white/[0.04] border border-transparent'
                    }`}
                  >
                    {/* Avatar with rank & online badge */}
                    <div className="relative shrink-0">
                      <img
                        src={peer.avatar}
                        alt={peer.name}
                        className={`w-11 h-11 rounded-2xl object-cover border transition-all ${
                          isSelected ? 'border-[#00f2ff]' : 'border-white/10 group-hover:border-white/30'
                        }`}
                      />
                      <span className="absolute -bottom-1 -right-1 px-1.5 py-0.2 rounded-md bg-black/90 border border-white/20 text-[#00f2ff] text-[9px] font-mono-tech font-bold">
                        #{peer.rank}
                      </span>
                    </div>

                    {/* Peer details & last message preview */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-1 mb-0.5">
                        <div className="flex items-center gap-1.5 truncate">
                          <span className={`text-xs font-bold font-heading truncate ${isSelected ? 'text-[#00f2ff]' : 'text-white'}`}>
                            {peer.name}
                          </span>
                          <ShieldCheck className="w-3 h-3 text-[#00f2ff] shrink-0" />
                        </div>
                        {lastMsg && (
                          <span className="text-[10px] font-mono-tech text-white/40 whitespace-nowrap shrink-0">
                            {lastMsg.timestamp}
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-2 text-[10px] font-mono-tech text-white/50 mb-1">
                        <span className="truncate max-w-[130px]">{peer.department.split(',')[0]}</span>
                        <span>•</span>
                        {isPeerPrivate ? (
                          <span className="text-amber-300 flex items-center gap-0.5 shrink-0">
                            <Lock className="w-2.5 h-2.5" /> Private
                          </span>
                        ) : (
                          <span className="text-emerald-400 flex items-center gap-0.5 shrink-0">
                            <Globe className="w-2.5 h-2.5" /> Public
                          </span>
                        )}
                      </div>

                      {/* Message preview or skill tags */}
                      {lastMsg ? (
                        <p className={`text-xs truncate ${isSelected ? 'text-white/90' : 'text-white/60'}`}>
                          {lastMsg.senderId === currentUser.id ? 'You: ' : ''}
                          {lastMsg.text}
                        </p>
                      ) : (
                        <p className="text-[11px] text-white/40 truncate">
                          Skills: {peer.skillsOffered && peer.skillsOffered.length > 0 ? peer.skillsOffered.slice(0, 2).join(', ') : 'Peer Exchange'}
                        </p>
                      )}
                    </div>

                    {/* Friend connected dot */}
                    {isPeerFriend && (
                      <span className="w-2 h-2 rounded-full bg-emerald-400 absolute top-3 right-2 shadow-[0_0_8px_rgba(52,211,153,0.8)]" title="Connected Friend" />
                    )}
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* ======================================================== */}
        {/* RIGHT PANEL: Active Conversation & Interactive Chat (8 Cols) */}
        {/* ======================================================== */}
        <div 
          className={`lg:col-span-8 flex flex-col h-full min-h-0 bg-[#080911] relative ${
            mobileView === 'list' ? 'hidden lg:flex' : 'flex'
          }`}
        >
          {/* Simulated P2P Call Banner */}
          {activeCallType && (
            <div className="p-3 bg-gradient-to-r from-cyan-900/90 to-blue-950/90 border-b border-[#00f2ff]/30 text-white flex items-center justify-between z-30 shadow-2xl animate-in slide-in-from-top">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-[#00f2ff]/20 border border-[#00f2ff] flex items-center justify-center animate-pulse">
                  {activeCallType === 'video' ? <Video className="w-4 h-4 text-[#00f2ff]" /> : <PhoneCall className="w-4 h-4 text-[#00f2ff]" />}
                </div>
                <div>
                  <div className="text-xs font-bold text-white flex items-center gap-2">
                    <span>{activeCallType === 'video' ? 'Campus P2P Video Call' : 'Encrypted Campus Audio Stream'} with {activePeer.name}</span>
                    <span className="text-[10px] font-mono-tech text-emerald-400 bg-emerald-500/20 px-1.5 py-0.2 rounded">CONNECTED</span>
                  </div>
                  <div className="text-[10px] font-mono-tech text-white/60">
                    Duration: {formatTimer(callDuration)} • WebRTC P2P Latency: 12ms
                  </div>
                </div>
              </div>

              <button
                onClick={() => setActiveCallType(null)}
                className="px-3 py-1.5 rounded-xl bg-red-500 hover:bg-red-600 text-white text-xs font-mono-tech font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <PhoneOff className="w-3.5 h-3.5" />
                <span>End Call</span>
              </button>
            </div>
          )}

          {/* Chat Window Header */}
          <div className="p-4 sm:p-5 border-b border-white/[0.08] flex items-center justify-between bg-[#0e0f1a]/95 backdrop-blur-md relative z-10">
            <div className="flex items-center gap-3">
              {/* Mobile Back button */}
              <button
                onClick={() => setMobileView('list')}
                className="lg:hidden p-1.5 rounded-xl bg-white/[0.05] border border-white/10 text-white hover:bg-white/10 cursor-pointer"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>

              {/* Active Peer Avatar */}
              <div 
                onClick={() => onOpenPassport(activePeer)}
                className="relative cursor-pointer group shrink-0"
                title="Click to view student passport"
              >
                <img
                  src={activePeer.avatar}
                  alt={activePeer.name}
                  className="w-11 h-11 rounded-2xl object-cover border-2 border-[#00f2ff]/50 group-hover:border-[#00f2ff] transition-all"
                />
                <span className="absolute -bottom-1 -right-1 px-1.5 py-0.2 rounded-full bg-[#00f2ff] text-black text-[9px] font-mono-tech font-bold">
                  #{activePeer.rank}
                </span>
              </div>

              {/* Active Peer Info */}
              <div>
                <div className="flex items-center gap-2">
                  <h3 
                    onClick={() => onOpenPassport(activePeer)}
                    className="text-base font-bold text-white font-heading cursor-pointer hover:text-[#00f2ff] transition-colors"
                  >
                    {activePeer.name}
                  </h3>
                  <span className="text-[10px] font-mono-tech text-[#00f2ff] px-2 py-0.5 rounded-full bg-[#00f2ff]/10 border border-[#00f2ff]/30">
                    {activePeer.title}
                  </span>
                </div>

                <div className="flex flex-wrap items-center gap-2 text-xs font-mono-tech mt-0.5">
                  <span className="text-white/60">{activePeer.department}</span>
                  <span className="text-white/30">•</span>
                  {activePeer.hostelWing && (
                    <>
                      <span className="text-white/50 flex items-center gap-1">
                        <Building2 className="w-3 h-3 text-white/40" />
                        {activePeer.hostelWing}
                      </span>
                      <span className="text-white/30">•</span>
                    </>
                  )}
                  {isPrivate ? (
                    <span className="text-amber-300 flex items-center gap-1 text-[11px]">
                      <Lock className="w-3 h-3" /> Private Peer ID
                    </span>
                  ) : (
                    <span className="text-emerald-400 flex items-center gap-1 text-[11px]">
                      <Globe className="w-3 h-3" /> Public Messaging Active
                    </span>
                  )}
                </div>
              </div>
            </div>

            {/* Header Actions */}
            <div className="flex items-center gap-1.5">
              {/* Call Simulation Buttons */}
              <button
                onClick={() => setActiveCallType('audio')}
                className="p-2 rounded-xl bg-white/[0.05] hover:bg-[#00f2ff]/20 text-white/70 hover:text-[#00f2ff] border border-white/10 transition-colors cursor-pointer"
                title="Start Encrypted Campus Audio Call"
              >
                <PhoneCall className="w-4 h-4" />
              </button>

              <button
                onClick={() => setActiveCallType('video')}
                className="p-2 rounded-xl bg-white/[0.05] hover:bg-[#c084fc]/20 text-white/70 hover:text-[#c084fc] border border-white/10 transition-colors cursor-pointer"
                title="Start Campus Video Call"
              >
                <Video className="w-4 h-4" />
              </button>

              {/* Search Inside Chat */}
              <button
                onClick={() => setIsSearchingInChat(!isSearchingInChat)}
                className={`p-2 rounded-xl border transition-colors cursor-pointer ${
                  isSearchingInChat
                    ? 'bg-[#00f2ff] text-black border-[#00f2ff]'
                    : 'bg-white/[0.05] hover:bg-white/10 text-white/70 hover:text-white border-white/10'
                }`}
                title="Search conversation messages"
              >
                <Search className="w-4 h-4" />
              </button>

              {/* Clear Thread */}
              {onClearConversation && conversation.length > 0 && (
                <button
                  onClick={() => setShowClearConfirm(true)}
                  className="p-2 rounded-xl bg-white/[0.05] hover:bg-red-500/20 text-white/70 hover:text-red-400 border border-white/10 transition-colors cursor-pointer"
                  title="Clear conversation messages"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              )}

              {/* View Passport */}
              <button
                onClick={() => onOpenPassport(activePeer)}
                className="hidden sm:inline-flex items-center gap-1.5 text-xs font-mono-tech px-3 py-1.5 rounded-xl bg-white/[0.05] hover:bg-white/10 text-white/80 hover:text-white border border-white/10 transition-colors cursor-pointer"
              >
                <Award className="w-3.5 h-3.5 text-[#00f2ff]" />
                <span>Passport</span>
              </button>
            </div>
          </div>

          {/* In-Chat Search Bar */}
          {isSearchingInChat && (
            <div className="p-2.5 bg-[#0c0e1a] border-b border-white/10 flex items-center gap-2 px-4 animate-in fade-in duration-150">
              <Search className="w-3.5 h-3.5 text-[#00f2ff]" />
              <input
                type="text"
                value={inChatSearchQuery}
                onChange={(e) => setInChatSearchQuery(e.target.value)}
                placeholder={`Search words in chat with ${activePeer.name}...`}
                className="flex-1 bg-transparent text-xs text-white placeholder-white/40 focus:outline-none font-sans"
                autoFocus
              />
              {inChatSearchQuery && (
                <span className="text-[10px] font-mono-tech text-white/50">
                  {displayedConversation.length} matches
                </span>
              )}
              <button
                onClick={() => {
                  setIsSearchingInChat(false);
                  setInChatSearchQuery('');
                }}
                className="text-white/40 hover:text-white text-xs p-1"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          {/* Clear Conversation Confirmation Modal */}
          {showClearConfirm && (
            <div className="absolute inset-0 z-40 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in">
              <div className="bg-[#121422] border border-white/15 rounded-3xl p-6 max-w-sm w-full text-center space-y-4 shadow-2xl">
                <div className="w-12 h-12 rounded-2xl bg-red-500/10 border border-red-500/30 flex items-center justify-center mx-auto text-red-400">
                  <Trash2 className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="text-base font-bold text-white font-heading">Clear Conversation?</h4>
                  <p className="text-xs text-white/60 font-sans mt-1">
                    This will remove the current message history between you and <strong>{activePeer.name}</strong>.
                  </p>
                </div>
                <div className="flex items-center gap-2 pt-2">
                  <button
                    onClick={() => setShowClearConfirm(false)}
                    className="flex-1 py-2.5 rounded-xl bg-white/[0.06] hover:bg-white/10 text-white text-xs font-mono-tech transition-colors cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={() => {
                      if (onClearConversation) onClearConversation(activePeer.id);
                      setShowClearConfirm(false);
                    }}
                    className="flex-1 py-2.5 rounded-xl bg-red-500 hover:bg-red-600 text-white text-xs font-mono-tech font-bold transition-colors cursor-pointer shadow-[0_0_15px_rgba(239,68,68,0.4)]"
                  >
                    Clear Chat
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Scrollable Conversation Stream Container */}
          <div 
            ref={chatMessagesContainerRef}
            className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4 custom-scrollbar"
          >
            {/* Security and encryption notice */}
            <div className="flex justify-center mb-2">
              <div className="px-3.5 py-1.5 rounded-full bg-white/[0.03] border border-white/[0.06] text-white/40 text-[10px] font-mono-tech flex items-center gap-1.5">
                <ShieldCheck className="w-3 h-3 text-[#00f2ff]" />
                <span>Verified On-Campus Peer Link • Student ID Protected</span>
              </div>
            </div>

            {displayedConversation.length === 0 ? (
              <div className="h-full min-h-[220px] flex flex-col items-center justify-center text-center p-8 text-white/40 space-y-3">
                <div className="w-12 h-12 rounded-2xl bg-white/[0.03] border border-white/[0.08] flex items-center justify-center text-[#00f2ff]">
                  <MessageSquare className="w-6 h-6" />
                </div>
                <div>
                  <p className="text-sm font-bold text-white font-heading">Start a conversation with {activePeer.name}</p>
                  <p className="text-xs text-white/50 font-sans mt-1">
                    Send a message below, record a voice note, or pick from quick campus prompts.
                  </p>
                </div>
              </div>
            ) : (
              displayedConversation.map((msg) => {
                const isMe = msg.senderId === currentUser.id;
                const isVoiceNote = msg.text.startsWith('🎙️ [Voice Note');
                const isAttachment = msg.text.startsWith('📄 [Attached') || msg.text.startsWith('💻 [Attached') || msg.text.startsWith('🛠️ [Equipment') || msg.text.startsWith('📍 [Campus');

                return (
                  <div
                    key={msg.id}
                    className={`flex gap-3 ${isMe ? 'justify-end' : 'justify-start'}`}
                  >
                    {!isMe && (
                      <img
                        src={activePeer.avatar}
                        alt={activePeer.name}
                        className="w-8 h-8 rounded-xl object-cover border border-white/10 self-end mb-1 shrink-0"
                      />
                    )}

                    <div
                      className={`max-w-[85%] sm:max-w-[70%] rounded-2xl p-3.5 text-xs sm:text-sm font-sans ${
                        isMe
                          ? 'bg-gradient-to-r from-[#00f2ff]/20 to-[#c084fc]/15 border border-[#00f2ff]/40 text-white rounded-br-none shadow-[0_0_20px_rgba(0,242,255,0.1)]'
                          : 'bg-[#141626] border border-white/10 text-white/90 rounded-bl-none'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-3 mb-1">
                        <span className="text-[10px] font-mono-tech text-white/50">
                          {isMe ? 'You' : activePeer.name}
                        </span>
                        <span className="text-[9px] font-mono-tech text-white/40">
                          {msg.timestamp}
                        </span>
                      </div>

                      {/* Voice Note Rendering */}
                      {isVoiceNote ? (
                        <div className="flex items-center gap-3 py-1">
                          <button
                            type="button"
                            onClick={() => {
                              if (playingVoiceId === msg.id) {
                                setPlayingVoiceId(null);
                              } else {
                                setPlayingVoiceId(msg.id);
                                setTimeout(() => setPlayingVoiceId(null), 4000);
                              }
                            }}
                            className="w-8 h-8 rounded-full bg-[#00f2ff] text-black flex items-center justify-center shrink-0 hover:scale-105 transition-transform cursor-pointer"
                          >
                            {playingVoiceId === msg.id ? (
                              <Pause className="w-4 h-4 fill-black" />
                            ) : (
                              <Play className="w-4 h-4 fill-black ml-0.5" />
                            )}
                          </button>

                          <div className="flex-1 space-y-1">
                            <div className="flex items-center gap-0.5 h-5">
                              {[12, 24, 16, 28, 10, 22, 32, 18, 26, 14, 20, 16, 24, 10].map((h, i) => (
                                <span
                                  key={i}
                                  style={{ height: `${h}px` }}
                                  className={`w-1 rounded-full transition-colors ${
                                    playingVoiceId === msg.id
                                      ? 'bg-[#00f2ff] animate-pulse'
                                      : 'bg-white/30'
                                  }`}
                                />
                              ))}
                            </div>
                            <div className="text-[10px] font-mono-tech text-[#00f2ff]">
                              {playingVoiceId === msg.id ? 'Playing Voice Stream...' : 'Voice Note'}
                            </div>
                          </div>
                        </div>
                      ) : isAttachment ? (
                        <div className="p-2.5 rounded-xl bg-black/40 border border-white/10 space-y-1 font-mono-tech text-xs">
                          <p className="leading-relaxed whitespace-pre-wrap text-[#00f2ff]">{msg.text}</p>
                        </div>
                      ) : (
                        <p className="leading-relaxed whitespace-pre-wrap">{msg.text}</p>
                      )}

                      {isMe && (
                        <div className="flex justify-end mt-1 text-[9px] font-mono-tech text-[#00f2ff] items-center gap-0.5">
                          <CheckCheck className="w-3.5 h-3.5" />
                          <span>Delivered</span>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })
            )}

            {/* Live Typing Indicator */}
            {isTyping && (
              <div className="flex gap-3 justify-start items-center">
                <img
                  src={activePeer.avatar}
                  alt={activePeer.name}
                  className="w-8 h-8 rounded-xl object-cover border border-white/10 shrink-0"
                />
                <div className="bg-[#141626] border border-white/10 rounded-2xl rounded-bl-none px-4 py-2.5 text-xs text-white/60 flex items-center gap-2">
                  <span className="text-[11px] font-mono-tech text-[#00f2ff]">{activePeer.name} is typing</span>
                  <div className="flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#00f2ff] animate-bounce" />
                    <span className="w-1.5 h-1.5 rounded-full bg-[#00f2ff] animate-bounce [animation-delay:0.2s]" />
                    <span className="w-1.5 h-1.5 rounded-full bg-[#00f2ff] animate-bounce [animation-delay:0.4s]" />
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Quick Campus Prompt Pills */}
          <div className="px-4 py-2 bg-[#0c0d18] border-t border-white/[0.04] flex items-center gap-2 overflow-x-auto no-scrollbar">
            <span className="text-[10px] font-mono-tech text-white/40 shrink-0 flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-[#00f2ff]" /> Quick:
            </span>
            {CHAT_QUICK_PROMPTS.map((prompt, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => handleSendMessage(prompt)}
                className="px-3 py-1 rounded-full bg-white/[0.03] hover:bg-[#00f2ff]/15 hover:border-[#00f2ff]/40 border border-white/[0.08] text-[11px] text-white/70 hover:text-white whitespace-nowrap font-sans transition-all cursor-pointer"
              >
                {prompt}
              </button>
            ))}
          </div>

          {/* Voice Recording Active Bar */}
          {isRecording && (
            <div className="p-3 bg-red-950/80 border-t border-red-500/30 flex items-center justify-between px-4 animate-in slide-in-from-bottom">
              <div className="flex items-center gap-3">
                <span className="w-3 h-3 rounded-full bg-red-500 animate-ping" />
                <span className="text-xs font-mono-tech text-red-200">
                  Recording Voice Note: <strong>{formatTimer(recordingSeconds)}</strong>
                </span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setIsRecording(false)}
                  className="px-3 py-1 rounded-lg bg-white/10 hover:bg-white/20 text-white text-xs font-mono-tech cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleFinishVoiceRecording}
                  className="px-4 py-1.5 rounded-lg bg-[#00f2ff] hover:bg-[#38f6ff] text-black font-bold text-xs font-mono-tech flex items-center gap-1 cursor-pointer"
                >
                  <Send className="w-3 h-3" />
                  <span>Send Audio</span>
                </button>
              </div>
            </div>
          )}

          {/* Message Input Control Bar */}
          <div className="p-3 sm:p-4 bg-[#0a0b14] border-t border-white/[0.08] shrink-0 sticky bottom-0 z-20">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSendMessage();
              }}
              className="flex items-center gap-2 relative"
            >
              {/* Attachment Trigger */}
              <div className="relative">
                <button
                  type="button"
                  onClick={() => {
                    setShowAttachmentMenu(!showAttachmentMenu);
                    setShowEmojiPicker(false);
                  }}
                  className="p-2.5 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] text-white/60 hover:text-white border border-white/10 transition-colors cursor-pointer"
                  title="Share File, Code, or Location"
                >
                  <Paperclip className="w-4 h-4" />
                </button>

                {showAttachmentMenu && (
                  <div className="absolute bottom-12 left-0 w-56 p-2 bg-[#121422] border border-white/15 rounded-2xl shadow-2xl space-y-1 z-30 animate-in fade-in slide-in-from-bottom-2">
                    <button
                      type="button"
                      onClick={() => handleSendAttachment('notes')}
                      className="w-full p-2 rounded-xl hover:bg-white/[0.06] text-left text-xs text-white/80 hover:text-[#00f2ff] flex items-center gap-2 font-mono-tech transition-colors cursor-pointer"
                    >
                      <BookOpen className="w-3.5 h-3.5 text-[#00f2ff]" />
                      <span>Share Study Notes</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => handleSendAttachment('code')}
                      className="w-full p-2 rounded-xl hover:bg-white/[0.06] text-left text-xs text-white/80 hover:text-[#c084fc] flex items-center gap-2 font-mono-tech transition-colors cursor-pointer"
                    >
                      <Code2 className="w-3.5 h-3.5 text-[#c084fc]" />
                      <span>Share Code Snippet</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => handleSendAttachment('gear')}
                      className="w-full p-2 rounded-xl hover:bg-white/[0.06] text-left text-xs text-white/80 hover:text-amber-400 flex items-center gap-2 font-mono-tech transition-colors cursor-pointer"
                    >
                      <Cpu className="w-3.5 h-3.5 text-amber-400" />
                      <span>Request Lab Gear</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => handleSendAttachment('location')}
                      className="w-full p-2 rounded-xl hover:bg-white/[0.06] text-left text-xs text-white/80 hover:text-emerald-400 flex items-center gap-2 font-mono-tech transition-colors cursor-pointer"
                    >
                      <MapPin className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Share Campus Pin</span>
                    </button>
                  </div>
                )}
              </div>

              {/* Emoji Quick Picker Trigger */}
              <div className="relative">
                <button
                  type="button"
                  onClick={() => {
                    setShowEmojiPicker(!showEmojiPicker);
                    setShowAttachmentMenu(false);
                  }}
                  className="p-2.5 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] text-white/60 hover:text-white border border-white/10 transition-colors cursor-pointer"
                  title="Quick Reactions"
                >
                  <Smile className="w-4 h-4" />
                </button>

                {showEmojiPicker && (
                  <div className="absolute bottom-12 left-0 p-2 bg-[#121422] border border-white/15 rounded-2xl shadow-2xl flex items-center gap-1.5 z-30 animate-in fade-in slide-in-from-bottom-2">
                    {['👍', '🚀', '🔥', '🎉', '💡', '❤️', '👏', '⚡', '☕', '📚'].map((emoji) => (
                      <button
                        key={emoji}
                        type="button"
                        onClick={() => {
                          setInputText((prev) => prev + emoji);
                          setShowEmojiPicker(false);
                          if (textInputRef.current) textInputRef.current.focus();
                        }}
                        className="p-1.5 text-base hover:scale-125 transition-transform cursor-pointer"
                      >
                        {emoji}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Voice Note Trigger */}
              <button
                type="button"
                onClick={() => setIsRecording(true)}
                className="p-2.5 rounded-xl bg-white/[0.04] hover:bg-red-500/20 text-white/60 hover:text-red-400 border border-white/10 transition-colors cursor-pointer"
                title="Record Voice Note"
              >
                <Mic className="w-4 h-4" />
              </button>

              {/* Main Text Input */}
              <input
                ref={textInputRef}
                type="text"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    handleSendMessage();
                  }
                }}
                placeholder={`Message ${activePeer.name}...`}
                className="flex-1 bg-[#121424] border border-white/10 rounded-2xl px-4 py-3 text-xs sm:text-sm text-white placeholder-white/40 focus:outline-none focus:border-[#00f2ff]/70 transition-all font-sans"
              />

              {/* Send Button */}
              <button
                type="submit"
                disabled={!inputText.trim()}
                className={`px-4 sm:px-5 py-3 rounded-2xl font-bold font-mono-tech text-xs flex items-center gap-1.5 transition-all cursor-pointer ${
                  inputText.trim()
                    ? 'bg-gradient-to-r from-[#00f2ff] to-[#38bdf8] text-black shadow-[0_0_20px_rgba(0,242,255,0.4)] hover:brightness-110'
                    : 'bg-white/[0.05] text-white/30 border border-white/[0.05] cursor-not-allowed'
                }`}
              >
                <span>Send</span>
                <Send className="w-3.5 h-3.5" />
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
};

```

---

## File: `src/components/CampusPulseSection.tsx`

```tsx
import React, { useState } from 'react';
import { PulsePost } from '../types';
import { ShareData } from './ShareModal';
import { 
  Radio, 
  Heart, 
  MessageCircle, 
  Share2, 
  Sparkles, 
  Plus, 
  Tag, 
  Send,
  ShieldCheck,
  Check
} from 'lucide-react';

interface CampusPulseSectionProps {
  posts: PulsePost[];
  onToggleLike: (postId: string) => void;
  onAddComment: (postId: string, text: string) => void;
  onOpenCreatePost: () => void;
  onOpenShare?: (data: ShareData) => void;
}

export const CampusPulseSection: React.FC<CampusPulseSectionProps> = ({
  posts,
  onToggleLike,
  onAddComment,
  onOpenCreatePost,
  onOpenShare,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [activeCommentPostId, setActiveCommentPostId] = useState<string | null>(null);
  const [commentInput, setCommentInput] = useState<string>('');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const categories = ['All', 'Projects', 'Events', 'Academic', 'Discussions', 'Sports'];

  const filteredPosts = posts.filter(
    (p) => selectedCategory === 'All' || p.category === selectedCategory
  );

  const handleSendComment = (postId: string) => {
    if (!commentInput.trim()) return;
    onAddComment(postId, commentInput.trim());
    setCommentInput('');
  };

  const handleShare = (post: PulsePost) => {
    const postUrl = `${window.location.origin}/pulse/${post.id}`;
    const sharePayload: ShareData = {
      title: `${post.author} on Campus OS Pulse (${post.category})`,
      text: post.text,
      url: postUrl,
      category: post.category,
    };

    if (onOpenShare) {
      onOpenShare(sharePayload);
    } else if (navigator.share) {
      navigator.share({
        title: sharePayload.title,
        text: sharePayload.text,
        url: sharePayload.url,
      }).catch(() => {});
    } else {
      navigator.clipboard.writeText(postUrl);
      setCopiedId(post.id);
      setTimeout(() => setCopiedId(null), 2000);
    }
  };

  return (
    <section id="pulse" className="py-28 border-b border-white/[0.08] relative bg-[#050505]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div>
            <div className="inline-flex items-center gap-2 text-xs font-mono tracking-[3px] text-[#00f2ff] font-bold uppercase mb-2">
              <Radio className="w-3.5 h-3.5 text-[#00f2ff] animate-pulse" />
              <span>LIVE BROADCAST</span>
            </div>
            <h2 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-white tracking-normal font-heading">
              Campus Pulse
            </h2>
            <p className="text-white/60 mt-2 text-base sm:text-lg max-w-xl font-normal">
              What's happening right now across university branches. Real-time updates, study groups, hackathons, and announcements.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              id="pulse-create-post-btn"
              onClick={onOpenCreatePost}
              className="px-6 py-3 bg-[#00f2ff] hover:bg-[#38f6ff] text-black font-semibold text-xs sm:text-sm rounded-full flex items-center gap-2 transition-all cursor-pointer shadow-[0_0_20px_rgba(0,242,255,0.3)] hover:scale-[1.02] active:scale-[0.98]"
            >
              <Plus className="w-4 h-4" />
              <span>Share Update</span>
            </button>
          </div>
        </div>

        {/* Category Pills */}
        <div className="flex items-center gap-2 overflow-x-auto pb-4 mb-8 scrollbar-none">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-4 py-2 text-xs font-mono-tech tracking-wider rounded-full transition-all cursor-pointer whitespace-nowrap uppercase ${
                selectedCategory === cat
                  ? 'bg-[#00f2ff]/20 border border-[#00f2ff] text-[#00f2ff] font-bold shadow-[0_0_15px_rgba(0,242,255,0.2)]'
                  : 'bg-[#0c0d12] border border-white/[0.08] text-white/50 hover:text-white hover:border-white/20'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* 2-Column Responsive Feed Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filteredPosts.map((post) => (
            <div
              key={post.id}
              id={`pulse-post-${post.id}`}
              className="p-6 rounded-2xl bg-[#0c0d12] border border-white/[0.08] hover:border-white/20 transition-all flex flex-col justify-between shadow-xl"
            >
              <div>
                {/* Author & Badge */}
                <div className="flex items-center justify-between gap-3 mb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-xs font-bold text-white font-mono-tech">
                      {post.author.slice(0, 2).toUpperCase()}
                    </div>
                    <div>
                      <div className="text-sm font-bold text-white flex items-center gap-1.5 font-heading">
                        <span>{post.author}</span>
                        {post.badge && (
                          <span className="px-2 py-0.5 rounded-full bg-[#00f2ff]/10 border border-[#00f2ff]/30 text-[9px] font-mono-tech text-[#00f2ff] uppercase font-bold">
                            {post.badge}
                          </span>
                        )}
                      </div>
                      <div className="text-[11px] font-mono-tech text-white/40">
                        {post.authorDepartment || 'Campus Member'} • {post.timestamp}
                      </div>
                    </div>
                  </div>

                  <span className="text-[10px] font-mono-tech text-white/50 px-3 py-1 rounded-full bg-[#050505] border border-white/10 uppercase">
                    {post.category}
                  </span>
                </div>

                {/* Post Body */}
                <p className="text-sm text-white/80 leading-relaxed my-3 font-normal">
                  {post.text}
                </p>
              </div>

              {/* Action Buttons: Like, Comment, Share */}
              <div className="pt-4 mt-3 border-t border-white/[0.06] flex items-center justify-between text-xs font-mono-tech text-white/50">
                <div className="flex items-center gap-5">
                  <button
                    onClick={() => onToggleLike(post.id)}
                    className={`flex items-center gap-1.5 transition-colors cursor-pointer ${
                      post.isLiked ? 'text-[#c084fc] font-bold' : 'hover:text-[#c084fc]'
                    }`}
                  >
                    <Heart
                      className={`w-4 h-4 ${
                        post.isLiked ? 'fill-[#c084fc] text-[#c084fc]' : ''
                      }`}
                    />
                    <span>{post.likesCount}</span>
                  </button>

                  <button
                    onClick={() =>
                      setActiveCommentPostId(
                        activeCommentPostId === post.id ? null : post.id
                      )
                    }
                    className="flex items-center gap-1.5 hover:text-[#00f2ff] transition-colors cursor-pointer"
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span>{post.commentsCount}</span>
                  </button>
                </div>

                <button
                  onClick={() => handleShare(post)}
                  className="flex items-center gap-1.5 px-2 py-1 rounded-md bg-white/[0.04] hover:bg-[#00f2ff]/15 hover:text-[#00f2ff] transition-all cursor-pointer border border-transparent hover:border-[#00f2ff]/30 text-white/60"
                  title="Share to WhatsApp, Telegram, X, etc."
                >
                  {copiedId === post.id ? (
                    <span className="text-[#00f2ff] text-[10px] flex items-center gap-1">
                      <Check className="w-3 h-3" /> Copied!
                    </span>
                  ) : (
                    <>
                      <Share2 className="w-3.5 h-3.5" />
                      <span className="text-[11px] font-mono-tech">Share</span>
                    </>
                  )}
                </button>
              </div>

              {/* Collapsible Comment Box */}
              {activeCommentPostId === post.id && (
                <div className="mt-4 pt-4 border-t border-white/[0.06] space-y-3">
                  {post.comments && post.comments.length > 0 && (
                    <div className="space-y-2 max-h-36 overflow-y-auto pr-1">
                      {post.comments.map((c) => (
                        <div
                          key={c.id}
                          className="p-2.5 rounded-xl bg-[#050505] border border-white/5 text-xs text-white/80"
                        >
                          <div className="flex justify-between text-[10px] font-mono-tech text-[#00f2ff] mb-1">
                            <span>{c.author}</span>
                            <span className="text-white/40">{c.time}</span>
                          </div>
                          <div>{c.text}</div>
                        </div>
                      ))}
                    </div>
                  )}

                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={commentInput}
                      onChange={(e) => setCommentInput(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && handleSendComment(post.id)}
                      placeholder="Write a response..."
                      className="flex-1 px-4 py-2 bg-[#050505] border border-white/10 rounded-xl text-xs text-white focus:outline-none focus:border-[#00f2ff] font-mono-tech"
                    />
                    <button
                      onClick={() => handleSendComment(post.id)}
                      className="px-4 py-2 bg-[#00f2ff] hover:bg-[#38f6ff] text-black font-bold rounded-xl text-xs cursor-pointer"
                    >
                      <Send className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

```

---

## File: `src/components/CommandPaletteModal.tsx`

```tsx
import React, { useState, useEffect } from 'react';
import { 
  Search, 
  X, 
  HandCoins, 
  ShoppingBag, 
  Layers3, 
  BookOpen, 
  Repeat, 
  Sparkles,
  ArrowRight
} from 'lucide-react';
import { MarketplaceItem, ProjectItem, BorrowItem, GuidanceTopic } from '../types';

interface CommandPaletteModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigateTab: (tab: string) => void;
  marketplaceItems: MarketplaceItem[];
  projects: ProjectItem[];
  borrowItems: BorrowItem[];
  guidanceTopics: GuidanceTopic[];
  onSelectItem: (item: MarketplaceItem) => void;
  onSelectProject: (proj: ProjectItem) => void;
}

export const CommandPaletteModal: React.FC<CommandPaletteModalProps> = ({
  isOpen,
  onClose,
  onNavigateTab,
  marketplaceItems,
  projects,
  borrowItems,
  guidanceTopics,
  onSelectItem,
  onSelectProject,
}) => {
  const [query, setQuery] = useState('');

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        // toggle logic handled by parent or shortcut
      }
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const q = query.toLowerCase().trim();

  const matchedMarketplace = q
    ? marketplaceItems.filter(
        (i) => i.title.toLowerCase().includes(q) || i.category.toLowerCase().includes(q)
      ).slice(0, 3)
    : [];

  const matchedProjects = q
    ? projects.filter(
        (p) => p.name.toLowerCase().includes(q) || p.tagline.toLowerCase().includes(q) || p.category.toLowerCase().includes(q)
      ).slice(0, 3)
    : [];

  const matchedBorrow = q
    ? borrowItems.filter(
        (b) => b.title.toLowerCase().includes(q) || b.category.toLowerCase().includes(q)
      ).slice(0, 3)
    : [];

  const matchedGuides = q
    ? guidanceTopics.filter(
        (g) => g.title.toLowerCase().includes(q) || g.summary.toLowerCase().includes(q)
      ).slice(0, 3)
    : [];

  return (
    <div 
      id="command-palette-backdrop"
      className="fixed inset-0 z-50 flex items-start justify-center pt-20 p-4 bg-black/80 backdrop-blur-md"
      onClick={onClose}
    >
      <div 
        id="command-palette-card"
        className="relative w-full max-w-2xl bg-[#121212] border border-[#00f2ff]/40 rounded-sm shadow-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Search Input */}
        <div className="flex items-center gap-3 px-4 py-3.5 border-b border-white/[0.08] bg-[#050505]">
          <Search className="w-5 h-5 text-[#00f2ff] shrink-0" />
          <input
            id="command-palette-input"
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Type a command, search items, projects, guides, or equipment..."
            autoFocus
            className="w-full bg-transparent text-sm text-white placeholder-white/40 focus:outline-none font-mono-tech"
          />
          <button
            id="close-command-palette-btn"
            onClick={onClose}
            className="p-1 rounded-sm text-white/40 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Results Container */}
        <div className="max-h-[60vh] overflow-y-auto p-4 space-y-4">
          {/* Quick Navigation Commands */}
          {!q && (
            <div className="space-y-1">
              <div className="text-[10px] font-mono-tech text-white/40 tracking-[2px] uppercase mb-2">
                APP WORKSPACES & MODULES
              </div>
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => { onNavigateTab('pulse'); onClose(); }}
                  className="flex items-center gap-2.5 p-2.5 rounded-sm bg-[#050505] border border-white/5 hover:border-[#00f2ff] text-left text-xs font-mono-tech text-white transition-all cursor-pointer"
                >
                  <span className="w-2 h-2 rounded-full bg-[#00f2ff]" />
                  <span>⚡ Campus Pulse Feed</span>
                </button>
                <button
                  onClick={() => { onNavigateTab('borrow'); onClose(); }}
                  className="flex items-center gap-2.5 p-2.5 rounded-sm bg-[#050505] border border-white/5 hover:border-[#00f2ff] text-left text-xs font-mono-tech text-white transition-all cursor-pointer"
                >
                  <HandCoins className="w-4 h-4 text-[#00f2ff]" />
                  <span>📦 Borrow & Lab Gear</span>
                </button>
                <button
                  onClick={() => { onNavigateTab('marketplace'); onClose(); }}
                  className="flex items-center gap-2.5 p-2.5 rounded-sm bg-[#050505] border border-white/5 hover:border-[#00f2ff] text-left text-xs font-mono-tech text-white transition-all cursor-pointer"
                >
                  <ShoppingBag className="w-4 h-4 text-[#00f2ff]" />
                  <span>🛒 Peer Marketplace</span>
                </button>
                <button
                  onClick={() => { onNavigateTab('projects'); onClose(); }}
                  className="flex items-center gap-2.5 p-2.5 rounded-sm bg-[#050505] border border-white/5 hover:border-[#bc13fe] text-left text-xs font-mono-tech text-white transition-all cursor-pointer"
                >
                  <Layers3 className="w-4 h-4 text-[#bc13fe]" />
                  <span>🔬 Research & Projects</span>
                </button>
                <button
                  onClick={() => { onNavigateTab('mentorship'); onClose(); }}
                  className="flex items-center gap-2.5 p-2.5 rounded-sm bg-[#050505] border border-white/5 hover:border-[#bc13fe] text-left text-xs font-mono-tech text-white transition-all cursor-pointer"
                >
                  <Repeat className="w-4 h-4 text-[#bc13fe]" />
                  <span>🤝 Skill Exchange & Guides</span>
                </button>
                <button
                  onClick={() => { onNavigateTab('compass'); onClose(); }}
                  className="flex items-center gap-2.5 p-2.5 rounded-sm bg-[#050505] border border-white/5 hover:border-[#00f2ff] text-left text-xs font-mono-tech text-white transition-all cursor-pointer"
                >
                  <Sparkles className="w-4 h-4 text-[#00f2ff]" />
                  <span>🧭 COMPASS AI Assistant</span>
                </button>
              </div>
            </div>
          )}

          {/* Matches: Marketplace */}
          {matchedMarketplace.length > 0 && (
            <div>
              <div className="text-[10px] font-mono-tech text-[#00f2ff] tracking-[2px] uppercase mb-2">
                MARKETPLACE ITEMS
              </div>
              <div className="space-y-1.5">
                {matchedMarketplace.map((item) => (
                  <div
                    key={item.id}
                    onClick={() => { onSelectItem(item); onClose(); }}
                    className="p-2.5 rounded-sm bg-[#050505] border border-white/5 hover:border-[#00f2ff] flex items-center justify-between cursor-pointer transition-all"
                  >
                    <div>
                      <div className="text-xs font-bold text-white font-heading">{item.title}</div>
                      <div className="text-[10px] font-mono-tech text-white/40">₹{item.price} • {item.sellerName} • {item.location}</div>
                    </div>
                    <ArrowRight className="w-4 h-4 text-[#00f2ff]" />
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Matches: Projects */}
          {matchedProjects.length > 0 && (
            <div>
              <div className="text-[10px] font-mono-tech text-[#bc13fe] tracking-[2px] uppercase mb-2">
                PROJECTS & BUILDS
              </div>
              <div className="space-y-1.5">
                {matchedProjects.map((p) => (
                  <div
                    key={p.id}
                    onClick={() => { onSelectProject(p); onClose(); }}
                    className="p-2.5 rounded-sm bg-[#050505] border border-white/5 hover:border-[#bc13fe] flex items-center justify-between cursor-pointer transition-all"
                  >
                    <div>
                      <div className="text-xs font-bold text-white font-heading">{p.name}</div>
                      <div className="text-[10px] font-mono-tech text-white/40">{p.category} • {p.creator} • {p.membersCount} members</div>
                    </div>
                    <ArrowRight className="w-4 h-4 text-[#bc13fe]" />
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Matches: Borrow Items */}
          {matchedBorrow.length > 0 && (
            <div>
              <div className="text-[10px] font-mono-tech text-[#00f2ff] tracking-[2px] uppercase mb-2">
                LAB & BORROW INVENTORY
              </div>
              <div className="space-y-1.5">
                {matchedBorrow.map((b) => (
                  <div
                    key={b.id}
                    onClick={() => { onNavigateTab('borrow'); onClose(); }}
                    className="p-2.5 rounded-sm bg-[#050505] border border-white/5 hover:border-[#00f2ff] flex items-center justify-between cursor-pointer transition-all"
                  >
                    <div>
                      <div className="text-xs font-bold text-white font-heading">{b.title}</div>
                      <div className="text-[10px] font-mono-tech text-white/40">{b.category} • Max {b.maxDays}d • {b.location}</div>
                    </div>
                    <span className="text-[10px] font-mono-tech text-[#00f2ff] uppercase font-bold">BORROW</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Matches: Guides */}
          {matchedGuides.length > 0 && (
            <div>
              <div className="text-[10px] font-mono-tech text-[#bc13fe] tracking-[2px] uppercase mb-2">
                SENIOR GUIDES & ARCHIVES
              </div>
              <div className="space-y-1.5">
                {matchedGuides.map((g) => (
                  <div
                    key={g.id}
                    onClick={() => { onNavigateTab('mentorship'); onClose(); }}
                    className="p-2.5 rounded-sm bg-[#050505] border border-white/5 hover:border-[#bc13fe] flex items-center justify-between cursor-pointer transition-all"
                  >
                    <div>
                      <div className="text-xs font-bold text-white font-heading">{g.title}</div>
                      <div className="text-[10px] font-mono-tech text-white/40">{g.category} • {g.mentorName}</div>
                    </div>
                    <BookOpen className="w-4 h-4 text-[#bc13fe]" />
                  </div>
                ))}
              </div>
            </div>
          )}

          {q && !matchedMarketplace.length && !matchedProjects.length && !matchedBorrow.length && !matchedGuides.length && (
            <div className="py-8 text-center text-xs font-mono-tech text-white/40">
              No campus records matching "{query}". Try searching by department or keyword.
            </div>
          )}
        </div>

        {/* Footer info */}
        <div className="px-4 py-2 border-t border-white/[0.06] bg-[#050505] flex items-center justify-between text-[10px] font-mono-tech text-white/40">
          <span>NAVIGATION SHORTCUTS</span>
          <span className="flex items-center gap-2">
            <span>[ESC] TO CLOSE</span>
            <span>•</span>
            <span>[ENTER] TO SELECT</span>
          </span>
        </div>
      </div>
    </div>
  );
};

```

---

## File: `src/components/CompassAssistant.tsx`

```tsx
import React, { useState, useRef, useEffect } from 'react';
import { CompassMessage } from '../types';
import { 
  Compass, 
  Send, 
  Sparkles, 
  Loader2, 
  Layers, 
  ArrowUpRight, 
  Bot, 
  User, 
  Volume2, 
  Radio 
} from 'lucide-react';

interface CompassAssistantProps {
  messages: CompassMessage[];
  onSendMessage: (text: string) => void;
  isLoading: boolean;
  onSelectActionCard?: (action: string, targetId: string) => void;
}

export const CompassAssistant: React.FC<CompassAssistantProps> = ({
  messages,
  onSendMessage,
  isLoading,
  onSelectActionCard,
}) => {
  const [inputText, setInputText] = useState('');
  const messagesContainerRef = useRef<HTMLDivElement | null>(null);

  const presets = [
    'Where can I find past year papers?',
    'Who is teaching DBMS this sem?',
    'Any internships for CS students?',
    'Where can I borrow a calculator?',
    'Find me an AI project looking for members.',
  ];

  const handleSend = () => {
    if (!inputText.trim() || isLoading) return;
    onSendMessage(inputText.trim());
    setInputText('');
  };

  useEffect(() => {
    if (messagesContainerRef.current) {
      messagesContainerRef.current.scrollTo({
        top: messagesContainerRef.current.scrollHeight,
        behavior: 'smooth',
      });
    }
  }, [messages, isLoading]);

  return (
    <div id="compass" className="bg-[#121212] border border-white/[0.08] border-t-2 border-t-[#bc13fe] rounded-sm p-6 relative flex flex-col justify-between shadow-2xl h-full">
      <div>
        {/* COMPASS Top Header */}
        <div className="flex items-center justify-between pb-4 mb-4 border-b border-white/[0.08]">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-sm bg-[#bc13fe]/10 border border-[#bc13fe]/40 flex items-center justify-center text-[#bc13fe] shadow-[0_0_15px_rgba(188,19,254,0.2)]">
              <Compass className="w-4 h-4 animate-spin-slow" />
            </div>
            <div>
              <div className="text-sm font-black text-white font-heading tracking-wide">
                COMPASS AI
              </div>
              <div className="text-[10px] font-mono-tech text-white/50">
                Your campus assistant. Always here.
              </div>
            </div>
          </div>

          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-sm bg-[#bc13fe]/10 border border-[#bc13fe]/30 text-[10px] font-mono-tech text-[#bc13fe] font-bold">
            <span className="w-2 h-2 rounded-full bg-[#bc13fe] animate-ping" />
            <span>ONLINE</span>
          </div>
        </div>

        {/* Message Thread Body */}
        <div ref={messagesContainerRef} className="space-y-3.5 max-h-[380px] overflow-y-auto pr-1 mb-4">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex flex-col ${
                msg.sender === 'user' ? 'items-end' : 'items-start'
              }`}
            >
              <div
                className={`max-w-[88%] p-3.5 rounded-sm text-xs sm:text-sm leading-relaxed ${
                  msg.sender === 'user'
                    ? 'bg-white text-black font-bold shadow-lg'
                    : 'bg-[#050505] border border-white/[0.08] text-white/90'
                }`}
              >
                {msg.sender === 'compass' && (
                  <div className="flex items-center gap-1.5 text-[9px] font-mono-tech text-[#bc13fe] uppercase tracking-[2px] mb-1.5 font-bold">
                    <Sparkles className="w-2.5 h-2.5 text-[#bc13fe]" />
                    <span>COMPASS // NEURAL CAMPUS INDEX</span>
                  </div>
                )}

                <div className="whitespace-pre-line">{msg.text}</div>

                {/* Suggested Action Cards Attached to Compass Responses */}
                {msg.suggestedCards && msg.suggestedCards.length > 0 && (
                  <div className="mt-3 space-y-2 pt-2 border-t border-white/[0.08]">
                    {msg.suggestedCards.map((card, idx) => (
                      <div
                        key={idx}
                        onClick={() =>
                          onSelectActionCard &&
                          onSelectActionCard(card.type, card.targetId)
                        }
                        className="p-2.5 rounded-sm bg-[#121212] border border-[#00f2ff]/30 hover:border-[#00f2ff] text-left transition-all cursor-pointer flex items-center justify-between gap-2 group"
                      >
                        <div>
                          <span className="text-[8px] font-mono-tech text-[#00f2ff] uppercase px-1.5 py-0.2 rounded-sm bg-[#00f2ff]/10 font-bold">
                            {card.tag}
                          </span>
                          <div className="text-xs font-bold text-white mt-1 group-hover:text-[#00f2ff] transition-colors font-heading">
                            {card.title}
                          </div>
                          <div className="text-[10px] text-white/50">
                            {card.subtitle}
                          </div>
                        </div>
                        <ArrowUpRight className="w-4 h-4 text-[#00f2ff] group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform shrink-0" />
                      </div>
                    ))}
                  </div>
                )}
              </div>
              <span className="text-[9px] font-mono-tech text-white/40 mt-1 px-1">
                {msg.timestamp}
              </span>
            </div>
          ))}

          {isLoading && (
            <div className="flex items-center gap-2 p-3 bg-[#050505] border border-white/[0.08] rounded-sm text-xs font-mono-tech text-[#00f2ff]">
              <Loader2 className="w-3.5 h-3.5 animate-spin text-[#00f2ff]" />
              <span>COMPASS is indexing campus neural database...</span>
            </div>
          )}
        </div>

        {/* Quick Suggestion Preset Pills */}
        <div className="space-y-1.5 mb-4">
          <div className="text-[10px] font-mono-tech text-white/50 tracking-[1px] uppercase">
            QUICK CAMPUS QUERIES:
          </div>
          <div className="flex flex-wrap gap-1.5">
            {presets.map((preset, idx) => (
              <button
                key={idx}
                onClick={() => onSendMessage(preset)}
                disabled={isLoading}
                className="px-2.5 py-1 rounded-sm bg-[#050505] border border-white/[0.08] hover:border-[#00f2ff] text-[10px] font-mono-tech text-white/70 hover:text-[#00f2ff] transition-all cursor-pointer text-left"
              >
                {preset}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Input Box Area */}
      <div className="pt-3 border-t border-white/[0.08]">
        <div className="relative flex items-center">
          <input
            id="compass-input-field"
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Ask anything about your campus..."
            disabled={isLoading}
            className="w-full pl-4 pr-12 py-3 bg-[#050505] border border-white/[0.1] focus:border-[#bc13fe] rounded-sm text-xs sm:text-sm text-white placeholder-white/40 focus:outline-none transition-colors font-mono-tech shadow-inner"
          />
          <button
            id="compass-send-btn"
            onClick={handleSend}
            disabled={!inputText.trim() || isLoading}
            className="absolute right-2 p-2 rounded-sm bg-[#bc13fe] hover:bg-[#a010d8] disabled:opacity-40 text-white transition-all cursor-pointer shadow-[0_0_15px_rgba(188,19,254,0.3)]"
          >
            <Send className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};


```

---

## File: `src/components/CompassSection.tsx`

```tsx
import React, { useState, useRef, useEffect } from 'react';
import { CompassMessage } from '../types';
import { 
  Send, 
  Sparkles, 
  Loader2, 
  ArrowUpRight,
  Zap,
  Copy,
  Check,
  Volume2,
  VolumeX
} from 'lucide-react';
import { CompassStarIcon } from './BrandLogos';

interface CompassSectionProps {
  messages: CompassMessage[];
  onSendMessage: (text: string) => void;
  isLoading: boolean;
  onSelectActionCard?: (action: string, targetId: string) => void;
}

export const CompassSection: React.FC<CompassSectionProps> = ({
  messages,
  onSendMessage,
  isLoading,
  onSelectActionCard,
}) => {
  const [inputText, setInputText] = useState('');
  const [activeCategoryTab, setActiveCategoryTab] = useState<'all' | 'academic' | 'gear' | 'projects' | 'skills' | 'campus'>('all');
  const [copiedMsgId, setCopiedMsgId] = useState<string | null>(null);
  const [speakingMsgId, setSpeakingMsgId] = useState<string | null>(null);
  const messagesContainerRef = useRef<HTMLDivElement | null>(null);

  const categorizedPresets = {
    all: [
      'Who can lend me a Casio fx-991 calculator today?',
      'Find me an AI or robotics project recruiting developers.',
      'Who is offering Figma UI/UX mentorship?',
      'Where can I find past year papers for Operating Systems?',
      'What are the Central Library 24/7 exam hours and Wi-Fi proxy?',
    ],
    academic: [
      'Where can I find past year papers for Operating Systems?',
      'Are Prof. Menon’s Signals & Systems exams open-notes?',
      'Who has handwritten DSA & DBMS notes for Semester 3?',
      'How do I apply for Summer Research Internships?',
    ],
    gear: [
      'Who can lend me a Casio fx-991 calculator today?',
      'Where can I reserve a 50MHz Oscilloscope on campus?',
      'Where can I borrow a Lab Coat & UV safety goggles?',
      'Who has an Arduino Mega and sensor kit available?',
    ],
    projects: [
      'Find me an AI or robotics project recruiting developers.',
      'How do I join the CampusVision attendance project?',
      'What skills does the SoilSense IoT squad need?',
      'Are there any NLP or speech recognition projects looking for members?',
    ],
    skills: [
      'Who is offering Figma UI/UX mentorship?',
      'Who can teach me KiCAD & PCB soldering?',
      'Find someone who knows ROS 2 and Gazebo robotics.',
      'How does the peer skill swap match score work?',
    ],
    campus: [
      'What are the Central Library 24/7 exam hours and Wi-Fi proxy?',
      'What are the hostel mess timings and special dinners?',
      'What is the campus emergency medical dispensary number?',
      'Where are the nearest printing and xerox shops on campus?',
    ],
  };

  const handleSend = (textToSend?: string) => {
    const text = textToSend || inputText;
    if (!text.trim() || isLoading) return;
    onSendMessage(text.trim());
    if (!textToSend) setInputText('');
  };

  const handleCopyText = (msgId: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedMsgId(msgId);
    setTimeout(() => setCopiedMsgId(null), 2000);
  };

  const handleSpeakText = (msgId: string, text: string) => {
    if (!('speechSynthesis' in window)) return;

    if (speakingMsgId === msgId) {
      window.speechSynthesis.cancel();
      setSpeakingMsgId(null);
      return;
    }

    window.speechSynthesis.cancel();
    const cleanSpeechText = text.replace(/[*#`_•]/g, ' ');
    const utterance = new SpeechSynthesisUtterance(cleanSpeechText);
    utterance.rate = 1.05;
    utterance.pitch = 1.0;
    utterance.onend = () => setSpeakingMsgId(null);
    utterance.onerror = () => setSpeakingMsgId(null);

    setSpeakingMsgId(msgId);
    window.speechSynthesis.speak(utterance);
  };

  useEffect(() => {
    if (messagesContainerRef.current) {
      messagesContainerRef.current.scrollTo({
        top: messagesContainerRef.current.scrollHeight,
        behavior: 'smooth',
      });
    }
  }, [messages.length, isLoading]);

  // Clean formatted rendering for markdown bold and bullet points
  const renderFormattedMessage = (rawText: string) => {
    const lines = rawText.split('\n');
    return (
      <div className="space-y-1.5 leading-relaxed text-sm font-sans">
        {lines.map((line, i) => {
          if (!line.trim()) return <div key={i} className="h-1.5" />;

          const parts = line.split(/(\*\*.*?\*\*|`.*?`)/g);
          const isBullet = line.trim().startsWith('•') || line.trim().startsWith('-');

          return (
            <div key={i} className={`${isBullet ? 'pl-2 text-zinc-300' : 'text-zinc-200'}`}>
              {parts.map((part, j) => {
                if (part.startsWith('**') && part.endsWith('**')) {
                  return (
                    <strong key={j} className="text-white font-bold">
                      {part.slice(2, -2)}
                    </strong>
                  );
                }
                if (part.startsWith('`') && part.endsWith('`')) {
                  return (
                    <code key={j} className="px-1.5 py-0.5 rounded bg-black/40 text-pink-300 font-mono text-xs border border-pink-500/20">
                      {part.slice(1, -1)}
                    </code>
                  );
                }
                return <span key={j}>{part}</span>;
              })}
            </div>
          );
        })}
      </div>
    );
  };

  return (
    <section id="compass" className="py-24 border-b border-white/[0.08] relative bg-[#04060c] overflow-hidden select-none">
      {/* Background Pink & Rose Radial Glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[900px] h-[600px] bg-gradient-to-r from-pink-600/15 via-rose-500/10 to-purple-600/10 rounded-full blur-[170px] pointer-events-none -z-10 animate-pulse-slow" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header matching Panel 07 Video Summary Bar */}
        <div className="flex items-center justify-between text-xs font-mono-tech text-pink-400 mb-8 pb-3 border-b border-white/[0.06]">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded bg-pink-950/80 border border-pink-400/40 text-pink-300 font-bold uppercase tracking-wider shadow-[0_0_12px_rgba(244,114,182,0.25)]">
              07 COMPASS
            </span>
            <span className="text-white/40 hidden sm:inline">// REASONING AGENT & LIVE QUERY ENGINE</span>
          </div>
          <span className="text-zinc-400 font-bold">01:02 - 01:15</span>
        </div>

        {/* Header Title */}
        <div className="text-center max-w-3xl mx-auto mb-10 space-y-3">
          <div className="inline-flex items-center justify-center gap-2 px-4 py-1.5 rounded-full bg-pink-950/50 border border-pink-400/30 text-pink-300 text-xs font-mono-tech uppercase font-bold tracking-widest backdrop-blur-md shadow-[0_0_20px_rgba(244,114,182,0.2)]">
            <CompassStarIcon size={20} glow={false} />
            <span>CAMPUS NEURAL CO-PILOT</span>
          </div>

          <h2 className="text-3xl sm:text-5xl font-bold text-white tracking-tight font-heading">
            Meet <span className="text-transparent bg-clip-text bg-gradient-to-r from-pink-300 via-rose-200 to-white drop-shadow-[0_0_25px_rgba(244,114,182,0.4)]">COMPASS</span>, your campus AI.
          </h2>

          <p className="text-sm sm:text-base text-zinc-400 max-w-xl mx-auto font-normal">
            Intelligent real-time reasoning across borrow gear, research squads, mentors, exams, textbooks, and campus pulse.
          </p>
        </div>

        {/* Two-Column Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start max-w-6xl mx-auto">
          
          {/* Left: Chat Terminal (8 cols) */}
          <div className="lg:col-span-8 bg-gradient-to-b from-[#14081c]/95 via-[#0d0514]/98 to-[#06040a] border border-pink-500/30 rounded-3xl p-4 sm:p-6 shadow-[0_0_50px_rgba(244,114,182,0.18)] backdrop-blur-xl relative flex flex-col justify-between min-h-[540px]">
            
            {/* Chat Header */}
            <div className="flex items-center justify-between pb-3.5 mb-3 border-b border-pink-500/20">
              <div className="flex items-center gap-3">
                <CompassStarIcon size={34} />
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-bold text-white font-heading">COMPASS AI</span>
                    <span className="px-1.5 py-0.2 rounded text-[9px] font-mono-tech uppercase font-bold bg-pink-500/20 text-pink-300 border border-pink-400/30">
                      Gemini 3.7 Flash
                    </span>
                  </div>
                  <div className="text-[11px] text-pink-200/60 font-mono-tech">Instant Reasoning across 6 Campus Layers</div>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-pink-950/80 border border-pink-400/40 text-[11px] font-mono-tech text-pink-300 shadow-sm">
                  <span className="w-2 h-2 rounded-full bg-pink-400 animate-pulse shadow-[0_0_8px_#f472b6]" />
                  <span>ONLINE</span>
                </div>
              </div>
            </div>

            {/* Query Category Filter Tabs */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-2 mb-3 border-b border-white/[0.04] scrollbar-none text-xs font-mono-tech">
              {[
                { id: 'all', label: 'All Queries' },
                { id: 'academic', label: '🎓 Academics & PYQs' },
                { id: 'gear', label: '📦 Lab & Gear' },
                { id: 'projects', label: '🚀 Squads' },
                { id: 'skills', label: '⚡ Skill Swap' },
                { id: 'campus', label: '📍 Campus Life' },
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveCategoryTab(tab.id as any)}
                  className={`px-2.5 py-1 rounded-xl whitespace-nowrap transition-all cursor-pointer text-xs ${
                    activeCategoryTab === tab.id
                      ? 'bg-pink-500 text-white font-bold shadow-[0_0_12px_rgba(244,114,182,0.4)]'
                      : 'bg-white/[0.04] text-pink-200/60 hover:text-white hover:bg-white/[0.08] border border-white/[0.06]'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            {/* Messages Area */}
            <div ref={messagesContainerRef} className="space-y-4 max-h-[340px] overflow-y-auto pr-2 mb-3 custom-scrollbar">
              {messages.map((msg) => (
                <div
                  key={msg.id}
                  className={`flex flex-col ${
                    msg.sender === 'user' ? 'items-end' : 'items-start'
                  }`}
                >
                  <div
                    className={`max-w-[92%] p-4 rounded-2xl text-sm leading-relaxed ${
                      msg.sender === 'user'
                        ? 'bg-gradient-to-r from-pink-600 via-rose-500 to-pink-500 text-white font-medium shadow-[0_0_20px_rgba(244,114,182,0.3)] rounded-br-sm'
                        : 'bg-[#0a030e]/90 border border-pink-500/25 text-zinc-200 rounded-bl-sm shadow-lg'
                    }`}
                  >
                    {msg.sender === 'compass' && (
                      <div className="flex items-center justify-between gap-2 pb-2 mb-2 border-b border-pink-500/20 text-[11px] font-mono-tech">
                        <div className="flex items-center gap-2 text-pink-300 font-bold">
                          <Sparkles className="w-3.5 h-3.5 text-pink-300" />
                          <span>COMPASS INTELLIGENCE</span>
                          {msg.category && (
                            <span className="px-2 py-0.5 rounded-full bg-pink-950 text-[10px] text-pink-200 border border-pink-500/30">
                              {msg.category}
                            </span>
                          )}
                        </div>

                        {/* Speech & Copy utilities */}
                        <div className="flex items-center gap-1.5">
                          <button
                            onClick={() => handleSpeakText(msg.id, msg.text)}
                            className="p-1 rounded bg-white/5 hover:bg-pink-500/20 text-pink-300 transition-colors cursor-pointer"
                            title={speakingMsgId === msg.id ? "Stop voice readout" : "Listen to response"}
                          >
                            {speakingMsgId === msg.id ? <VolumeX className="w-3.5 h-3.5 text-rose-400 animate-pulse" /> : <Volume2 className="w-3.5 h-3.5" />}
                          </button>
                          <button
                            onClick={() => handleCopyText(msg.id, msg.text)}
                            className="p-1 rounded bg-white/5 hover:bg-pink-500/20 text-pink-300 transition-colors cursor-pointer"
                            title="Copy response to clipboard"
                          >
                            {copiedMsgId === msg.id ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                          </button>
                        </div>
                      </div>
                    )}

                    {/* Rendered Body */}
                    {renderFormattedMessage(msg.text)}

                    {/* Action Cards attached */}
                    {msg.suggestedCards && msg.suggestedCards.length > 0 && (
                      <div className="mt-3.5 grid grid-cols-1 sm:grid-cols-3 gap-2 pt-3 border-t border-pink-500/20">
                        {msg.suggestedCards.map((card, idx) => (
                          <div
                            key={idx}
                            onClick={() =>
                              onSelectActionCard &&
                              onSelectActionCard(card.type, card.targetId)
                            }
                            className="p-3 rounded-xl bg-[#14061a] border border-pink-500/30 hover:border-pink-300 text-left transition-all cursor-pointer flex flex-col justify-between group shadow-sm hover:shadow-[0_0_20px_rgba(244,114,182,0.3)]"
                          >
                            <div>
                              <div className="flex items-center justify-between gap-1 mb-1">
                                <span className="text-[9px] font-mono-tech text-pink-300 uppercase px-1.5 py-0.5 rounded bg-pink-950/70 border border-pink-400/30 font-bold">
                                  {card.tag}
                                </span>
                                <span className="text-[10px] text-pink-200/70 font-mono-tech">
                                  {idx === 0 ? '98% Match' : idx === 1 ? '92% Match' : '88% Match'}
                                </span>
                              </div>
                              <div className="text-xs font-bold text-white mt-1 group-hover:text-pink-200 transition-colors line-clamp-2 font-heading">
                                {card.title}
                              </div>
                              <div className="text-[10px] text-white/50 line-clamp-1 mt-0.5">
                                {card.subtitle}
                              </div>
                            </div>
                            <div className="mt-2 pt-2 border-t border-white/5 flex items-center justify-between text-[11px] text-pink-300 font-semibold">
                              <span>{card.actionLabel || 'View Detail'}</span>
                              <ArrowUpRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
                            </div>
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Interactive Follow-Up Questions */}
                    {msg.followUpQueries && msg.followUpQueries.length > 0 && (
                      <div className="mt-3 pt-2.5 border-t border-pink-500/15">
                        <div className="text-[10px] font-mono-tech text-pink-200/60 uppercase tracking-wider mb-1.5">
                          SUGGESTED FOLLOW-UPS:
                        </div>
                        <div className="flex flex-wrap gap-1.5">
                          {msg.followUpQueries.map((followUp, fIdx) => (
                            <button
                              key={fIdx}
                              onClick={() => handleSend(followUp)}
                              className="px-2.5 py-1 rounded-lg bg-pink-950/40 hover:bg-pink-500/20 border border-pink-500/30 text-pink-200 hover:text-white text-xs transition-colors cursor-pointer text-left"
                            >
                              💬 {followUp}
                            </button>
                          ))}
                        </div>
                      </div>
                    )}

                  </div>
                </div>
              ))}

              {isLoading && (
                <div className="flex items-center gap-2.5 p-3.5 bg-[#0a030e] border border-pink-500/30 rounded-2xl text-xs sm:text-sm font-mono-tech text-pink-300 animate-pulse">
                  <Loader2 className="w-4 h-4 animate-spin text-pink-400" />
                  <span>COMPASS is synthesizing campus neural network data...</span>
                </div>
              )}
            </div>

            {/* Quick Query Pills */}
            <div className="mb-3">
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-[11px] scrollbar-none">
                {categorizedPresets[activeCategoryTab].map((preset, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleSend(preset)}
                    disabled={isLoading}
                    className="px-3 py-1.5 rounded-xl bg-[#0d0412] border border-pink-500/30 hover:border-pink-400 text-pink-200/80 hover:text-white transition-all cursor-pointer whitespace-nowrap shrink-0 hover:shadow-[0_0_12px_rgba(244,114,182,0.25)] text-xs"
                  >
                    {preset}
                  </button>
                ))}
              </div>
            </div>

            {/* Input Box */}
            <div className="relative flex items-center">
              <input
                id="compass-section-input"
                type="text"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                placeholder="Ask COMPASS anything about gear, projects, mentors, PYQs, exams, timings..."
                disabled={isLoading}
                className="w-full pl-4 pr-12 py-3.5 bg-[#0a030e] border border-pink-500/35 focus:border-pink-400 rounded-2xl text-sm text-white placeholder-pink-200/40 focus:outline-none transition-colors font-sans focus:ring-2 focus:ring-pink-500/20"
              />
              <button
                id="compass-section-send-btn"
                onClick={() => handleSend()}
                disabled={!inputText.trim() || isLoading}
                className="absolute right-2 p-2.5 rounded-xl bg-gradient-to-r from-pink-600 via-rose-500 to-pink-400 hover:from-pink-500 hover:to-white hover:text-black disabled:opacity-40 text-white font-bold transition-all cursor-pointer shadow-[0_0_20px_rgba(244,114,182,0.5)]"
                title="Send query"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>

          </div>

          {/* Right: Holographic Star Pedestal */}
          <div className="lg:col-span-4 p-6 sm:p-8 rounded-3xl bg-gradient-to-b from-[#180722]/90 via-[#0e0414]/95 to-[#060309] border border-pink-500/30 relative overflow-hidden shadow-[0_0_40px_rgba(244,114,182,0.2)]">
            
            {/* Ambient Pink Backlight */}
            <div className="absolute inset-0 bg-radial-at-c from-pink-600/25 via-rose-500/10 to-transparent blur-2xl pointer-events-none" />

            <div className="relative z-10 flex flex-col md:grid md:grid-cols-2 md:gap-8 lg:flex lg:flex-col lg:gap-0 items-center justify-center text-center md:text-left lg:text-center">
              {/* Holographic Glowing Pedestal Stage */}
              <div className="relative w-48 h-48 sm:w-56 sm:h-56 flex items-center justify-center mb-4 md:mb-0 lg:mb-4 mx-auto">
                <div className="absolute inset-0 rounded-full border border-pink-500/35 animate-spin-slow" />
                <div className="absolute inset-4 rounded-full border border-rose-400/30 animate-reverse-spin" />
                <div className="absolute inset-10 rounded-full border border-white/30 border-dashed" />
                <div className="absolute bottom-4 w-36 h-8 rounded-full bg-pink-500/30 blur-md" />

                <div className="relative z-10 animate-float">
                  <CompassStarIcon size={100} glow={true} />
                </div>
              </div>

              <div className="w-full flex flex-col justify-center">
                <div className="space-y-1.5 mt-2 md:mt-0 lg:mt-2">
                  <h4 className="text-base font-bold text-white font-heading tracking-wide">
                    Campus Neural Core
                  </h4>
                  <p className="text-xs text-pink-200/70 max-w-xs md:max-w-none lg:max-w-xs mx-auto md:mx-0 lg:mx-auto leading-relaxed">
                    Autonomous reasoning connecting student rosters, borrow items, skill exchanges, and timetable sync with sub-second latency.
                  </p>
                </div>

                {/* Quick Live Stats */}
                <div className="grid grid-cols-2 gap-2 mt-4 sm:mt-5 w-full pt-4 border-t border-pink-500/20 text-left font-mono-tech">
                  <div className="p-2.5 rounded-xl bg-black/50 border border-pink-500/20">
                    <div className="text-[10px] text-pink-200/60">INTELLIGENCE</div>
                    <div className="text-xs font-bold text-pink-300">Gemini 3.7 + Graph</div>
                  </div>
                  <div className="p-2.5 rounded-xl bg-black/50 border border-pink-500/20">
                    <div className="text-[10px] text-pink-200/60">CAMPUS REACH</div>
                    <div className="text-xs font-bold text-white">6 Unified Layers</div>
                  </div>
                </div>

                {/* Prompt trigger cards */}
                <div className="w-full mt-4 space-y-2">
                  <button
                    onClick={() => handleSend("Give me a quick 3-point briefing of what's happening on campus today.")}
                    className="w-full p-2 rounded-xl bg-pink-500/10 hover:bg-pink-500/20 border border-pink-500/30 text-[11px] font-mono-tech text-pink-200 hover:text-white transition-colors text-left flex items-center justify-between cursor-pointer"
                  >
                    <span>⚡ Get Today's Campus Briefing</span>
                    <ArrowUpRight className="w-3.5 h-3.5 text-pink-400" />
                  </button>
                  <button
                    onClick={() => handleSend("What emergency and medical contacts are available 24/7?")}
                    className="w-full p-2 rounded-xl bg-pink-500/10 hover:bg-pink-500/20 border border-pink-500/30 text-[11px] font-mono-tech text-pink-200 hover:text-white transition-colors text-left flex items-center justify-between cursor-pointer"
                  >
                    <span>🚨 Emergency & Medical Contacts</span>
                    <ArrowUpRight className="w-3.5 h-3.5 text-pink-400" />
                  </button>
                </div>
              </div>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};


```

---

## File: `src/components/CreateListingModal.tsx`

```tsx
import React, { useState } from 'react';
import { MarketplaceItem } from '../types';
import { X, Plus, ShoppingBag, CheckCircle, Image as ImageIcon } from 'lucide-react';

interface CreateListingModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCreateItem?: (item: Omit<MarketplaceItem, 'id' | 'createdAt' | 'available'>) => void;
  onCreateListing?: (item: Omit<MarketplaceItem, 'id' | 'createdAt' | 'available'>) => void;
}

export const CreateListingModal: React.FC<CreateListingModalProps> = ({
  isOpen,
  onClose,
  onCreateItem,
  onCreateListing,
}) => {
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<MarketplaceItem['category']>('Books');
  const [price, setPrice] = useState<number>(350);
  const [condition, setCondition] = useState<MarketplaceItem['condition']>('Good');
  const [location, setLocation] = useState('');
  const [description, setDescription] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [success, setSuccess] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !location) return;

    const createFn = onCreateListing || onCreateItem;
    if (createFn) {
      createFn({
        title,
        category,
        price: Number(price),
        condition,
        location,
        sellerId: 'u-current',
        sellerName: 'You (Verified Student)',
        sellerVerified: true,
        sellerDepartment: 'Campus Student',
        description: description || 'No extra description provided.',
        symbol: category === 'Books' ? '∿' : category === 'Electronics' ? '01' : '▱',
        size: 'standard',
        imageUrl: imageUrl || undefined,
      });
    }

    setSuccess(true);
    setTimeout(() => {
      setSuccess(false);
      setTitle('');
      setLocation('');
      setDescription('');
      setImageUrl('');
      onClose();
    }, 1800);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
      <div className="relative w-full max-w-xl bg-[#090C12] border border-cyan-400/40 rounded-2xl p-6 sm:p-8 max-h-[90vh] overflow-y-auto shadow-2xl">
        {/* Close */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-lg bg-zinc-900 border border-white/10 text-zinc-400 hover:text-white transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-xl bg-cyan-950/60 border border-cyan-400/40 flex items-center justify-center text-cyan-300">
            <Plus className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-white font-heading">
              LIST A MARKETPLACE ITEM
            </h2>
            <p className="text-xs font-mono-tech text-cyan-400">
              Give unused items a second student life. +30 Impact points.
            </p>
          </div>
        </div>

        {success ? (
          <div className="p-6 rounded-xl bg-emerald-950/80 border border-emerald-400/40 text-emerald-300 text-center font-mono-tech text-sm">
            <CheckCircle className="w-8 h-8 mx-auto mb-2 text-emerald-400" />
            <div>Listing published successfully to ON CAMPUS Marketplace!</div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-mono-tech text-zinc-300 mb-1">
                ITEM TITLE
              </label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g. Engineering Mathematics Kreyszig 10th Ed or Casio FX-991"
                required
                className="w-full px-3 py-2 bg-zinc-950 border border-white/10 rounded text-sm text-white focus:outline-none focus:border-cyan-400 font-mono-tech"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-mono-tech text-zinc-300 mb-1">
                  CATEGORY
                </label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value as any)}
                  className="w-full px-3 py-2 bg-zinc-950 border border-white/10 rounded text-sm text-white focus:outline-none focus:border-cyan-400 font-mono-tech"
                >
                  <option value="Books">Books</option>
                  <option value="Electronics">Electronics</option>
                  <option value="Furniture">Furniture</option>
                  <option value="Notes">Notes</option>
                  <option value="Equipment">Equipment</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-mono-tech text-zinc-300 mb-1">
                  PRICE (₹ INR)
                </label>
                <input
                  type="number"
                  min="0"
                  value={price}
                  onChange={(e) => setPrice(Number(e.target.value))}
                  required
                  className="w-full px-3 py-2 bg-zinc-950 border border-white/10 rounded text-sm text-white focus:outline-none focus:border-cyan-400 font-mono-tech"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-mono-tech text-zinc-300 mb-1">
                  CONDITION
                </label>
                <select
                  value={condition}
                  onChange={(e) => setCondition(e.target.value as any)}
                  className="w-full px-3 py-2 bg-zinc-950 border border-white/10 rounded text-sm text-white focus:outline-none focus:border-cyan-400 font-mono-tech"
                >
                  <option value="Brand New">Brand New</option>
                  <option value="Like new">Like new</option>
                  <option value="Good">Good</option>
                  <option value="Fair">Fair</option>
                  <option value="Digital scan">Digital scan</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-mono-tech text-zinc-300 mb-1">
                  CAMPUS LOCATION / HOSTEL
                </label>
                <input
                  type="text"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  placeholder="e.g. Block C or PG near Gate 2"
                  required
                  className="w-full px-3 py-2 bg-zinc-950 border border-white/10 rounded text-sm text-white focus:outline-none focus:border-cyan-400 font-mono-tech"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-mono-tech text-zinc-300 mb-1">
                IMAGE URL (OPTIONAL)
              </label>
              <input
                type="url"
                value={imageUrl}
                onChange={(e) => setImageUrl(e.target.value)}
                placeholder="https://images.unsplash.com/..."
                className="w-full px-3 py-2 bg-zinc-950 border border-white/10 rounded text-sm text-white focus:outline-none focus:border-cyan-400 font-mono-tech"
              />
            </div>

            <div>
              <label className="block text-xs font-mono-tech text-zinc-300 mb-1">
                DESCRIPTION & NOTES
              </label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="State any markings, included chargers, semester applicability..."
                rows={3}
                className="w-full px-3 py-2 bg-zinc-950 border border-white/10 rounded text-sm text-white focus:outline-none focus:border-cyan-400 font-mono-tech"
              />
            </div>

            <div className="pt-2">
              <button
                type="submit"
                className="w-full py-3 bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-black font-bold text-xs font-mono-tech tracking-wider uppercase rounded transition-all cursor-pointer shadow-lg"
              >
                PUBLISH LISTING TO CAMPUS
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};

```

---

## File: `src/components/CreatePostModal.tsx`

```tsx
import React, { useState } from 'react';
import { PulsePost } from '../types';
import { X, Radio, Send, CheckCircle } from 'lucide-react';

interface CreatePostModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCreatePost: (post: Omit<PulsePost, 'id' | 'likesCount' | 'commentsCount' | 'timestamp' | 'comments'>) => void;
}

export const CreatePostModal: React.FC<CreatePostModalProps> = ({
  isOpen,
  onClose,
  onCreatePost,
}) => {
  const [text, setText] = useState('');
  const [category, setCategory] = useState<PulsePost['category']>('Projects');
  const [success, setSuccess] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!text.trim()) return;

    onCreatePost({
      author: 'You (Campus Member)',
      authorDepartment: 'Verified Student',
      badge: 'CONTRIBUTOR',
      text: text.trim(),
      category,
    });

    setSuccess(true);
    setTimeout(() => {
      setSuccess(false);
      setText('');
      onClose();
    }, 1500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
      <div className="relative w-full max-w-lg bg-[#090C12] border border-cyan-400/40 rounded-2xl p-6 sm:p-8 shadow-2xl">
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-lg bg-zinc-900 border border-white/10 text-zinc-400 hover:text-white transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-xl bg-cyan-950/60 border border-cyan-400/40 flex items-center justify-center text-cyan-300">
            <Radio className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-white font-heading">
              BROADCAST TO CAMPUS PULSE
            </h2>
            <p className="text-xs font-mono-tech text-cyan-400">
              Share updates, ask questions, or announce club activities.
            </p>
          </div>
        </div>

        {success ? (
          <div className="p-6 rounded-xl bg-emerald-950/80 border border-emerald-400/40 text-emerald-300 text-center font-mono-tech text-sm">
            <CheckCircle className="w-8 h-8 mx-auto mb-2 text-emerald-400" />
            <div>Broadcast dispatched to campus feed!</div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-mono-tech text-zinc-300 mb-1">
                TOPIC CATEGORY
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as any)}
                className="w-full px-3 py-2 bg-zinc-950 border border-white/10 rounded text-sm text-white focus:outline-none focus:border-cyan-400 font-mono-tech"
              >
                <option value="Projects">Projects</option>
                <option value="Events">Events</option>
                <option value="Academic">Academic</option>
                <option value="Discussions">Discussions</option>
                <option value="Sports">Sports</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-mono-tech text-zinc-300 mb-1">
                YOUR CAMPUS PULSE MESSAGE
              </label>
              <textarea
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder="What's happening? e.g. Open hack night at Innovation Lab tonight at 8 PM..."
                rows={4}
                required
                className="w-full px-3 py-2 bg-zinc-950 border border-white/10 rounded text-sm text-white focus:outline-none focus:border-cyan-400 font-mono-tech"
              />
            </div>

            <div className="pt-2">
              <button
                type="submit"
                className="w-full py-3 bg-cyan-400 hover:bg-cyan-300 text-black font-bold text-xs font-mono-tech tracking-wider uppercase rounded transition-all cursor-pointer shadow-lg flex items-center justify-center gap-2"
              >
                <Send className="w-4 h-4" />
                <span>BROADCAST NOW (+10 IMPACT)</span>
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};

```

---

## File: `src/components/CreateProjectModal.tsx`

```tsx
import React, { useState } from 'react';
import { ProjectItem } from '../types';
import { X, Plus, Layers, CheckCircle } from 'lucide-react';

interface CreateProjectModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCreateProject: (project: Omit<ProjectItem, 'id' | 'membersCount' | 'followersCount' | 'updatesCount'>) => void;
}

export const CreateProjectModal: React.FC<CreateProjectModalProps> = ({
  isOpen,
  onClose,
  onCreateProject,
}) => {
  const [name, setName] = useState('');
  const [tagline, setTagline] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('AI / ROBOTICS');
  const [skillsText, setSkillsText] = useState('Python, React, Fast API');
  const [recruiting, setRecruiting] = useState(true);
  const [progressPercent, setProgressPercent] = useState(25);
  const [success, setSuccess] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !tagline) return;

    const skillsRequired = skillsText
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean);

    onCreateProject({
      name,
      tagline,
      description: description || tagline,
      category,
      creator: 'You (Project Builder)',
      creatorTitle: 'Project Builder',
      progressPercent: Number(progressPercent),
      skillsRequired: skillsRequired.length > 0 ? skillsRequired : ['Open Collab'],
      recruiting,
      accentColor: '#9B7CFF',
      recentUpdate: 'Project published on the ON CAMPUS Research Hub.',
    });

    setSuccess(true);
    setTimeout(() => {
      setSuccess(false);
      setName('');
      setTagline('');
      setDescription('');
      onClose();
    }, 1800);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
      <div className="relative w-full max-w-xl bg-[#090C12] border border-violet-400/40 rounded-2xl p-6 sm:p-8 max-h-[90vh] overflow-y-auto shadow-2xl">
        {/* Close */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-lg bg-zinc-900 border border-white/10 text-zinc-400 hover:text-white transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-xl bg-violet-950/60 border border-violet-400/40 flex items-center justify-center text-violet-300">
            <Plus className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-white font-heading">
              PUBLISH A RESEARCH PROJECT
            </h2>
            <p className="text-xs font-mono-tech text-violet-400">
              Gather a team, find skilled collaborators and build in public. +60 Impact.
            </p>
          </div>
        </div>

        {success ? (
          <div className="p-6 rounded-xl bg-emerald-950/80 border border-emerald-400/40 text-emerald-300 text-center font-mono-tech text-sm">
            <CheckCircle className="w-8 h-8 mx-auto mb-2 text-emerald-400" />
            <div>Project published to ON CAMPUS showcase!</div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-mono-tech text-zinc-300 mb-1">
                PROJECT NAME
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Autonomous Campus Delivery Robot"
                required
                className="w-full px-3 py-2 bg-zinc-950 border border-white/10 rounded text-sm text-white focus:outline-none focus:border-violet-400 font-mono-tech"
              />
            </div>

            <div>
              <label className="block text-xs font-mono-tech text-zinc-300 mb-1">
                ONE-LINE TAGLINE
              </label>
              <input
                type="text"
                value={tagline}
                onChange={(e) => setTagline(e.target.value)}
                placeholder="e.g. Low-cost LiDAR navigation rover for hostel deliveries"
                required
                className="w-full px-3 py-2 bg-zinc-950 border border-white/10 rounded text-sm text-white focus:outline-none focus:border-violet-400 font-mono-tech"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-mono-tech text-zinc-300 mb-1">
                  CATEGORY
                </label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full px-3 py-2 bg-zinc-950 border border-white/10 rounded text-sm text-white focus:outline-none focus:border-violet-400 font-mono-tech"
                >
                  <option value="AI / ROBOTICS">AI / ROBOTICS</option>
                  <option value="IOT / SUSTAINABILITY">IOT / SUSTAINABILITY</option>
                  <option value="EDTECH / NLP">EDTECH / NLP</option>
                  <option value="SYSTEMS / MOBILITY">SYSTEMS / MOBILITY</option>
                  <option value="BIOTECH / HEALTH">BIOTECH / HEALTH</option>
                  <option value="FINTECH / CRYPTO">FINTECH / CRYPTO</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-mono-tech text-zinc-300 mb-1">
                  CURRENT PROGRESS ({progressPercent}%)
                </label>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={progressPercent}
                  onChange={(e) => setProgressPercent(Number(e.target.value))}
                  className="w-full mt-2 accent-violet-400"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-mono-tech text-zinc-300 mb-1">
                SKILLS REQUIRED (COMMA-SEPARATED)
              </label>
              <input
                type="text"
                value={skillsText}
                onChange={(e) => setSkillsText(e.target.value)}
                placeholder="e.g. Python, ROS 2, SolidWorks, PyTorch"
                className="w-full px-3 py-2 bg-zinc-950 border border-white/10 rounded text-sm text-white focus:outline-none focus:border-violet-400 font-mono-tech"
              />
            </div>

            <div>
              <label className="block text-xs font-mono-tech text-zinc-300 mb-1">
                DETAILED RESEARCH ABSTRACT & GOALS
              </label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Explain the hardware architecture, software stack, milestone roadmaps and what teammates will learn."
                rows={3}
                className="w-full px-3 py-2 bg-zinc-950 border border-white/10 rounded text-sm text-white focus:outline-none focus:border-violet-400 font-mono-tech"
              />
            </div>

            <div className="flex items-center gap-2 pt-1">
              <input
                type="checkbox"
                id="recruiting-check"
                checked={recruiting}
                onChange={(e) => setRecruiting(e.target.checked)}
                className="rounded accent-violet-400"
              />
              <label htmlFor="recruiting-check" className="text-xs font-mono-tech text-zinc-300 cursor-pointer">
                Actively looking for collaborators / teammates across campus
              </label>
            </div>

            <div className="pt-2">
              <button
                type="submit"
                className="w-full py-3 bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 text-white font-bold text-xs font-mono-tech tracking-wider uppercase rounded transition-all cursor-pointer shadow-lg"
              >
                PUBLISH PROJECT TO CAMPUS (+60 IMPACT)
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};

```

---

## File: `src/components/DirectMessageModal.tsx`

```tsx
import React, { useState, useEffect, useRef } from 'react';
import { 
  X, 
  Send, 
  Lock, 
  Globe, 
  ShieldCheck, 
  MessageSquare, 
  Sparkles, 
  Building2, 
  Maximize2,
  CheckCheck
} from 'lucide-react';
import { UserProfile, DirectMessage } from '../types';

interface DirectMessageModalProps {
  isOpen: boolean;
  onClose: () => void;
  targetUser: UserProfile | null;
  currentUser: UserProfile;
  messages: DirectMessage[];
  onSendMessage: (targetUserId: string, text: string) => void;
  onSendFriendRequest: (targetUserId: string) => void;
  onOpenPassport?: (user: UserProfile) => void;
  onOpenInPageChat?: (user: UserProfile) => void;
}

const QUICK_CAMPUS_PROMPTS = [
  'Hey! Are you open to collaborating on a project?',
  'Hi! Saw your verified notes, would love to ask a quick question.',
  'Hey, is the lab equipment still available to borrow?',
  'Hi! Would you be up for a skill swap session this week?'
];

export const DirectMessageModal: React.FC<DirectMessageModalProps> = ({
  isOpen,
  onClose,
  targetUser,
  currentUser,
  messages,
  onSendMessage,
  onOpenPassport,
  onOpenInPageChat,
}) => {
  const [inputText, setInputText] = useState('');
  const chatScrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Auto-scroll chat container to bottom when new messages arrive
  useEffect(() => {
    if (chatScrollRef.current) {
      chatScrollRef.current.scrollTo({
        top: chatScrollRef.current.scrollHeight,
        behavior: 'smooth'
      });
    }
  }, [messages.length, isOpen]);

  if (!isOpen || !targetUser) return null;

  const isPrivate = !!targetUser.isPrivate;

  // Filter messages between currentUser and targetUser
  const conversation = messages.filter(
    (m) =>
      (m.senderId === currentUser.id && m.receiverId === targetUser.id) ||
      (m.senderId === targetUser.id && m.receiverId === currentUser.id)
  );

  const handleSend = (e?: React.FormEvent, directText?: string) => {
    if (e) e.preventDefault();
    const textToSend = (directText !== undefined ? directText : inputText).trim();
    if (!textToSend) return;
    onSendMessage(targetUser.id, textToSend);
    setInputText('');
    if (inputRef.current) {
      inputRef.current.focus();
    }
  };

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 overflow-y-auto bg-black/85 backdrop-blur-xl animate-in fade-in duration-200"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div 
        id="direct-message-modal-card"
        className="relative w-full max-w-xl bg-[#0b0c14] border border-white/15 rounded-3xl shadow-[0_0_60px_rgba(0,242,255,0.15)] flex flex-col overflow-hidden text-white h-[85vh] max-h-[640px]"
      >
        {/* Glow header */}
        <div className="absolute top-0 left-0 right-0 h-28 bg-gradient-to-b from-[#00f2ff]/20 via-[#c084fc]/10 to-transparent blur-xl pointer-events-none" />

        {/* Top Chat Header */}
        <div className="p-4 sm:p-5 border-b border-white/[0.08] flex items-center justify-between relative z-10 bg-[#0e0f1a]/95 backdrop-blur-md">
          <div className="flex items-center gap-3">
            <div 
              onClick={() => onOpenPassport && onOpenPassport(targetUser)}
              className="relative cursor-pointer group shrink-0"
              title="Click to view full Student Passport"
            >
              <img
                src={targetUser.avatar}
                alt={targetUser.name}
                className="w-11 h-11 rounded-2xl object-cover border-2 border-[#00f2ff]/50 group-hover:border-[#00f2ff] transition-all"
              />
              <span className="absolute -bottom-1 -right-1 px-1.5 py-0.2 rounded-full bg-[#00f2ff] text-black text-[9px] font-mono-tech font-bold">
                #{targetUser.rank}
              </span>
            </div>

            <div>
              <div className="flex items-center gap-2">
                <h3 
                  onClick={() => onOpenPassport && onOpenPassport(targetUser)}
                  className="text-base font-bold text-white font-heading cursor-pointer hover:text-[#00f2ff] transition-colors"
                >
                  {targetUser.name}
                </h3>
                <ShieldCheck className="w-4 h-4 text-[#00f2ff]" />
              </div>

              <div className="flex items-center gap-2 text-xs font-mono-tech mt-0.5">
                <span className="text-white/60">{targetUser.department}</span>
                <span className="text-white/30">•</span>
                {isPrivate ? (
                  <span className="text-amber-300 flex items-center gap-1 text-[11px]">
                    <Lock className="w-3 h-3" /> Private Peer ID
                  </span>
                ) : (
                  <span className="text-emerald-400 flex items-center gap-1 text-[11px]">
                    <Globe className="w-3 h-3" /> Public Profile
                  </span>
                )}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            {onOpenInPageChat && (
              <button
                onClick={() => {
                  onClose();
                  onOpenInPageChat(targetUser);
                }}
                className="w-8 h-8 rounded-full bg-white/[0.06] hover:bg-cyan-500/20 text-white/70 hover:text-[#00f2ff] flex items-center justify-center transition-colors cursor-pointer border border-white/10"
                title="Expand to Full Campus Chat Section"
                aria-label="Open Full Campus Chat Section"
              >
                <Maximize2 className="w-4 h-4" />
              </button>
            )}

            <button
              onClick={onClose}
              className="w-8 h-8 rounded-full bg-white/[0.06] hover:bg-white/[0.15] text-white/70 hover:text-white flex items-center justify-center transition-colors cursor-pointer border border-white/10"
              aria-label="Close direct messaging"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Messaging Area */}
        <div 
          ref={chatScrollRef}
          className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-3 custom-scrollbar flex flex-col justify-between"
        >
          {/* Top Profile Summary Badge */}
          <div className="p-3 rounded-2xl bg-[#121422] border border-white/5 flex items-center justify-between text-xs font-mono-tech">
            <div className="flex items-center gap-2 text-white/70">
              <Building2 className="w-3.5 h-3.5 text-[#00f2ff]" />
              <span>{targetUser.hostelWing || 'Campus Resident'}</span>
            </div>
            <div className="text-[#00f2ff]">
              Impact: {targetUser.impactScore} PTS
            </div>
          </div>

          {/* Open Chat History */}
          <div className="flex-1 space-y-3 overflow-y-auto py-2">
            {conversation.length === 0 ? (
              <div className="py-10 text-center text-white/40 font-mono-tech space-y-2">
                <MessageSquare className="w-8 h-8 mx-auto text-white/20" />
                <p className="text-xs">Start of your direct peer chat with {targetUser.name}.</p>
                <p className="text-[11px] text-[#00f2ff]/70">
                  {isPrivate ? '🔒 Encrypted Direct Channel' : '🌐 Verified Campus Messaging'}
                </p>
              </div>
            ) : (
              conversation.map((msg) => {
                const isMine = msg.senderId === currentUser.id;
                return (
                  <div
                    key={msg.id}
                    className={`flex flex-col ${isMine ? 'items-end' : 'items-start'}`}
                  >
                    <div
                      className={`max-w-[80%] p-3.5 rounded-2xl text-xs sm:text-sm font-sans leading-relaxed ${
                        isMine
                          ? 'bg-[#00f2ff] text-black font-medium rounded-br-none shadow-[0_0_15px_rgba(0,242,255,0.2)]'
                          : 'bg-[#181a29] text-white border border-white/10 rounded-bl-none'
                      }`}
                    >
                      {msg.text}
                    </div>
                    <div className="flex items-center gap-1 mt-1 px-1">
                      <span className="text-[10px] font-mono-tech text-white/40">
                        {msg.timestamp}
                      </span>
                      {isMine && (
                        <CheckCheck className="w-3 h-3 text-[#00f2ff]" />
                      )}
                    </div>
                  </div>
                );
              })
            )}
          </div>

          {/* Quick Prompts */}
          {conversation.length === 0 && (
            <div className="pt-2 border-t border-white/[0.06]">
              <div className="text-[11px] font-mono-tech text-white/40 mb-1.5 flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-[#00f2ff]" />
                <span>Suggested quick messages:</span>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {QUICK_CAMPUS_PROMPTS.map((prompt, i) => (
                  <button
                    key={i}
                    onClick={() => handleSend(undefined, prompt)}
                    className="text-[11px] font-sans px-2.5 py-1 rounded-lg bg-white/[0.04] hover:bg-white/[0.1] hover:border-[#00f2ff]/30 text-white/70 hover:text-white border border-white/5 transition-colors cursor-pointer text-left"
                  >
                    {prompt}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Input Bar */}
        <form 
          onSubmit={handleSend}
          className="p-3 sm:p-4 border-t border-white/[0.08] bg-[#0e0f1a] flex items-center gap-2"
        >
          <input
            ref={inputRef}
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSend();
              }
            }}
            placeholder={`Message ${targetUser.name.split(' ')[0]} directly...`}
            className="flex-1 px-4 py-2.5 bg-[#141625] border border-white/10 rounded-2xl text-xs sm:text-sm text-white placeholder-white/40 focus:outline-none focus:border-[#00f2ff] font-sans"
          />
          <button
            type="submit"
            disabled={!inputText.trim()}
            className="px-4 py-2.5 rounded-2xl bg-[#00f2ff] hover:bg-[#38f6ff] disabled:opacity-30 text-black font-bold text-xs font-mono-tech flex items-center gap-1.5 transition-all cursor-pointer shadow-[0_0_12px_rgba(0,242,255,0.3)] shrink-0"
          >
            <span>Send</span>
            <Send className="w-3.5 h-3.5" />
          </button>
        </form>
      </div>
    </div>
  );
};

```

---

## File: `src/components/FinalCinematicSection.tsx`

```tsx
import React from 'react';
import { ArrowRight, Sparkles } from 'lucide-react';
import { OnCampusOrbitalIcon } from './BrandLogos';

interface FinalCinematicSectionProps {
  onEnterApp: () => void;
}

export const FinalCinematicSection: React.FC<FinalCinematicSectionProps> = ({
  onEnterApp,
}) => {
  return (
    <section className="py-28 relative overflow-hidden bg-[#04060d] text-center border-t border-white/[0.08]">
      {/* Background radial glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[500px] bg-gradient-to-r from-violet-600/15 via-cyan-500/10 to-transparent rounded-full blur-3xl pointer-events-none -z-10 animate-pulse-slow" />

      {/* Futuristic Horizon Grid Line */}
      <div className="max-w-5xl mx-auto px-4 h-16 mb-6 relative opacity-60 flex items-center justify-center">
        <div className="w-full h-[1px] bg-gradient-to-r from-transparent via-cyan-400 to-transparent shadow-[0_0_15px_#22d3ee]" />
      </div>

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-violet-500/10 border border-violet-500/30 text-violet-300 text-xs font-mono-tech tracking-[2px] uppercase font-bold">
          <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
          <span>09 // THE FUTURE TOGETHER</span>
        </div>

        {/* Big On Campus Emblem */}
        <div className="flex justify-center my-4">
          <div className="p-4 rounded-3xl bg-[#090d1f]/80 border border-violet-500/30 shadow-[0_0_50px_rgba(139,92,246,0.3)]">
            <OnCampusOrbitalIcon size={64} />
          </div>
        </div>

        <h2 className="text-4xl sm:text-6xl lg:text-7xl font-bold text-white tracking-normal leading-[1.05] font-heading">
          Everything your campus has. <br />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-300 via-white to-violet-400 drop-shadow-[0_0_35px_rgba(34,211,238,0.4)]">
            Connected.
          </span>
        </h2>

        <p className="text-base sm:text-xl text-zinc-400 font-normal max-w-xl mx-auto tracking-widest uppercase font-mono-tech">
          It was all already there. We just connected it.
        </p>

        <div className="pt-4">
          <button
            id="final-enter-btn"
            onClick={onEnterApp}
            className="px-9 py-4 bg-gradient-to-r from-violet-600 via-indigo-600 to-cyan-500 hover:from-violet-500 hover:to-cyan-400 text-white font-bold text-sm font-mono-tech tracking-[2px] uppercase rounded-full inline-flex items-center gap-3 shadow-[0_0_35px_rgba(139,92,246,0.5)] hover:scale-105 transition-all cursor-pointer"
          >
            <span>ENTER ON CAMPUS</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        {/* 6 Key Manifesto Stats */}
        <div className="pt-16 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3.5 text-left border-t border-white/[0.08] mt-16 font-mono-tech">
          <div className="p-4 bg-[#090d1c] border border-violet-500/20 rounded-2xl">
            <div className="text-xl font-black text-white font-heading">12,850+</div>
            <div className="text-[10px] text-zinc-400 mt-0.5 uppercase">Students</div>
          </div>
          <div className="p-4 bg-[#090d1c] border border-violet-500/20 rounded-2xl">
            <div className="text-xl font-black text-white font-heading">256+</div>
            <div className="text-[10px] text-zinc-400 mt-0.5 uppercase">Projects</div>
          </div>
          <div className="p-4 bg-[#090d1c] border border-violet-500/20 rounded-2xl">
            <div className="text-xl font-black text-white font-heading">18,430+</div>
            <div className="text-[10px] text-zinc-400 mt-0.5 uppercase">Connections</div>
          </div>
          <div className="p-4 bg-[#090d1c] border border-violet-500/20 rounded-2xl">
            <div className="text-xl font-black text-cyan-400 font-heading">2.4L+</div>
            <div className="text-[10px] text-zinc-400 mt-0.5 uppercase">Resources Shared</div>
          </div>
          <div className="p-4 bg-[#090d1c] border border-violet-500/20 rounded-2xl">
            <div className="text-xl font-black text-violet-400 font-heading">96+</div>
            <div className="text-[10px] text-zinc-400 mt-0.5 uppercase">Communities</div>
          </div>
          <div className="p-4 bg-[#090d1c] border border-violet-500/20 rounded-2xl">
            <div className="text-xl font-black text-white font-heading">∞</div >
            <div className="text-[10px] text-zinc-400 mt-0.5 uppercase">Possibilities</div>
          </div>
        </div>
      </div>
    </section>
  );
};


```

---

## File: `src/components/FloatingCompassWidget.tsx`

```tsx
import React, { useState, useRef, useEffect } from 'react';
import { CompassMessage } from '../types';
import { 
  Send, 
  Sparkles, 
  Loader2, 
  X, 
  Minimize2, 
  Maximize2, 
  ArrowUpRight, 
  Copy, 
  Check, 
  Volume2, 
  VolumeX, 
  Zap, 
  HelpCircle,
  MessageSquare
} from 'lucide-react';
import { CompassStarIcon } from './BrandLogos';

interface FloatingCompassWidgetProps {
  messages: CompassMessage[];
  onSendMessage: (text: string) => void;
  isLoading: boolean;
  onSelectActionCard?: (action: string, targetId: string) => void;
  isOpen: boolean;
  onToggle: () => void;
}

export const FloatingCompassWidget: React.FC<FloatingCompassWidgetProps> = ({
  messages,
  onSendMessage,
  isLoading,
  onSelectActionCard,
  isOpen,
  onToggle,
}) => {
  const [inputText, setInputText] = useState('');
  const [isExpanded, setIsExpanded] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);
  const [copiedMsgId, setCopiedMsgId] = useState<string | null>(null);
  const [speakingMsgId, setSpeakingMsgId] = useState<string | null>(null);
  const messagesContainerRef = useRef<HTMLDivElement | null>(null);
  const prevMsgLengthRef = useRef(messages.length);

  const presets = [
    'Where can I borrow a calculator today?',
    'Who has PYQs for Operating Systems?',
    'Any AI squads recruiting members?',
    'Who is offering Figma UX mentorship?',
  ];

  // Track unread messages if widget is closed
  useEffect(() => {
    if (!isOpen && messages.length > prevMsgLengthRef.current) {
      setUnreadCount((prev) => prev + (messages.length - prevMsgLengthRef.current));
    }
    prevMsgLengthRef.current = messages.length;
  }, [messages, isOpen]);

  // Reset unread count when opening & container scroll
  useEffect(() => {
    if (isOpen) {
      setUnreadCount(0);
      if (messagesContainerRef.current) {
        messagesContainerRef.current.scrollTo({
          top: messagesContainerRef.current.scrollHeight,
          behavior: 'smooth',
        });
      }
    }
  }, [isOpen, messages.length, isLoading]);

  const handleSend = (textToSend?: string) => {
    const text = textToSend || inputText;
    if (!text.trim() || isLoading) return;
    onSendMessage(text.trim());
    if (!textToSend) setInputText('');
  };

  const handleCopyText = (msgId: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedMsgId(msgId);
    setTimeout(() => setCopiedMsgId(null), 2000);
  };

  const handleSpeakText = (msgId: string, text: string) => {
    if (!('speechSynthesis' in window)) return;

    if (speakingMsgId === msgId) {
      window.speechSynthesis.cancel();
      setSpeakingMsgId(null);
      return;
    }

    window.speechSynthesis.cancel();
    const cleanSpeechText = text.replace(/[*#`_•]/g, ' ');
    const utterance = new SpeechSynthesisUtterance(cleanSpeechText);
    utterance.rate = 1.05;
    utterance.pitch = 1.0;
    utterance.onend = () => setSpeakingMsgId(null);
    utterance.onerror = () => setSpeakingMsgId(null);

    setSpeakingMsgId(msgId);
    window.speechSynthesis.speak(utterance);
  };

  // Formatted rendering helper
  const renderFormattedMessage = (rawText: string) => {
    const lines = rawText.split('\n');
    return (
      <div className="space-y-1.5 leading-relaxed text-sm font-sans">
        {lines.map((line, i) => {
          if (!line.trim()) return <div key={i} className="h-1.5" />;

          const parts = line.split(/(\*\*.*?\*\*|`.*?`)/g);
          const isBullet = line.trim().startsWith('•') || line.trim().startsWith('-');

          return (
            <div key={i} className={`${isBullet ? 'pl-2 text-zinc-300' : 'text-zinc-200'}`}>
              {parts.map((part, j) => {
                if (part.startsWith('**') && part.endsWith('**')) {
                  return (
                    <strong key={j} className="text-white font-bold">
                      {part.slice(2, -2)}
                    </strong>
                  );
                }
                if (part.startsWith('`') && part.endsWith('`')) {
                  return (
                    <code key={j} className="px-1.5 py-0.5 rounded bg-black/40 text-pink-300 font-mono text-xs border border-pink-500/20">
                      {part.slice(1, -1)}
                    </code>
                  );
                }
                return <span key={j}>{part}</span>;
              })}
            </div>
          );
        })}
      </div>
    );
  };

  return (
    <div className="fixed bottom-4 right-4 sm:bottom-6 sm:right-6 z-50 flex flex-col items-end pointer-events-none select-none">
      
      {/* ========================================================================= */}
      {/* POPUP CHATBOX (Pink & White themed) */}
      {/* ========================================================================= */}
      {isOpen && (
        <div 
          id="compass-floating-chatbox"
          className={`pointer-events-auto mb-3 sm:mb-4 bg-[#0a060e]/95 backdrop-blur-2xl border border-pink-500/30 rounded-3xl shadow-[0_20px_70px_rgba(236,72,153,0.35)] flex flex-col overflow-hidden transition-all duration-300 animate-in fade-in zoom-in-95 origin-bottom-right ${
            isExpanded 
              ? 'w-[calc(100vw-2rem)] sm:w-[500px] h-[82vh] max-h-[750px]' 
              : 'w-[calc(100vw-2rem)] sm:w-[400px] h-[540px] max-h-[82vh]'
          }`}
        >
          {/* Top Bar with Pink-to-White gradient banner */}
          <div className="px-5 py-4 bg-gradient-to-r from-pink-950/80 via-[#150a1b]/90 to-[#0c0612]/90 border-b border-pink-500/20 flex items-center justify-between relative">
            
            {/* Ambient Pink Top Highlight */}
            <div className="absolute top-0 left-0 right-0 h-[1.5px] bg-gradient-to-r from-transparent via-pink-400 to-transparent" />

            <div className="flex items-center gap-3">
              {/* Compass Icon Badge */}
              <div className="relative">
                <CompassStarIcon size={36} />
                <span className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 bg-pink-400 border-2 border-black rounded-full shadow-[0_0_6px_#f472b6]" />
              </div>

              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-sm font-bold text-white font-heading tracking-wide">
                    COMPASS <span className="text-transparent bg-clip-text bg-gradient-to-r from-pink-300 via-rose-200 to-white">AI</span>
                  </h3>
                  <span className="px-1.5 py-0.5 rounded text-[9px] font-mono-tech uppercase font-bold bg-pink-500/20 text-pink-300 border border-pink-500/40 shadow-sm">
                    Gemini 3.7
                  </span>
                </div>
                <p className="text-[11px] text-pink-200/70 font-normal">
                  Your instant campus neural co-pilot
                </p>
              </div>
            </div>

            {/* Window Controls */}
            <div className="flex items-center gap-1.5">
              <button
                onClick={() => setIsExpanded(!isExpanded)}
                className="p-1.5 rounded-xl bg-white/[0.05] hover:bg-pink-500/20 text-white/70 hover:text-white border border-white/10 transition-all cursor-pointer"
                title={isExpanded ? 'Collapse view' : 'Expand view'}
              >
                {isExpanded ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
              </button>

              <button
                onClick={onToggle}
                className="p-1.5 rounded-xl bg-white/[0.05] hover:bg-rose-500/30 text-white/70 hover:text-white border border-white/10 transition-all cursor-pointer"
                title="Close chat"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Messages Feed */}
          <div ref={messagesContainerRef} className="flex-1 p-4 sm:p-5 overflow-y-auto space-y-4 custom-scrollbar bg-gradient-to-b from-transparent to-pink-950/10">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex flex-col ${
                  msg.sender === 'user' ? 'items-end' : 'items-start'
                }`}
              >
                <div
                  className={`max-w-[90%] p-3.5 sm:p-4 rounded-2xl text-sm leading-relaxed transition-all shadow-md ${
                    msg.sender === 'user'
                      ? 'bg-gradient-to-r from-pink-500 to-rose-400 text-white font-medium shadow-[0_4px_20px_rgba(244,114,182,0.35)] rounded-br-none'
                      : 'bg-[#150a1d]/90 border border-pink-500/25 text-slate-100 rounded-bl-none shadow-black/50'
                  }`}
                >
                  {msg.sender === 'compass' && (
                    <div className="flex items-center justify-between gap-2 pb-2 mb-2 border-b border-pink-500/20 text-[11px] font-mono-tech">
                      <div className="flex items-center gap-1.5 text-pink-300 font-bold">
                        <Sparkles className="w-3 h-3 text-pink-300" />
                        <span>COMPASS AI</span>
                        {msg.category && (
                          <span className="px-1.5 py-0.5 rounded-full bg-pink-950 text-[9px] text-pink-200 border border-pink-500/30">
                            {msg.category}
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => handleSpeakText(msg.id, msg.text)}
                          className="p-1 rounded bg-white/5 hover:bg-pink-500/20 text-pink-300 transition-colors cursor-pointer"
                          title="Read aloud"
                        >
                          {speakingMsgId === msg.id ? <VolumeX className="w-3 h-3 text-rose-400 animate-pulse" /> : <Volume2 className="w-3 h-3" />}
                        </button>
                        <button
                          onClick={() => handleCopyText(msg.id, msg.text)}
                          className="p-1 rounded bg-white/5 hover:bg-pink-500/20 text-pink-300 transition-colors cursor-pointer"
                          title="Copy response"
                        >
                          {copiedMsgId === msg.id ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                        </button>
                      </div>
                    </div>
                  )}

                  {/* Rendered Markdown Body */}
                  {renderFormattedMessage(msg.text)}

                  {/* Interactive Action Cards */}
                  {msg.suggestedCards && msg.suggestedCards.length > 0 && (
                    <div className="mt-3 space-y-2 pt-2 border-t border-pink-500/20">
                      {msg.suggestedCards.map((card, idx) => (
                        <div
                          key={idx}
                          onClick={() =>
                            onSelectActionCard &&
                            onSelectActionCard(card.type, card.targetId)
                          }
                          className="p-2.5 rounded-xl bg-black/60 border border-pink-500/30 hover:border-pink-400 text-left transition-all cursor-pointer flex items-center justify-between gap-2 group hover:bg-pink-950/40"
                        >
                          <div className="min-w-0 flex-1">
                            <div className="flex items-center gap-1.5">
                              <span className="text-[9px] font-mono-tech text-pink-300 uppercase px-1.5 py-0.5 rounded bg-pink-500/20 font-bold">
                                {card.tag}
                              </span>
                              <span className="text-[9px] text-pink-200/60 font-mono-tech">
                                {card.actionLabel || 'View'}
                              </span>
                            </div>
                            <div className="text-xs font-bold text-white mt-1 group-hover:text-pink-300 transition-colors truncate">
                              {card.title}
                            </div>
                            <div className="text-[10px] text-white/60 truncate">
                              {card.subtitle}
                            </div>
                          </div>
                          <ArrowUpRight className="w-3.5 h-3.5 text-pink-400 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform shrink-0" />
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Interactive Follow-Up Chips */}
                  {msg.followUpQueries && msg.followUpQueries.length > 0 && (
                    <div className="mt-2.5 pt-2 border-t border-pink-500/15">
                      <div className="text-[9px] font-mono-tech text-pink-200/50 uppercase tracking-wider mb-1">
                        FOLLOW UP:
                      </div>
                      <div className="flex flex-wrap gap-1">
                        {msg.followUpQueries.map((followUp, fIdx) => (
                          <button
                            key={fIdx}
                            onClick={() => handleSend(followUp)}
                            className="px-2 py-0.5 rounded-md bg-pink-950/40 hover:bg-pink-500/20 border border-pink-500/30 text-pink-200 hover:text-white text-[11px] transition-colors cursor-pointer text-left"
                          >
                            💬 {followUp}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                </div>

                <span className="text-[10px] font-mono-tech text-white/40 mt-1 px-1">
                  {msg.timestamp}
                </span>
              </div>
            ))}

            {isLoading && (
              <div className="flex items-center gap-2.5 p-3 bg-[#150a1d]/80 border border-pink-500/30 rounded-2xl text-xs font-mono-tech text-pink-300 animate-pulse">
                <Loader2 className="w-3.5 h-3.5 animate-spin text-pink-400" />
                <span>COMPASS is querying campus network...</span>
              </div>
            )}
          </div>

          {/* Quick Suggestion Chips */}
          <div className="px-3.5 py-2 border-t border-pink-500/15 bg-black/40">
            <div className="flex items-center gap-1.5 overflow-x-auto pb-0.5 scrollbar-none">
              {presets.map((preset, idx) => (
                <button
                  key={idx}
                  onClick={() => handleSend(preset)}
                  disabled={isLoading}
                  className="px-2.5 py-1 rounded-xl bg-pink-500/10 hover:bg-pink-500/20 border border-pink-500/25 text-[11px] font-medium text-pink-200 whitespace-nowrap transition-all cursor-pointer shrink-0"
                >
                  {preset}
                </button>
              ))}
            </div>
          </div>

          {/* Input Area */}
          <div className="p-3.5 bg-black/70 border-t border-pink-500/20">
            <div className="relative flex items-center">
              <input
                id="floating-compass-input"
                type="text"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                placeholder="Ask COMPASS anything..."
                disabled={isLoading}
                className="w-full pl-3.5 pr-11 py-2.5 bg-[#150a1d] border border-pink-500/30 focus:border-pink-400 rounded-xl text-xs sm:text-sm text-white placeholder-pink-200/50 focus:outline-none transition-all shadow-inner focus:shadow-[0_0_20px_rgba(244,114,182,0.2)] font-sans"
              />
              <button
                id="floating-compass-send"
                onClick={() => handleSend()}
                disabled={!inputText.trim() || isLoading}
                className="absolute right-1.5 p-2 rounded-lg bg-gradient-to-r from-pink-500 to-rose-400 hover:from-pink-400 hover:to-rose-300 disabled:opacity-40 text-white transition-all cursor-pointer shadow-[0_0_15px_rgba(244,114,182,0.4)]"
              >
                <Send className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

        </div>
      )}

      {/* ========================================================================= */}
      {/* FLOATING COMPASS LOGO BUTTON (Pink & White Mixture Glow) */}
      {/* ========================================================================= */}
      <button
        id="floating-compass-trigger-btn"
        onClick={onToggle}
        className="pointer-events-auto relative group p-1 rounded-full cursor-pointer transition-transform duration-300 hover:scale-110 active:scale-95 focus:outline-none"
        title="Open COMPASS AI Assistant"
      >
        {/* Luminous Pulsing Pink Glow Rings */}
        <div className="absolute inset-0 rounded-full bg-gradient-to-r from-pink-600 via-rose-400 to-white opacity-75 blur-md group-hover:opacity-100 group-hover:blur-lg transition-all animate-pulse" />

        {/* Outer Dual-Tone Pink + White Ring */}
        <div className="relative w-13 h-13 sm:w-14 sm:h-14 rounded-full bg-gradient-to-tr from-pink-500 via-rose-300 to-white p-[2px] shadow-[0_0_30px_rgba(244,114,182,0.8)] flex items-center justify-center">
          
          {/* Inner Dark Radial Capsule */}
          <div className="w-full h-full rounded-full bg-[#120718] flex items-center justify-center relative overflow-hidden">
            <CompassStarIcon size={34} />
          </div>

          {/* Unread Message / Live Active Ping Badge */}
          {unreadCount > 0 ? (
            <span className="absolute -top-1 -right-1 px-1.5 py-0.5 rounded-full bg-white text-pink-600 font-bold text-[10px] shadow-[0_0_10px_#ffffff] animate-bounce">
              {unreadCount}
            </span>
          ) : (
            <span className="absolute top-0 right-0 w-3 h-3 rounded-full bg-pink-400 border-2 border-black animate-ping shadow-[0_0_6px_#f472b6]" />
          )}

        </div>

        {/* Hover Tooltip Pill */}
        <div className="absolute right-full mr-3 top-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-100 pointer-events-none transition-all duration-200 translate-x-2 group-hover:translate-x-0 whitespace-nowrap px-3.5 py-1.5 rounded-full bg-[#14081c]/95 border border-pink-500/40 text-white text-xs font-semibold backdrop-blur-xl shadow-lg flex items-center gap-1.5">
          <Sparkles className="w-3.5 h-3.5 text-pink-300" />
          <span>Ask COMPASS</span>
        </div>
      </button>

    </div>
  );
};


```

---

## File: `src/components/Footer.tsx`

```tsx
import React from 'react';
import { Sparkles, ArrowUp, Shield, Zap } from 'lucide-react';
import { OnCampusOrbitalIcon } from './BrandLogos';

export const Footer: React.FC = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const scrollTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#03050b] border-t border-white/[0.08] text-white/70 text-sm">
      {/* Top Footer Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10">
          {/* Brand Col */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-3">
              <OnCampusOrbitalIcon size={32} />
              <span className="text-lg font-bold tracking-[3px] text-white font-mono-tech uppercase">
                ON CAMPUS
              </span>
            </div>
            <p className="text-zinc-400 text-sm leading-relaxed max-w-sm">
              The unified digital platform for university students. Borrowing, guidance, skill exchange, peer marketplace, connections, and an AI co-pilot.
            </p>
            <div className="flex items-center gap-2 text-xs font-mono-tech text-cyan-400 pt-2">
              <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
              <span>CAMPUS NETWORK // OPERATIONAL V3.2</span>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-3">
            <div className="text-xs font-mono-tech uppercase text-white font-bold tracking-[2px]">
              SERVICES
            </div>
            <ul className="space-y-2 text-sm text-zinc-400">
              <li>
                <button onClick={() => scrollTo('services')} className="hover:text-white transition-colors cursor-pointer">
                  Borrow Network
                </button>
              </li>
              <li>
                <button onClick={() => scrollTo('services')} className="hover:text-white transition-colors cursor-pointer">
                  Senior Guidance
                </button>
              </li>
              <li>
                <button onClick={() => scrollTo('services')} className="hover:text-white transition-colors cursor-pointer">
                  Skill Exchange
                </button>
              </li>
              <li>
                <button onClick={() => scrollTo('marketplace')} className="hover:text-white transition-colors cursor-pointer">
                  Campus Marketplace
                </button>
              </li>
              <li>
                <button onClick={() => scrollTo('projects')} className="hover:text-white transition-colors cursor-pointer">
                  Projects & Connect
                </button>
              </li>
            </ul>
          </div>

          {/* Platform */}
          <div className="space-y-3">
            <div className="text-xs font-mono-tech uppercase text-white font-bold tracking-[2px]">
              PLATFORM
            </div>
            <ul className="space-y-2 text-sm text-zinc-400">
              <li>
                <button onClick={() => scrollTo('impact')} className="hover:text-white transition-colors cursor-pointer">
                  Impact Engine
                </button>
              </li>
              <li>
                <button onClick={() => scrollTo('impact')} className="hover:text-white transition-colors cursor-pointer">
                  Leaderboard
                </button>
              </li>
              <li>
                <button onClick={() => scrollTo('compass')} className="hover:text-white transition-colors cursor-pointer">
                  COMPASS AI
                </button>
              </li>
              <li>
                <button onClick={() => scrollTo('pulse')} className="hover:text-white transition-colors cursor-pointer">
                  Campus Pulse
                </button>
              </li>
            </ul>
          </div>

          {/* Security & Nodes */}
          <div className="space-y-3">
            <div className="text-xs font-mono-tech uppercase text-white font-bold tracking-[2px]">
              SECURITY
            </div>
            <div className="p-4 rounded-2xl bg-[#080b18] border border-violet-500/20 space-y-2">
              <div className="flex items-center gap-2 text-xs font-bold text-white font-mono-tech">
                <Shield className="w-4 h-4 text-cyan-400" />
                <span>VERIFIED CAMPUS ID</span>
              </div>
              <p className="text-[11px] text-zinc-400 leading-relaxed font-mono-tech">
                Zero spam. Only active university credentials and encrypted peer verification.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Reference Sub-Bar: Connect Learn Share Build Lead */}
      <div className="border-t border-white/[0.06] bg-[#020307] py-3.5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-center gap-4 sm:gap-8 text-xs font-mono-tech uppercase text-zinc-400 tracking-[3px]">
          <span>Connect</span>
          <span>•</span>
          <span>Learn</span>
          <span>•</span>
          <span>Share</span>
          <span>•</span>
          <span>Build</span>
          <span>•</span>
          <span>Lead</span>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-white/[0.08] bg-[#020307] py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs font-mono-tech text-zinc-500">
          <div>
            &copy; {new Date().getFullYear()} ON CAMPUS • BY STUDENTS, FOR STUDENTS.
          </div>

          <div className="flex items-center gap-6">
            <span>PRIVACY PROTOCOL</span>
            <span>CAMPUS TERMS</span>
            <button
              onClick={scrollToTop}
              className="flex items-center gap-1.5 text-zinc-300 hover:text-cyan-400 transition-colors cursor-pointer ml-2"
            >
              <span>BACK TO TOP</span>
              <ArrowUp className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};


```

---

## File: `src/components/FullLeaderboardModal.tsx`

```tsx
import React, { useState, useMemo } from 'react';
import { 
  Trophy, 
  X, 
  Search, 
  TrendingUp, 
  Award, 
  Sparkles, 
  Zap, 
  BookOpen, 
  Layers, 
  ShieldCheck, 
  Heart, 
  Download, 
  QrCode, 
  Filter, 
  CheckCircle2, 
  ChevronRight, 
  Building2, 
  Share2,
  Users,
  Compass,
  Check
} from 'lucide-react';
import { UserProfile } from '../types';
import { ShareData } from './ShareModal';

interface FullLeaderboardModalProps {
  isOpen: boolean;
  onClose: () => void;
  users: UserProfile[];
  currentUser: UserProfile;
  onSelectUserForPassport: (user: UserProfile) => void;
  onGiveKudos: (userId: string) => void;
  onOpenShare?: (data: ShareData) => void;
}

export const FullLeaderboardModal: React.FC<FullLeaderboardModalProps> = ({
  isOpen,
  onClose,
  users,
  currentUser,
  onSelectUserForPassport,
  onGiveKudos,
  onOpenShare,
}) => {
  const [timeframe, setTimeframe] = useState<'season' | 'weekly' | 'all-time'>('season');
  const [activePillar, setActivePillar] = useState<'all' | 'knowledge' | 'skills' | 'resources' | 'projects'>('all');
  const [selectedDepartment, setSelectedDepartment] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [showCertificateForUser, setShowCertificateForUser] = useState<UserProfile | null>(null);
  const [kudosGiven, setKudosGiven] = useState<{ [key: string]: boolean }>({});
  const [copiedLeaderboard, setCopiedLeaderboard] = useState(false);

  const handleShareLeaderboard = () => {
    const leaderUrl = `${window.location.origin}/leaderboard`;
    const sharePayload: ShareData = {
      title: `Campus Proof-of-Karma Standings — ${currentUser.name} is Rank #${currentUser.rank}!`,
      text: `Check out the verified campus impact standings on Campus OS. Total 50+ students audited by zero-knowledge peer validations.`,
      url: leaderUrl,
      category: 'CAMPUS LEADERBOARD',
    };

    if (onOpenShare) {
      onOpenShare(sharePayload);
    } else if (navigator.share) {
      navigator.share({
        title: sharePayload.title,
        text: sharePayload.text,
        url: sharePayload.url,
      }).catch(() => {});
    } else {
      navigator.clipboard?.writeText(leaderUrl);
      setCopiedLeaderboard(true);
      setTimeout(() => setCopiedLeaderboard(false), 2000);
    }
  };

  // Filter and Sort Users
  const filteredUsers = useMemo(() => {
    const result = users
      .filter((user) => {
        // Search query
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          const matchesName = (user.name || '').toLowerCase().includes(q);
          const matchesDept = (user.department || '').toLowerCase().includes(q);
          const matchesBio = (user.bio || '').toLowerCase().includes(q);
          const matchesSkills = (user.skillsOffered || []).some((s) => (s || '').toLowerCase().includes(q));
          if (!matchesName && !matchesDept && !matchesBio && !matchesSkills) return false;
        }

        // Department filter
        if (selectedDepartment !== 'all') {
          if (!user.department.toLowerCase().includes(selectedDepartment.toLowerCase())) {
            return false;
          }
        }

        return true;
      })
      .sort((a, b) => {
        if (activePillar === 'knowledge') return b.knowledgeScore - a.knowledgeScore;
        if (activePillar === 'skills') return b.skillScore - a.skillScore;
        if (activePillar === 'resources') return b.resourceScore - a.resourceScore;
        if (activePillar === 'projects') return b.projectScore - a.projectScore;
        return b.impactScore - a.impactScore;
      });

    console.log(`[FullLeaderboardModal] Evaluated filter -> Displaying ${result.length} of ${users.length} students (Timeframe: ${timeframe}, Pillar: ${activePillar}, Dept: ${selectedDepartment}, Query: "${searchQuery}")`);
    return result;
  }, [users, searchQuery, selectedDepartment, activePillar, timeframe]);

  if (!isOpen) return null;

  console.log(`[FullLeaderboardModal] Rendered modal with isOpen=true. Total students: ${users.length}, Filtered displayed: ${filteredUsers.length}`);

  const handleKudos = (userId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (kudosGiven[userId]) return;
    setKudosGiven((prev) => ({ ...prev, [userId]: true }));
    onGiveKudos(userId);
  };

  const top3 = filteredUsers.slice(0, 3);
  const departments = ['all', 'Computer Science', 'Robotics', 'Electrical', 'Design', 'Physics', 'BioTech', 'Civil', 'Chemical', 'Mathematics', 'Aerospace'];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 md:p-6 overflow-y-auto bg-black/85 backdrop-blur-xl animate-in fade-in duration-200">
      
      {/* Modal Container */}
      <div className="relative w-full max-w-6xl bg-[#0a0a0e] border border-white/15 rounded-3xl shadow-[0_0_80px_rgba(0,242,255,0.15)] flex flex-col max-h-[92vh] overflow-hidden">
        
        {/* Ambient Top Glow */}
        <div className="absolute top-0 left-1/4 right-1/4 h-32 bg-gradient-to-b from-[#00f2ff]/15 via-[#c084fc]/10 to-transparent blur-2xl pointer-events-none" />

        {/* ========================================================================= */}
        {/* MODAL HEADER */}
        {/* ========================================================================= */}
        <div className="p-5 sm:p-7 border-b border-white/[0.08] flex flex-col md:flex-row md:items-center justify-between gap-4 relative z-10 bg-[#0d0d12]">
          <div>
            <div className="flex items-center gap-2 text-[11px] font-mono-tech tracking-[3px] text-[#00f2ff] font-bold uppercase">
              <Trophy className="w-4 h-4 text-[#00f2ff]" />
              <span>C A M P U S &nbsp; P R O O F - O F - K A R M A &nbsp; L E A D E R B O A R D</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white font-heading mt-1 flex items-center gap-3">
              <span>Campus Impact Standings</span>
              <span className="text-xs font-mono-tech px-2.5 py-1 rounded-full bg-[#00f2ff]/10 text-[#00f2ff] border border-[#00f2ff]/30 font-normal">
                Live Semester 2026
              </span>
            </h2>
            <p className="text-xs sm:text-sm text-white/60 mt-1 max-w-2xl font-normal">
              Audited by zero-knowledge peer validations. Earn verified karma by sharing laboratory equipment, teaching skills, and mentoring juniors.
            </p>
          </div>

          <div className="flex items-center gap-2.5 self-end md:self-auto flex-wrap">
            <button
              onClick={handleShareLeaderboard}
              className="px-3.5 py-2 rounded-xl bg-white/[0.08] hover:bg-[#00f2ff]/20 text-white hover:text-[#00f2ff] border border-white/10 hover:border-[#00f2ff]/40 text-xs font-mono-tech flex items-center gap-2 transition-all cursor-pointer"
              title="Share Standings to WhatsApp, Telegram, X, LinkedIn, etc."
            >
              {copiedLeaderboard ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Share2 className="w-3.5 h-3.5" />}
              <span>{copiedLeaderboard ? 'Copied' : 'Share Standings'}</span>
            </button>

            <button
              onClick={() => {
                const myRow = document.getElementById(`user-row-${currentUser.id}`);
                if (myRow) {
                  myRow.scrollIntoView({ behavior: 'smooth', block: 'center' });
                  myRow.classList.add('ring-2', 'ring-[#00f2ff]');
                  setTimeout(() => myRow.classList.remove('ring-2', 'ring-[#00f2ff]'), 2000);
                }
              }}
              className="px-3.5 py-2 rounded-xl bg-[#12131a] hover:bg-[#1a1c26] border border-white/10 text-xs font-mono-tech text-white flex items-center gap-2 transition-all cursor-pointer hover:border-[#00f2ff]/50"
            >
              <Zap className="w-3.5 h-3.5 text-[#00f2ff]" />
              <span>Spotlight My Rank (#{currentUser.rank})</span>
            </button>

            <button
              onClick={onClose}
              className="w-10 h-10 rounded-full bg-white/[0.05] hover:bg-white/[0.1] text-white/70 hover:text-white flex items-center justify-center transition-colors cursor-pointer border border-white/10"
              title="Close modal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* ========================================================================= */}
        {/* FILTER & SEARCH TOOLBAR */}
        {/* ========================================================================= */}
        <div className="p-4 sm:px-7 bg-[#0b0c10] border-b border-white/[0.06] flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          
          {/* Timeframe Toggle */}
          <div className="flex items-center gap-1 bg-[#12131a] p-1 rounded-xl border border-white/10 self-start">
            {[
              { id: 'season', label: 'Semester 2026' },
              { id: 'weekly', label: 'Weekly Sprint' },
              { id: 'all-time', label: 'Hall of Fame' },
            ].map((t) => (
              <button
                key={t.id}
                onClick={() => setTimeframe(t.id as any)}
                className={`px-3 py-1.5 rounded-lg text-xs font-mono-tech uppercase tracking-wider transition-all cursor-pointer ${
                  timeframe === t.id
                    ? 'bg-[#00f2ff] text-black font-bold shadow-[0_0_15px_rgba(0,242,255,0.4)]'
                    : 'text-white/60 hover:text-white'
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>

          {/* Pillar Filters */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0 scrollbar-none">
            {[
              { id: 'all', label: 'All Karma', icon: Trophy, color: 'text-yellow-400' },
              { id: 'knowledge', label: 'Knowledge', icon: BookOpen, color: 'text-[#00f2ff]' },
              { id: 'skills', label: 'Skills', icon: Zap, color: 'text-[#c084fc]' },
              { id: 'resources', label: 'Resources', icon: Layers, color: 'text-emerald-400' },
              { id: 'projects', label: 'Projects', icon: TrendingUp, color: 'text-rose-400' },
            ].map((pillar) => {
              const Icon = pillar.icon;
              const isActive = activePillar === pillar.id;
              return (
                <button
                  key={pillar.id}
                  onClick={() => setActivePillar(pillar.id as any)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-medium flex items-center gap-1.5 whitespace-nowrap transition-all cursor-pointer border ${
                    isActive
                      ? 'bg-white/10 text-white border-white/30 shadow-sm'
                      : 'bg-[#12131a]/60 text-white/60 border-white/5 hover:border-white/20 hover:text-white'
                  }`}
                >
                  <Icon className={`w-3.5 h-3.5 ${pillar.color}`} />
                  <span>{pillar.label}</span>
                </button>
              );
            })}
          </div>

          {/* Search Bar */}
          <div className="relative min-w-[240px]">
            <Search className="w-4 h-4 text-white/40 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              placeholder="Search by student, skill, dept..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3.5 py-2 rounded-xl bg-[#12131a] border border-white/10 text-xs text-white placeholder:text-white/40 focus:outline-none focus:border-[#00f2ff] transition-all font-mono-tech"
            />
          </div>
        </div>

        {/* Department Filter Sub-Bar & Active Count Badge */}
        <div className="px-4 sm:px-7 py-2.5 bg-[#090a0e] border-b border-white/[0.04] flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0 scrollbar-none max-w-full">
            <span className="text-[10px] font-mono-tech text-white/40 uppercase mr-1">Department:</span>
            {departments.map((dept) => {
              const isSelected = selectedDepartment === dept;
              return (
                <button
                  key={dept}
                  onClick={() => setSelectedDepartment(dept)}
                  className={`px-2.5 py-1 rounded-lg text-[11px] font-mono-tech transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-[#00f2ff]/20 text-[#00f2ff] border border-[#00f2ff]/40 font-bold shadow-[0_0_10px_rgba(0,242,255,0.2)]'
                      : 'bg-white/[0.03] text-white/50 border border-white/[0.05] hover:text-white hover:border-white/20'
                  }`}
                >
                  {dept === 'all' ? 'All Departments' : dept}
                </button>
              );
            })}
          </div>

          <div className="flex items-center gap-2 font-mono-tech text-[11px] text-white/60">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span>
              Showing <strong className="text-white">{filteredUsers.length}</strong> of <strong className="text-[#00f2ff]">{users.length}</strong> verified students
            </span>
          </div>
        </div>

        {/* ========================================================================= */}
        {/* MAIN SCROLLABLE CONTENT */}
        {/* ========================================================================= */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-7 space-y-8 custom-scrollbar">
          
          {/* TOP 3 PODIUM (Visible when looking at default rankings) */}
          {top3.length >= 3 && !searchQuery && selectedDepartment === 'all' && (
            <div>
              <div className="text-[11px] font-mono-tech text-white/50 uppercase tracking-[2px] mb-3 flex items-center gap-2">
                <Sparkles className="w-3.5 h-3.5 text-yellow-400" />
                <span>TOP CAMPUS LEADERS // PODIUM</span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 sm:gap-6">
                {/* Silver - Rank 2 */}
                <div 
                  onClick={() => onSelectUserForPassport(top3[1])}
                  className="order-2 md:order-1 bg-gradient-to-b from-[#161824] to-[#0c0d12] border border-white/20 hover:border-white/40 rounded-3xl p-5 relative overflow-hidden transition-all duration-300 hover:scale-[1.02] cursor-pointer group shadow-xl"
                >
                  <div className="absolute top-0 right-0 w-24 h-24 bg-white/10 rounded-full blur-2xl pointer-events-none" />
                  <div className="flex items-center justify-between mb-3">
                    <span className="w-8 h-8 rounded-xl bg-white/10 border border-white/30 text-white font-mono-tech font-bold text-sm flex items-center justify-center shadow-md">
                      #2
                    </span>
                    <span className="text-xl">🥈</span>
                  </div>
                  
                  <div className="flex items-center gap-3 mb-3">
                    <img 
                      src={top3[1].avatar} 
                      alt={top3[1].name} 
                      className="w-14 h-14 rounded-2xl object-cover border-2 border-white/30 shadow-md"
                    />
                    <div>
                      <h4 className="font-bold text-white text-base group-hover:text-[#00f2ff] transition-colors flex items-center gap-1.5">
                        <span>{top3[1].name}</span>
                        <ShieldCheck className="w-4 h-4 text-[#00f2ff]" />
                      </h4>
                      <p className="text-[11px] text-white/60 font-mono-tech truncate max-w-[160px]">
                        {top3[1].department}
                      </p>
                    </div>
                  </div>

                  <div className="p-2.5 rounded-xl bg-[#08080c] border border-white/5 flex items-center justify-between mb-4">
                    <span className="text-xs text-white/60 font-mono-tech">Reputation Karma</span>
                    <span className="text-lg font-black text-white font-mono-tech">
                      {top3[1].impactScore} <span className="text-[10px] text-[#00f2ff]">PTS</span>
                    </span>
                  </div>

                  <div className="flex items-center justify-between pt-2 border-t border-white/5">
                    <button
                      onClick={(e) => handleKudos(top3[1].id, e)}
                      className={`text-xs font-mono-tech px-3 py-1.5 rounded-xl flex items-center gap-1.5 transition-all ${
                        kudosGiven[top3[1].id]
                          ? 'bg-pink-500/20 text-pink-300 border border-pink-500/40'
                          : 'bg-white/5 hover:bg-pink-500/20 text-white/70 hover:text-pink-300 border border-white/10'
                      }`}
                    >
                      <Heart className="w-3.5 h-3.5 text-pink-400" />
                      <span>{kudosGiven[top3[1].id] ? 'Kudos Sent!' : 'Give Kudos (+5)'}</span>
                    </button>
                    <span className="text-xs text-[#00f2ff] font-mono-tech flex items-center gap-1">
                      <span>Passport</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </span>
                  </div>
                </div>

                {/* Gold - Rank 1 (Center Highlight) */}
                <div 
                  onClick={() => onSelectUserForPassport(top3[0])}
                  className="order-1 md:order-2 bg-gradient-to-b from-[#241f14] via-[#1a1710] to-[#0c0c10] border-2 border-yellow-500/50 hover:border-yellow-400 rounded-3xl p-6 relative overflow-hidden transition-all duration-300 hover:scale-[1.03] cursor-pointer group shadow-[0_0_40px_rgba(234,179,8,0.2)] md:-translate-y-2"
                >
                  <div className="absolute top-0 right-0 w-32 h-32 bg-yellow-500/20 rounded-full blur-2xl pointer-events-none" />
                  <div className="flex items-center justify-between mb-3">
                    <span className="px-3 py-1 rounded-xl bg-yellow-500/20 border border-yellow-500/50 text-yellow-300 font-mono-tech font-bold text-xs flex items-center gap-1.5 shadow-md">
                      <Trophy className="w-3.5 h-3.5" />
                      #1 CAMPUS LEADER
                    </span>
                    <span className="text-2xl animate-bounce">🥇</span>
                  </div>
                  
                  <div className="flex items-center gap-3.5 mb-3">
                    <img 
                      src={top3[0].avatar} 
                      alt={top3[0].name} 
                      className="w-16 h-16 rounded-2xl object-cover border-2 border-yellow-400 shadow-lg"
                    />
                    <div>
                      <h4 className="font-extrabold text-white text-lg group-hover:text-yellow-300 transition-colors flex items-center gap-1.5">
                        <span>{top3[0].name}</span>
                        <ShieldCheck className="w-4 h-4 text-yellow-400" />
                      </h4>
                      <p className="text-xs text-yellow-200/70 font-mono-tech">
                        {top3[0].title}
                      </p>
                      <p className="text-[11px] text-white/50 font-mono-tech truncate max-w-[180px]">
                        {top3[0].department}
                      </p>
                    </div>
                  </div>

                  <div className="p-3 rounded-xl bg-[#08080c] border border-yellow-500/30 flex items-center justify-between mb-4">
                    <div>
                      <div className="text-[10px] text-yellow-400/80 font-mono-tech uppercase">Proof of Karma</div>
                      <div className="text-xs text-white/50 font-mono-tech">54 Guides • 28 Loans</div>
                    </div>
                    <span className="text-2xl font-black text-yellow-300 font-mono-tech">
                      {top3[0].impactScore} <span className="text-xs text-yellow-400">PTS</span>
                    </span>
                  </div>

                  <div className="flex items-center justify-between pt-2 border-t border-white/5">
                    <button
                      onClick={(e) => handleKudos(top3[0].id, e)}
                      className={`text-xs font-mono-tech px-3.5 py-1.5 rounded-xl flex items-center gap-1.5 transition-all ${
                        kudosGiven[top3[0].id]
                          ? 'bg-pink-500/20 text-pink-300 border border-pink-500/40'
                          : 'bg-yellow-500/10 hover:bg-yellow-500/20 text-yellow-300 border border-yellow-500/30'
                      }`}
                    >
                      <Heart className="w-3.5 h-3.5 text-pink-400" />
                      <span>{kudosGiven[top3[0].id] ? 'Kudos Sent!' : 'Give Kudos (+5)'}</span>
                    </button>
                    <span className="text-xs text-yellow-400 font-mono-tech flex items-center gap-1 font-bold">
                      <span>View Passport</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </span>
                  </div>
                </div>

                {/* Bronze - Rank 3 */}
                <div 
                  onClick={() => onSelectUserForPassport(top3[2])}
                  className="order-3 bg-gradient-to-b from-[#1f1610] to-[#0c0d12] border border-amber-600/30 hover:border-amber-500/50 rounded-3xl p-5 relative overflow-hidden transition-all duration-300 hover:scale-[1.02] cursor-pointer group shadow-xl"
                >
                  <div className="absolute top-0 right-0 w-24 h-24 bg-amber-600/10 rounded-full blur-2xl pointer-events-none" />
                  <div className="flex items-center justify-between mb-3">
                    <span className="w-8 h-8 rounded-xl bg-amber-600/20 border border-amber-600/40 text-amber-300 font-mono-tech font-bold text-sm flex items-center justify-center shadow-md">
                      #3
                    </span>
                    <span className="text-xl">🥉</span>
                  </div>
                  
                  <div className="flex items-center gap-3 mb-3">
                    <img 
                      src={top3[2].avatar} 
                      alt={top3[2].name} 
                      className="w-14 h-14 rounded-2xl object-cover border-2 border-amber-600/40 shadow-md"
                    />
                    <div>
                      <h4 className="font-bold text-white text-base group-hover:text-amber-300 transition-colors flex items-center gap-1.5">
                        <span>{top3[2].name}</span>
                        <ShieldCheck className="w-4 h-4 text-amber-400" />
                      </h4>
                      <p className="text-[11px] text-white/60 font-mono-tech truncate max-w-[160px]">
                        {top3[2].department}
                      </p>
                    </div>
                  </div>

                  <div className="p-2.5 rounded-xl bg-[#08080c] border border-white/5 flex items-center justify-between mb-4">
                    <span className="text-xs text-white/60 font-mono-tech">Reputation Karma</span>
                    <span className="text-lg font-black text-amber-300 font-mono-tech">
                      {top3[2].impactScore} <span className="text-[10px] text-amber-400">PTS</span>
                    </span>
                  </div>

                  <div className="flex items-center justify-between pt-2 border-t border-white/5">
                    <button
                      onClick={(e) => handleKudos(top3[2].id, e)}
                      className={`text-xs font-mono-tech px-3 py-1.5 rounded-xl flex items-center gap-1.5 transition-all ${
                        kudosGiven[top3[2].id]
                          ? 'bg-pink-500/20 text-pink-300 border border-pink-500/40'
                          : 'bg-white/5 hover:bg-pink-500/20 text-white/70 hover:text-pink-300 border border-white/10'
                      }`}
                    >
                      <Heart className="w-3.5 h-3.5 text-pink-400" />
                      <span>{kudosGiven[top3[2].id] ? 'Kudos Sent!' : 'Give Kudos (+5)'}</span>
                    </button>
                    <span className="text-xs text-amber-400 font-mono-tech flex items-center gap-1">
                      <span>Passport</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ===================================================================== */}
          {/* COMPLETE CAMPUS DIRECTORY & RANKINGS TABLE */}
          {/* ===================================================================== */}
          <div className="bg-[#0e0f15] border border-white/[0.08] rounded-3xl overflow-hidden shadow-2xl">
            
            {/* Table Column Bar */}
            <div className="p-4 sm:px-6 bg-[#13141c] border-b border-white/[0.06] grid grid-cols-12 gap-3 text-[10px] font-mono-tech text-white/50 uppercase tracking-wider items-center">
              <div className="col-span-2 sm:col-span-1 text-center">RANK</div>
              <div className="col-span-6 sm:col-span-5">STUDENT & DEPARTMENT</div>
              <div className="hidden sm:block sm:col-span-3">IMPACT PILLARS (K/S/R/P)</div>
              <div className="col-span-4 sm:col-span-3 text-right">KARMA & ACTION</div>
            </div>

            {/* List Rows */}
            <div className="divide-y divide-white/[0.04]">
              {filteredUsers.map((user, idx) => {
                const rank = idx + 1;
                const isCurrentUser = user.id === currentUser.id;

                return (
                  <div
                    key={user.id}
                    id={`user-row-${user.id}`}
                    onClick={() => onSelectUserForPassport(user)}
                    className={`p-4 sm:px-6 grid grid-cols-12 gap-3 items-center transition-all cursor-pointer hover:bg-white/[0.03] ${
                      isCurrentUser ? 'bg-[#00f2ff]/5 border-l-4 border-l-[#00f2ff]' : ''
                    }`}
                  >
                    {/* Rank Badge */}
                    <div className="col-span-2 sm:col-span-1 flex flex-col items-center justify-center">
                      <span className={`w-8 h-8 rounded-xl font-mono-tech font-bold text-xs flex items-center justify-center ${
                        rank === 1
                          ? 'bg-yellow-500/20 text-yellow-300 border border-yellow-500/40 shadow-sm'
                          : rank === 2
                          ? 'bg-slate-300/20 text-slate-200 border border-slate-300/30'
                          : rank === 3
                          ? 'bg-amber-600/20 text-amber-300 border border-amber-600/30'
                          : 'bg-[#181a24] text-white/70 border border-white/5'
                      }`}>
                        #{rank}
                      </span>
                      {user.monthlyGrowthPercent && (
                        <span className="text-[9px] font-mono-tech text-emerald-400 mt-1">
                          +{user.monthlyGrowthPercent}%
                        </span>
                      )}
                    </div>

                    {/* Student Info */}
                    <div className="col-span-6 sm:col-span-5 flex items-center gap-3">
                      <img 
                        src={user.avatar} 
                        alt={user.name} 
                        className="w-10 h-10 rounded-xl object-cover border border-white/10 shadow-sm flex-shrink-0"
                      />
                      <div className="min-w-0">
                        <div className="flex items-center gap-1.5">
                          <span className="font-bold text-white text-sm sm:text-base truncate hover:text-[#00f2ff]">
                            {user.name}
                          </span>
                          {user.verified && (
                            <ShieldCheck className="w-3.5 h-3.5 text-[#00f2ff] flex-shrink-0" />
                          )}
                          {isCurrentUser && (
                            <span className="text-[9px] font-mono-tech bg-[#00f2ff]/20 text-[#00f2ff] px-1.5 py-0.2 rounded font-bold uppercase">
                              YOU
                            </span>
                          )}
                        </div>

                        <div className="text-[11px] text-white/50 font-mono-tech truncate">
                          {user.title} • {user.department}
                        </div>

                        {/* Badges preview */}
                        {user.badges && user.badges.length > 0 && (
                          <div className="hidden sm:flex items-center gap-1.5 mt-1">
                            {user.badges.slice(0, 2).map((b) => (
                              <span
                                key={b}
                                className="text-[9px] font-mono-tech text-white/60 bg-white/5 border border-white/10 px-1.5 py-0.2 rounded"
                              >
                                {b}
                              </span>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>

                    {/* 4 Pillars Breakdown Bars */}
                    <div className="hidden sm:block sm:col-span-3">
                      <div className="grid grid-cols-4 gap-1.5 font-mono-tech text-[10px] text-center">
                        <div className="bg-[#12131c] p-1 rounded border border-white/5" title="Knowledge Score">
                          <div className="text-[#00f2ff] text-[8px]">KNW</div>
                          <div className="text-white font-bold">{user.knowledgeScore}</div>
                        </div>
                        <div className="bg-[#12131c] p-1 rounded border border-white/5" title="Skill Score">
                          <div className="text-[#c084fc] text-[8px]">SKL</div>
                          <div className="text-white font-bold">{user.skillScore}</div>
                        </div>
                        <div className="bg-[#12131c] p-1 rounded border border-white/5" title="Resource Score">
                          <div className="text-emerald-400 text-[8px]">RES</div>
                          <div className="text-white font-bold">{user.resourceScore}</div>
                        </div>
                        <div className="bg-[#12131c] p-1 rounded border border-white/5" title="Project Score">
                          <div className="text-rose-400 text-[8px]">PRJ</div>
                          <div className="text-white font-bold">{user.projectScore}</div>
                        </div>
                      </div>
                    </div>

                    {/* Karma Score & Quick Kudos Action */}
                    <div className="col-span-4 sm:col-span-3 flex items-center justify-end gap-3">
                      <div className="text-right font-mono-tech">
                        <div className="text-base sm:text-lg font-black text-white font-heading">
                          {user.impactScore} <span className="text-[10px] text-[#00f2ff]">PTS</span>
                        </div>
                        <div className="text-[10px] text-white/40">
                          {user.hostelWing || 'Campus Node'}
                        </div>
                      </div>

                      <button
                        onClick={(e) => handleKudos(user.id, e)}
                        className={`p-2 rounded-xl border transition-all cursor-pointer ${
                          kudosGiven[user.id]
                            ? 'bg-pink-500/20 border-pink-500/50 text-pink-300 shadow-[0_0_10px_rgba(244,114,182,0.4)]'
                            : 'bg-white/5 border-white/10 hover:border-pink-500/40 text-white/60 hover:text-pink-300'
                        }`}
                        title="Give Kudos (+5 Karma)"
                      >
                        <Heart className="w-4 h-4" />
                      </button>

                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setShowCertificateForUser(user);
                        }}
                        className="p-2 rounded-xl bg-white/5 border border-white/10 hover:border-[#00f2ff]/40 text-white/60 hover:text-[#00f2ff] transition-all cursor-pointer hidden sm:block"
                        title="View Verified Certificate"
                      >
                        <Award className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* ========================================================================= */}
          {/* HOSTEL WING & DEPARTMENT BATTLEBOARD */}
          {/* ========================================================================= */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4">
            
            {/* Hostel Wings Battle */}
            <div className="bg-[#0e0f15] border border-white/[0.08] rounded-3xl p-6 shadow-xl">
              <div className="flex items-center justify-between mb-4">
                <div className="text-sm font-bold text-white font-heading flex items-center gap-2">
                  <Building2 className="w-4 h-4 text-[#00f2ff]" />
                  <span>Hostel Wing Impact Battle</span>
                </div>
                <span className="text-[10px] font-mono-tech text-[#00f2ff]">LIVE SCORES</span>
              </div>

              <div className="space-y-3 font-mono-tech text-xs">
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-white font-medium">North Block (H4)</span>
                    <span className="text-[#00f2ff] font-bold">5,562 Karma</span>
                  </div>
                  <div className="w-full h-2.5 rounded-full bg-white/5 overflow-hidden">
                    <div className="h-full bg-gradient-to-r from-[#00f2ff] to-[#38bdf8] rounded-full w-[88%]" />
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-white font-medium">Tech Tower (H7)</span>
                    <span className="text-[#c084fc] font-bold">4,489 Karma</span>
                  </div>
                  <div className="w-full h-2.5 rounded-full bg-white/5 overflow-hidden">
                    <div className="h-full bg-gradient-to-r from-[#c084fc] to-[#a855f7] rounded-full w-[72%]" />
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-white font-medium">Research Enclave (PG)</span>
                    <span className="text-emerald-400 font-bold">3,790 Karma</span>
                  </div>
                  <div className="w-full h-2.5 rounded-full bg-white/5 overflow-hidden">
                    <div className="h-full bg-gradient-to-r from-emerald-400 to-teal-500 rounded-full w-[60%]" />
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-white font-medium">East Wing (H2)</span>
                    <span className="text-amber-400 font-bold">2,670 Karma</span>
                  </div>
                  <div className="w-full h-2.5 rounded-full bg-white/5 overflow-hidden">
                    <div className="h-full bg-gradient-to-r from-amber-400 to-orange-500 rounded-full w-[45%]" />
                  </div>
                </div>
              </div>
            </div>

            {/* Zero-Knowledge Protocol Guarantee */}
            <div className="bg-[#0e0f15] border border-white/[0.08] rounded-3xl p-6 shadow-xl flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className="text-sm font-bold text-white font-heading flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-emerald-400" />
                    <span>Cryptographic Reputation Protocol</span>
                  </div>
                  <span className="text-[10px] font-mono-tech text-emerald-400 px-2 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/30">
                    AUDITED
                  </span>
                </div>
                <p className="text-xs text-white/70 leading-relaxed font-normal">
                  All loans, study sprint hours, and notes downloads generate an immutable campus receipt. Points cannot be inflated or purchased. Zero personal identity leaks.
                </p>
              </div>

              <div className="pt-4 border-t border-white/5 flex items-center justify-between text-xs font-mono-tech text-white/50">
                <span>CONTRACT: 0x9f8b...22ea</span>
                <span className="text-[#00f2ff]">BLOCK #4,921,080</span>
              </div>
            </div>

          </div>

        </div>

        {/* ========================================================================= */}
        {/* MODAL FOOTER */}
        {/* ========================================================================= */}
        <div className="p-4 sm:px-7 bg-[#0d0d12] border-t border-white/[0.08] flex items-center justify-between text-xs font-mono-tech text-white/60">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
            <span>Real-time Campus Ledger Sync</span>
          </div>

          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-white text-black font-bold hover:bg-white/90 transition-all cursor-pointer"
          >
            Close Leaderboard
          </button>
        </div>

      </div>

      {/* ========================================================================= */}
      {/* VERIFIED DIGITAL CERTIFICATE POPUP */}
      {/* ========================================================================= */}
      {showCertificateForUser && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/90 backdrop-blur-2xl animate-in zoom-in-95 duration-200">
          <div className="relative w-full max-w-lg bg-[#0c0d14] border-2 border-[#00f2ff]/40 rounded-3xl p-7 shadow-[0_0_60px_rgba(0,242,255,0.3)] text-center space-y-5">
            <button
              onClick={() => setShowCertificateForUser(null)}
              className="absolute top-4 right-4 text-white/50 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="w-16 h-16 rounded-2xl bg-[#00f2ff]/10 border border-[#00f2ff]/40 flex items-center justify-center mx-auto text-[#00f2ff]">
              <Award className="w-8 h-8" />
            </div>

            <div>
              <div className="text-[10px] font-mono-tech text-[#00f2ff] tracking-[3px] uppercase">
                OFFICIAL CAMPUS PROOF-OF-IMPACT
              </div>
              <h3 className="text-2xl font-black text-white font-heading mt-1">
                {showCertificateForUser.name}
              </h3>
              <p className="text-xs text-white/60 font-mono-tech mt-0.5">
                Rank #{showCertificateForUser.rank} • {showCertificateForUser.department}
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-[#12131c] border border-white/10 space-y-2 text-left text-xs font-mono-tech">
              <div className="flex items-center justify-between">
                <span className="text-white/50">Verified Karma Score:</span>
                <span className="text-white font-bold text-sm">{showCertificateForUser.impactScore} PTS</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-white/50">Accolade Title:</span>
                <span className="text-[#00f2ff] font-bold">{showCertificateForUser.title}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-white/50">On-Time Return Rate:</span>
                <span className="text-emerald-400 font-bold">100% (Zero Defaults)</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-white/50">Cryptographic Hash:</span>
                <span className="text-white/40 truncate max-w-[160px]">{showCertificateForUser.verifiedHash || '0x4f82a...99c1'}</span>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <button
                onClick={() => {
                  alert(`Certificate for ${showCertificateForUser.name} verified and ready to export!`);
                  setShowCertificateForUser(null);
                }}
                className="flex-1 py-3 rounded-xl bg-[#00f2ff] text-black font-bold text-xs flex items-center justify-center gap-2 hover:bg-[#00f2ff]/90 transition-all cursor-pointer font-mono-tech"
              >
                <Download className="w-4 h-4" />
                <span>Download Proof Certificate</span>
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};

```

---

## File: `src/components/GuidanceModal.tsx`

```tsx
import React, { useState } from 'react';
import { GuidanceTopic } from '../types';
import { 
  X, 
  Compass, 
  BookOpen, 
  Sparkles, 
  CheckCircle, 
  Eye, 
  ArrowRight,
  ShieldCheck,
  HelpCircle,
  UserCheck,
  MessageSquare
} from 'lucide-react';

interface GuidanceModalProps {
  isOpen: boolean;
  onClose: () => void;
  topics: GuidanceTopic[];
  onAddTopic: (topic: Omit<GuidanceTopic, 'id' | 'reads'>) => void;
  onRequestGuidance?: (subject: string, category: string, question: string, preferredFormat: string) => void;
}

export const GuidanceModal: React.FC<GuidanceModalProps> = ({
  isOpen,
  onClose,
  topics,
  onAddTopic,
  onRequestGuidance,
}) => {
  const [activeTab, setActiveTab] = useState<'guides' | 'request' | 'share'>('guides');
  const [selectedTopicId, setSelectedTopicId] = useState<string | null>(null);

  // Form State - Share Guide
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<GuidanceTopic['category']>('Course Advice');
  const [summary, setSummary] = useState('');
  const [tipsText, setTipsText] = useState('');
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Form State - Request Guidance
  const [reqSubject, setReqSubject] = useState('');
  const [reqCategory, setReqCategory] = useState<GuidanceTopic['category']>('Course Advice');
  const [reqQuestion, setReqQuestion] = useState('');
  const [reqFormat, setReqFormat] = useState('15-Min Quick Chat or Audio');
  const [reqTargetYear, setReqTargetYear] = useState('3rd / 4th Year Senior');

  // Open guidance requests community feed
  const [openRequests, setOpenRequests] = useState([
    {
      id: 'gr-1',
      subject: 'Compiler Design Lab Setup & Flex/Bison pointers',
      category: 'Course Advice',
      requester: 'Kartik N. (2nd Year CSE)',
      format: '15-Min Quick Chat',
      target: 'Senior who took CSE302',
      responsesCount: 2,
    },
    {
      id: 'gr-2',
      subject: 'Preparing for Summer Internship Coding Rounds (Fintech/Quant)',
      category: 'Career Prep',
      requester: 'Ananya S. (3rd Year IT)',
      format: 'Resume Review & Mock Q&A',
      target: 'Placed 4th Year Senior',
      responsesCount: 4,
    },
    {
      id: 'gr-3',
      subject: 'Professor Rao Research Group - How to approach for Lab RA?',
      category: 'Professor Insights',
      requester: 'Dev M. (2nd Year ECE)',
      format: 'Coffee/Quick 10m Chat',
      target: 'Current Lab RA Student',
      responsesCount: 1,
    }
  ]);

  if (!isOpen) return null;

  const handleShareSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !summary) return;

    const tips = tipsText
      .split('\n')
      .map((t) => t.trim())
      .filter(Boolean);

    onAddTopic({
      title,
      category,
      mentorName: 'You (Senior Mentor)',
      mentorTitle: 'Campus Contributor',
      summary,
      tips: tips.length > 0 ? tips : ['Study with real lecture code', 'Ask in lab hours'],
    });

    setSuccessMsg('Your Guidance Guide was published to the Campus Memory Layer! +50 Impact points earned.');
    setTitle('');
    setSummary('');
    setTipsText('');
    setTimeout(() => {
      setSuccessMsg(null);
      setActiveTab('guides');
    }, 2000);
  };

  const handleRequestGuidanceSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reqSubject.trim() || !reqQuestion.trim()) return;

    if (onRequestGuidance) {
      onRequestGuidance(reqSubject, reqCategory, reqQuestion, reqFormat);
    }

    const newReq = {
      id: `gr-${Date.now()}`,
      subject: reqSubject,
      category: reqCategory,
      requester: 'You (Verified Student)',
      format: reqFormat,
      target: reqTargetYear,
      responsesCount: 0,
    };

    setOpenRequests([newReq, ...openRequests]);
    setSuccessMsg(`Your guidance request for "${reqSubject}" was submitted! We are matching you with verified senior mentors.`);
    setReqSubject('');
    setReqQuestion('');
    setTimeout(() => {
      setSuccessMsg(null);
    }, 3000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
      <div className="relative w-full max-w-3xl bg-[#090C12] border border-violet-400/40 rounded-2xl p-6 sm:p-8 max-h-[90vh] overflow-y-auto shadow-2xl">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-lg bg-zinc-900 border border-white/10 text-zinc-400 hover:text-white transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-xl bg-violet-950/60 border border-violet-400/40 flex items-center justify-center text-violet-300">
            <Compass className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-white font-heading">
              02 // CAMPUS MEMORY & GUIDANCE
            </h2>
            <p className="text-xs font-mono-tech text-violet-400">
              Learn from people who've already been there. Course insights, mentorship & guidance requests.
            </p>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex flex-wrap gap-2 border-b border-white/[0.08] pb-4 mb-6">
          <button
            onClick={() => setActiveTab('guides')}
            className={`px-4 py-2 text-xs font-mono-tech tracking-wider rounded transition-all cursor-pointer ${
              activeTab === 'guides'
                ? 'bg-violet-950/80 border border-violet-400/60 text-violet-300 font-bold'
                : 'text-zinc-400 hover:text-white'
            }`}
          >
            VERIFIED GUIDES ({topics.length})
          </button>
          <button
            onClick={() => setActiveTab('request')}
            className={`px-4 py-2 text-xs font-mono-tech tracking-wider rounded transition-all cursor-pointer ${
              activeTab === 'request'
                ? 'bg-gradient-to-r from-violet-950 to-indigo-950 border border-violet-400 text-violet-200 font-bold shadow-[0_0_15px_rgba(168,85,247,0.2)]'
                : 'text-zinc-400 hover:text-white'
            }`}
          >
            + REQUEST GUIDANCE / MENTOR
          </button>
          <button
            onClick={() => setActiveTab('share')}
            className={`px-4 py-2 text-xs font-mono-tech tracking-wider rounded transition-all cursor-pointer ${
              activeTab === 'share'
                ? 'bg-violet-950/80 border border-violet-400/60 text-violet-300 font-bold'
                : 'text-zinc-400 hover:text-white'
            }`}
          >
            + SHARE SENIOR GUIDE (+50 IMPACT)
          </button>
        </div>

        {successMsg && (
          <div className="mb-6 p-4 rounded-xl bg-emerald-950/60 border border-emerald-400/40 text-emerald-300 text-xs sm:text-sm font-mono-tech flex items-center gap-2">
            <CheckCircle className="w-4 h-4 shrink-0" />
            <span>{successMsg}</span>
          </div>
        )}

        {/* Tab 1: Guides List */}
        {activeTab === 'guides' && (
          <div className="space-y-4">
            {topics.map((topic) => (
              <div
                key={topic.id}
                className="p-5 rounded-xl bg-zinc-950/80 border border-white/[0.08] hover:border-violet-400/50 transition-all"
              >
                <div className="flex items-center justify-between text-[10px] font-mono-tech text-violet-400 mb-2">
                  <span className="px-2 py-0.5 rounded bg-violet-950/60 border border-violet-400/20 text-violet-300">
                    {topic.category}
                  </span>
                  <span className="flex items-center gap-1 text-zinc-400">
                    <Eye className="w-3.5 h-3.5" />
                    {topic.reads} students referenced
                  </span>
                </div>

                <h3 className="text-lg font-bold text-white font-heading mb-1.5">
                  {topic.title}
                </h3>
                <p className="text-xs text-zinc-300 leading-relaxed mb-4">
                  {topic.summary}
                </p>

                {/* Key Bullet Points */}
                <div className="p-3 rounded-lg bg-zinc-900/80 border border-white/[0.06] space-y-1.5 mb-3">
                  <div className="text-[10px] font-mono-tech text-cyan-400 uppercase tracking-wider">
                    PRO-TIPS & EXECUTION NOTES:
                  </div>
                  {topic.tips.map((tip, idx) => (
                    <div
                      key={idx}
                      className="text-xs text-zinc-300 font-mono-tech flex items-start gap-2"
                    >
                      <span className="text-violet-400 font-bold">›</span>
                      <span>{tip}</span>
                    </div>
                  ))}
                </div>

                <div className="pt-2 border-t border-white/[0.04] flex items-center justify-between text-xs font-mono-tech text-zinc-400">
                  <div className="flex items-center gap-1.5 text-zinc-300">
                    <ShieldCheck className="w-3.5 h-3.5 text-violet-400" />
                    <span>Curated by {topic.mentorName}</span>
                    <span className="text-[10px] text-zinc-400">({topic.mentorTitle})</span>
                  </div>

                  <button
                    onClick={() => {
                      setSuccessMsg(`Connected with ${topic.mentorName}! Mentor chat channel opened.`);
                      setTimeout(() => setSuccessMsg(null), 3000);
                    }}
                    className="px-3 py-1.5 bg-violet-950 hover:bg-violet-900 border border-violet-400/40 text-violet-300 text-xs font-mono-tech rounded transition-all cursor-pointer"
                  >
                    ASK AUTHOR A QUESTION
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Tab 2: Request Guidance Form & Community Questions */}
        {activeTab === 'request' && (
          <div className="space-y-6">
            <form onSubmit={handleRequestGuidanceSubmit} className="p-5 rounded-xl bg-zinc-950/90 border border-violet-400/30 space-y-4">
              <div className="flex items-center gap-2 pb-2 border-b border-white/[0.08]">
                <HelpCircle className="w-4 h-4 text-violet-400" />
                <span className="text-xs font-mono-tech text-violet-300 font-bold uppercase tracking-wider">
                  Request Specific Guidance or 1-on-1 Senior Mentorship
                </span>
              </div>

              <div>
                <label className="block text-xs font-mono-tech text-zinc-300 mb-1">
                  WHAT DO YOU NEED GUIDANCE ON? *
                </label>
                <input
                  type="text"
                  value={reqSubject}
                  onChange={(e) => setReqSubject(e.target.value)}
                  placeholder="e.g. Navigating Operating Systems project, Off-campus placement strategy, or Lab Exam tips"
                  required
                  className="w-full px-3.5 py-2.5 bg-zinc-900 border border-white/10 rounded text-sm text-white focus:outline-none focus:border-violet-400 font-mono-tech"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-mono-tech text-zinc-300 mb-1">
                    CATEGORY
                  </label>
                  <select
                    value={reqCategory}
                    onChange={(e) => setReqCategory(e.target.value as any)}
                    className="w-full px-3 py-2 bg-zinc-900 border border-white/10 rounded text-xs sm:text-sm text-white focus:outline-none focus:border-violet-400 font-mono-tech"
                  >
                    <option value="Course Advice">Course Advice</option>
                    <option value="Career Prep">Career Prep / Internships</option>
                    <option value="Professor Insights">Professor Insights</option>
                    <option value="Campus Hack">Campus Hack / Lifestyle</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-mono-tech text-zinc-300 mb-1">
                    PREFERRED FORMAT
                  </label>
                  <select
                    value={reqFormat}
                    onChange={(e) => setReqFormat(e.target.value)}
                    className="w-full px-3 py-2 bg-zinc-900 border border-white/10 rounded text-xs sm:text-sm text-white focus:outline-none focus:border-violet-400 font-mono-tech"
                  >
                    <option value="15-Min Quick Chat">15-Min Quick Chat</option>
                    <option value="Audio Call / Huddle">Audio Call / Huddle</option>
                    <option value="Written Tips / Notes">Written Tips / Notes</option>
                    <option value="In-person Library Sync">In-person Library Sync</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-mono-tech text-zinc-300 mb-1">
                    TARGET SENIOR
                  </label>
                  <input
                    type="text"
                    value={reqTargetYear}
                    onChange={(e) => setReqTargetYear(e.target.value)}
                    placeholder="e.g. 3rd/4th Year Senior"
                    className="w-full px-3 py-2 bg-zinc-900 border border-white/10 rounded text-xs sm:text-sm text-white focus:outline-none focus:border-violet-400 font-mono-tech"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-mono-tech text-zinc-300 mb-1">
                  DETAILED QUESTION / CURRENT BLOCKER *
                </label>
                <textarea
                  value={reqQuestion}
                  onChange={(e) => setReqQuestion(e.target.value)}
                  placeholder="Describe your current situation, what you've tried, and what exact advice would help you the most."
                  rows={3}
                  required
                  className="w-full px-3 py-2 bg-zinc-900 border border-white/10 rounded text-xs sm:text-sm text-white focus:outline-none focus:border-violet-400 font-mono-tech"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 text-white font-bold text-xs font-mono-tech tracking-wider uppercase rounded transition-all cursor-pointer shadow-[0_0_20px_rgba(168,85,247,0.3)]"
              >
                BROADCAST GUIDANCE REQUEST TO SENIOR NETWORK
              </button>
            </form>

            {/* Open Guidance Requests Feed */}
            <div>
              <div className="flex items-center justify-between text-xs font-mono-tech text-violet-400 mb-3 font-bold uppercase">
                <span>ACTIVE GUIDANCE REQUESTS FROM JUNIORS ({openRequests.length})</span>
                <span className="text-zinc-400 text-[11px] font-normal">Seniors: Can you guide on these?</span>
              </div>

              <div className="space-y-3">
                {openRequests.map((req) => (
                  <div
                    key={req.id}
                    className="p-4 rounded-xl bg-zinc-950/60 border border-white/[0.08] hover:border-violet-400/40 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3"
                  >
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="px-2 py-0.5 rounded bg-violet-950/70 border border-violet-400/20 text-[10px] font-mono-tech text-violet-300">
                          {req.category}
                        </span>
                        <span className="text-xs text-zinc-400 font-mono-tech">
                          Format: <strong className="text-zinc-200">{req.format}</strong>
                        </span>
                        <span className="text-[10px] text-violet-300/80 font-mono-tech">
                          Seeking: {req.target}
                        </span>
                      </div>
                      <h4 className="text-sm font-bold text-white font-heading">
                        {req.subject}
                      </h4>
                      <p className="text-xs text-zinc-400 font-mono-tech">
                        Posted by {req.requester} • {req.responsesCount} mentors volunteered
                      </p>
                    </div>

                    <button
                      onClick={() => {
                        setSuccessMsg(`You volunteered to mentor for "${req.subject}"! +30 Impact points pending.`);
                        setTimeout(() => setSuccessMsg(null), 3000);
                      }}
                      className="px-3.5 py-1.5 bg-white/[0.08] hover:bg-violet-600 hover:text-white text-violet-300 border border-violet-400/40 text-xs font-mono-tech font-semibold rounded transition-all cursor-pointer shrink-0"
                    >
                      I CAN GUIDE (+30 IMPACT)
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Tab 3: Share Guide Form */}
        {activeTab === 'share' && (
          <form onSubmit={handleShareSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-mono-tech text-zinc-300 mb-1">
                GUIDE TITLE
              </label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g. How to score S-grade in Database Systems with Prof. Sharma"
                required
                className="w-full px-3 py-2 bg-zinc-950 border border-white/10 rounded text-sm text-white focus:outline-none focus:border-violet-400 font-mono-tech"
              />
            </div>

            <div>
              <label className="block text-xs font-mono-tech text-zinc-300 mb-1">
                CATEGORY
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as any)}
                className="w-full px-3 py-2 bg-zinc-950 border border-white/10 rounded text-sm text-white focus:outline-none focus:border-violet-400 font-mono-tech"
              >
                <option value="Course Advice">Course Advice</option>
                <option value="Professor Insights">Professor Insights</option>
                <option value="Campus Hack">Campus Hack</option>
                <option value="Career Prep">Career Prep</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-mono-tech text-zinc-300 mb-1">
                SUMMARY & CONTEXT
              </label>
              <textarea
                value={summary}
                onChange={(e) => setSummary(e.target.value)}
                placeholder="Explain the big picture, common pitfalls, and what to watch out for."
                rows={3}
                required
                className="w-full px-3 py-2 bg-zinc-950 border border-white/10 rounded text-sm text-white focus:outline-none focus:border-violet-400 font-mono-tech"
              />
            </div>

            <div>
              <label className="block text-xs font-mono-tech text-zinc-300 mb-1">
                ACTIONABLE TIPS (ONE PER LINE)
              </label>
              <textarea
                value={tipsText}
                onChange={(e) => setTipsText(e.target.value)}
                placeholder="Tip 1: Focus on B+ Tree balancing&#10;Tip 2: Submit lab assignments before 6 PM&#10;Tip 3: Check 2024 past papers"
                rows={3}
                className="w-full px-3 py-2 bg-zinc-950 border border-white/10 rounded text-sm text-white focus:outline-none focus:border-violet-400 font-mono-tech"
              />
            </div>

            <div className="pt-2">
              <button
                type="submit"
                className="w-full py-3 bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 text-white font-bold text-xs font-mono-tech tracking-wider uppercase rounded transition-all cursor-pointer shadow-lg"
              >
                PUBLISH TO GUIDANCE REPOSITORY (+50 IMPACT)
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};

```

---

## File: `src/components/Hero.tsx`

```tsx
import React from 'react';
import { ArrowRight, Sparkles, Presentation } from 'lucide-react';
import { Campus3DVisualizer } from './Campus3DVisualizer';
import { OnCampusOrbitalIcon, CompassStarIcon } from './BrandLogos';

interface HeroProps {
  onOpenCompass?: () => void;
  onExplore?: () => void;
  onExploreServices?: () => void;
  onEnterNetwork?: () => void;
  onSelectHub?: (hubName: string) => void;
  onOpenPresentation?: () => void;
  onOpenVideo?: () => void;
  onOpenChat?: () => void;
}

export const Hero: React.FC<HeroProps> = ({ 
  onOpenCompass, 
  onExplore,
  onExploreServices,
  onEnterNetwork,
  onSelectHub,
  onOpenPresentation,
  onOpenVideo,
  onOpenChat,
}) => {
  const handleExplore = onExplore || onExploreServices || (() => {
    document.getElementById('services')?.scrollIntoView({ behavior: 'smooth' });
  });

  const handleEnter = onEnterNetwork || handleExplore;

  return (
    <section id="hero" className="relative min-h-[92vh] pt-24 sm:pt-28 md:pt-32 pb-16 md:pb-20 flex flex-col justify-center overflow-hidden bg-[#05060a] select-none">
      
      {/* ========================================================================= */}
      {/* 3D CONSTELLATION NETWORK VISUALIZER (Spanning panoramic 3D layer) */}
      {/* ========================================================================= */}
      <Campus3DVisualizer onSelectNode={onSelectHub} />

      {/* Subtle Ambient Vignette & Deep Space Glow (No grid lines) */}
      <div className="absolute top-1/3 right-1/4 w-[700px] h-[550px] bg-[#00f2ff]/[0.05] rounded-full blur-[160px] pointer-events-none -z-10" />
      <div className="absolute bottom-1/4 left-1/6 w-[500px] h-[400px] bg-[#818cf8]/[0.04] rounded-full blur-[140px] pointer-events-none -z-10" />

      {/* ========================================================================= */}
      {/* HERO CONTENT CONTAINER */}
      {/* ========================================================================= */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full relative z-10 pointer-events-none">
        <div className="max-w-xl md:max-w-lg lg:max-w-2xl space-y-5 sm:space-y-6 md:space-y-7 pointer-events-none">
          
          {/* Top Pill Badge with Orbital Logo */}
          <div className="inline-flex items-center gap-2.5 px-3.5 sm:px-4 py-1.5 rounded-full border border-violet-400/30 bg-violet-950/40 text-violet-200 text-xs font-medium backdrop-blur-xl shadow-[0_0_20px_rgba(168,85,247,0.15)] pointer-events-auto">
            <OnCampusOrbitalIcon size={18} glow={false} />
            <span className="font-heading tracking-wider uppercase font-bold text-[11px] sm:text-xs">ON CAMPUS ECOSYSTEM</span>
            <span className="w-1 h-1 rounded-full bg-cyan-400" />
            <span className="text-white/80 text-[11px] sm:text-xs">Everything already here</span>
          </div>

          {/* Main Headline with luminous Cyan-Violet Glow */}
          <h1 className="text-3xl sm:text-5xl md:text-5xl lg:text-7xl font-bold tracking-tight text-white leading-[1.1] sm:leading-[1.08] font-heading drop-shadow-md">
            Everything your campus has. <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#00f2ff] via-[#a78bfa] to-[#f472b6] drop-shadow-[0_0_50px_rgba(0,242,255,0.4)]">
              Connected.
            </span>
          </h1>

          {/* Subtitle matching exact direction */}
          <p className="text-sm sm:text-lg md:text-xl text-slate-300 max-w-lg font-normal leading-relaxed">
            Discover people. Share resources. Build ideas. Make an impact.
          </p>

          {/* Action Buttons */}
          <div className="flex flex-wrap items-center gap-2.5 sm:gap-3.5 md:gap-4 pt-2 pointer-events-auto">
            <button
              id="hero-enter-network-btn"
              onClick={handleEnter}
              className="bg-[#22d3ee] hover:bg-[#38bdf8] text-black font-semibold text-xs sm:text-sm md:text-base px-5 sm:px-6 md:px-7 py-3 sm:py-3.5 rounded-full flex items-center gap-2 transition-all duration-200 cursor-pointer shadow-[0_0_30px_rgba(34,211,238,0.35)] hover:shadow-[0_0_45px_rgba(34,211,238,0.55)] hover:scale-[1.02] active:scale-[0.98]"
            >
              <span>Explore On Campus</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              id="hero-explore-services-btn"
              onClick={() => {
                const videoSection = document.getElementById('walkthrough') || document.getElementById('services');
                videoSection?.scrollIntoView({ behavior: 'smooth' });
              }}
              className="bg-white/[0.05] hover:bg-white/[0.1] text-white border border-white/15 text-xs sm:text-sm md:text-base font-medium px-5 sm:px-6 md:px-7 py-3 sm:py-3.5 rounded-full transition-all duration-200 cursor-pointer backdrop-blur-md"
            >
              Watch how it works
            </button>

            {onOpenPresentation && (
              <button
                id="hero-pitch-deck-btn"
                onClick={onOpenPresentation}
                className="bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-300 hover:text-white border border-cyan-400/40 hover:border-cyan-300 text-xs sm:text-sm md:text-base font-medium px-4 sm:px-5 py-3 sm:py-3.5 rounded-full flex items-center gap-2 transition-all cursor-pointer backdrop-blur-md shadow-[0_0_20px_rgba(0,242,255,0.15)] hover:shadow-[0_0_30px_rgba(0,242,255,0.3)]"
              >
                <Presentation className="w-4 h-4 text-cyan-400" />
                <span className="font-heading tracking-wide">Pitch Deck</span>
              </button>
            )}

            {onOpenCompass && (
              <button
                id="hero-ask-compass-btn"
                onClick={onOpenCompass}
                className="bg-gradient-to-r from-pink-950/70 via-[#18071e]/80 to-rose-950/70 hover:from-pink-900/90 hover:to-rose-900/90 text-pink-200 hover:text-white border border-pink-400/40 hover:border-pink-300 text-xs sm:text-xs md:text-sm font-medium px-3.5 sm:px-4 md:px-5 py-3 sm:py-3.5 rounded-full flex items-center gap-2 transition-all cursor-pointer shadow-[0_0_25px_rgba(244,114,182,0.3)] hover:shadow-[0_0_35px_rgba(244,114,182,0.5)]"
              >
                <CompassStarIcon size={18} glow={false} />
                <span className="font-heading tracking-wide">COMPASS AI</span>
              </button>
            )}
          </div>

          {/* 3 Bottom Clean Live Stats matching screenshot */}
          <div className="pt-5 sm:pt-6 md:pt-8 flex items-center gap-6 sm:gap-10 md:gap-14 pointer-events-auto">
            <div>
              <div className="text-2xl sm:text-3xl md:text-4xl font-bold text-white font-heading">6</div>
              <div className="text-[10px] sm:text-xs text-white/50 font-normal mt-0.5">unified services</div>
            </div>
            <div>
              <div className="text-2xl sm:text-3xl md:text-4xl font-bold text-white font-heading">1</div>
              <div className="text-[10px] sm:text-xs text-white/50 font-normal mt-0.5">student identity</div>
            </div>
            <div>
              <div className="text-2xl sm:text-3xl md:text-4xl font-bold text-white font-heading">∞</div >
              <div className="text-[10px] sm:text-xs text-white/50 font-normal mt-0.5">connections</div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};


```

---

## File: `src/components/HostelWingsModal.tsx`

```tsx
import React from 'react';
import { 
  X, 
  Globe, 
  Building2, 
  Radio, 
  Zap, 
  ShieldCheck, 
  Layers, 
  CheckCircle2,
  Users
} from 'lucide-react';

interface HostelWingsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const HostelWingsModal: React.FC<HostelWingsModalProps> = ({
  isOpen,
  onClose,
}) => {
  if (!isOpen) return null;

  const wings = [
    {
      id: 'h4',
      code: 'H4',
      name: 'North Block Hostel',
      status: '98% Active',
      studentsCount: 380,
      inventoryCount: 42,
      topLenders: ['Ananya Rao', 'Yuvraj Sen', 'Rhea Nair'],
      liveNodes: '14 Hardware Nodes Online',
      accentColor: 'from-[#00f2ff] to-[#38bdf8]',
      borderGlow: 'border-[#00f2ff]/40',
    },
    {
      id: 'h7',
      code: 'H7',
      name: 'Tech Tower Hostel',
      status: '100% Active',
      studentsCount: 420,
      inventoryCount: 58,
      topLenders: ['Devansh Iyer', 'Aman Tiwari', 'Siddharth V.'],
      liveNodes: '18 Hardware Nodes Online',
      accentColor: 'from-[#c084fc] to-[#a855f7]',
      borderGlow: 'border-[#c084fc]/40',
    },
    {
      id: 'pg',
      code: 'PG',
      name: 'Research & Postgrad Enclave',
      status: '90% Active',
      studentsCount: 260,
      inventoryCount: 34,
      topLenders: ['Kabir Shah', 'Tanvi Joshi'],
      liveNodes: '11 Hardware Nodes Online',
      accentColor: 'from-emerald-400 to-teal-500',
      borderGlow: 'border-emerald-500/40',
    },
    {
      id: 'h2',
      code: 'H2',
      name: 'East Wing Hostel',
      status: '85% Active',
      studentsCount: 310,
      inventoryCount: 26,
      topLenders: ['Priya Malhotra', 'Meera Chawla'],
      liveNodes: '9 Hardware Nodes Online',
      accentColor: 'from-amber-400 to-orange-500',
      borderGlow: 'border-amber-500/40',
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 overflow-y-auto bg-black/85 backdrop-blur-xl animate-in fade-in duration-200">
      
      <div className="relative w-full max-w-3xl bg-[#0b0c12] border border-white/15 rounded-3xl shadow-[0_0_60px_rgba(0,242,255,0.15)] flex flex-col overflow-hidden text-white max-h-[90vh]">
        
        {/* Header */}
        <div className="p-5 sm:p-6 border-b border-white/[0.08] flex items-center justify-between bg-[#0e0f18]">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl bg-[#c084fc]/10 border border-[#c084fc]/30 flex items-center justify-center text-[#c084fc]">
              <Globe className="w-5 h-5" />
            </div>
            <div>
              <div className="text-[10px] font-mono-tech text-[#c084fc] tracking-[2px] uppercase">
                HOSTEL LOCALIZATION HUBS
              </div>
              <h3 className="text-xl font-bold text-white font-heading">
                Campus Wings & Node Distribution
              </h3>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-white/[0.05] hover:bg-white/[0.1] text-white/70 hover:text-white flex items-center justify-center transition-colors cursor-pointer border border-white/10"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Wings List */}
        <div className="p-6 space-y-4 overflow-y-auto custom-scrollbar flex-1">
          <p className="text-xs text-white/60 font-mono-tech">
            Lend or collect items locally from your nearest hostel lobby within 5 minutes without crossing the campus perimeter.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {wings.map((wing) => (
              <div
                key={wing.id}
                className={`p-5 rounded-2xl bg-[#12131c] border ${wing.borderGlow} space-y-3 relative overflow-hidden`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-8 h-8 rounded-xl bg-white/10 border border-white/20 font-mono-tech font-black text-sm flex items-center justify-center text-white">
                      {wing.code}
                    </span>
                    <div>
                      <h4 className="text-sm font-bold text-white font-heading">{wing.name}</h4>
                      <span className="text-[10px] font-mono-tech text-[#00f2ff]">{wing.liveNodes}</span>
                    </div>
                  </div>
                  <span className="text-xs font-mono-tech font-bold text-emerald-400">
                    {wing.status}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs font-mono-tech pt-2 border-t border-white/5">
                  <div className="bg-[#090a0f] p-2 rounded-lg border border-white/5">
                    <div className="text-[10px] text-white/40">Active Peers</div>
                    <div className="text-white font-bold">{wing.studentsCount}</div>
                  </div>
                  <div className="bg-[#090a0f] p-2 rounded-lg border border-white/5">
                    <div className="text-[10px] text-white/40">Lobby Inventory</div>
                    <div className="text-white font-bold">{wing.inventoryCount} items</div>
                  </div>
                </div>

                <div className="text-xs font-mono-tech text-white/50">
                  <span>Top Lenders: </span>
                  <span className="text-white/80">{wing.topLenders && wing.topLenders.length > 0 ? wing.topLenders.join(', ') : 'Hostel Active Peers'}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 sm:px-6 bg-[#0e0f18] border-t border-white/[0.08] flex items-center justify-between text-xs font-mono-tech text-white/60">
          <div className="flex items-center gap-1.5">
            <Radio className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
            <span>All 4 Hostel Drop Points Operational</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-white text-black font-bold hover:bg-white/90 cursor-pointer"
          >
            Close
          </button>
        </div>

      </div>
    </div>
  );
};

```

---

## File: `src/components/ImpactLeaderboard.tsx`

```tsx
import React, { useState } from 'react';
import { UserProfile } from '../types';
import { 
  TrendingUp, 
  Trophy, 
  Sparkles, 
  BookOpen, 
  Repeat, 
  Boxes, 
  Layers3, 
  ShieldCheck,
  ArrowRight,
  GitBranch,
  Globe,
  Lock,
  BarChart3,
  Split,
  Server,
  Activity,
  Award,
  CheckCircle2,
  Zap,
  Plus
} from 'lucide-react';

interface ImpactLeaderboardProps {
  users: UserProfile[];
  onSelectUser?: (user: UserProfile) => void;
  onOpenFullLeaderboard?: () => void;
  onOpenAnalytics?: () => void;
  onOpenSquads?: () => void;
  onOpenWings?: () => void;
  onOpenPassport?: (user: UserProfile) => void;
}

export const ImpactLeaderboard: React.FC<ImpactLeaderboardProps> = ({
  users,
  onSelectUser,
  onOpenFullLeaderboard,
  onOpenAnalytics,
  onOpenSquads,
  onOpenWings,
  onOpenPassport,
}) => {
  const [activeTab, setActiveTab] = useState<'season' | 'all-time' | 'departments'>('season');
  const [selectedUserIndex, setSelectedUserIndex] = useState<number>(2);
  const [activeMetricTab, setActiveMetricTab] = useState<'karma' | 'growth' | 'reliability'>('karma');

  const selectedUser = users[selectedUserIndex] || users[0];

  const handleOpenLeaderboard = (source: string) => {
    console.log(`[ImpactLeaderboard] Full Leaderboard clicked from '${source}'. Triggering onOpenFullLeaderboard(). Total users available: ${users.length}`);
    if (onOpenFullLeaderboard) {
      onOpenFullLeaderboard();
    }
  };

  const handleSelectUser = (user: UserProfile, idx: number) => {
    setSelectedUserIndex(idx);
    if (onSelectUser) {
      onSelectUser(user);
    }
  };

  return (
    <section id="impact" className="py-28 border-b border-white/[0.08] relative bg-[#000000] text-white overflow-hidden font-sans">
      {/* Background ambient dark neon glow */}
      <div className="absolute top-1/3 left-1/4 w-[700px] h-[500px] bg-[#00f2ff]/5 rounded-full blur-[160px] pointer-events-none -z-10" />
      <div className="absolute bottom-10 right-1/4 w-[600px] h-[400px] bg-[#c084fc]/5 rounded-full blur-[140px] pointer-events-none -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* TOP HEADER */}
        <div className="max-w-3xl mb-16 space-y-4">
          <div className="inline-flex items-center gap-2 text-[11px] font-mono-tech tracking-[4px] text-[#00f2ff] font-bold uppercase">
            <TrendingUp className="w-4 h-4 text-[#00f2ff]" />
            <span>I M P A C T &nbsp; E N G I N E &nbsp; // &nbsp; 2 0 2 6</span>
          </div>

          <h2 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-white tracking-normal leading-tight font-heading">
            Don't just be on campus.{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#00f2ff] via-[#4ff5ff] to-[#c084fc] drop-shadow-[0_0_40px_rgba(0,242,255,0.35)]">
              Make an impact on it.
            </span>
          </h2>

          <p className="text-white/70 text-base sm:text-lg leading-relaxed font-normal">
            Every useful action adds to your journey. Every contribution leaves a mark.
          </p>
        </div>

        {/* ========================================================================= */}
        {/* PREMIUM FRAMER-STYLE BENTO GRID SYSTEM (Matching User Screenshot Layout) */}
        {/* ========================================================================= */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-stretch">
          
          {/* ===================================================================== */}
          {/* TOP-LEFT CARD: "Student Identity & Karma Config" (Like Framer Site Settings) */}
          {/* ===================================================================== */}
          <div className="col-span-1 md:col-span-6 lg:col-span-4 bg-[#0a0a0c] border border-white/[0.08] hover:border-white/20 rounded-3xl p-6 sm:p-7 flex flex-col justify-between transition-all duration-300 shadow-2xl relative overflow-hidden group">
            {/* Top glow */}
            <div className="absolute top-0 right-0 w-32 h-32 bg-[#00f2ff]/10 rounded-full blur-3xl pointer-events-none" />

            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-bold text-white font-heading">
                  Active Contributor
                </h3>
                <span className="text-[10px] font-mono-tech text-[#00f2ff] px-2.5 py-0.5 rounded-full bg-[#00f2ff]/10 border border-[#00f2ff]/30 uppercase font-bold">
                  RANK // {String(selectedUser.rank).padStart(2, '0')}
                </span>
              </div>

              {/* Title & Tag Section */}
              <div className="space-y-1.5">
                <div className="text-xs font-mono-tech text-white/50 flex items-center justify-between">
                  <span>Student Handle</span>
                  <span className="text-[#00f2ff] font-mono-tech">/campus/{selectedUser.id}</span>
                </div>
                <div className="p-3.5 rounded-xl bg-[#121318] border border-white/[0.06] text-sm text-white font-medium flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <img 
                      src={selectedUser.avatar} 
                      alt={selectedUser.name} 
                      className="w-6 h-6 rounded-full object-cover border border-white/20" 
                    />
                    <span className="font-semibold text-white">{selectedUser.name}</span>
                  </div>
                  <span className="text-xs font-mono-tech text-[#00f2ff]">THIS MONTH // +{selectedUser.monthlyGrowthPercent || 18}%</span>
                </div>
              </div>

              {/* Persona Description */}
              <div className="space-y-1.5">
                <div className="text-xs font-mono-tech text-white/50">Campus Bio & Accolade</div>
                <div className="p-4 rounded-xl bg-[#121318] border border-white/[0.06] text-xs leading-relaxed text-white/70 font-mono-tech">
                  LEVEL // {selectedUser.title.toUpperCase()} • {selectedUser.department}
                </div>
              </div>

              {/* Mini Social / Badge Preview */}
              <div className="space-y-2 pt-2">
                <div className="text-[11px] font-mono-tech text-white/40 flex items-center justify-between">
                  <span>Campus Badge Preview</span>
                  <span className="text-[10px] text-white/30">1200 x 630</span>
                </div>
                <div className="h-20 rounded-xl bg-gradient-to-br from-[#121318] to-[#1a1b24] border border-white/[0.08] p-3 flex items-center justify-between overflow-hidden relative">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-[#00f2ff]/10 border border-[#00f2ff]/40 flex items-center justify-center text-lg">
                      {selectedUser.nametagIcon || '✨'}
                    </div>
                    <div>
                      <div className="text-xs font-bold text-white font-heading">{selectedUser.name}</div>
                      <div className="text-[10px] text-[#00f2ff] font-mono-tech uppercase font-bold">{selectedUser.title}</div>
                    </div>
                  </div>
                  <div className="text-right font-mono-tech">
                    <div className="text-sm font-black text-white">IMPACT // {selectedUser.impactScore}</div>
                    <div className="text-[9px] text-[#00f2ff]">VERIFIED</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Bottom Link Action */}
            <div 
              onClick={() => onOpenPassport?.(selectedUser)}
              className="pt-6 mt-6 border-t border-white/[0.06] flex items-center justify-between cursor-pointer group"
            >
              <span className="text-sm font-semibold text-white group-hover:text-[#00f2ff] transition-colors flex items-center gap-1.5">
                <span>Identity & Passport</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </span>
              <span className="text-[10px] font-mono-tech text-white/40">PASSPORT // ID</span>
            </div>
          </div>

          {/* ===================================================================== */}
          {/* TOP-CENTER COLUMN: 2 Stacked Cards (Collaboration & Localization style) */}
          {/* ===================================================================== */}
          <div className="col-span-1 md:col-span-6 lg:col-span-4 flex flex-col gap-6">
            
            {/* CARD A: Collaboration / Live Peer Squads */}
            <div 
              onClick={() => onOpenSquads?.()}
              className="bg-[#0a0a0c] border border-white/[0.08] hover:border-white/20 rounded-3xl p-6 flex flex-col justify-between transition-all duration-300 shadow-2xl relative overflow-hidden group cursor-pointer"
            >
              <div>
                <div className="flex items-center justify-between mb-4">
                  <div className="text-sm font-bold text-white font-heading flex items-center gap-2">
                    <GitBranch className="w-4 h-4 text-[#00f2ff]" />
                    <span>Peer Squads</span>
                  </div>
                  <button 
                    onClick={(e) => { e.stopPropagation(); onOpenSquads?.(); }}
                    className="w-6 h-6 rounded-full bg-white/[0.05] hover:bg-white/[0.1] text-white/70 hover:text-white flex items-center justify-center text-xs transition-colors"
                  >
                    <Plus className="w-3.5 h-3.5" />
                  </button>
                </div>

                <div className="space-y-2">
                  <div className="p-2.5 rounded-xl bg-[#121318] border border-white/[0.06] flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-[#00f2ff]" />
                      <span className="text-white font-medium">Main Hub (All Hostels)</span>
                    </div>
                    <span className="text-[10px] font-mono-tech text-white/40">1m ago</span>
                  </div>

                  <div className="p-2.5 rounded-xl bg-[#1a1c24] border border-[#00f2ff]/30 flex items-center justify-between text-xs shadow-[0_0_15px_rgba(0,242,255,0.1)]">
                    <div className="flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-[#c084fc] animate-ping" />
                      <span className="text-white font-medium">hackathon-squad-ai</span>
                    </div>
                    <span className="text-[10px] font-mono-tech text-[#00f2ff]">Active</span>
                  </div>

                  <div className="pl-6 space-y-1.5 border-l border-white/10 ml-3 py-1">
                    <div className="flex items-center justify-between text-[11px] text-white/70">
                      <div className="flex items-center gap-2">
                        <img src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=120&q=80" className="w-4 h-4 rounded-full" />
                        <span>Aarav (Frontend Lead)</span>
                      </div>
                      <span className="text-[10px] font-mono-tech text-white/40">8m</span>
                    </div>
                    <div className="flex items-center justify-between text-[11px] text-white/70">
                      <div className="flex items-center gap-2">
                        <img src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=120&q=80" className="w-4 h-4 rounded-full" />
                        <span>Dev (ML Engineer)</span>
                      </div>
                      <span className="text-[10px] font-mono-tech text-white/40">10m</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="pt-4 mt-4 border-t border-white/[0.06] flex items-center justify-between">
                <span className="text-sm font-semibold text-white group-hover:text-[#00f2ff] transition-colors flex items-center gap-1.5 cursor-pointer">
                  <span>Collaboration</span>
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </span>
                <span className="text-[10px] font-mono-tech text-white/40">3 ACTIVE TEAMS</span>
              </div>
            </div>

            {/* CARD B: Hostel / Department Localization Hub */}
            <div 
              onClick={() => onOpenWings?.()}
              className="bg-[#0a0a0c] border border-white/[0.08] hover:border-white/20 rounded-3xl p-6 flex flex-col justify-between transition-all duration-300 shadow-2xl relative overflow-hidden group cursor-pointer"
            >
              <div>
                <div className="flex items-center justify-between mb-4">
                  <div className="text-sm font-bold text-white font-heading flex items-center gap-2">
                    <Globe className="w-4 h-4 text-[#c084fc]" />
                    <span>Hostel Wings</span>
                  </div>
                  <button 
                    onClick={(e) => { e.stopPropagation(); onOpenWings?.(); }}
                    className="w-6 h-6 rounded-full bg-white/[0.05] hover:bg-white/[0.1] text-white/70 hover:text-white flex items-center justify-center text-xs transition-colors"
                  >
                    <Plus className="w-3.5 h-3.5" />
                  </button>
                </div>

                <div className="space-y-2">
                  <div className="p-2.5 rounded-xl bg-[#121318] border border-white/[0.06] flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-mono-tech font-bold px-1.5 py-0.5 rounded bg-white/10 text-white">H4</span>
                      <span className="text-white">North Block Hostel</span>
                    </div>
                    <span className="text-xs font-mono-tech text-[#00f2ff] font-bold">98% Active</span>
                  </div>

                  <div className="p-2.5 rounded-xl bg-[#121318] border border-white/[0.06] flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-mono-tech font-bold px-1.5 py-0.5 rounded bg-white/10 text-white">H7</span>
                      <span className="text-white">Tech Tower Hostel</span>
                    </div>
                    <span className="text-xs font-mono-tech text-[#c084fc] font-bold">100% Active</span>
                  </div>

                  <div className="p-2.5 rounded-xl bg-[#121318] border border-white/[0.06] flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-mono-tech font-bold px-1.5 py-0.5 rounded bg-white/10 text-white">PG</span>
                      <span className="text-white">Research Enclave</span>
                    </div>
                    <span className="text-xs font-mono-tech text-[#fb923c] font-bold">90% Active</span>
                  </div>
                </div>
              </div>

              <div className="pt-4 mt-4 border-t border-white/[0.06] flex items-center justify-between">
                <span className="text-sm font-semibold text-white group-hover:text-[#c084fc] transition-colors flex items-center gap-1.5 cursor-pointer">
                  <span>Campus Wings</span>
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </span>
                <span className="text-[10px] font-mono-tech text-white/40">12 LOCATIONS</span>
              </div>
            </div>

          </div>

          {/* ===================================================================== */}
          {/* TOP-RIGHT COLUMN: 2 Stacked Cards (Hosting 99.99% & Security Lock Bar) */}
          {/* ===================================================================== */}
          <div className="col-span-1 md:col-span-12 lg:col-span-4 grid grid-cols-1 md:grid-cols-2 lg:flex lg:flex-col gap-6">
            
            {/* CARD A: 99.99% Reliability / Trust Index */}
            <div className="bg-[#0a0a0c] border border-white/[0.08] hover:border-white/20 rounded-3xl p-6 sm:p-7 flex flex-col justify-between transition-all duration-300 shadow-2xl relative overflow-hidden group min-h-[220px]">
              {/* Subtle background curved neon wave */}
              <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[#00f2ff]/5 to-transparent pointer-events-none" />

              <div>
                <div className="text-4xl sm:text-5xl font-black text-white font-heading tracking-tight">
                  99.99%
                </div>
                <div className="text-xl sm:text-2xl font-bold text-white/40 font-heading -mt-1">
                  item return rate
                </div>
                <p className="text-xs text-white/60 mt-3 font-normal">
                  Zero collateral defaults across 12,480 peer loans through cryptographic karma validation.
                </p>
              </div>

              <div className="pt-4 border-t border-white/[0.06] flex items-center justify-between">
                <span className="text-sm font-semibold text-white group-hover:text-[#00f2ff] transition-colors flex items-center gap-1.5 cursor-pointer">
                  <span>Trust Matrix</span>
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </span>
                <span className="text-[10px] font-mono-tech text-[#00f2ff] flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#00f2ff] animate-ping" />
                  VERIFIED 24/7
                </span>
              </div>
            </div>

            {/* CARD B: Campus URL / SSL Security Protocol */}
            <div className="bg-[#0a0a0c] border border-white/[0.08] hover:border-white/20 rounded-3xl p-6 flex flex-col justify-between transition-all duration-300 shadow-2xl relative overflow-hidden group">
              <div>
                <div className="text-xs font-mono-tech text-white/50 mb-3 uppercase tracking-wider">
                  Verified Campus Node
                </div>

                {/* Cyber Browser Address Bar (from Framer Security card) */}
                <div className="p-2.5 rounded-2xl bg-[#121318] border border-white/[0.08] flex items-center gap-2 shadow-inner">
                  <div className="flex items-center gap-1.5 text-white/30 pl-1">
                    <span className="w-2.5 h-2.5 rounded-full bg-white/20" />
                    <span className="w-2.5 h-2.5 rounded-full bg-white/20" />
                    <span className="w-2.5 h-2.5 rounded-full bg-white/20" />
                  </div>
                  
                  <div className="flex-1 ml-2 py-1.5 px-3 rounded-xl bg-[#090a0e] border border-[#00f2ff]/30 flex items-center gap-2 text-xs font-mono-tech text-white/90">
                    <Lock className="w-3.5 h-3.5 text-[#00f2ff]" />
                    <span className="truncate">https://oncampus.edu/node/secure</span>
                  </div>
                </div>
              </div>

              <div className="pt-4 mt-4 border-t border-white/[0.06] flex items-center justify-between">
                <span className="text-sm font-semibold text-white group-hover:text-[#00f2ff] transition-colors flex items-center gap-1.5 cursor-pointer">
                  <span>Security & Zero-Knowledge</span>
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </span>
                <ShieldCheck className="w-4 h-4 text-[#00f2ff]" />
              </div>
            </div>

          </div>

          {/* ===================================================================== */}
          {/* BOTTOM-LEFT CARD: Framer-Style Analytics Chart Block (Spanning 8 cols) */}
          {/* ===================================================================== */}
          <div className="col-span-1 md:col-span-12 lg:col-span-8 bg-[#0a0a0c] border border-white/[0.08] hover:border-white/20 rounded-3xl p-6 sm:p-8 flex flex-col justify-between transition-all duration-300 shadow-2xl relative overflow-hidden group">
            
            <div>
              {/* Analytics Header */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
                <div>
                  <h3 className="text-2xl font-bold text-white font-heading">
                    Campus Analytics
                  </h3>
                  <p className="text-xs text-white/50 font-mono-tech mt-0.5">
                    Real-time peer lending & knowledge trade volume
                  </p>
                </div>

                {/* Metric Quick Stats matching Framer Screenshot */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 sm:gap-6 bg-[#121318] p-3 rounded-2xl border border-white/[0.06]">
                  <div>
                    <div className="text-[10px] text-white/40 font-mono-tech flex items-center gap-1">
                      <span>Live Peers</span>
                      <span className="w-1.5 h-1.5 rounded-full bg-[#00f2ff] animate-ping" />
                    </div>
                    <div className="text-lg sm:text-xl font-bold text-white font-heading">414</div>
                  </div>

                  <div>
                    <div className="text-[10px] text-white/40 font-mono-tech">Unique Traders</div>
                    <div className="text-lg sm:text-xl font-bold text-white font-heading">1.7K</div>
                  </div>

                  <div>
                    <div className="text-[10px] text-white/40 font-mono-tech">Karma Volume</div>
                    <div className="text-lg sm:text-xl font-bold text-white font-heading">2.2M</div>
                  </div>

                  <div>
                    <div className="text-[10px] text-white/40 font-mono-tech">Growth Rate</div>
                    <div className="text-lg sm:text-xl font-bold text-[#00f2ff] font-heading">+40.9%</div>
                  </div>
                </div>
              </div>

              {/* Framer-Style Dual Neon Curve Chart */}
              <div className="relative w-full h-56 sm:h-64 my-4 rounded-2xl bg-gradient-to-b from-[#111218]/40 to-transparent p-4 border border-white/[0.04] flex items-end">
                
                {/* Background Grid Lines */}
                <div className="absolute inset-0 flex flex-col justify-between p-4 opacity-15 pointer-events-none">
                  <div className="border-b border-dashed border-white w-full" />
                  <div className="border-b border-dashed border-white w-full" />
                  <div className="border-b border-dashed border-white w-full" />
                </div>

                {/* SVG Curves */}
                <svg className="w-full h-full overflow-visible" preserveAspectRatio="none" viewBox="0 0 500 150">
                  <defs>
                    <linearGradient id="neonCyanGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                      <stop offset="0%" stopColor="#00f2ff" stopOpacity="0.8" />
                      <stop offset="100%" stopColor="#c084fc" stopOpacity="0.8" />
                    </linearGradient>
                    <linearGradient id="fillGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                      <stop offset="0%" stopColor="#00f2ff" stopOpacity="0.2" />
                      <stop offset="100%" stopColor="#00f2ff" stopOpacity="0" />
                    </linearGradient>
                  </defs>

                  {/* Shaded Area */}
                  <path 
                    d="M0,130 Q70,90 140,110 T280,60 T420,40 L500,20 L500,150 L0,150 Z" 
                    fill="url(#fillGrad)" 
                  />

                  {/* Primary Purple Line */}
                  <path
                    d="M0,110 Q70,140 140,95 T280,75 T420,50 L500,30"
                    fill="none"
                    stroke="#c084fc"
                    strokeWidth="2.5"
                    strokeDasharray="4 2"
                  />

                  {/* Secondary Glowing Cyan Line */}
                  <path
                    d="M0,130 Q70,90 140,110 T280,60 T420,40 L500,20"
                    fill="none"
                    stroke="url(#neonCyanGrad)"
                    strokeWidth="3.5"
                    filter="drop-shadow(0px 0px 8px #00f2ff)"
                  />
                </svg>

                {/* Floating Framer Chart Tooltip Card (Matching Screenshot) */}
                <div className="absolute top-6 right-8 sm:right-16 bg-[#181a24]/90 backdrop-blur-md border border-white/15 p-3.5 rounded-2xl shadow-[0_0_30px_rgba(0,0,0,0.8)] text-xs">
                  <div className="text-[11px] font-mono-tech text-white/50 mb-1.5 font-bold">Aug 15, 2026</div>
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-[#c084fc]" />
                      <span className="text-white/70">Trades:</span>
                      <span className="font-bold text-white font-mono-tech">135,535</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-[#00f2ff]" />
                      <span className="text-white/70">Active Peers:</span>
                      <span className="font-bold text-white font-mono-tech">54,817</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Bottom Card Footer */}
            <div 
              onClick={() => onOpenAnalytics?.()}
              className="pt-4 mt-2 border-t border-white/[0.06] flex items-center justify-between cursor-pointer group"
            >
              <span className="text-sm font-semibold text-white group-hover:text-[#00f2ff] transition-colors flex items-center gap-1.5">
                <span>Detailed Impact Analytics</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </span>
              <span className="text-[10px] font-mono-tech text-white/40">AUDITED BY ZERO-KNOWLEDGE</span>
            </div>
          </div>

          {/* ===================================================================== */}
          {/* BOTTOM-RIGHT CARD: Leaderboard Standings / Variant Testing (Spanning 4 cols) */}
          {/* ===================================================================== */}
          <div className="col-span-1 md:col-span-12 lg:col-span-4 bg-[#0a0a0c] border border-white/[0.08] hover:border-white/20 rounded-3xl p-6 sm:p-7 flex flex-col justify-between transition-all duration-300 shadow-2xl relative overflow-hidden group">
            
            <div>
              <div className="flex items-center justify-between mb-2">
                <div>
                  <div className="text-[10px] font-mono-tech text-[#00f2ff] uppercase tracking-widest font-bold">
                    WHO'S MAKING CAMPUS BETTER?
                  </div>
                  <div className="text-2xl sm:text-3xl font-black text-white font-heading mt-0.5">
                    {selectedUser.impactScore.toLocaleString()} <span className="text-xs font-mono-tech font-normal text-white/50">PTS</span>
                  </div>
                </div>
                <button
                  onClick={() => handleOpenLeaderboard('Trophy Icon')}
                  className="w-10 h-10 rounded-2xl bg-[#facc15]/10 border border-[#facc15]/40 flex items-center justify-center text-[#facc15] hover:bg-[#facc15]/20 transition-colors cursor-pointer"
                  title="View Full Leaderboard Standings"
                >
                  <Trophy className="w-5 h-5" />
                </button>
              </div>

              <p className="text-xs text-white/60 mb-4 font-normal">
                Your contribution moves you forward.
              </p>

              {/* Blue Pill Bar visual (Matching Framer screenshot's blue gradient bar) */}
              <div 
                onClick={() => handleOpenLeaderboard('Gradient Bar')}
                className="w-full h-8 rounded-xl bg-gradient-to-r from-[#00f2ff] via-[#3b82f6] to-[#1e1b4b] mb-6 shadow-[0_0_20px_rgba(0,242,255,0.25)] cursor-pointer hover:opacity-90 transition-opacity" 
                title="Click to view full standings"
              />

              {/* Leaderboard Users List (Interactive Selection) */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-[11px] font-mono-tech text-white/40 pb-1 border-b border-white/[0.06]">
                  <span>STUDENT</span>
                  <div className="flex items-center gap-4">
                    <span>KARMA</span>
                    <span>RANK</span>
                  </div>
                </div>

                {users.slice(0, 4).map((user, idx) => {
                  const isSelected = idx === selectedUserIndex;
                  const isTop = idx === 0;

                  return (
                    <div
                      key={user.id}
                      onClick={() => handleSelectUser(user, idx)}
                      className={`p-2.5 rounded-xl border transition-all cursor-pointer flex items-center justify-between ${
                        isSelected 
                          ? 'bg-[#181b24] border-[#00f2ff] shadow-[0_0_15px_rgba(0,242,255,0.2)]'
                          : 'bg-[#121318]/60 border-white/[0.04] hover:border-white/20 hover:bg-white/[0.02]'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <span className={`w-2 h-2 rounded-full ${isSelected ? 'bg-[#00f2ff]' : 'bg-white/30'}`} />
                        <span className="text-xs font-bold text-white truncate max-w-[120px]">
                          {user.name}
                        </span>
                        {isTop && (
                          <span className="text-[9px] font-mono-tech bg-[#facc15]/20 text-[#facc15] px-1.5 py-0.2 rounded font-bold">
                            TOP 1
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-4 text-xs font-mono-tech">
                        <span className="text-white font-bold">{user.impactScore}</span>
                        <span className="text-white/40">#{user.rank}</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Bottom Link Action */}
            <div 
              onClick={() => handleOpenLeaderboard('Footer Link')}
              className="pt-4 mt-6 border-t border-white/[0.06] flex items-center justify-between cursor-pointer group hover:bg-white/[0.02] p-1.5 -mx-1.5 rounded-xl transition-colors"
            >
              <span className="text-sm font-semibold text-white group-hover:text-[#00f2ff] transition-colors flex items-center gap-1.5">
                <span>Full Leaderboard</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </span>
              <span className="text-[10px] font-mono-tech text-white/40">{users.length}+ STUDENTS</span>
            </div>

          </div>

        </div>
      </div>
    </section>
  );
};

```

---

## File: `src/components/MarketplaceDetailModal.tsx`

```tsx
import React, { useState } from 'react';
import { MarketplaceItem } from '../types';
import { ShareData } from './ShareModal';
import { 
  X, 
  MapPin, 
  ShieldCheck, 
  Mail, 
  MessageCircle, 
  CheckCircle, 
  ShoppingBag,
  Clock,
  Sparkles,
  Tag,
  Share2,
  Check
} from 'lucide-react';

interface MarketplaceDetailModalProps {
  item: MarketplaceItem | null;
  onClose: () => void;
  onContactSeller: (itemId: string, message: string) => void;
  onOpenShare?: (data: ShareData) => void;
}

export const MarketplaceDetailModal: React.FC<MarketplaceDetailModalProps> = ({
  item,
  onClose,
  onContactSeller,
  onOpenShare,
}) => {
  const [message, setMessage] = useState('');
  const [isSent, setIsSent] = useState(false);
  const [copied, setCopied] = useState(false);

  if (!item) return null;

  const handleShare = () => {
    const itemUrl = `${window.location.origin}/marketplace/${item.id}`;
    const sharePayload: ShareData = {
      title: `${item.title} — ₹${item.price} on Campus Marketplace`,
      text: `${item.description} (Seller: ${item.sellerName}, Condition: ${item.condition})`,
      url: itemUrl,
      category: item.category,
      image: item.imageUrl,
    };

    if (onOpenShare) {
      onOpenShare(sharePayload);
    } else if (navigator.share) {
      navigator.share({
        title: sharePayload.title,
        text: sharePayload.text,
        url: sharePayload.url,
      }).catch(() => {});
    } else {
      navigator.clipboard?.writeText(itemUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;
    onContactSeller(item.id, message.trim());
    setIsSent(true);
    setTimeout(() => {
      setIsSent(false);
      setMessage('');
      onClose();
    }, 2000);
  };

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-xl animate-in fade-in duration-200"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div 
        id="marketplace-detail-modal-card"
        className="relative w-full max-w-2xl bg-[#090b10] border border-white/20 rounded-3xl shadow-[0_0_60px_rgba(0,242,255,0.2)] flex flex-col max-h-[90vh] overflow-hidden text-white"
      >
        {/* Dedicated Fixed Header Bar - Guarantees Close Button NEVER Overlaps Content */}
        <div className="px-5 py-4 sm:px-6 sm:py-4.5 border-b border-white/[0.08] bg-[#0d0f17] flex items-center justify-between shrink-0 z-20">
          <div className="flex items-center gap-2.5 overflow-hidden">
            <span className="px-2.5 py-1 rounded-md bg-[#00f2ff]/20 border border-[#00f2ff]/40 text-[#00f2ff] text-[11px] font-mono-tech font-bold uppercase tracking-wider shrink-0">
              {item.category}
            </span>
            <span className="text-white/40 text-xs hidden sm:inline">•</span>
            <span className="text-xs font-mono-tech text-white/60 truncate hidden sm:inline">
              Verified Campus Listing
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleShare}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/[0.08] hover:bg-[#00f2ff]/20 text-white hover:text-[#00f2ff] transition-all cursor-pointer border border-white/10 hover:border-[#00f2ff]/30 text-xs font-mono-tech"
              title="Share listing to WhatsApp, Telegram, X, etc."
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Share2 className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied' : 'Share'}</span>
            </button>

            <button
              id="marketplace-modal-close-btn"
              onClick={onClose}
              aria-label="Close modal"
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/[0.08] hover:bg-white/[0.18] text-white/80 hover:text-white transition-all cursor-pointer border border-white/10 text-xs font-mono-tech"
            >
              <span>Close</span>
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Scrollable Modal Content */}
        <div className="p-5 sm:p-7 space-y-6 overflow-y-auto custom-scrollbar relative z-10 flex-1">
          {/* Image Container with Dedicated Spacing */}
          {item.imageUrl && (
            <div className="w-full h-56 sm:h-64 rounded-2xl overflow-hidden bg-black border border-white/10 relative group">
              <img
                src={item.imageUrl}
                alt={item.title}
                className="w-full h-full object-cover group-hover:scale-102 transition-transform duration-500"
              />
              <div className="absolute bottom-3 left-3 px-3 py-1 rounded-lg bg-black/80 backdrop-blur-md border border-white/20 text-xs font-mono-tech text-white flex items-center gap-1.5">
                <Tag className="w-3.5 h-3.5 text-[#00f2ff]" />
                <span>Condition: {item.condition}</span>
              </div>
            </div>
          )}

          {/* Title & Price Row */}
          <div>
            <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3 mb-2">
              <h2 className="text-2xl sm:text-3xl font-black text-white font-heading tracking-tight">
                {item.title}
              </h2>
              <div className="text-2xl sm:text-3xl font-black text-[#00f2ff] font-mono-tech shrink-0">
                ₹{item.price.toLocaleString()}
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-3 text-xs font-mono-tech text-zinc-400">
              <span className="flex items-center gap-1 text-white/80">
                <MapPin className="w-3.5 h-3.5 text-[#00f2ff]" />
                {item.location}
              </span>
              <span className="text-white/30">•</span>
              <span className="px-2 py-0.5 rounded bg-white/5 border border-white/10 text-white/70">
                {item.condition}
              </span>
              <span className="text-white/30">•</span>
              <span className="flex items-center gap-1 text-white/60">
                <Clock className="w-3.5 h-3.5" />
                {item.createdAt || 'Listed Recently'}
              </span>
            </div>
          </div>

          {/* Description Box */}
          <div className="p-4 sm:p-5 rounded-2xl bg-[#12141f] border border-white/[0.08]">
            <div className="text-[11px] font-mono-tech text-[#00f2ff] uppercase tracking-wider mb-2 font-bold flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5" />
              <span>ITEM DETAILS & SPECIFICATIONS</span>
            </div>
            <p className="text-sm text-zinc-200 leading-relaxed whitespace-pre-line font-normal">
              {item.description}
            </p>
          </div>

          {/* Seller Card */}
          <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-[#12141f] to-[#161928] border border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3.5">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#00f2ff]/20 to-[#c084fc]/20 border border-[#00f2ff]/40 flex items-center justify-center font-bold text-white text-base font-mono-tech shadow-md shrink-0">
                {item.sellerName.slice(0, 2).toUpperCase()}
              </div>
              <div>
                <div className="text-sm sm:text-base font-bold text-white flex items-center gap-1.5">
                  <span>{item.sellerName}</span>
                  {item.sellerVerified !== false && (
                    <ShieldCheck className="w-4 h-4 text-[#00f2ff]" />
                  )}
                </div>
                <div className="text-xs font-mono-tech text-white/60">
                  {item.sellerDepartment || 'Verified Campus Student'}
                </div>
                <div className="text-[10px] font-mono-tech text-[#00f2ff] mt-0.5">
                  ⭐ 4.9 Rating (Verified Peer)
                </div>
              </div>
            </div>

            <span className="px-3 py-1.5 rounded-full bg-emerald-950/70 border border-emerald-400/40 text-[10px] font-mono-tech text-emerald-300 font-bold self-start sm:self-center">
              ✓ CAMPUS ID VERIFIED
            </span>
          </div>

          {/* Contact & Instant Reserve Form */}
          {isSent ? (
            <div className="p-5 rounded-2xl bg-emerald-950/80 border border-emerald-400/50 text-emerald-300 text-xs sm:text-sm font-mono-tech flex items-center gap-3 shadow-lg">
              <CheckCircle className="w-5 h-5 shrink-0 text-emerald-400" />
              <span>Direct notification sent to {item.sellerName}! They will coordinate pickup at {item.location}.</span>
            </div>
          ) : (
            <div className="space-y-4 pt-2 border-t border-white/[0.08]">
              {/* 1-Click Instant Reserve Action */}
              <button
                type="button"
                onClick={() => {
                  onContactSeller(item.id, `Reserved item "${item.title}" for ₹${item.price}. Ready for campus handover.`);
                  setIsSent(true);
                  setTimeout(() => {
                    setIsSent(false);
                    onClose();
                  }, 2200);
                }}
                className="w-full py-3.5 px-4 bg-[#00f2ff] hover:bg-[#38f6ff] text-black font-bold text-xs sm:text-sm font-mono-tech tracking-wider uppercase rounded-xl transition-all cursor-pointer shadow-[0_0_25px_rgba(0,242,255,0.3)] flex items-center justify-center gap-2"
              >
                <ShoppingBag className="w-4 h-4" />
                <span>Instant Reserve (₹{item.price.toLocaleString()})</span>
              </button>

              <div className="relative flex items-center justify-center my-2">
                <div className="border-t border-white/10 w-full" />
                <span className="bg-[#090b10] px-3 text-[10px] font-mono-tech text-zinc-500 uppercase">OR SEND CUSTOM INQUIRY</span>
              </div>

              <form onSubmit={handleSend} className="space-y-3">
                <label className="block text-xs font-mono-tech text-zinc-300 font-medium">
                  MESSAGE SELLER DIRECTLY
                </label>
                <textarea
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder={`Hi ${item.sellerName.split(' ')[0]}, is this still available? Can we meet at ${item.location} today?`}
                  rows={2}
                  required
                  className="w-full px-3.5 py-2.5 bg-[#12141f] border border-white/10 rounded-xl text-xs sm:text-sm text-white focus:outline-none focus:border-[#00f2ff] font-mono-tech transition-colors"
                />
                <button
                  type="submit"
                  className="w-full py-3 bg-white/10 hover:bg-white/20 text-white font-bold text-xs font-mono-tech tracking-wider uppercase rounded-xl transition-all cursor-pointer border border-white/20 flex items-center justify-center gap-2"
                >
                  <MessageCircle className="w-4 h-4 text-[#00f2ff]" />
                  <span>Send Peer Message</span>
                </button>
              </form>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

```

---

## File: `src/components/MarketplaceSection.tsx`

```tsx
import React, { useState, useMemo } from 'react';
import { MarketplaceItem } from '../types';
import { 
  Search, 
  Plus, 
  MapPin, 
  ShieldCheck, 
  ShoppingBag,
  ArrowUpRight,
  Sparkles,
  Tag,
  Clock,
  ArrowRight,
  ArrowUpDown,
  Filter,
  Layers,
  RotateCcw
} from 'lucide-react';

interface MarketplaceSectionProps {
  items: MarketplaceItem[];
  onSelectItem: (item: MarketplaceItem) => void;
  onOpenCreateModal: () => void;
}

export const MarketplaceSection: React.FC<MarketplaceSectionProps> = ({
  items,
  onSelectItem,
  onOpenCreateModal,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [sortBy, setSortBy] = useState<'recommended' | 'price-asc' | 'price-desc' | 'newest'>('recommended');

  const categories = ['All', 'Electronics', 'Books', 'Furniture', 'Equipment', 'Notes'];

  // Dynamic Filtering & Sorting Logic
  const filteredAndSortedItems = useMemo(() => {
    let result = items.filter((item) => {
      const matchesCat = 
        selectedCategory === 'All' || 
        item.category.toLowerCase() === selectedCategory.toLowerCase();
      
      const query = searchQuery.trim().toLowerCase();
      const matchesQuery =
        !query ||
        item.title.toLowerCase().includes(query) ||
        item.description.toLowerCase().includes(query) ||
        item.location.toLowerCase().includes(query) ||
        item.sellerName.toLowerCase().includes(query) ||
        item.category.toLowerCase().includes(query);

      return matchesCat && matchesQuery;
    });

    // Apply Sorter
    if (sortBy === 'price-asc') {
      result = [...result].sort((a, b) => a.price - b.price);
    } else if (sortBy === 'price-desc') {
      result = [...result].sort((a, b) => b.price - a.price);
    } else if (sortBy === 'newest') {
      // Sort by creation date if available, or maintain reverse chronological
      result = [...result].reverse();
    }

    return result;
  }, [items, selectedCategory, searchQuery, sortBy]);

  return (
    <section id="marketplace" className="py-24 sm:py-28 border-b border-white/[0.08] relative bg-[#000000] text-white overflow-hidden font-sans">
      {/* Background ambient lighting */}
      <div className="absolute top-1/4 right-1/4 w-[750px] h-[550px] bg-[#00f2ff]/5 rounded-full blur-[170px] pointer-events-none -z-10" />
      <div className="absolute bottom-10 left-1/4 w-[650px] h-[450px] bg-[#c084fc]/5 rounded-full blur-[150px] pointer-events-none -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* ========================================================================= */}
        {/* TOP SECTION HEADER */}
        {/* ========================================================================= */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div>
            <div className="inline-flex items-center gap-2 text-[11px] font-mono-tech tracking-[4px] text-[#00f2ff] font-bold uppercase mb-2">
              <ShoppingBag className="w-3.5 h-3.5 text-[#00f2ff]" />
              <span>C A M P U S &nbsp; C O M M E R C E &nbsp; // &nbsp; Z E R O &nbsp; F E E S</span>
            </div>
            <h2 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-white tracking-normal font-heading">
              Give unused things a second life.
            </h2>
            <p className="text-white/60 mt-2 text-base sm:text-lg max-w-2xl font-normal leading-relaxed">
              Buy, sell, or trade lab gear, laptops, textbooks, and hostel essentials directly with verified peers.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              id="marketplace-list-item-btn"
              onClick={onOpenCreateModal}
              className="inline-flex items-center gap-2 px-7 py-3.5 bg-white hover:bg-zinc-200 text-black font-bold text-xs sm:text-sm rounded-full transition-all cursor-pointer shadow-lg hover:shadow-[0_0_25px_rgba(255,255,255,0.3)] hover:scale-[1.02] active:scale-[0.98]"
            >
              <Plus className="w-4 h-4" />
              <span>List an Item</span>
            </button>
          </div>
        </div>

        {/* ========================================================================= */}
        {/* FILTER, SEARCH & ITEM SORTER ROW */}
        {/* ========================================================================= */}
        <div className="flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-4 mb-10 pb-6 border-b border-white/[0.08]">
          {/* Category Pills */}
          <div className="flex items-center gap-2 overflow-x-auto pb-2 lg:pb-0 scrollbar-none">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-4 py-2 text-xs font-mono-tech tracking-wider rounded-full transition-all cursor-pointer whitespace-nowrap uppercase ${
                  selectedCategory === cat
                    ? 'bg-[#00f2ff]/20 border border-[#00f2ff] text-[#00f2ff] font-bold shadow-[0_0_15px_rgba(0,242,255,0.2)]'
                    : 'bg-[#0a0a0c] border border-white/[0.08] text-white/50 hover:text-white hover:border-white/20'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Search Bar & Sorter Controls */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
            {/* Search Input */}
            <div className="relative min-w-[240px] flex-1">
              <Search className="w-4 h-4 text-white/40 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search gear, laptops, books..."
                className="w-full pl-10 pr-4 py-2.5 bg-[#0a0a0c] border border-white/[0.08] focus:border-[#00f2ff] rounded-full text-xs text-white placeholder-white/40 focus:outline-none transition-colors font-mono-tech"
              />
            </div>

            {/* Sorter Selector */}
            <div className="flex items-center gap-2 bg-[#0a0a0c] border border-white/[0.08] rounded-full px-3.5 py-1.5 shrink-0">
              <ArrowUpDown className="w-3.5 h-3.5 text-[#00f2ff]" />
              <span className="text-[11px] font-mono-tech text-white/50 uppercase hidden sm:inline">Sort:</span>
              <select
                id="marketplace-sorter-select"
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="bg-transparent text-xs font-mono-tech text-white focus:outline-none cursor-pointer pr-1"
              >
                <option value="recommended" className="bg-[#0a0a0c] text-white">Recommended</option>
                <option value="price-asc" className="bg-[#0a0a0c] text-white">Price: Low to High</option>
                <option value="price-desc" className="bg-[#0a0a0c] text-white">Price: High to Low</option>
                <option value="newest" className="bg-[#0a0a0c] text-white">Newest Listed</option>
              </select>
            </div>
          </div>
        </div>

        {/* ========================================================================= */}
        {/* DYNAMIC MARKETPLACE GRID (Bento + Grid Hybrid) */}
        {/* ========================================================================= */}
        {filteredAndSortedItems.length === 0 ? (
          <div className="py-16 text-center bg-[#0d0e12] border border-white/[0.08] rounded-3xl p-8 max-w-lg mx-auto">
            <div className="w-12 h-12 rounded-full bg-[#00f2ff]/10 border border-[#00f2ff]/30 text-[#00f2ff] flex items-center justify-center mx-auto mb-4">
              <ShoppingBag className="w-6 h-6" />
            </div>
            <h3 className="text-xl font-bold text-white font-heading">No listings found</h3>
            <p className="text-sm text-white/60 mt-1 mb-6 font-mono-tech">
              No campus items match "{searchQuery || selectedCategory}". Try clearing your filters.
            </p>
            <div className="flex items-center justify-center gap-3">
              <button
                onClick={() => {
                  setSelectedCategory('All');
                  setSearchQuery('');
                  setSortBy('recommended');
                }}
                className="px-4 py-2 rounded-full bg-white/10 hover:bg-white/20 text-xs font-mono-tech text-white flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reset Filters</span>
              </button>
              <button
                onClick={onOpenCreateModal}
                className="px-5 py-2 rounded-full bg-[#00f2ff] hover:bg-[#38f6ff] text-xs font-mono-tech text-black font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>List an Item</span>
              </button>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-stretch">
            {filteredAndSortedItems.map((item, idx) => {
              // Create an asymmetric clean 12-col rhythm
              const isLargeLead = idx === 0;
              const isMedium = idx === 1 || idx === 4;
              const colSpan = isLargeLead 
                ? 'col-span-1 md:col-span-12 lg:col-span-6' 
                : isMedium 
                  ? 'col-span-1 md:col-span-6 lg:col-span-6' 
                  : 'col-span-1 md:col-span-6 lg:col-span-3';

              return (
                <div 
                  key={item.id}
                  id={`marketplace-card-${item.id}`}
                  onClick={() => onSelectItem(item)}
                  className={`${colSpan} rounded-3xl bg-[#0d0e12] border border-white/[0.08] hover:border-white/30 p-6 sm:p-7 min-h-[380px] relative flex flex-col justify-between overflow-hidden group cursor-pointer transition-all duration-500 shadow-2xl`}
                >
                  {/* Background Image with Gradient Overlay */}
                  {item.imageUrl && (
                    <img 
                      src={item.imageUrl} 
                      alt={item.title} 
                      className="absolute inset-0 w-full h-full object-cover opacity-50 group-hover:opacity-75 group-hover:scale-105 transition-all duration-700 pointer-events-none"
                    />
                  )}
                  <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-black/20 pointer-events-none" />
                  
                  {/* Top Bar with Category, Location & Handover Badges */}
                  <div className="relative z-10 flex items-start justify-between gap-3">
                    <div className="flex flex-col gap-1">
                      <div className="flex items-center gap-2 text-xs font-mono-tech text-white/80">
                        <span className="px-2 py-0.5 rounded bg-black/60 border border-white/20 text-[#00f2ff] font-bold text-[10px] uppercase">
                          {item.category}
                        </span>
                        <span className="text-white/40">•</span>
                        <span className="text-[11px] text-white/70 truncate max-w-[140px]">{item.location}</span>
                      </div>
                    </div>

                    {/* Floating Price Badge */}
                    <div className="px-3 py-1.5 rounded-2xl bg-black/80 backdrop-blur-xl border border-white/20 text-xs font-mono-tech font-bold text-white shadow-xl flex items-center gap-1.5 shrink-0">
                      <span className="text-[#00f2ff]">₹{item.price.toLocaleString()}</span>
                    </div>
                  </div>

                  {/* Bottom Headline & Seller Action */}
                  <div className="relative z-10 pt-16">
                    <div className="flex items-center gap-2 text-[10px] font-mono-tech text-white/60 mb-1 uppercase tracking-wider">
                      <span>Condition: {item.condition}</span>
                    </div>

                    <h3 className={`${isLargeLead ? 'text-2xl sm:text-3xl' : 'text-xl sm:text-2xl'} font-black text-white font-heading tracking-tight group-hover:text-[#00f2ff] transition-colors leading-tight line-clamp-2`}>
                      {item.title}
                    </h3>

                    <p className="text-xs sm:text-sm text-white/70 max-w-md mt-1.5 line-clamp-2 font-normal">
                      {item.description}
                    </p>
                    
                    <div className="mt-4 flex items-center justify-between border-t border-white/10 pt-3">
                      <span className="text-xs font-mono-tech text-white/60 flex items-center gap-1.5">
                        <ShieldCheck className="w-3.5 h-3.5 text-[#00f2ff]" />
                        <span className="truncate max-w-[150px]">{item.sellerName}</span>
                      </span>

                      <div className="w-8 h-8 rounded-full bg-white/10 group-hover:bg-[#00f2ff] group-hover:text-black flex items-center justify-center text-white transition-all">
                        <ArrowUpRight className="w-4 h-4" />
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

      </div>
    </section>
  );
};

```

---

## File: `src/components/MobileSectionNavigator.tsx`

```tsx
import React from 'react';
import { 
  Sparkles, 
  Layers, 
  Trophy, 
  Radio, 
  FolderGit2, 
  ShoppingBag, 
  ChevronLeft, 
  ChevronRight, 
  ListOrdered, 
  Scroll,
  ArrowRight,
  Zap,
  MessageSquare
} from 'lucide-react';
import { CompassStarIcon } from './BrandLogos';

export interface MobileSection {
  id: string;
  name: string;
  shortName: string;
  badge?: string;
  icon: React.ReactNode;
}

export const MOBILE_SECTIONS: MobileSection[] = [
  {
    id: 'overview',
    name: 'Overview & Showcase',
    shortName: 'Overview',
    icon: <Sparkles className="w-4 h-4 text-cyan-400" />,
  },
  {
    id: 'services',
    name: '6 Campus Services',
    shortName: 'Services',
    badge: '6 Core',
    icon: <Layers className="w-4 h-4 text-violet-400" />,
  },
  {
    id: 'impact',
    name: 'Impact & Leaderboard',
    shortName: 'Impact',
    badge: 'Top 50',
    icon: <Trophy className="w-4 h-4 text-amber-400" />,
  },
  {
    id: 'compass',
    name: 'COMPASS AI Core',
    shortName: 'COMPASS',
    badge: 'AI',
    icon: <CompassStarIcon size={16} glow={false} />,
  },
  {
    id: 'chat',
    name: 'Campus Peer Chat',
    shortName: 'Peer Chat',
    badge: 'Live',
    icon: <MessageSquare className="w-4 h-4 text-cyan-400" />,
  },
  {
    id: 'pulse',
    name: 'Live Campus Pulse',
    shortName: 'Pulse',
    badge: 'Feed',
    icon: <Radio className="w-4 h-4 text-emerald-400" />,
  },
  {
    id: 'projects',
    name: 'Research & Projects',
    shortName: 'Projects',
    badge: 'Collabs',
    icon: <FolderGit2 className="w-4 h-4 text-blue-400" />,
  },
  {
    id: 'marketplace',
    name: 'Student Marketplace',
    shortName: 'Market',
    badge: 'P2P',
    icon: <ShoppingBag className="w-4 h-4 text-pink-400" />,
  },
];

interface MobileSectionNavigatorProps {
  activeSection: string;
  onSelectSection: (sectionId: string) => void;
  isTabbedMode: boolean;
  onToggleTabbedMode: (enabled: boolean) => void;
}

export const MobileSectionNavigator: React.FC<MobileSectionNavigatorProps> = ({
  activeSection,
  onSelectSection,
  isTabbedMode,
  onToggleTabbedMode,
}) => {
  const currentIndex = MOBILE_SECTIONS.findIndex((s) => s.id === activeSection);
  const safeIndex = currentIndex >= 0 ? currentIndex : 0;
  const currentSection = MOBILE_SECTIONS[safeIndex];

  const handlePrev = () => {
    if (safeIndex > 0) {
      const prevSection = MOBILE_SECTIONS[safeIndex - 1];
      onSelectSection(prevSection.id);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handleNext = () => {
    if (safeIndex < MOBILE_SECTIONS.length - 1) {
      const nextSection = MOBILE_SECTIONS[safeIndex + 1];
      onSelectSection(nextSection.id);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  return (
    <div className="lg:hidden sticky top-16 z-40 bg-[#070913]/95 backdrop-blur-xl border-b border-white/[0.08] shadow-xl">
      {/* Top Controls Row */}
      <div className="px-3 pt-2 pb-1.5 flex items-center justify-between gap-2 border-b border-white/[0.04]">
        {/* Section Counter & Mode Badge */}
        <div className="flex items-center gap-2">
          <span className="text-[10px] font-mono-tech px-2 py-0.5 rounded-md bg-white/[0.06] text-white/70 border border-white/10 font-medium">
            {isTabbedMode ? `SECTION ${safeIndex + 1} OF ${MOBILE_SECTIONS.length}` : 'ALL SECTIONS'}
          </span>
          <span className="text-xs font-heading font-semibold text-white truncate max-w-[150px]">
            {currentSection.name}
          </span>
        </div>

        {/* View Mode Toggle: Tabbed (Single Section) vs Continuous Flow */}
        <button
          onClick={() => onToggleTabbedMode(!isTabbedMode)}
          className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-mono-tech font-semibold transition-all cursor-pointer border ${
            isTabbedMode
              ? 'bg-[#00f2ff]/15 text-[#00f2ff] border-[#00f2ff]/40 shadow-[0_0_12px_rgba(0,242,255,0.2)]'
              : 'bg-white/[0.05] text-white/70 border-white/10 hover:text-white'
          }`}
          title={isTabbedMode ? "Switch to Continuous Full Scroll" : "Switch to Fast Section-by-Section Mode"}
        >
          {isTabbedMode ? (
            <>
              <ListOrdered className="w-3 h-3 text-[#00f2ff]" />
              <span>Tabs View</span>
            </>
          ) : (
            <>
              <Scroll className="w-3 h-3 text-slate-400" />
              <span>Full Flow</span>
            </>
          )}
        </button>
      </div>

      {/* Horizontal Scrollable Section Tabs */}
      <div className="flex items-center gap-1.5 px-3 py-2 overflow-x-auto no-scrollbar scroll-smooth">
        {MOBILE_SECTIONS.map((sec, idx) => {
          const isActive = sec.id === activeSection;
          return (
            <button
              key={sec.id}
              onClick={() => {
                onSelectSection(sec.id);
                if (isTabbedMode) {
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                } else {
                  const el = document.getElementById(sec.id);
                  if (el) {
                    el.scrollIntoView({ behavior: 'smooth' });
                  }
                }
              }}
              className={`shrink-0 flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium transition-all duration-200 cursor-pointer border ${
                isActive
                  ? 'bg-white/15 text-white border-white/30 shadow-[0_0_15px_rgba(255,255,255,0.15)] font-semibold'
                  : 'bg-white/[0.03] text-white/60 hover:text-white hover:bg-white/[0.08] border-white/5'
              }`}
            >
              {sec.icon}
              <span className="whitespace-nowrap">{sec.shortName}</span>
              {sec.badge && (
                <span className={`text-[9px] px-1 py-0.2 rounded font-mono-tech ${
                  isActive ? 'bg-cyan-400/30 text-cyan-200' : 'bg-white/10 text-white/50'
                }`}>
                  {sec.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Prev / Next Quick Nav Strip (Only when Tabbed Mode is active) */}
      {isTabbedMode && (
        <div className="px-3 py-1.5 bg-[#05060b] border-t border-white/[0.04] flex items-center justify-between gap-2 text-xs">
          <button
            onClick={handlePrev}
            disabled={safeIndex === 0}
            className={`flex items-center gap-1 px-2.5 py-1 rounded-lg transition-all ${
              safeIndex === 0 
                ? 'opacity-30 text-white/30 cursor-not-allowed' 
                : 'text-white/80 hover:text-white bg-white/[0.05] hover:bg-white/10 active:scale-95 cursor-pointer'
            }`}
          >
            <ChevronLeft className="w-3.5 h-3.5" />
            <span className="text-[11px] font-mono-tech">Prev</span>
          </button>

          <div className="flex items-center gap-1">
            {MOBILE_SECTIONS.map((s, idx) => (
              <span
                key={s.id}
                onClick={() => onSelectSection(s.id)}
                className={`h-1.5 rounded-full transition-all duration-300 cursor-pointer ${
                  idx === safeIndex ? 'w-5 bg-[#00f2ff]' : 'w-1.5 bg-white/20 hover:bg-white/40'
                }`}
              />
            ))}
          </div>

          <button
            onClick={handleNext}
            disabled={safeIndex === MOBILE_SECTIONS.length - 1}
            className={`flex items-center gap-1 px-2.5 py-1 rounded-lg transition-all ${
              safeIndex === MOBILE_SECTIONS.length - 1 
                ? 'opacity-30 text-white/30 cursor-not-allowed' 
                : 'text-white/80 hover:text-white bg-white/[0.05] hover:bg-white/10 active:scale-95 cursor-pointer'
            }`}
          >
            <span className="text-[11px] font-mono-tech">Next</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
      )}
    </div>
  );
};

interface MobileNextSectionFooterProps {
  currentSectionId: string;
  onNavigateNext: (nextSectionId: string) => void;
  onNavigateSection: (sectionId: string) => void;
}

export const MobileNextSectionFooter: React.FC<MobileNextSectionFooterProps> = ({
  currentSectionId,
  onNavigateNext,
  onNavigateSection,
}) => {
  const currentIndex = MOBILE_SECTIONS.findIndex((s) => s.id === currentSectionId);
  const nextSection = currentIndex >= 0 && currentIndex < MOBILE_SECTIONS.length - 1 
    ? MOBILE_SECTIONS[currentIndex + 1] 
    : null;

  return (
    <div className="lg:hidden px-4 py-8 bg-[#05060b] border-t border-white/[0.08] space-y-4">
      {nextSection ? (
        <button
          onClick={() => {
            onNavigateNext(nextSection.id);
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          className="w-full p-4 rounded-2xl bg-gradient-to-r from-cyan-950/40 via-violet-950/40 to-pink-950/40 hover:from-cyan-900/60 hover:to-pink-900/60 border border-white/15 hover:border-cyan-400/40 flex items-center justify-between text-left transition-all duration-300 shadow-xl group cursor-pointer active:scale-[0.99]"
        >
          <div>
            <div className="text-[10px] font-mono-tech text-cyan-300 uppercase tracking-wider flex items-center gap-1.5">
              <Zap className="w-3 h-3 text-cyan-400" />
              <span>Continue to Next Section</span>
            </div>
            <div className="text-sm font-bold text-white font-heading mt-0.5 group-hover:text-cyan-200 transition-colors">
              {nextSection.name}
            </div>
          </div>
          <div className="w-9 h-9 rounded-full bg-white/10 flex items-center justify-center group-hover:bg-cyan-400 group-hover:text-black transition-all">
            <ArrowRight className="w-4 h-4 text-white group-hover:text-black" />
          </div>
        </button>
      ) : (
        <button
          onClick={() => {
            onNavigateSection('overview');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          className="w-full p-4 rounded-2xl bg-white/[0.04] hover:bg-white/[0.08] border border-white/15 text-center transition-all cursor-pointer"
        >
          <div className="text-xs font-mono-tech text-cyan-300">You've explored all 7 campus sections</div>
          <div className="text-sm font-bold text-white font-heading mt-0.5">Return to Top Overview ↑</div>
        </button>
      )}

      {/* Quick Jump Grid of All Sections */}
      <div className="pt-2">
        <div className="text-[11px] font-mono-tech text-white/40 uppercase tracking-wider mb-2">
          Jump to any section:
        </div>
        <div className="grid grid-cols-2 gap-1.5">
          {MOBILE_SECTIONS.map((sec) => {
            const isCurrent = sec.id === currentSectionId;
            return (
              <button
                key={sec.id}
                onClick={() => {
                  onNavigateSection(sec.id);
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className={`p-2 rounded-xl text-left text-xs flex items-center gap-2 transition-all cursor-pointer ${
                  isCurrent
                    ? 'bg-white/15 text-white font-bold border border-white/20'
                    : 'bg-white/[0.02] hover:bg-white/[0.06] text-white/70 hover:text-white border border-white/5'
                }`}
              >
                {sec.icon}
                <span className="truncate">{sec.shortName}</span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};

```

---

## File: `src/components/Navbar.tsx`

```tsx
import React, { useState } from 'react';
import { UserProfile } from '../types';
import { ShieldCheck, Search, Menu, X, ArrowRight, Sparkles, Compass, Bell, Presentation, Play } from 'lucide-react';
import { OnCampusOrbitalIcon, CompassStarIcon } from './BrandLogos';

interface NavbarProps {
  currentUser: UserProfile | null;
  onOpenAuth: () => void;
  onOpenCompass: () => void;
  onOpenSearch?: () => void;
  onOpenNotifications?: () => void;
  unreadNotificationsCount?: number;
  onOpenServiceModal?: (service: string) => void;
  onNavigateSection?: (sectionId: string) => void;
  onOpenPresentation?: () => void;
  activeSection?: string;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentUser,
  onOpenAuth,
  onOpenCompass,
  onOpenSearch,
  onOpenNotifications,
  unreadNotificationsCount = 0,
  onOpenServiceModal,
  onNavigateSection,
  onOpenPresentation,
  activeSection = 'hero',
}) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const scrollTo = (id: string) => {
    setIsMobileMenuOpen(false);
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
    if (onNavigateSection) {
      onNavigateSection(id);
    }
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-[#05060b]/95 backdrop-blur-2xl border-b border-white/[0.08]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-3">
        {/* Brand: Glowing Orbital Ring Logo + ON CAMPUS */}
        <div 
          onClick={() => scrollTo('hero')} 
          className="flex items-center gap-2.5 sm:gap-3 cursor-pointer group select-none shrink-0"
          id="brand-logo"
        >
          <OnCampusOrbitalIcon size={30} />
          <span className="text-base sm:text-lg font-bold tracking-[2.5px] sm:tracking-[3px] text-white font-heading uppercase group-hover:text-[#00f2ff] transition-colors">
            ON CAMPUS
          </span>
        </div>

        {/* Center Navigation: Services, Impact, COMPASS, Pulse, Projects, Marketplace (Desktop) */}
        <nav className="hidden lg:flex items-center gap-7">
          <button
            onClick={() => scrollTo('services')}
            className={`text-sm font-medium transition-colors hover:text-white cursor-pointer ${
              activeSection === 'services' ? 'text-[#00f2ff]' : 'text-white/70'
            }`}
          >
            Services
          </button>

          <button
            onClick={() => scrollTo('impact')}
            className={`text-sm font-medium transition-colors hover:text-white cursor-pointer ${
              activeSection === 'impact' ? 'text-[#00f2ff]' : 'text-white/70'
            }`}
          >
            Impact
          </button>

          <button
            onClick={() => scrollTo('compass')}
            className={`text-sm font-medium transition-colors hover:text-white cursor-pointer flex items-center gap-1.5 ${
              activeSection === 'compass' ? 'text-pink-300' : 'text-white/70'
            }`}
          >
            <CompassStarIcon size={16} glow={false} />
            <span>COMPASS</span>
          </button>

          <button
            onClick={() => scrollTo('chat')}
            className={`text-sm font-medium transition-colors hover:text-white cursor-pointer flex items-center gap-1.5 ${
              activeSection === 'chat' ? 'text-[#00f2ff]' : 'text-white/70'
            }`}
          >
            <span>Peer Chat</span>
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
          </button>

          <button
            onClick={() => scrollTo('pulse')}
            className={`text-sm font-medium transition-colors hover:text-white cursor-pointer ${
              activeSection === 'pulse' ? 'text-[#00f2ff]' : 'text-white/70'
            }`}
          >
            Pulse
          </button>

          <button
            onClick={() => scrollTo('projects')}
            className={`text-sm font-medium transition-colors hover:text-white cursor-pointer ${
              activeSection === 'projects' ? 'text-[#00f2ff]' : 'text-white/70'
            }`}
          >
            Projects
          </button>

          <button
            onClick={() => scrollTo('marketplace')}
            className={`text-sm font-medium transition-colors hover:text-white cursor-pointer ${
              activeSection === 'marketplace' ? 'text-[#00f2ff]' : 'text-white/70'
            }`}
          >
            Marketplace
          </button>

          {onOpenPresentation && (
            <button
              onClick={onOpenPresentation}
              className="text-xs font-mono-tech px-2.5 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 hover:bg-cyan-500/20 hover:text-white transition-all cursor-pointer flex items-center gap-1.5 shadow-[0_0_12px_rgba(0,242,255,0.15)]"
              title="Open Ecosystem Pitch Deck & Presentation"
            >
              <Presentation className="w-3.5 h-3.5 text-cyan-400" />
              <span>Pitch Deck</span>
            </button>
          )}
        </nav>

        {/* Right CTA / Search / Auth / Mobile Toggle */}
        <div className="flex items-center gap-1.5 sm:gap-2.5 md:gap-3 shrink-0">
          {/* Quick Command Palette Search Button */}
          {onOpenSearch && (
            <button
              id="navbar-search-btn"
              onClick={onOpenSearch}
              className="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/[0.04] border border-white/10 hover:border-cyan-400/40 hover:bg-white/[0.08] transition-all text-xs text-white/60 hover:text-white font-mono-tech cursor-pointer"
              title="Quick Search & Commands (⌘K)"
            >
              <Search className="w-3.5 h-3.5 text-cyan-400" />
              <span className="hidden lg:inline">Search...</span>
              <kbd className="px-1.5 py-0.5 text-[10px] bg-white/[0.08] rounded text-white/50 border border-white/10">⌘K</kbd>
            </button>
          )}

          {/* Top Bar Notification Bell Icon with Requests Badge */}
          {onOpenNotifications && (
            <button
              id="navbar-notifications-btn"
              onClick={onOpenNotifications}
              className="relative p-2 sm:px-2.5 sm:py-1.5 rounded-full bg-white/[0.05] border border-white/10 hover:border-[#00f2ff]/50 hover:bg-white/[0.1] transition-all text-white/80 hover:text-white cursor-pointer flex items-center gap-1.5 shrink-0"
              title="Campus Requests & Notifications"
              aria-label="Open notifications"
            >
              <Bell className="w-4 h-4 text-[#00f2ff]" />
              {unreadNotificationsCount > 0 && (
                <span className="flex items-center justify-center min-w-[17px] h-[17px] px-1 rounded-full bg-gradient-to-r from-[#00f2ff] to-[#38bdf8] text-black font-mono-tech font-black text-[10px] shadow-[0_0_10px_rgba(0,242,255,0.6)] animate-pulse">
                  {unreadNotificationsCount}
                </span>
              )}
            </button>
          )}

          {currentUser ? (
            <button
              id="user-profile-btn"
              onClick={onOpenAuth}
              className="flex items-center gap-1.5 sm:gap-2 px-2 sm:px-2.5 md:px-3 py-1.5 rounded-full bg-white/[0.05] border border-white/10 hover:border-white/25 transition-all text-xs font-mono-tech cursor-pointer shrink-0"
              title="Edit Profile & Switch Identity"
            >
              <img
                src={currentUser.avatar}
                alt={currentUser.name}
                className="w-5 h-5 rounded-full object-cover border border-[#00f2ff]/50 shrink-0"
              />
              <span className="text-white/90 font-medium hidden xs:inline sm:inline truncate max-w-[60px] sm:max-w-[85px]">
                {currentUser.name.split(' ')[0]}
              </span>
              <span className="text-[#00f2ff] text-[10px] hidden md:inline">
                #{currentUser.rank}
              </span>
            </button>
          ) : (
            <button
              id="signin-btn"
              onClick={onOpenAuth}
              className="text-xs sm:text-sm text-white/80 hover:text-white font-medium px-2 sm:px-2.5 py-1.5 transition-colors cursor-pointer shrink-0"
            >
              Sign in
            </button>
          )}

          <button
            id="get-started-btn"
            onClick={() => scrollTo('services')}
            className="hidden lg:inline-flex bg-[#00f2ff] hover:bg-[#38f6ff] text-black font-semibold text-xs sm:text-sm px-3.5 sm:px-5 py-2 rounded-full transition-all duration-200 cursor-pointer shadow-[0_0_20px_rgba(0,242,255,0.25)] hover:shadow-[0_0_25px_rgba(0,242,255,0.4)] hover:scale-[1.02] active:scale-[0.98] shrink-0"
          >
            Get started
          </button>

          {/* Mobile Hamburger Toggle Button */}
          <button
            id="navbar-mobile-toggle"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="lg:hidden p-2 rounded-xl bg-white/[0.05] border border-white/10 text-white/80 hover:text-white hover:bg-white/10 transition-colors cursor-pointer shrink-0"
            aria-label={isMobileMenuOpen ? 'Close menu' : 'Open menu'}
          >
            {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Slide-Down Navigation Menu */}
      {isMobileMenuOpen && (
        <div 
          id="navbar-mobile-menu"
          className="lg:hidden bg-[#070910]/98 backdrop-blur-2xl border-b border-white/15 px-4 py-5 space-y-4 animate-in slide-in-from-top-2 duration-200 shadow-2xl"
        >
          {/* Quick Search & Notifications on Mobile */}
          <div className="flex items-center gap-2">
            {onOpenSearch && (
              <button
                onClick={() => {
                  setIsMobileMenuOpen(false);
                  onOpenSearch();
                }}
                className="flex-1 flex items-center justify-between px-4 py-3 rounded-2xl bg-[#121420] border border-white/10 text-xs font-mono-tech text-white/70 hover:text-white transition-all cursor-pointer"
              >
                <div className="flex items-center gap-2.5">
                  <Search className="w-4 h-4 text-cyan-400" />
                  <span>Search gear, mentors...</span>
                </div>
                <span className="px-2 py-0.5 rounded bg-white/10 text-[10px] text-white/60">⌘K</span>
              </button>
            )}

            {onOpenNotifications && (
              <button
                onClick={() => {
                  setIsMobileMenuOpen(false);
                  onOpenNotifications();
                }}
                className="flex items-center gap-2 px-4 py-3 rounded-2xl bg-[#121420] border border-white/10 hover:border-[#00f2ff]/40 text-xs font-mono-tech text-white transition-all cursor-pointer shrink-0"
              >
                <Bell className="w-4 h-4 text-[#00f2ff]" />
                {unreadNotificationsCount > 0 && (
                  <span className="px-1.5 py-0.5 rounded-full bg-[#00f2ff] text-black font-bold text-[10px]">
                    {unreadNotificationsCount}
                  </span>
                )}
              </button>
            )}
          </div>

          {/* Navigation Links Grid */}
          <div className="grid grid-cols-2 md:grid-cols-3 gap-2.5 text-sm font-medium">
            <button
              onClick={() => scrollTo('overview')}
              className={`p-3 rounded-2xl border text-left transition-all cursor-pointer flex items-center justify-between ${
                activeSection === 'overview' || activeSection === 'hero'
                  ? 'bg-cyan-950/40 border-cyan-400 text-cyan-300'
                  : 'bg-white/[0.03] border-white/10 text-white/80 hover:bg-white/[0.06] hover:text-white'
              }`}
            >
              <span>Overview</span>
              <ArrowRight className="w-3.5 h-3.5 opacity-50" />
            </button>

            <button
              onClick={() => scrollTo('services')}
              className={`p-3 rounded-2xl border text-left transition-all cursor-pointer flex items-center justify-between ${
                activeSection === 'services'
                  ? 'bg-cyan-950/40 border-cyan-400 text-cyan-300'
                  : 'bg-white/[0.03] border-white/10 text-white/80 hover:bg-white/[0.06] hover:text-white'
              }`}
            >
              <span>Services Hub</span>
              <ArrowRight className="w-3.5 h-3.5 opacity-50" />
            </button>

            <button
              onClick={() => scrollTo('impact')}
              className={`p-3 rounded-2xl border text-left transition-all cursor-pointer flex items-center justify-between ${
                activeSection === 'impact'
                  ? 'bg-cyan-950/40 border-cyan-400 text-cyan-300'
                  : 'bg-white/[0.03] border-white/10 text-white/80 hover:bg-white/[0.06] hover:text-white'
              }`}
            >
              <span>Impact Board</span>
              <ArrowRight className="w-3.5 h-3.5 opacity-50" />
            </button>

            <button
              onClick={() => scrollTo('compass')}
              className={`p-3 rounded-2xl border text-left transition-all cursor-pointer flex items-center justify-between ${
                activeSection === 'compass'
                  ? 'bg-pink-950/40 border-pink-400 text-pink-300'
                  : 'bg-white/[0.03] border-white/10 text-white/80 hover:bg-white/[0.06] hover:text-white'
              }`}
            >
              <div className="flex items-center gap-1.5">
                <CompassStarIcon size={14} glow={false} />
                <span>COMPASS AI</span>
              </div>
              <ArrowRight className="w-3.5 h-3.5 opacity-50" />
            </button>

            <button
              onClick={() => scrollTo('chat')}
              className={`p-3 rounded-2xl border text-left transition-all cursor-pointer flex items-center justify-between ${
                activeSection === 'chat'
                  ? 'bg-cyan-950/40 border-cyan-400 text-cyan-300'
                  : 'bg-white/[0.03] border-white/10 text-white/80 hover:bg-white/[0.06] hover:text-white'
              }`}
            >
              <div className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400" />
                <span>Peer Chat</span>
              </div>
              <ArrowRight className="w-3.5 h-3.5 opacity-50" />
            </button>

            <button
              onClick={() => scrollTo('pulse')}
              className={`p-3 rounded-2xl border text-left transition-all cursor-pointer flex items-center justify-between ${
                activeSection === 'pulse'
                  ? 'bg-cyan-950/40 border-cyan-400 text-cyan-300'
                  : 'bg-white/[0.03] border-white/10 text-white/80 hover:bg-white/[0.06] hover:text-white'
              }`}
            >
              <span>Campus Pulse</span>
              <ArrowRight className="w-3.5 h-3.5 opacity-50" />
            </button>

            <button
              onClick={() => scrollTo('projects')}
              className={`p-3 rounded-2xl border text-left transition-all cursor-pointer flex items-center justify-between ${
                activeSection === 'projects'
                  ? 'bg-cyan-950/40 border-cyan-400 text-cyan-300'
                  : 'bg-white/[0.03] border-white/10 text-white/80 hover:bg-white/[0.06] hover:text-white'
              }`}
            >
              <span>Projects & Teams</span>
              <ArrowRight className="w-3.5 h-3.5 opacity-50" />
            </button>

            <button
              onClick={() => scrollTo('marketplace')}
              className={`p-3 rounded-2xl border text-left transition-all cursor-pointer flex items-center justify-between ${
                activeSection === 'marketplace'
                  ? 'bg-cyan-950/40 border-cyan-400 text-cyan-300'
                  : 'bg-white/[0.03] border-white/10 text-white/80 hover:bg-white/[0.06] hover:text-white'
              }`}
            >
              <span>Marketplace</span>
              <ArrowRight className="w-3.5 h-3.5 opacity-50" />
            </button>

            {onOpenPresentation && (
              <button
                onClick={() => {
                  setIsMobileMenuOpen(false);
                  onOpenPresentation();
                }}
                className="p-3 rounded-2xl border border-cyan-500/40 bg-cyan-950/30 text-cyan-300 hover:bg-cyan-900/40 text-left transition-all cursor-pointer flex items-center justify-between col-span-2 md:col-span-3"
              >
                <div className="flex items-center gap-2">
                  <Presentation className="w-4 h-4 text-cyan-400" />
                  <span className="font-bold">Launch Pitch Deck & Ecosystem Presentation</span>
                </div>
                <Play className="w-3.5 h-3.5 text-cyan-400" />
              </button>
            )}
          </div>

          {/* User Profile / Auth Action Card on Mobile */}
          <div className="pt-2 border-t border-white/10 flex items-center justify-between gap-3">
            {currentUser ? (
              <button
                onClick={() => {
                  setIsMobileMenuOpen(false);
                  onOpenAuth();
                }}
                className="flex-1 p-3 rounded-2xl bg-[#121420] border border-white/10 flex items-center justify-between text-left cursor-pointer"
              >
                <div className="flex items-center gap-3">
                  <img
                    src={currentUser.avatar}
                    alt={currentUser.name}
                    className="w-9 h-9 rounded-xl object-cover border border-[#00f2ff]/50"
                  />
                  <div>
                    <div className="text-xs font-bold text-white flex items-center gap-1.5">
                      <span>{currentUser.name}</span>
                      <ShieldCheck className="w-3.5 h-3.5 text-[#00f2ff]" />
                    </div>
                    <div className="text-[10px] font-mono-tech text-white/50">
                      Rank #{currentUser.rank} • {currentUser.impactScore} Karma
                    </div>
                  </div>
                </div>
                <span className="text-[10px] font-mono-tech text-[#00f2ff] uppercase font-bold">Switch</span>
              </button>
            ) : (
              <button
                onClick={() => {
                  setIsMobileMenuOpen(false);
                  onOpenAuth();
                }}
                className="w-full py-3 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-mono-tech text-center cursor-pointer"
              >
                Sign in with University ID
              </button>
            )}

            <button
              onClick={() => scrollTo('services')}
              className="sm:hidden px-5 py-3 rounded-2xl bg-[#00f2ff] hover:bg-[#38f6ff] text-black font-bold text-xs font-mono-tech shrink-0 cursor-pointer shadow-[0_0_20px_rgba(0,242,255,0.3)]"
            >
              Explore
            </button>
          </div>
        </div>
      )}
    </header>
  );
};


```

---

## File: `src/components/NotificationsModal.tsx`

```tsx
import React, { useState } from 'react';
import { 
  X, 
  Bell, 
  UserPlus, 
  Check, 
  Layers, 
  Rocket, 
  Heart, 
  RefreshCw, 
  MessageSquare, 
  ShieldCheck, 
  Clock, 
  CheckCircle2, 
  XCircle,
  ExternalLink,
  Sparkles,
  Lock,
  Globe
} from 'lucide-react';
import { CampusNotification, UserProfile } from '../types';

interface NotificationsModalProps {
  isOpen: boolean;
  onClose: () => void;
  notifications: CampusNotification[];
  currentUser?: UserProfile;
  users?: UserProfile[];
  onAcceptFriendRequest: (notificationId: string, senderId: string) => void;
  onDeclineRequest: (notificationId: string) => void;
  onApproveBorrowRequest: (notificationId: string) => void;
  onAcceptProjectInvite: (notificationId: string) => void;
  onAcceptSkillSwap: (notificationId: string) => void;
  onMarkAllAsRead: () => void;
  onOpenPassport?: (user: UserProfile) => void;
  onOpenDirectMessage?: (user: UserProfile) => void;
}

export const NotificationsModal: React.FC<NotificationsModalProps> = ({
  isOpen,
  onClose,
  notifications,
  currentUser,
  users = [],
  onAcceptFriendRequest,
  onDeclineRequest,
  onApproveBorrowRequest,
  onAcceptProjectInvite,
  onAcceptSkillSwap,
  onMarkAllAsRead,
  onOpenPassport,
  onOpenDirectMessage,
}) => {
  const [activeFilter, setActiveFilter] = useState<'all' | 'requests' | 'activity'>('all');

  if (!isOpen) return null;

  const unreadCount = notifications.filter((n) => !n.read).length;
  const requestsCount = notifications.filter((n) => 
    n.type === 'friend_request' || n.type === 'borrow_request' || n.type === 'project_invite' || n.type === 'skill_swap'
  ).length;

  const filteredNotifications = notifications.filter((n) => {
    if (activeFilter === 'requests') {
      return (
        n.type === 'friend_request' ||
        n.type === 'borrow_request' ||
        n.type === 'project_invite' ||
        n.type === 'skill_swap'
      );
    }
    if (activeFilter === 'activity') {
      return n.type === 'kudos' || n.type === 'marketplace_inquiry' || n.type === 'system';
    }
    return true;
  });

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'friend_request':
        return <UserPlus className="w-4 h-4 text-[#00f2ff]" />;
      case 'borrow_request':
        return <Layers className="w-4 h-4 text-emerald-400" />;
      case 'project_invite':
        return <Rocket className="w-4 h-4 text-[#c084fc]" />;
      case 'skill_swap':
        return <RefreshCw className="w-4 h-4 text-amber-400" />;
      case 'kudos':
        return <Heart className="w-4 h-4 text-pink-400" />;
      default:
        return <Bell className="w-4 h-4 text-cyan-400" />;
    }
  };

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 overflow-y-auto bg-black/85 backdrop-blur-xl animate-in fade-in duration-200"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div 
        id="notifications-modal-card"
        className="relative w-full max-w-2xl bg-[#0b0c14] border border-white/15 rounded-3xl shadow-[0_0_60px_rgba(0,242,255,0.15)] flex flex-col overflow-hidden text-white max-h-[90vh]"
      >
        {/* Glow accent */}
        <div className="absolute top-0 left-0 right-0 h-32 bg-gradient-to-b from-[#00f2ff]/20 via-[#c084fc]/10 to-transparent blur-2xl pointer-events-none" />

        {/* Modal Header */}
        <div className="p-4 sm:p-5 border-b border-white/[0.08] flex items-center justify-between relative z-10 bg-[#0e0f1a]/90 backdrop-blur-md">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-2xl bg-[#00f2ff]/10 border border-[#00f2ff]/30 flex items-center justify-center text-[#00f2ff]">
              <Bell className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base sm:text-lg font-bold text-white font-heading">
                  Campus Notifications & Requests
                </h3>
                {unreadCount > 0 && (
                  <span className="px-2 py-0.5 rounded-full bg-[#00f2ff] text-black text-[11px] font-mono-tech font-bold">
                    {unreadCount} new
                  </span>
                )}
              </div>
              <p className="text-xs text-white/50 font-mono-tech">
                Friend connections, hardware loans, and squad invitations
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {unreadCount > 0 && (
              <button
                onClick={onMarkAllAsRead}
                className="hidden sm:inline-flex px-3 py-1.5 rounded-xl bg-white/[0.06] hover:bg-white/10 text-xs text-white/80 hover:text-white font-mono-tech transition-colors cursor-pointer border border-white/10"
              >
                Mark all read
              </button>
            )}

            <button
              onClick={onClose}
              className="w-8 h-8 rounded-full bg-white/[0.06] hover:bg-white/[0.15] text-white/70 hover:text-white flex items-center justify-center transition-colors cursor-pointer border border-white/10"
              aria-label="Close notifications"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Filter Navigation Tabs */}
        <div className="px-4 sm:px-6 pt-3 pb-2 border-b border-white/[0.06] flex items-center justify-between gap-2 bg-[#0d0e17]">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveFilter('all')}
              className={`px-3 py-1.5 rounded-xl text-xs font-mono-tech transition-all cursor-pointer ${
                activeFilter === 'all'
                  ? 'bg-[#00f2ff]/20 text-[#00f2ff] border border-[#00f2ff]/40 font-bold'
                  : 'bg-white/[0.03] text-white/60 hover:text-white hover:bg-white/[0.08] border border-white/5'
              }`}
            >
              All ({notifications.length})
            </button>
            <button
              onClick={() => setActiveFilter('requests')}
              className={`px-3 py-1.5 rounded-xl text-xs font-mono-tech transition-all cursor-pointer flex items-center gap-1.5 ${
                activeFilter === 'requests'
                  ? 'bg-[#00f2ff]/20 text-[#00f2ff] border border-[#00f2ff]/40 font-bold'
                  : 'bg-white/[0.03] text-white/60 hover:text-white hover:bg-white/[0.08] border border-white/5'
              }`}
            >
              <UserPlus className="w-3.5 h-3.5" />
              <span>Requests ({requestsCount})</span>
            </button>
            <button
              onClick={() => setActiveFilter('activity')}
              className={`px-3 py-1.5 rounded-xl text-xs font-mono-tech transition-all cursor-pointer flex items-center gap-1.5 ${
                activeFilter === 'activity'
                  ? 'bg-[#00f2ff]/20 text-[#00f2ff] border border-[#00f2ff]/40 font-bold'
                  : 'bg-white/[0.03] text-white/60 hover:text-white hover:bg-white/[0.08] border border-white/5'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Activity</span>
            </button>
          </div>

          <div className="text-[11px] font-mono-tech text-white/40 hidden md:flex items-center gap-1">
            <span>Profile:</span>
            {currentUser?.isPrivate ? (
              <span className="text-amber-300 flex items-center gap-1">
                <Lock className="w-3 h-3" /> Private (Req Required)
              </span>
            ) : (
              <span className="text-emerald-400 flex items-center gap-1">
                <Globe className="w-3 h-3" /> Public (Open Chat)
              </span>
            )}
          </div>
        </div>

        {/* Notifications Feed List */}
        <div className="p-4 sm:p-6 space-y-3 overflow-y-auto max-h-[60vh] custom-scrollbar">
          {filteredNotifications.length === 0 ? (
            <div className="py-12 text-center text-white/40 font-mono-tech space-y-2">
              <Bell className="w-8 h-8 mx-auto text-white/20" />
              <p className="text-sm">No notifications in this category right now.</p>
              <p className="text-xs text-white/30">You're all caught up on your campus connections!</p>
            </div>
          ) : (
            filteredNotifications.map((notif) => {
              const isPending = notif.status === 'pending';
              const isAccepted = notif.status === 'accepted';
              const isDeclined = notif.status === 'declined';

              return (
                <div
                  key={notif.id}
                  className={`p-4 rounded-2xl border transition-all duration-200 relative ${
                    !notif.read
                      ? 'bg-[#131522] border-[#00f2ff]/30 shadow-[0_0_15px_rgba(0,242,255,0.06)]'
                      : 'bg-[#0f1019] border-white/[0.06] hover:border-white/15'
                  }`}
                >
                  {/* Unread indicator pip */}
                  {!notif.read && (
                    <span className="absolute top-4 right-4 w-2 h-2 rounded-full bg-[#00f2ff] shadow-[0_0_8px_#00f2ff]" />
                  )}

                  <div className="flex items-start gap-3.5">
                    {/* Sender Avatar or Icon */}
                    {notif.senderAvatar ? (
                      <div className="relative shrink-0">
                        <img
                          src={notif.senderAvatar}
                          alt={notif.senderName || 'Sender'}
                          className="w-11 h-11 rounded-xl object-cover border border-white/20"
                        />
                        <div className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-[#121420] border border-white/20 flex items-center justify-center">
                          {getNotificationIcon(notif.type)}
                        </div>
                      </div>
                    ) : (
                      <div className="w-11 h-11 rounded-xl bg-white/[0.08] border border-white/10 flex items-center justify-center shrink-0">
                        {getNotificationIcon(notif.type)}
                      </div>
                    )}

                    {/* Content Body */}
                    <div className="flex-1 min-w-0 pr-4">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h4 className="text-sm font-bold text-white font-heading">
                          {notif.title}
                        </h4>
                        <span className="text-[10px] font-mono-tech text-white/40 flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {notif.timestamp}
                        </span>
                      </div>

                      <p className="text-xs text-white/70 font-sans mt-1 leading-relaxed">
                        {notif.description}
                      </p>

                      {/* Additional Metadata / Tags */}
                      {notif.meta?.projectName && (
                        <div className="mt-2 inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-[#c084fc]/10 border border-[#c084fc]/30 text-[11px] font-mono-tech text-[#c084fc]">
                          <Rocket className="w-3 h-3" />
                          <span>Project: {notif.meta.projectName}</span>
                        </div>
                      )}

                      {notif.meta?.itemName && (
                        <div className="mt-2 inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-[11px] font-mono-tech text-emerald-300">
                          <Layers className="w-3 h-3" />
                          <span>Item: {notif.meta.itemName} ({notif.meta.daysRequested} Days)</span>
                        </div>
                      )}

                      {/* Action Buttons for Interactive Requests */}
                      {isPending && (
                        <div className="mt-3 flex items-center gap-2.5 flex-wrap">
                          {/* FRIEND REQUEST ACCEPT */}
                          {notif.type === 'friend_request' && (
                            <>
                              <button
                                onClick={() => notif.senderId && onAcceptFriendRequest(notif.id, notif.senderId)}
                                className="px-3.5 py-1.5 rounded-xl bg-[#00f2ff] hover:bg-[#38f6ff] text-black font-bold text-xs font-mono-tech flex items-center gap-1.5 transition-all cursor-pointer shadow-[0_0_12px_rgba(0,242,255,0.25)]"
                              >
                                <Check className="w-3.5 h-3.5" />
                                <span>Accept & Connect</span>
                              </button>

                              <button
                                onClick={() => onDeclineRequest(notif.id)}
                                className="px-3 py-1.5 rounded-xl bg-white/[0.06] hover:bg-white/15 text-white/70 hover:text-white text-xs font-mono-tech transition-colors cursor-pointer border border-white/10"
                              >
                                Decline
                              </button>

                              {notif.meta?.userProfile && (
                                <button
                                  onClick={() => onOpenPassport(notif.meta!.userProfile!)}
                                  className="px-2.5 py-1.5 rounded-xl bg-white/[0.03] hover:bg-white/[0.08] text-white/60 hover:text-[#00f2ff] text-xs font-mono-tech flex items-center gap-1 transition-colors cursor-pointer"
                                >
                                  <span>View Passport</span>
                                  <ExternalLink className="w-3 h-3" />
                                </button>
                              )}
                            </>
                          )}

                          {/* BORROW REQUEST APPROVE */}
                          {notif.type === 'borrow_request' && (
                            <>
                              <button
                                onClick={() => onApproveBorrowRequest(notif.id)}
                                className="px-3.5 py-1.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-black font-bold text-xs font-mono-tech flex items-center gap-1.5 transition-all cursor-pointer shadow-[0_0_12px_rgba(16,185,129,0.3)]"
                              >
                                <Check className="w-3.5 h-3.5" />
                                <span>Approve Loan (+10 Karma)</span>
                              </button>

                              <button
                                onClick={() => onDeclineRequest(notif.id)}
                                className="px-3 py-1.5 rounded-xl bg-white/[0.06] hover:bg-white/15 text-white/70 hover:text-white text-xs font-mono-tech transition-colors cursor-pointer border border-white/10"
                              >
                                Decline
                              </button>
                            </>
                          )}

                          {/* PROJECT INVITE / APPLICATION */}
                          {notif.type === 'project_invite' && (
                            <>
                              <button
                                onClick={() => onAcceptProjectInvite(notif.id)}
                                className="px-3.5 py-1.5 rounded-xl bg-[#c084fc] hover:bg-[#d8b4fe] text-black font-bold text-xs font-mono-tech flex items-center gap-1.5 transition-all cursor-pointer shadow-[0_0_12px_rgba(192,132,252,0.3)]"
                              >
                                <Check className="w-3.5 h-3.5" />
                                <span>Accept to Squad</span>
                              </button>

                              <button
                                onClick={() => onDeclineRequest(notif.id)}
                                className="px-3 py-1.5 rounded-xl bg-white/[0.06] hover:bg-white/15 text-white/70 hover:text-white text-xs font-mono-tech transition-colors cursor-pointer border border-white/10"
                              >
                                Decline
                              </button>
                            </>
                          )}

                          {/* SKILL SWAP MATCH */}
                          {notif.type === 'skill_swap' && (
                            <>
                              <button
                                onClick={() => onAcceptSkillSwap(notif.id)}
                                className="px-3.5 py-1.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-black font-bold text-xs font-mono-tech flex items-center gap-1.5 transition-all cursor-pointer"
                              >
                                <Check className="w-3.5 h-3.5" />
                                <span>Confirm Swap Session</span>
                              </button>

                              <button
                                onClick={() => onDeclineRequest(notif.id)}
                                className="px-3 py-1.5 rounded-xl bg-white/[0.06] hover:bg-white/15 text-white/70 hover:text-white text-xs font-mono-tech transition-colors cursor-pointer border border-white/10"
                              >
                                Decline
                              </button>
                            </>
                          )}
                        </div>
                      )}

                      {/* STATUS DISPLAY AFTER ACTION */}
                      {isAccepted && (
                        <div className="mt-2.5 flex items-center gap-3">
                          <span className="inline-flex items-center gap-1.5 text-xs font-mono-tech text-emerald-400 bg-emerald-500/10 px-2.5 py-1 rounded-lg border border-emerald-500/20">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>Request Accepted & Connected</span>
                          </span>

                          {notif.type === 'friend_request' && notif.meta?.userProfile && onOpenDirectMessage && (
                            <button
                              onClick={() => onOpenDirectMessage(notif.meta!.userProfile!)}
                              className="px-2.5 py-1 rounded-lg bg-[#00f2ff]/20 hover:bg-[#00f2ff]/30 text-[#00f2ff] text-xs font-mono-tech flex items-center gap-1 border border-[#00f2ff]/40 transition-colors cursor-pointer"
                            >
                              <MessageSquare className="w-3 h-3" />
                              <span>Message Friend</span>
                            </button>
                          )}
                        </div>
                      )}

                      {isDeclined && (
                        <div className="mt-2.5">
                          <span className="inline-flex items-center gap-1.5 text-xs font-mono-tech text-red-400/80 bg-red-500/10 px-2.5 py-1 rounded-lg border border-red-500/20">
                            <XCircle className="w-3.5 h-3.5" />
                            <span>Request Declined</span>
                          </span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 border-t border-white/[0.08] bg-[#0c0d16] flex items-center justify-between text-xs font-mono-tech text-white/50">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-[#00f2ff]" />
            <span>Zero-Knowledge Cryptographic Peer Audit</span>
          </div>

          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-medium transition-colors cursor-pointer"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};

```

---

## File: `src/components/PeerSquadsModal.tsx`

```tsx
import React, { useState } from 'react';
import { 
  X, 
  GitBranch, 
  Plus, 
  Users, 
  Sparkles, 
  ShieldCheck, 
  Check, 
  MessageSquare,
  ArrowRight,
  Zap
} from 'lucide-react';
import { UserProfile } from '../types';

interface PeerSquadsModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserProfile;
}

export const PeerSquadsModal: React.FC<PeerSquadsModalProps> = ({
  isOpen,
  onClose,
  currentUser,
}) => {
  const [squads, setSquads] = useState([
    {
      id: 'sq-1',
      name: 'hackathon-squad-ai',
      topic: 'Inter-College GenAI Hackathon 2026',
      members: [
        { name: 'Aarav Patel', role: 'Frontend Lead', avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80' },
        { name: 'Devansh Iyer', role: 'ML Engineer', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&auto=format&fit=crop&q=80' },
        { name: 'Priya M.', role: 'IoT Architect', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=120&auto=format&fit=crop&q=80' },
      ],
      lookingFor: ['Next.js / Rust Dev', 'UI/UX Designer'],
      status: 'Recruiting',
      activeSprint: 'Drafting architecture proposal',
      joined: false,
    },
    {
      id: 'sq-2',
      name: 'os-distributed-core',
      topic: 'Kernel & Distributed Storage Study Group',
      members: [
        { name: 'Ananya Rao', role: 'Lead TA', avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80' },
        { name: 'Yuvraj Sen', role: 'Peer Reviewer', avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=120&auto=format&fit=crop&q=80' },
      ],
      lookingFor: ['C / Go Programmer'],
      status: 'Active',
      activeSprint: 'Mock Mid-Sem Question Sprint',
      joined: false,
    },
    {
      id: 'sq-3',
      name: 'rover-firmware-crew',
      topic: 'Autonomous University Mars Rover 2026',
      members: [
        { name: 'Kabir Shah', role: 'Fabrication', avatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=120&auto=format&fit=crop&q=80' },
        { name: 'Rhea Nair', role: 'Physics Calc', avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=120&auto=format&fit=crop&q=80' },
      ],
      lookingFor: ['ROS 2 / STM32 Dev'],
      status: 'Recruiting',
      activeSprint: 'Telemetry Testing in Main Ground',
      joined: false,
    },
  ]);

  const [isCreating, setIsCreating] = useState(false);
  const [newSquadName, setNewSquadName] = useState('');
  const [newSquadTopic, setNewSquadTopic] = useState('');

  if (!isOpen) return null;

  const handleJoinSquad = (squadId: string) => {
    setSquads((prev) =>
      prev.map((s) => (s.id === squadId ? { ...s, joined: true } : s))
    );
  };

  const handleCreateSquad = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSquadName.trim()) return;

    const newSq = {
      id: `sq-${Date.now()}`,
      name: newSquadName.toLowerCase().replace(/\s+/g, '-'),
      topic: newSquadTopic || 'Campus Build Sprint',
      members: [
        { name: currentUser.name, role: 'Founder', avatar: currentUser.avatar },
      ],
      lookingFor: ['Open for all peers'],
      status: 'Recruiting',
      activeSprint: 'Sprint planning',
      joined: true,
    };

    setSquads([newSq, ...squads]);
    setIsCreating(false);
    setNewSquadName('');
    setNewSquadTopic('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 overflow-y-auto bg-black/85 backdrop-blur-xl animate-in fade-in duration-200">
      
      <div className="relative w-full max-w-3xl bg-[#0b0c12] border border-white/15 rounded-3xl shadow-[0_0_60px_rgba(0,242,255,0.15)] flex flex-col overflow-hidden text-white max-h-[90vh]">
        
        {/* Modal Header */}
        <div className="p-5 sm:p-6 border-b border-white/[0.08] flex items-center justify-between bg-[#0e0f18]">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl bg-[#00f2ff]/10 border border-[#00f2ff]/30 flex items-center justify-center text-[#00f2ff]">
              <GitBranch className="w-5 h-5" />
            </div>
            <div>
              <div className="text-[10px] font-mono-tech text-[#00f2ff] tracking-[2px] uppercase">
                PEER SQUAD ENGINE
              </div>
              <h3 className="text-xl font-bold text-white font-heading">
                Campus Hackathon & Study Squads
              </h3>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsCreating(!isCreating)}
              className="px-3.5 py-1.5 rounded-xl bg-[#00f2ff] text-black font-bold text-xs flex items-center gap-1.5 hover:bg-[#00f2ff]/90 transition-all cursor-pointer font-mono-tech"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Form Squad</span>
            </button>

            <button
              onClick={onClose}
              className="w-9 h-9 rounded-full bg-white/[0.05] hover:bg-white/[0.1] text-white/70 hover:text-white flex items-center justify-center transition-colors cursor-pointer border border-white/10"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Create Squad Form Drawer */}
        {isCreating && (
          <form onSubmit={handleCreateSquad} className="p-5 bg-[#12131e] border-b border-white/10 space-y-3">
            <div className="text-xs font-mono-tech text-[#00f2ff] uppercase font-bold">
              Form New Campus Peer Squad
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <input 
                type="text"
                placeholder="Squad handle (e.g. quantum-sim-dev)"
                value={newSquadName}
                onChange={(e) => setNewSquadName(e.target.value)}
                required
                className="px-3.5 py-2 rounded-xl bg-[#0a0a0f] border border-white/10 text-xs text-white placeholder:text-white/40 focus:outline-none focus:border-[#00f2ff]"
              />
              <input 
                type="text"
                placeholder="Topic / Hackathon Goal"
                value={newSquadTopic}
                onChange={(e) => setNewSquadTopic(e.target.value)}
                className="px-3.5 py-2 rounded-xl bg-[#0a0a0f] border border-white/10 text-xs text-white placeholder:text-white/40 focus:outline-none focus:border-[#00f2ff]"
              />
            </div>
            <div className="flex justify-end gap-2">
              <button 
                type="button" 
                onClick={() => setIsCreating(false)}
                className="px-3 py-1.5 rounded-lg text-xs text-white/60 hover:text-white"
              >
                Cancel
              </button>
              <button 
                type="submit"
                className="px-4 py-1.5 rounded-lg bg-[#00f2ff] text-black font-bold text-xs font-mono-tech"
              >
                Launch Squad (+30 Karma)
              </button>
            </div>
          </form>
        )}

        {/* Squads List */}
        <div className="p-6 space-y-4 overflow-y-auto custom-scrollbar flex-1">
          {squads.map((squad) => (
            <div 
              key={squad.id}
              className="p-5 rounded-2xl bg-[#12131c] border border-white/10 space-y-4 hover:border-white/20 transition-all"
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-[#00f2ff] animate-ping" />
                    <span className="font-mono-tech font-bold text-sm text-[#00f2ff]">
                      {squad.name}
                    </span>
                    <span className="text-[10px] font-mono-tech bg-white/10 text-white px-2 py-0.5 rounded-full">
                      {squad.status}
                    </span>
                  </div>
                  <h4 className="text-base font-bold text-white font-heading mt-1">
                    {squad.topic}
                  </h4>
                </div>

                <button
                  onClick={() => handleJoinSquad(squad.id)}
                  disabled={squad.joined}
                  className={`px-4 py-2 rounded-xl text-xs font-mono-tech font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                    squad.joined
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                      : 'bg-white/10 hover:bg-white/20 text-white border border-white/20 hover:border-[#00f2ff]'
                  }`}
                >
                  {squad.joined ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Joined Squad</span>
                    </>
                  ) : (
                    <>
                      <Zap className="w-3.5 h-3.5 text-[#00f2ff]" />
                      <span>Request to Join</span>
                    </>
                  )}
                </button>
              </div>

              {/* Members */}
              <div className="flex flex-wrap items-center gap-3 pt-2 border-t border-white/5">
                <div className="text-xs font-mono-tech text-white/50">Crew:</div>
                <div className="flex items-center gap-2">
                  {squad.members.map((m, idx) => (
                    <div key={idx} className="flex items-center gap-1.5 bg-[#090a0f] px-2.5 py-1 rounded-lg border border-white/5 text-xs">
                      <img src={m.avatar} alt={m.name} className="w-4 h-4 rounded-full object-cover" />
                      <span className="text-white font-medium">{m.name}</span>
                      <span className="text-[9px] text-[#00f2ff] font-mono-tech">({m.role})</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Looking for */}
              <div className="flex flex-wrap items-center gap-2 text-xs font-mono-tech">
                <span className="text-white/40">Looking for:</span>
                {squad.lookingFor.map((r, i) => (
                  <span key={i} className="px-2 py-0.5 rounded bg-purple-500/10 border border-purple-500/20 text-purple-300 text-[11px]">
                    {r}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>

      </div>
    </div>
  );
};

```

---

## File: `src/components/PresentationModal.tsx`

```tsx
import React, { useState, useEffect } from 'react';
import { 
  X, 
  ChevronLeft, 
  ChevronRight, 
  Maximize2, 
  Minimize2, 
  Sparkles, 
  ShieldCheck, 
  Layers, 
  Compass, 
  Share2, 
  Trophy, 
  Activity, 
  Cpu, 
  Users, 
  ArrowRight, 
  ExternalLink,
  CheckCircle2,
  Box,
  Play,
  Pause,
  Repeat
} from 'lucide-react';

interface PresentationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLaunchService?: (serviceId: string) => void;
}

export const PresentationModal: React.FC<PresentationModalProps> = ({
  isOpen,
  onClose,
  onLaunchService
}) => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isAutoplay, setIsAutoplay] = useState(false);

  const slides = [
    {
      id: 'vision',
      badge: 'VISION & MANIFESTO',
      title: 'ON CAMPUS',
      subtitle: 'Everything your campus has. Connected.',
      tagline: 'A unified digital ecosystem connecting students with campus resources, skills, knowledge, projects, communities and opportunities.',
      highlights: [
        { label: 'Campus Connected', desc: 'Transform isolated dorms and faculties into an active, collaborative network.' },
        { label: 'Peer-to-Peer First', desc: 'Empower students to share hardware, mentor juniors, and build high-impact projects.' },
        { label: 'ZK Student Identity', desc: 'Privacy-preserving cryptographic student verification and skill attestation.' }
      ]
    },
    {
      id: 'problem',
      badge: 'THE PROBLEM & OPPORTUNITY',
      title: 'The Fragmented Campus Paradox',
      subtitle: 'Why thousands of students on the same campus remain disconnected.',
      points: [
        { icon: '📦', title: 'Idle Physical Resources', desc: 'Laptops, lab kits, books, and graphing calculators gather dust in hostel rooms while other students struggle to buy them.' },
        { icon: '🧠', title: 'Lost Senior Wisdom', desc: 'Crucial advice on courses, electives, and professors gets lost every graduation cycle without structured archival.' },
        { icon: '🔍', title: 'Siloed Talent & Projects', desc: 'Founders cannot find developers; designers cannot find teammates; clubs struggle with recruitment across batches.' },
        { icon: '⚠️', title: 'Spammy Chat Groups', desc: 'Vital announcements, lost-and-found items, and peer requests get buried under endless unmoderated messaging groups.' }
      ]
    },
    {
      id: 'core-services',
      badge: 'CORE 6 PILLARS',
      title: 'The Six Core Services',
      subtitle: 'Engineered for seamless campus life, collaboration, and mutual growth.',
      services: [
        { id: 'borrow', icon: '🛠️', title: 'Borrow', desc: 'Borrow lab tools, cameras, notes & hardware with verified escrow security.', action: 'Launch Borrowing' },
        { id: 'guidance', icon: '🧭', title: 'Guidance', desc: '1-on-1 senior mentorship, course insights, professor prep, and exam strategies.', action: 'Explore Mentorship' },
        { id: 'skills', icon: '🤝', title: 'Skill Exchange', desc: 'Swap skills: teach Python in exchange for UI/UX design or guitar tutoring.', action: 'Open Skill Swaps' },
        { id: 'marketplace', icon: '🛒', Marketplace: 'Marketplace', desc: 'Zero-commission student commerce for textbooks, electronics, and hostel essentials.', action: 'Browse Market' },
        { id: 'impact', icon: '🌟', title: 'Impact & Leaderboard', desc: 'Gamified campus contributions, karma rankings, and top-tier student badges.', action: 'View Rankings' },
        { id: 'compass', icon: '🧭', title: 'COMPASS AI', desc: 'Intelligent natural-language agent that routes you across the campus ecosystem.', action: 'Ask COMPASS' }
      ]
    },
    {
      id: 'innovations',
      badge: 'DEEP TECH INNOVATIONS',
      title: 'Key Platform Innovations',
      subtitle: 'Modern architectural primitives built for next-generation universities.',
      features: [
        {
          title: '3D Campus Digital Twin',
          desc: 'Interactive WebGL/Three.js spatial map with live building occupancy, lab statuses, and hostel activity zones.',
          tag: 'Three.js / WebGL',
          color: 'from-cyan-500/20 to-blue-500/20'
        },
        {
          title: 'Zero-Knowledge Student Passport',
          desc: 'Cryptographically attest student status, GPA thresholds, and verified skills without leaking private data.',
          tag: 'ZK Attestation',
          color: 'from-purple-500/20 to-pink-500/20'
        },
        {
          title: 'Campus Pulse Realtime Feed',
          desc: 'High-velocity campus updates, hackathon calls, lost-and-found alerts, and peer squads with live voting.',
          tag: 'Realtime SSE',
          color: 'from-amber-500/20 to-orange-500/20'
        },
        {
          title: 'Student Project Incubator',
          desc: 'Recruit co-founders, post open roles, share prototypes, and accumulate campus-wide backing.',
          tag: 'Ecosystem Engine',
          color: 'from-emerald-500/20 to-teal-500/20'
        }
      ]
    },
    {
      id: 'tech-stack',
      badge: 'ARCHITECTURE & STACK',
      title: 'Built with Modern Web Standards',
      subtitle: 'Production-ready, highly responsive full-stack TypeScript stack.',
      stack: [
        { category: 'Frontend Framework', tech: 'React 18 + Next.js Architectural Primitives', desc: 'Component modularity, optimized lifecycle hooks, client-side caching' },
        { category: 'Type Safety & Speed', tech: 'TypeScript + Strict Mode', desc: '100% end-to-end typed schemas, zero any-leakage, robust interfaces' },
        { category: 'Visual & 3D Engine', tech: 'Tailwind CSS + Three.js / WebGL', desc: 'Custom cyberpunk-glass aesthetic, responsive mobile-first typography' },
        { category: 'Server & API Proxy', tech: 'Express Node.js + Safe Proxy Endpoints', desc: 'Zero API keys exposed in browser, secure REST & event streams' }
      ]
    },
    {
      id: 'live-demo',
      badge: 'LIVE INTERACTIVE DEMO',
      title: 'Experience ON CAMPUS Now',
      subtitle: 'Jump directly into any module to test the live capabilities.',
      actions: [
        { label: '🏛️ Explore 3D Campus Twin', id: 'campus3d', desc: 'Navigate the interactive 3D map' },
        { label: '🛠️ Test Borrowing System', id: 'borrow', desc: 'Simulate peer hardware lending' },
        { label: '💬 Launch Campus Live Chat', id: 'chat', desc: 'Connect with active peers in real-time' },
        { label: '🚀 View Student Projects', id: 'projects', desc: 'Browse research & hackathon teams' },
        { label: '🏆 Open Impact Leaderboard', id: 'leaderboard', desc: 'See top campus contributors' },
        { label: '🧭 Chat with COMPASS AI', id: 'compass', desc: 'Ask campus navigation queries' }
      ]
    }
  ];

  // Keyboard navigation
  useEffect(() => {
    if (!isOpen) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowRight' || e.key === ' ' || e.key === 'PageDown') {
        e.preventDefault();
        setCurrentSlide(prev => Math.min(prev + 1, slides.length - 1));
      } else if (e.key === 'ArrowLeft' || e.key === 'PageUp') {
        e.preventDefault();
        setCurrentSlide(prev => Math.max(prev - 1, 0));
      } else if (e.key === 'Escape') {
        onClose();
      } else if (e.key.toLowerCase() === 'f') {
        setIsFullscreen(prev => !prev);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, slides.length, onClose]);

  // Autoplay timer
  useEffect(() => {
    if (!isOpen || !isAutoplay) return;

    const timer = setInterval(() => {
      setCurrentSlide(prev => (prev + 1) % slides.length);
    }, 7000);

    return () => clearInterval(timer);
  }, [isOpen, isAutoplay, slides.length]);

  if (!isOpen) return null;

  const current = slides[currentSlide];

  return (
    <div className={`fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-6 bg-black/90 backdrop-blur-2xl animate-fadeIn ${isFullscreen ? 'p-0' : ''}`}>
      <div 
        id="presentation-deck-card"
        className={`relative w-full ${isFullscreen ? 'h-full max-w-none rounded-none' : 'max-w-5xl h-[88vh] rounded-3xl'} bg-gradient-to-b from-[#0a0f1d] via-[#070b14] to-[#04070d] border border-cyan-500/30 overflow-hidden shadow-[0_0_80px_rgba(0,242,255,0.2)] flex flex-col`}
      >
        {/* Top Presentation Bar */}
        <div className="px-6 py-4 border-b border-white/10 flex items-center justify-between bg-white/[0.02] shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-cyan-400 to-blue-600 p-0.5 shadow-[0_0_15px_rgba(0,242,255,0.4)]">
              <div className="w-full h-full bg-[#080c16] rounded-[6px] flex items-center justify-center">
                <Sparkles className="w-4 h-4 text-cyan-400" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-sm tracking-tight text-white">ON CAMPUS</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 font-mono-tech">
                  ECOSYSTEM PITCH DECK
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Autoplay Toggle */}
            <button
              onClick={() => setIsAutoplay(!isAutoplay)}
              className={`p-2 rounded-xl border text-xs flex items-center gap-1.5 transition-all cursor-pointer ${
                isAutoplay 
                  ? 'bg-cyan-500/20 border-cyan-500/50 text-cyan-300' 
                  : 'bg-white/5 border-white/10 hover:bg-white/10 text-white/70 hover:text-white'
              }`}
              title={isAutoplay ? 'Pause auto-slides' : 'Start auto-slides'}
            >
              {isAutoplay ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
              <span className="hidden sm:inline font-mono-tech text-[11px]">{isAutoplay ? 'Autoplay ON' : 'Autoplay'}</span>
            </button>

            {/* Fullscreen Toggle */}
            <button
              onClick={() => setIsFullscreen(!isFullscreen)}
              className="p-2 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 text-white/70 hover:text-white transition-all cursor-pointer"
              title={isFullscreen ? 'Exit full screen (F)' : 'Full screen (F)'}
            >
              {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
            </button>

            {/* Close */}
            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 text-white/70 hover:text-white transition-all cursor-pointer"
              title="Close presentation (Esc)"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Presentation Slide Stage */}
        <div className="flex-1 p-6 sm:p-10 md:p-12 overflow-y-auto flex flex-col justify-center relative">
          {/* Background Atmospheric Glow */}
          <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />

          <div className="relative z-10 max-w-4xl mx-auto w-full">
            {/* Slide Category Badge */}
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 text-xs font-mono-tech uppercase tracking-widest mb-4">
              <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-ping" />
              {current.badge}
            </div>

            {/* Slide Title */}
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-extrabold tracking-tight text-white mb-2">
              {current.title}
            </h2>
            <p className="text-base sm:text-xl text-cyan-300/90 font-medium mb-6">
              {current.subtitle}
            </p>

            {/* SLIDE 1: VISION */}
            {current.id === 'vision' && (
              <div className="space-y-6">
                <p className="text-base sm:text-lg text-white/80 leading-relaxed max-w-3xl bg-white/[0.03] p-5 rounded-2xl border border-white/10">
                  {current.tagline}
                </p>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
                  {current.highlights?.map((h, i) => (
                    <div key={i} className="p-5 rounded-2xl bg-gradient-to-b from-white/[0.05] to-white/[0.01] border border-white/10 hover:border-cyan-500/40 transition-all">
                      <div className="text-cyan-400 font-bold text-base mb-1.5 flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0" />
                        {h.label}
                      </div>
                      <p className="text-xs sm:text-sm text-white/70 leading-relaxed">{h.desc}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* SLIDE 2: THE PROBLEM */}
            {current.id === 'problem' && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {current.points?.map((pt, i) => (
                  <div key={i} className="p-5 rounded-2xl bg-white/[0.03] border border-white/10 hover:border-rose-500/30 transition-all flex gap-4">
                    <span className="text-3xl p-2 rounded-xl bg-white/5 h-fit">{pt.icon}</span>
                    <div>
                      <h4 className="text-base font-bold text-white mb-1">{pt.title}</h4>
                      <p className="text-xs sm:text-sm text-white/70 leading-relaxed">{pt.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* SLIDE 3: 6 CORE SERVICES */}
            {current.id === 'core-services' && (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
                {current.services?.map((s, i) => (
                  <div key={i} className="p-4 rounded-2xl bg-white/[0.03] border border-white/10 hover:border-cyan-500/40 hover:bg-white/[0.06] transition-all flex flex-col justify-between group">
                    <div>
                      <div className="flex items-center gap-2.5 mb-2">
                        <span className="text-xl">{s.icon}</span>
                        <h4 className="text-base font-bold text-white group-hover:text-cyan-300 transition-colors">{s.title}</h4>
                      </div>
                      <p className="text-xs text-white/70 leading-relaxed mb-3">{s.desc}</p>
                    </div>
                    {onLaunchService && (
                      <button
                        onClick={() => {
                          onClose();
                          onLaunchService(s.id);
                        }}
                        className="text-[11px] font-mono-tech text-cyan-400 hover:text-cyan-300 flex items-center gap-1 mt-1 cursor-pointer"
                      >
                        <span>{s.action}</span>
                        <ArrowRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
                      </button>
                    )}
                  </div>
                ))}
              </div>
            )}

            {/* SLIDE 4: INNOVATIONS */}
            {current.id === 'innovations' && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {current.features?.map((f, i) => (
                  <div key={i} className={`p-5 rounded-2xl bg-gradient-to-br ${f.color} border border-white/15 backdrop-blur-sm space-y-2`}>
                    <div className="flex items-center justify-between">
                      <h4 className="text-base sm:text-lg font-bold text-white">{f.title}</h4>
                      <span className="px-2.5 py-0.5 rounded-full bg-white/10 text-[10px] font-mono-tech text-white/80 border border-white/15">
                        {f.tag}
                      </span>
                    </div>
                    <p className="text-xs sm:text-sm text-white/80 leading-relaxed">{f.desc}</p>
                  </div>
                ))}
              </div>
            )}

            {/* SLIDE 5: TECH STACK */}
            {current.id === 'tech-stack' && (
              <div className="space-y-3">
                {current.stack?.map((st, i) => (
                  <div key={i} className="p-4 rounded-xl bg-white/[0.03] border border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div className="space-y-0.5">
                      <span className="text-[10px] font-mono-tech text-cyan-400 uppercase">{st.category}</span>
                      <h4 className="text-sm font-bold text-white">{st.tech}</h4>
                    </div>
                    <p className="text-xs text-white/60 sm:text-right max-w-sm">{st.desc}</p>
                  </div>
                ))}
              </div>
            )}

            {/* SLIDE 6: LIVE DEMO LAUNCHER */}
            {current.id === 'live-demo' && (
              <div className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                  {current.actions?.map((act, i) => (
                    <button
                      key={i}
                      onClick={() => {
                        onClose();
                        if (onLaunchService) onLaunchService(act.id);
                      }}
                      className="p-4 text-left rounded-2xl bg-white/[0.04] border border-cyan-500/20 hover:border-cyan-400 hover:bg-cyan-500/10 transition-all cursor-pointer group"
                    >
                      <div className="font-bold text-sm text-white group-hover:text-cyan-300 flex items-center justify-between">
                        <span>{act.label}</span>
                        <ExternalLink className="w-3.5 h-3.5 text-cyan-400 opacity-0 group-hover:opacity-100 transition-opacity" />
                      </div>
                      <p className="text-xs text-white/60 mt-1">{act.desc}</p>
                    </button>
                  ))}
                </div>
                <div className="p-4 rounded-2xl bg-cyan-500/5 border border-cyan-500/20 text-center">
                  <span className="text-xs font-mono-tech text-cyan-300">
                    💡 Press <kbd className="px-1.5 py-0.5 bg-white/10 rounded text-[10px]">⌘K</kbd> anywhere in the application to access instant command search.
                  </span>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Bottom Slide Controller */}
        <div className="px-6 py-4 border-t border-white/10 bg-white/[0.02] flex items-center justify-between shrink-0">
          {/* Slide Dots / Selector */}
          <div className="flex items-center gap-1.5">
            {slides.map((s, idx) => (
              <button
                key={idx}
                onClick={() => setCurrentSlide(idx)}
                className={`h-2 rounded-full transition-all cursor-pointer ${
                  currentSlide === idx 
                    ? 'w-8 bg-cyan-400 shadow-[0_0_10px_rgba(0,242,255,0.6)]' 
                    : 'w-2 bg-white/20 hover:bg-white/40'
                }`}
                title={`Go to slide ${idx + 1}: ${s.title}`}
              />
            ))}
          </div>

          {/* Slide Numbers & Prev/Next buttons */}
          <div className="flex items-center gap-3">
            <span className="text-xs font-mono-tech text-white/50">
              Slide {currentSlide + 1} of {slides.length}
            </span>

            <div className="flex items-center gap-1">
              <button
                onClick={() => setCurrentSlide(prev => Math.max(prev - 1, 0))}
                disabled={currentSlide === 0}
                className="p-2 rounded-xl bg-white/5 hover:bg-white/10 disabled:opacity-30 disabled:cursor-not-allowed text-white transition-all cursor-pointer"
                title="Previous Slide (Left Arrow)"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                onClick={() => setCurrentSlide(prev => Math.min(prev + 1, slides.length - 1))}
                disabled={currentSlide === slides.length - 1}
                className="p-2 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-500/30 disabled:opacity-30 disabled:cursor-not-allowed transition-all cursor-pointer"
                title="Next Slide (Right Arrow or Space)"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

```

---

## File: `src/components/ProjectDetailModal.tsx`

```tsx
import React, { useState } from 'react';
import { ProjectItem } from '../types';
import { ShareData } from './ShareModal';
import { 
  X, 
  Users, 
  Heart, 
  Sparkles, 
  ArrowUpRight, 
  CheckCircle, 
  Send, 
  Radio, 
  Layers,
  Share2,
  Check
} from 'lucide-react';

interface ProjectDetailModalProps {
  project: ProjectItem | null;
  onClose: () => void;
  onJoinProject: (projectId: string) => void;
  onToggleFollow: (projectId: string) => void;
  onPostUpdate: (projectId: string, updateText: string) => void;
  onOpenShare?: (data: ShareData) => void;
}

export const ProjectDetailModal: React.FC<ProjectDetailModalProps> = ({
  project,
  onClose,
  onJoinProject,
  onToggleFollow,
  onPostUpdate,
  onOpenShare,
}) => {
  const [updateInput, setUpdateInput] = useState('');
  const [justApplied, setJustApplied] = useState(false);
  const [copied, setCopied] = useState(false);

  if (!project) return null;

  const handleShare = () => {
    const projectUrl = `${window.location.origin}/projects/${project.id}`;
    const rolesText = (project.openRoles || []).join(', ');
    const sharePayload: ShareData = {
      title: `${project.name} — ${project.tagline}`,
      text: `${project.description} Lead: ${project.leadName} (${project.department}).${rolesText ? ` Recruiting: ${rolesText}` : ''}`,
      url: projectUrl,
      category: project.category,
    };

    if (onOpenShare) {
      onOpenShare(sharePayload);
    } else if (navigator.share) {
      navigator.share({
        title: sharePayload.title,
        text: sharePayload.text,
        url: sharePayload.url,
      }).catch(() => {});
    } else {
      navigator.clipboard?.writeText(projectUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleApply = () => {
    onJoinProject(project.id);
    setJustApplied(true);
    setTimeout(() => setJustApplied(false), 2500);
  };

  const handleSendUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!updateInput.trim()) return;
    onPostUpdate(project.id, updateInput.trim());
    setUpdateInput('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
      <div className="relative w-full max-w-3xl bg-[#090C12] border border-violet-400/40 rounded-2xl p-6 sm:p-8 max-h-[90vh] overflow-y-auto shadow-2xl">
        {/* Top Controls */}
        <div className="absolute top-5 right-5 flex items-center gap-2">
          <button
            onClick={handleShare}
            className="p-2 rounded-lg bg-zinc-900 border border-white/10 text-zinc-300 hover:text-[#00f2ff] hover:border-[#00f2ff]/40 transition-all cursor-pointer flex items-center gap-1.5 text-xs font-mono-tech"
            title="Share Project"
          >
            {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Share2 className="w-4 h-4" />}
            <span className="hidden sm:inline">{copied ? 'Copied' : 'Share'}</span>
          </button>

          <button
            onClick={onClose}
            className="p-2 rounded-lg bg-zinc-900 border border-white/10 text-zinc-400 hover:text-white transition-colors cursor-pointer"
            title="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-6">
          {/* Header */}
          <div>
            <div className="flex items-center justify-between gap-3 text-xs font-mono-tech mb-2">
              <span className="text-zinc-400 tracking-wider">
                {project.category}
              </span>
              {project.recruiting ? (
                <span className="px-2.5 py-0.5 rounded-full bg-emerald-950/80 border border-emerald-400/40 text-emerald-300 font-semibold">
                  ● RECRUITING MEMBERS
                </span>
              ) : (
                <span className="px-2.5 py-0.5 rounded-full bg-zinc-900 border border-white/10 text-zinc-400">
                  CORE TEAM ASSEMBLED
                </span>
              )}
            </div>

            <h2 className="text-3xl font-bold text-white font-heading">
              {project.name}
            </h2>
            <p className="text-sm text-cyan-300 font-mono-tech mt-1">
              {project.tagline}
            </p>
          </div>

          {/* Metrics bar */}
          <div className="grid grid-cols-3 gap-3 p-4 rounded-xl bg-zinc-950/80 border border-white/[0.06] text-center font-mono-tech">
            <div>
              <div className="text-xl font-bold text-white font-heading">
                {project.membersCount}
              </div>
              <div className="text-[10px] text-zinc-400">Active Members</div>
            </div>
            <div>
              <div className="text-xl font-bold text-cyan-400 font-heading">
                {project.followersCount}
              </div>
              <div className="text-[10px] text-zinc-400">Followers</div>
            </div>
            <div>
              <div className="text-xl font-bold text-violet-400 font-heading">
                {project.progressPercent}%
              </div>
              <div className="text-[10px] text-zinc-400">Milestone Progress</div>
            </div>
          </div>

          {/* Description */}
          <div className="p-4 rounded-xl bg-zinc-950/60 border border-white/[0.06] space-y-2">
            <div className="text-xs font-mono-tech text-zinc-400 uppercase">
              ABOUT THE BUILD
            </div>
            <p className="text-sm text-zinc-300 leading-relaxed">
              {project.description}
            </p>
          </div>

          {/* Skills Required */}
          <div>
            <div className="text-xs font-mono-tech text-zinc-400 uppercase mb-2">
              LOOKING FOR SKILLS IN:
            </div>
            <div className="flex flex-wrap gap-2">
              {project.skillsRequired.map((skill) => (
                <span
                  key={skill}
                  className="px-3 py-1 rounded bg-zinc-900 border border-cyan-400/30 text-xs font-mono-tech text-cyan-300"
                >
                  {skill}
                </span>
              ))}
            </div>
          </div>

          {/* Recent Updates Stream */}
          <div className="p-4 rounded-xl bg-zinc-950/90 border border-white/[0.08] space-y-3">
            <div className="flex items-center justify-between text-xs font-mono-tech text-zinc-300">
              <div className="flex items-center gap-1.5 text-violet-300">
                <Radio className="w-3.5 h-3.5 animate-pulse" />
                <span>LATEST PROJECT LOG</span>
              </div>
              <span className="text-[10px] text-zinc-400">
                {project.updatesCount} Updates Logged
              </span>
            </div>

            <p className="text-xs text-zinc-300 bg-zinc-900/60 p-3 rounded border border-white/5 font-mono-tech leading-relaxed">
              {project.recentUpdate || 'Initial prototype architecture committed to repository.'}
            </p>

            {/* Post update form */}
            <form onSubmit={handleSendUpdate} className="flex gap-2 pt-2">
              <input
                type="text"
                value={updateInput}
                onChange={(e) => setUpdateInput(e.target.value)}
                placeholder="Post a new sprint update or changelog..."
                className="flex-1 px-3 py-1.5 bg-zinc-900 border border-white/10 rounded text-xs text-white focus:outline-none focus:border-violet-400 font-mono-tech"
              />
              <button
                type="submit"
                className="px-3 py-1.5 bg-violet-600 hover:bg-violet-500 text-white font-semibold rounded text-xs font-mono-tech cursor-pointer"
              >
                LOG UPDATE
              </button>
            </form>
          </div>

          {/* Actions */}
          <div className="pt-2 flex flex-wrap items-center justify-between gap-4">
            <button
              onClick={() => onToggleFollow(project.id)}
              className={`px-4 py-2.5 rounded text-xs font-mono-tech tracking-wider flex items-center gap-2 transition-all cursor-pointer ${
                project.isFollowing
                  ? 'bg-rose-950/80 border border-rose-500/40 text-rose-300'
                  : 'bg-zinc-900 hover:bg-zinc-800 border border-white/10 text-white'
              }`}
            >
              <Heart className={`w-3.5 h-3.5 ${project.isFollowing ? 'fill-rose-500' : ''}`} />
              <span>{project.isFollowing ? 'FOLLOWING' : 'FOLLOW PROJECT'}</span>
            </button>

            {project.recruiting && (
              <button
                onClick={handleApply}
                disabled={project.hasApplied || justApplied}
                className={`px-6 py-2.5 text-xs font-mono-tech tracking-wider uppercase font-bold rounded transition-all cursor-pointer shadow-lg ${
                  project.hasApplied || justApplied
                    ? 'bg-emerald-950 border border-emerald-400/60 text-emerald-300'
                    : 'bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 text-white'
                }`}
              >
                {project.hasApplied || justApplied ? 'APPLICATION SUBMITTED ✓' : 'REQUEST TO JOIN TEAM'}
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

```

---

## File: `src/components/ProjectsSection.tsx`

```tsx
import React from 'react';
import { ProjectItem } from '../types';
import { 
  ArrowUpRight, 
  Users, 
  Heart, 
  Plus, 
  Layers3
} from 'lucide-react';

interface ProjectsSectionProps {
  projects: ProjectItem[];
  onSelectProject: (project: ProjectItem) => void;
  onOpenCreateProject: () => void;
  onToggleFollow: (projectId: string) => void;
  onJoinProject: (projectId: string) => void;
}

export const ProjectsSection: React.FC<ProjectsSectionProps> = ({
  projects,
  onSelectProject,
  onOpenCreateProject,
  onToggleFollow,
  onJoinProject,
}) => {
  return (
    <section id="projects" className="py-28 border-b border-white/[0.08] relative bg-[#050505]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div>
            <div className="inline-flex items-center gap-2 text-xs font-mono tracking-[3px] text-[#818cf8] font-bold uppercase mb-2">
              <Layers3 className="w-3.5 h-3.5 text-[#818cf8]" />
              <span>COLLABORATIONS & RESEARCH</span>
            </div>
            <h2 className="text-3xl sm:text-5xl lg:text-6xl font-bold text-white tracking-tight font-heading max-w-2xl leading-[1.12]">
              Don't just study what's being built.{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#818cf8] via-[#c084fc] to-[#00f2ff]">
                Help build what's next.
              </span>
            </h2>
            <p className="text-white/60 mt-3 text-base sm:text-lg max-w-xl font-normal">
              Join active campus teams or recruit peers for your breakthrough ideas.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              id="create-project-btn"
              onClick={onOpenCreateProject}
              className="inline-flex items-center gap-2 px-6 py-3 bg-[#c084fc] hover:bg-[#a855f7] text-black font-semibold text-xs sm:text-sm rounded-full transition-all cursor-pointer shadow-[0_0_20px_rgba(192,132,252,0.3)] hover:scale-[1.02] active:scale-[0.98]"
            >
              <Plus className="w-4 h-4" />
              <span>Start a Project</span>
            </button>
          </div>
        </div>

        {/* Horizontal Project Showcase Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {projects.map((project) => (
            <div
              key={project.id}
              id={`project-card-${project.id}`}
              className="group relative rounded-2xl bg-[#0c0d12] border border-white/[0.08] hover:border-white/20 transition-all duration-300 hover:-translate-y-1.5 flex flex-col justify-between p-6 overflow-hidden shadow-xl"
            >
              {/* Glowing Ambient Top */}
              <div 
                className="absolute top-0 right-0 w-32 h-32 rounded-full blur-3xl opacity-10 pointer-events-none transition-opacity group-hover:opacity-20"
                style={{ backgroundColor: '#c084fc' }}
              />

              <div>
                {/* Status & Category */}
                <div className="flex items-center justify-between gap-2 pb-4 mb-4 border-b border-white/[0.06]">
                  <span className="text-[10px] font-mono-tech text-white/50 tracking-[1px] uppercase">
                    {project.category}
                  </span>
                  {project.recruiting ? (
                    <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-[#00f2ff]/10 border border-[#00f2ff]/30 text-[9px] font-mono-tech text-[#00f2ff] font-bold">
                      <span className="w-1.5 h-1.5 rounded-full bg-[#00f2ff] animate-ping" />
                      RECRUITING
                    </span>
                  ) : (
                    <span className="px-2.5 py-0.5 rounded-full bg-[#050505] border border-white/10 text-[9px] font-mono-tech text-white/40">
                      ACTIVE TEAM
                    </span>
                  )}
                </div>

                {/* Project Title & Tagline */}
                <h3 
                  onClick={() => onSelectProject(project)}
                  className="text-lg font-bold text-white group-hover:text-[#c084fc] transition-colors font-heading mb-2 cursor-pointer leading-snug"
                >
                  {project.name}
                </h3>
                <p className="text-xs text-white/60 leading-relaxed line-clamp-3 mb-4 font-normal">
                  {project.tagline}
                </p>

                {/* Skills Required Tags */}
                <div className="flex flex-wrap gap-1.5 my-3">
                  {project.skillsRequired.slice(0, 3).map((skill) => (
                    <span
                      key={skill}
                      className="px-2.5 py-1 rounded-full bg-[#050505] border border-white/[0.08] text-[10px] font-mono-tech text-white/70"
                    >
                      {skill}
                    </span>
                  ))}
                  {project.skillsRequired.length > 3 && (
                    <span className="px-2 py-1 rounded-full bg-[#050505] text-[10px] font-mono-tech text-white/40">
                      +{project.skillsRequired.length - 3}
                    </span>
                  )}
                </div>
              </div>

              {/* Progress & Actions Footer */}
              <div className="mt-6 pt-4 border-t border-white/[0.06] space-y-4">
                {/* Progress bar */}
                <div>
                  <div className="flex justify-between text-[10px] font-mono-tech text-white/50 mb-1.5">
                    <span>BUILD PROGRESS</span>
                    <span className="text-white font-bold">{project.progressPercent}%</span>
                  </div>
                  <div className="w-full h-1.5 bg-[#050505] rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-[#c084fc] to-[#00f2ff] rounded-full"
                      style={{ width: `${project.progressPercent}%` }}
                    />
                  </div>
                </div>

                {/* Metrics & CTA Buttons */}
                <div className="flex items-center justify-between pt-1">
                  <div className="flex items-center gap-3 text-xs font-mono-tech text-white/50">
                    <span className="flex items-center gap-1">
                      <Users className="w-3.5 h-3.5 text-white/40" />
                      {project.membersCount}
                    </span>
                    <span className="flex items-center gap-1">
                      <Heart 
                        className={`w-3.5 h-3.5 cursor-pointer transition-colors ${
                          project.isFollowing ? 'fill-[#c084fc] text-[#c084fc]' : 'text-white/40 hover:text-[#c084fc]'
                        }`}
                        onClick={() => onToggleFollow(project.id)}
                      />
                      {project.followersCount}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    {project.recruiting && (
                      <button
                        onClick={() => onJoinProject(project.id)}
                        disabled={project.hasApplied}
                        className={`px-3.5 py-1.5 text-xs font-mono-tech rounded-full transition-all cursor-pointer font-semibold ${
                          project.hasApplied
                            ? 'bg-[#00f2ff]/10 border border-[#00f2ff]/40 text-[#00f2ff]'
                            : 'bg-white hover:bg-zinc-200 text-black'
                        }`}
                      >
                        {project.hasApplied ? 'Applied' : 'Join'}
                      </button>
                    )}

                    <button
                      onClick={() => onSelectProject(project)}
                      className="p-2 rounded-full bg-[#050505] hover:bg-white/[0.08] text-[#00f2ff] border border-white/10 hover:border-[#00f2ff] transition-all cursor-pointer"
                      title="View Project Details"
                    >
                      <ArrowUpRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

```

---

## File: `src/components/ServicesSection.tsx`

```tsx
import React, { useState, useMemo } from 'react';
import { 
  BookOpen, 
  GraduationCap, 
  ArrowLeftRight, 
  ShoppingBag, 
  Users, 
  ArrowUpRight, 
  Sparkles, 
  Search, 
  X, 
  Filter, 
  CheckCircle2, 
  MapPin, 
  Clock, 
  Tag, 
  ArrowRight, 
  Layers3, 
  Zap,
  SlidersHorizontal,
  ExternalLink
} from 'lucide-react';
import { CompassStarIcon } from './BrandLogos';
import { 
  BorrowItem, 
  GuidanceTopic, 
  SkillMatch, 
  MarketplaceItem, 
  ProjectItem 
} from '../types';
import { 
  mockBorrowItems, 
  mockGuidanceTopics, 
  mockSkillMatches, 
  mockMarketplaceItems, 
  mockProjects 
} from '../data/mockData';

interface ServicesSectionProps {
  onOpenServiceModal?: (service: string) => void;
  onNavigateSection?: (sectionId: string) => void;
  onSelectService?: (service: string) => void;
  borrowItems?: BorrowItem[];
  guidanceTopics?: GuidanceTopic[];
  skillMatches?: SkillMatch[];
  marketplaceItems?: MarketplaceItem[];
  projects?: ProjectItem[];
  onSelectMarketplaceItem?: (item: MarketplaceItem) => void;
  onSelectProject?: (project: ProjectItem) => void;
  onAskCompassWithQuery?: (query: string) => void;
}

export const ServicesSection: React.FC<ServicesSectionProps> = ({
  onOpenServiceModal,
  onNavigateSection,
  onSelectService,
  borrowItems = mockBorrowItems,
  guidanceTopics = mockGuidanceTopics,
  skillMatches = mockSkillMatches,
  marketplaceItems = mockMarketplaceItems,
  projects = mockProjects,
  onSelectMarketplaceItem,
  onSelectProject,
  onAskCompassWithQuery,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategoryFilter, setActiveCategoryFilter] = useState<
    'all' | 'borrow' | 'guidance' | 'skills' | 'marketplace' | 'projects'
  >('all');
  const [showResultsDrawer, setShowResultsDrawer] = useState(false);

  const handleCardClick = (serviceId: string) => {
    if (onSelectService) {
      onSelectService(serviceId);
    } else if (onOpenServiceModal) {
      onOpenServiceModal(serviceId);
    }
  };

  const quickSearchSuggestions = [
    { label: 'TI-84 Calculator', category: 'borrow' as const },
    { label: 'Oscilloscope', category: 'borrow' as const },
    { label: 'Operating Systems', category: 'guidance' as const },
    { label: 'Figma UI/UX', category: 'skills' as const },
    { label: 'Lab Coat & Gear', category: 'borrow' as const },
    { label: 'Robotics AI', category: 'projects' as const },
    { label: 'CampusVision', category: 'projects' as const },
  ];

  // Aggregated Search Results
  const searchResults = useMemo(() => {
    const query = searchQuery.trim().toLowerCase();
    const results: Array<{
      id: string;
      protocol: 'borrow' | 'guidance' | 'skills' | 'marketplace' | 'projects';
      title: string;
      subtitle: string;
      categoryTag: string;
      ownerOrMentor: string;
      metaInfo: string;
      accentColor: string;
      originalItem: any;
    }> = [];

    // 1. Borrow Items
    if (activeCategoryFilter === 'all' || activeCategoryFilter === 'borrow') {
      borrowItems.forEach((item) => {
        const matches =
          !query ||
          item.title.toLowerCase().includes(query) ||
          item.category.toLowerCase().includes(query) ||
          item.description.toLowerCase().includes(query) ||
          item.location.toLowerCase().includes(query) ||
          item.ownerName.toLowerCase().includes(query);

        if (matches) {
          results.push({
            id: item.id,
            protocol: 'borrow',
            title: item.title,
            subtitle: item.description,
            categoryTag: item.category,
            ownerOrMentor: item.ownerName,
            metaInfo: `${item.location} • Max ${item.maxDays} days`,
            accentColor: '#00f2ff',
            originalItem: item,
          });
        }
      });
    }

    // 2. Guidance Topics
    if (activeCategoryFilter === 'all' || activeCategoryFilter === 'guidance') {
      guidanceTopics.forEach((topic) => {
        const matches =
          !query ||
          topic.title.toLowerCase().includes(query) ||
          topic.category.toLowerCase().includes(query) ||
          topic.summary.toLowerCase().includes(query) ||
          topic.mentorName.toLowerCase().includes(query) ||
          topic.tips.some((tip) => tip.toLowerCase().includes(query));

        if (matches) {
          results.push({
            id: topic.id,
            protocol: 'guidance',
            title: topic.title,
            subtitle: topic.summary,
            categoryTag: topic.category,
            ownerOrMentor: topic.mentorName,
            metaInfo: `${topic.mentorTitle} • ${topic.reads} Reads`,
            accentColor: '#a855f7',
            originalItem: topic,
          });
        }
      });
    }

    // 3. Skill Matches
    if (activeCategoryFilter === 'all' || activeCategoryFilter === 'skills') {
      skillMatches.forEach((match) => {
        const skillsText = `${match.studentA.teaches} ${match.studentB.teaches} ${match.studentA.name} ${match.studentB.name}`.toLowerCase();
        const matches = !query || skillsText.includes(query);

        if (matches) {
          results.push({
            id: match.id,
            protocol: 'skills',
            title: `${match.studentA.teaches} ↔ ${match.studentB.teaches}`,
            subtitle: `Skill exchange between ${match.studentA.name} and ${match.studentB.name}`,
            categoryTag: `${match.matchScore}% Match Score`,
            ownerOrMentor: `${match.studentA.name} & ${match.studentB.name}`,
            metaInfo: `${match.studentA.year} • ${match.studentB.year}`,
            accentColor: '#38bdf8',
            originalItem: match,
          });
        }
      });
    }

    // 4. Marketplace Items
    if (activeCategoryFilter === 'all' || activeCategoryFilter === 'marketplace') {
      marketplaceItems.forEach((mItem) => {
        const matches =
          !query ||
          mItem.title.toLowerCase().includes(query) ||
          mItem.category.toLowerCase().includes(query) ||
          mItem.description.toLowerCase().includes(query) ||
          mItem.location.toLowerCase().includes(query) ||
          mItem.sellerName.toLowerCase().includes(query);

        if (matches) {
          results.push({
            id: mItem.id,
            protocol: 'marketplace',
            title: mItem.title,
            subtitle: mItem.description,
            categoryTag: mItem.category,
            ownerOrMentor: mItem.sellerName,
            metaInfo: `₹${mItem.price} • ${mItem.location} • ${mItem.condition}`,
            accentColor: '#f43f5e',
            originalItem: mItem,
          });
        }
      });
    }

    // 5. Research & Projects
    if (activeCategoryFilter === 'all' || activeCategoryFilter === 'projects') {
      projects.forEach((proj) => {
        const matches =
          !query ||
          proj.name.toLowerCase().includes(query) ||
          proj.tagline.toLowerCase().includes(query) ||
          proj.description.toLowerCase().includes(query) ||
          proj.category.toLowerCase().includes(query) ||
          proj.skillsRequired.some((s) => s.toLowerCase().includes(query)) ||
          proj.creator.toLowerCase().includes(query);

        if (matches) {
          results.push({
            id: proj.id,
            protocol: 'projects',
            title: proj.name,
            subtitle: proj.tagline || proj.description,
            categoryTag: proj.category,
            ownerOrMentor: proj.creator,
            metaInfo: `${proj.membersCount} Members • ${proj.recruiting ? 'Recruiting' : 'In Progress'}`,
            accentColor: '#818cf8',
            originalItem: proj,
          });
        }
      });
    }

    return results;
  }, [searchQuery, activeCategoryFilter, borrowItems, guidanceTopics, skillMatches, marketplaceItems, projects]);

  const handleResultAction = (result: typeof searchResults[0]) => {
    if (result.protocol === 'borrow') {
      handleCardClick('borrow');
    } else if (result.protocol === 'guidance') {
      handleCardClick('guidance');
    } else if (result.protocol === 'skills') {
      handleCardClick('skills');
    } else if (result.protocol === 'marketplace') {
      if (onSelectMarketplaceItem) {
        onSelectMarketplaceItem(result.originalItem);
      } else {
        document.getElementById('marketplace')?.scrollIntoView({ behavior: 'smooth' });
      }
    } else if (result.protocol === 'projects') {
      if (onSelectProject) {
        onSelectProject(result.originalItem);
      } else {
        document.getElementById('projects')?.scrollIntoView({ behavior: 'smooth' });
      }
    }
  };

  const handleTriggerCompass = (query: string) => {
    if (onAskCompassWithQuery) {
      onAskCompassWithQuery(query);
    } else {
      const compassEl = document.getElementById('compass');
      compassEl?.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const services = [
    {
      id: 'borrow',
      code: '01',
      title: 'BORROW',
      subtitle: "Don't buy what you can borrow.",
      description: 'The things you need are probably closer than you think.',
      icon: BookOpen,
      isCustomIcon: false,
      accentColor: '#00f2ff',
      accentGlow: 'rgba(0, 242, 255, 0.45)',
      cardBg: 'from-[#051522]/95 via-[#060c18]/95 to-[#04060c]',
      borderStyle: 'border-[#00f2ff]/30 group-hover:border-[#00f2ff]',
      glowShadow: 'group-hover:shadow-[0_0_40px_rgba(0,242,255,0.35)]',
      iconColor: 'text-[#00f2ff]',
      iconBg: 'bg-[#00f2ff]/10 border-[#00f2ff]/30',
      badgeText: `${borrowItems.length} Items Active`,
      slantAngle: 'transform-none xl:-rotate-1 xl:hover:rotate-0 xl:-skew-y-1 xl:hover:skew-y-0',
    },
    {
      id: 'guidance',
      code: '02',
      title: 'GUIDANCE',
      subtitle: "Learn from people who've already been there.",
      description: 'Courses, professors, campus processes and knowledge — made easier to navigate.',
      icon: GraduationCap,
      isCustomIcon: false,
      accentColor: '#a855f7',
      accentGlow: 'rgba(168, 85, 247, 0.45)',
      cardBg: 'from-[#19092c]/95 via-[#0c071a]/95 to-[#04060c]',
      borderStyle: 'border-purple-500/30 group-hover:border-purple-400',
      glowShadow: 'group-hover:shadow-[0_0_40px_rgba(168,85,247,0.35)]',
      iconColor: 'text-purple-300',
      iconBg: 'bg-purple-500/10 border-purple-500/30',
      badgeText: `${guidanceTopics.length} Blueprint Guides`,
      slantAngle: 'transform-none xl:rotate-1 xl:hover:rotate-0 xl:skew-y-1 xl:hover:skew-y-0',
    },
    {
      id: 'skills',
      code: '03',
      title: 'SKILL EXCHANGE',
      subtitle: 'You know something. Someone needs it.',
      description: "Trade what you know. Learn what you don't.",
      icon: ArrowLeftRight,
      isCustomIcon: false,
      accentColor: '#38bdf8',
      accentGlow: 'rgba(56, 189, 248, 0.45)',
      cardBg: 'from-[#07192a]/95 via-[#060e1c]/95 to-[#04060c]',
      borderStyle: 'border-sky-500/30 group-hover:border-sky-400',
      glowShadow: 'group-hover:shadow-[0_0_40px_rgba(56,189,248,0.35)]',
      iconColor: 'text-sky-300',
      iconBg: 'bg-sky-500/10 border-sky-500/30',
      badgeText: `${skillMatches.length} Active Matches`,
      slantAngle: 'transform-none xl:-rotate-1 xl:hover:rotate-0 xl:-skew-y-1 xl:hover:skew-y-0',
    },
    {
      id: 'marketplace',
      code: '04',
      title: 'MARKETPLACE',
      subtitle: 'Give unused things a second life.',
      description: "What you don't need anymore could be exactly what someone else needs.",
      icon: ShoppingBag,
      isCustomIcon: false,
      accentColor: '#f43f5e',
      accentGlow: 'rgba(244, 63, 94, 0.45)',
      cardBg: 'from-[#220712]/95 via-[#12050b]/95 to-[#04060c]',
      borderStyle: 'border-rose-500/30 group-hover:border-rose-400',
      glowShadow: 'group-hover:shadow-[0_0_40px_rgba(244,63,94,0.35)]',
      iconColor: 'text-rose-300',
      iconBg: 'bg-rose-500/10 border-rose-500/30',
      badgeText: `${marketplaceItems.length} Listings`,
      slantAngle: 'transform-none xl:rotate-1 xl:hover:rotate-0 xl:skew-y-1 xl:hover:skew-y-0',
    },
    {
      id: 'connect',
      code: '05',
      title: 'CONNECT',
      subtitle: 'Find your squad. Build together.',
      description: 'Discover peers, hackathon teammates, clubs, and project collaborators across branches.',
      icon: Users,
      isCustomIcon: false,
      accentColor: '#818cf8',
      accentGlow: 'rgba(129, 140, 248, 0.45)',
      cardBg: 'from-[#0e112d]/95 via-[#080a1c]/95 to-[#04060c]',
      borderStyle: 'border-indigo-500/30 group-hover:border-indigo-400',
      glowShadow: 'group-hover:shadow-[0_0_40px_rgba(129,140,248,0.35)]',
      iconColor: 'text-indigo-300',
      iconBg: 'bg-indigo-500/10 border-indigo-500/30',
      badgeText: `${projects.length} Active Squads`,
      slantAngle: 'transform-none xl:-rotate-1 xl:hover:rotate-0 xl:-skew-y-1 xl:hover:skew-y-0',
    },
    {
      id: 'compass',
      code: '06',
      title: 'COMPASS',
      subtitle: 'Meet COMPASS, your campus AI.',
      description: 'Your real-time guide to projects, mentors, gear, exams, and campus intelligence.',
      icon: null,
      isCustomIcon: true,
      accentColor: '#f472b6',
      accentGlow: 'rgba(244, 114, 182, 0.65)',
      cardBg: 'from-[#280a22]/95 via-[#160614]/95 to-[#04060c]',
      borderStyle: 'border-pink-400/40 group-hover:border-pink-300',
      glowShadow: 'group-hover:shadow-[0_0_50px_rgba(244,114,182,0.5)]',
      iconColor: 'text-pink-300',
      iconBg: 'bg-pink-500/15 border-pink-400/40',
      badgeText: 'Neural Co-Pilot',
      slantAngle: 'transform-none xl:rotate-1 xl:hover:rotate-0 xl:skew-y-1 xl:hover:skew-y-0',
    },
  ];

  const isSearchActive = searchQuery.trim().length > 0 || showResultsDrawer;

  return (
    <section id="services" className="py-28 border-b border-white/[0.08] relative bg-[#030409] overflow-hidden select-none">
      {/* Background Volumetric Neon Lights */}
      <div className="absolute top-1/3 left-1/4 w-[700px] h-[450px] bg-[#00f2ff]/10 rounded-full blur-[160px] pointer-events-none -z-10 animate-pulse-slow" />
      <div className="absolute bottom-1/4 right-1/4 w-[700px] h-[450px] bg-[#f472b6]/10 rounded-full blur-[160px] pointer-events-none -z-10 animate-pulse-slow" />

      {/* Cybernetic Dot Matrix Grid Pattern Overlay */}
      <div 
        className="absolute inset-0 opacity-[0.03] pointer-events-none -z-10" 
        style={{ backgroundImage: 'radial-gradient(#ffffff 1px, transparent 1px)', backgroundSize: '24px 24px' }} 
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header matching Panel 02 Video Summary Bar */}
        <div className="flex items-center justify-between text-xs font-mono-tech text-cyan-400 mb-8 pb-3 border-b border-white/[0.08]">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded bg-cyan-950/80 border border-cyan-400/40 text-cyan-300 font-bold uppercase tracking-widest shadow-[0_0_12px_rgba(0,242,255,0.2)]">
              02 SERVICES & DISCOVERY
            </span>
            <span className="text-white/40 hidden sm:inline">// LIVE UNIFIED SEARCH PROTOCOL</span>
          </div>
          <span className="text-zinc-400 font-bold">00:08 - 00:20</span>
        </div>

        {/* Center Title */}
        <div className="text-center max-w-3xl mx-auto mb-10 space-y-3">
          <div className="inline-flex items-center gap-2 px-4 py-1 rounded-full bg-white/[0.04] border border-white/10 text-xs font-mono-tech text-white/70 uppercase tracking-widest backdrop-blur-md">
            <Sparkles className="w-3.5 h-3.5 text-cyan-400 animate-spin-slow" />
            <span>SIX INTERCONNECTED CAMPUS PROTOCOLS</span>
          </div>
          <h2 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-white tracking-tight font-heading">
            One campus. <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-300 via-pink-300 to-violet-300 drop-shadow-[0_0_30px_rgba(0,242,255,0.3)]">Infinite possibilities.</span>
          </h2>
          <p className="text-sm sm:text-base text-zinc-400 font-normal max-w-xl mx-auto">
            Everything you need is already around you. You just need to find it.
          </p>
        </div>

        {/* ========================================================================= */}
        {/* SEARCH ITEM HUB (HIGHLY FUNCTIONAL DISCOVERY ENGINE) */}
        {/* ========================================================================= */}
        <div className="max-w-4xl mx-auto mb-12 relative z-20">
          <div className="p-3 sm:p-4 rounded-3xl bg-[#090b14]/90 border border-cyan-500/30 hover:border-cyan-400/60 shadow-[0_0_35px_rgba(0,242,255,0.12)] backdrop-blur-2xl transition-all duration-300">
            
            {/* Search Input Bar */}
            <div className="relative flex items-center">
              <div className="absolute left-4 flex items-center pointer-events-none text-cyan-400">
                <Search className="w-5 h-5 drop-shadow-[0_0_8px_rgba(0,242,255,0.6)]" />
              </div>

              <input
                id="services-global-search-input"
                type="text"
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  if (!showResultsDrawer && e.target.value.trim()) {
                    setShowResultsDrawer(true);
                  }
                }}
                onFocus={() => setShowResultsDrawer(true)}
                placeholder="Search items to borrow, skills, mentors, lab gear, notes, listings..."
                className="w-full pl-12 pr-28 py-3.5 sm:py-4 bg-[#111422]/80 border border-white/[0.08] focus:border-cyan-400 rounded-2xl text-white placeholder-zinc-500 text-sm sm:text-base focus:outline-none focus:ring-2 focus:ring-cyan-400/30 transition-all font-sans"
              />

              {/* Right Action Tools inside Search Input */}
              <div className="absolute right-3 flex items-center gap-2">
                {searchQuery && (
                  <button
                    onClick={() => {
                      setSearchQuery('');
                      setShowResultsDrawer(false);
                    }}
                    className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white/70 hover:text-white transition-colors cursor-pointer"
                    title="Clear search"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}

                <button
                  onClick={() => setShowResultsDrawer((prev) => !prev)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-mono-tech flex items-center gap-1.5 transition-all cursor-pointer ${
                    showResultsDrawer 
                      ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-400/40 shadow-[0_0_12px_rgba(0,242,255,0.2)]'
                      : 'bg-white/[0.06] text-white/60 hover:text-white border border-white/10'
                  }`}
                >
                  <SlidersHorizontal className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">
                    {searchResults.length} Match{searchResults.length === 1 ? '' : 'es'}
                  </span>
                </button>
              </div>
            </div>

            {/* Protocol Filter Tabs */}
            <div className="flex items-center gap-1.5 sm:gap-2 mt-3 overflow-x-auto pb-1 scrollbar-none text-xs font-mono-tech">
              {[
                { key: 'all', label: 'ALL PROTOCOLS', count: borrowItems.length + guidanceTopics.length + skillMatches.length + marketplaceItems.length + projects.length },
                { key: 'borrow', label: '📦 BORROW GEAR', count: borrowItems.length },
                { key: 'guidance', label: '🎓 MENTORS & NOTES', count: guidanceTopics.length },
                { key: 'skills', label: '⚡ SKILL TRADES', count: skillMatches.length },
                { key: 'marketplace', label: '🛍️ MARKETPLACE', count: marketplaceItems.length },
                { key: 'projects', label: '🚀 SQUADS & LABS', count: projects.length },
              ].map((tab) => {
                const isActive = activeCategoryFilter === tab.key;
                return (
                  <button
                    key={tab.key}
                    onClick={() => {
                      setActiveCategoryFilter(tab.key as any);
                      setShowResultsDrawer(true);
                    }}
                    className={`px-3 py-1.5 rounded-xl whitespace-nowrap transition-all cursor-pointer flex items-center gap-1.5 ${
                      isActive
                        ? 'bg-cyan-400 text-black font-bold shadow-[0_0_15px_rgba(0,242,255,0.35)]'
                        : 'bg-white/[0.04] text-white/60 hover:text-white hover:bg-white/[0.08] border border-white/[0.06]'
                    }`}
                  >
                    <span>{tab.label}</span>
                    <span className={`text-[10px] px-1.5 py-0.2 rounded-md ${isActive ? 'bg-black/20 text-black font-extrabold' : 'bg-white/10 text-white/50'}`}>
                      {tab.count}
                    </span>
                  </button>
                );
              })}
            </div>

            {/* Quick Keyword Pills for fast searching */}
            <div className="flex flex-wrap items-center gap-2 mt-3 pt-3 border-t border-white/[0.06] text-xs">
              <span className="text-[11px] font-mono-tech text-white/40 uppercase tracking-wider flex items-center gap-1">
                <Tag className="w-3 h-3 text-cyan-400" />
                <span>Quick Find:</span>
              </span>
              {quickSearchSuggestions.map((pill) => (
                <button
                  key={pill.label}
                  onClick={() => {
                    setSearchQuery(pill.label);
                    setActiveCategoryFilter('all');
                    setShowResultsDrawer(true);
                  }}
                  className="px-2.5 py-1 rounded-lg bg-white/[0.03] hover:bg-cyan-500/15 hover:border-cyan-400/40 border border-white/[0.06] text-zinc-300 hover:text-cyan-300 transition-colors text-[11px] font-mono-tech cursor-pointer"
                >
                  +{pill.label}
                </button>
              ))}
            </div>

          </div>

          {/* ===================================================================== */}
          {/* EXPANDABLE INTERACTIVE SEARCH RESULTS DRAWER */}
          {/* ===================================================================== */}
          {showResultsDrawer && (
            <div className="mt-3 p-4 sm:p-5 rounded-3xl bg-[#090b14]/95 border border-cyan-500/40 shadow-[0_0_50px_rgba(0,242,255,0.2)] backdrop-blur-2xl animate-fadeIn">
              <div className="flex items-center justify-between pb-3 mb-3 border-b border-white/[0.08]">
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
                  <span className="text-xs font-mono-tech text-white font-bold tracking-wider">
                    {searchResults.length} ITEM{searchResults.length === 1 ? '' : 'S'} FOUND ACROSS CAMPUS
                  </span>
                  {searchQuery && (
                    <span className="text-xs font-mono-tech text-cyan-400">
                      matching "{searchQuery}"
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-3">
                  <button
                    onClick={() => handleTriggerCompass(searchQuery || 'Find items to borrow and senior mentors')}
                    className="text-xs font-mono-tech text-pink-300 hover:text-pink-200 flex items-center gap-1 cursor-pointer"
                  >
                    <CompassStarIcon size={14} glow={false} />
                    <span>Ask COMPASS AI</span>
                  </button>

                  <button
                    onClick={() => setShowResultsDrawer(false)}
                    className="text-xs font-mono-tech text-white/50 hover:text-white transition-colors cursor-pointer px-2 py-1 rounded bg-white/5"
                  >
                    Collapse View
                  </button>
                </div>
              </div>

              {/* Items Grid */}
              {searchResults.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5 max-h-[380px] overflow-y-auto pr-1">
                  {searchResults.map((res) => (
                    <div
                      key={`${res.protocol}-${res.id}`}
                      onClick={() => handleResultAction(res)}
                      className="p-3.5 rounded-2xl bg-[#111422]/90 hover:bg-[#161a2e] border border-white/[0.06] hover:border-cyan-400/50 transition-all cursor-pointer group flex flex-col justify-between shadow-lg"
                    >
                      <div>
                        {/* Protocol & Category Badge */}
                        <div className="flex items-center justify-between mb-2">
                          <span 
                            className="px-2 py-0.5 rounded text-[10px] font-mono-tech uppercase font-bold tracking-wider border"
                            style={{ 
                              color: res.accentColor,
                              backgroundColor: `${res.accentColor}15`,
                              borderColor: `${res.accentColor}30`
                            }}
                          >
                            {res.protocol.toUpperCase()}
                          </span>
                          <span className="text-[10px] font-mono-tech text-white/40 truncate max-w-[120px]">
                            {res.categoryTag}
                          </span>
                        </div>

                        {/* Title */}
                        <h4 className="text-sm font-bold text-white group-hover:text-cyan-300 transition-colors line-clamp-1 font-heading">
                          {res.title}
                        </h4>

                        {/* Subtitle / Description */}
                        <p className="text-xs text-zinc-400 line-clamp-2 mt-1 font-normal leading-relaxed">
                          {res.subtitle}
                        </p>
                      </div>

                      {/* Bottom Info & Action */}
                      <div className="pt-2.5 mt-2.5 border-t border-white/[0.06] flex items-center justify-between text-[11px] font-mono-tech">
                        <span className="text-zinc-400 truncate max-w-[150px]">
                          {res.metaInfo}
                        </span>
                        <div className="flex items-center gap-1 text-cyan-400 group-hover:translate-x-0.5 transition-transform font-bold">
                          <span>OPEN</span>
                          <ArrowRight className="w-3 h-3" />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="py-8 text-center space-y-3">
                  <div className="w-12 h-12 rounded-full bg-cyan-950/60 border border-cyan-400/30 flex items-center justify-center mx-auto text-cyan-400">
                    <Search className="w-5 h-5" />
                  </div>
                  <div className="text-sm font-bold text-white font-heading">
                    No direct catalog items found for "{searchQuery}"
                  </div>
                  <p className="text-xs text-zinc-400 max-w-md mx-auto">
                    Would you like to ask the COMPASS campus neural network or create a peer broadcast request?
                  </p>
                  <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
                    <button
                      onClick={() => handleTriggerCompass(`I am looking for ${searchQuery}. Who can help me?`)}
                      className="px-4 py-2 rounded-xl bg-pink-600 hover:bg-pink-500 text-white text-xs font-bold font-mono-tech flex items-center gap-2 cursor-pointer shadow-[0_0_20px_rgba(244,114,182,0.3)]"
                    >
                      <CompassStarIcon size={16} glow={false} />
                      <span>Ask COMPASS to find "{searchQuery}"</span>
                    </button>
                    <button
                      onClick={() => handleCardClick('borrow')}
                      className="px-4 py-2 rounded-xl bg-cyan-400 hover:bg-cyan-300 text-black text-xs font-bold font-mono-tech cursor-pointer"
                    >
                      Post a Wanted Item Request
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

        </div>

        {/* 6 Glowing Dynamic Service Boxes */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 sm:gap-5 lg:gap-4 perspective-1000">
          {services.map((s) => {
            const Icon = s.icon;
            return (
              <div
                key={s.id}
                id={`service-card-${s.id}`}
                onClick={() => handleCardClick(s.id)}
                className={`group relative p-6 sm:p-5 rounded-3xl bg-gradient-to-b ${s.cardBg} border ${s.borderStyle} ${s.glowShadow} ${s.slantAngle} transition-all duration-500 hover:-translate-y-4 hover:scale-[1.04] cursor-pointer flex flex-col justify-between min-h-[340px] text-center overflow-hidden shadow-2xl backdrop-blur-xl`}
              >
                {/* Radiant Ambient Colored Core Glow */}
                <div 
                  className="absolute -top-10 left-1/2 -translate-x-1/2 w-36 h-36 rounded-full blur-3xl opacity-30 group-hover:opacity-75 transition-all duration-500 pointer-events-none"
                  style={{ backgroundColor: s.accentGlow }}
                />

                {/* Laser Circuit Line Across Card */}
                <div 
                  className="absolute inset-0 opacity-10 group-hover:opacity-25 transition-opacity pointer-events-none"
                  style={{
                    backgroundImage: `linear-gradient(135deg, ${s.accentColor} 1px, transparent 1px)`,
                    backgroundSize: '20px 20px'
                  }}
                />

                {/* Top Corner Angled Tech Cut Accent */}
                <div className="flex items-center justify-between w-full mb-3 text-[10px] font-mono-tech relative z-10">
                  <span 
                    className="px-2 py-0.5 rounded-md font-bold uppercase tracking-wider transition-colors shadow-sm"
                    style={{ 
                      backgroundColor: `${s.accentColor}18`,
                      color: s.accentColor,
                      border: `1px solid ${s.accentColor}40`
                    }}
                  >
                    // {s.code}
                  </span>
                  
                  <div className="flex items-center gap-1 text-[10px] text-white/50 group-hover:text-white transition-colors">
                    <span className="w-1.5 h-1.5 rounded-full animate-ping" style={{ backgroundColor: s.accentColor }} />
                    <span className="hidden sm:inline font-mono-tech uppercase text-[9px]">{s.badgeText}</span>
                  </div>
                </div>

                {/* Top Glowing 3D Icon Pod with Radiant Halos */}
                <div className="pt-1 flex flex-col items-center relative z-10">
                  <div className="relative mb-4">
                    {/* Pulsing Backlight Ring */}
                    <div 
                      className="absolute inset-0 rounded-2xl blur-lg opacity-40 group-hover:opacity-100 transition-opacity"
                      style={{ backgroundColor: s.accentGlow }}
                    />

                    {/* Icon Capsule */}
                    <div className={`w-16 h-16 sm:w-15 sm:h-15 rounded-2xl ${s.iconBg} border flex items-center justify-center transition-all duration-500 group-hover:scale-115 group-hover:rotate-3 shadow-xl relative z-10 backdrop-blur-md`}>
                      {s.isCustomIcon ? (
                        <CompassStarIcon size={38} />
                      ) : Icon ? (
                        <Icon 
                          className={`w-7 h-7 ${s.iconColor} transition-transform duration-500 group-hover:scale-110 drop-shadow-[0_0_12px_${s.accentColor}]`} 
                        />
                      ) : null}
                    </div>
                  </div>

                  {/* Card Main Title */}
                  <h3 className="text-base sm:text-[15px] font-bold text-white tracking-wider font-heading uppercase group-hover:text-white transition-colors drop-shadow-md">
                    {s.title}
                  </h3>

                  {/* Subtitle Tech Line */}
                  <span className="text-[10px] font-mono-tech text-white/40 uppercase tracking-wider mt-0.5 mb-2">
                    {s.subtitle}
                  </span>
                </div>

                {/* Card Description */}
                <div className="pb-2 relative z-10">
                  <p className="text-xs text-zinc-400 group-hover:text-zinc-200 leading-relaxed font-normal transition-colors">
                    {s.description}
                  </p>
                </div>

                {/* Bottom Launch Bar with Glowing Accent Edge */}
                <div className="pt-3 border-t border-white/[0.08] flex items-center justify-between text-[11px] font-mono-tech relative z-10">
                  <span className="text-white/40 group-hover:text-white transition-colors uppercase tracking-wider text-[10px]">
                    EXPLORE
                  </span>
                  <div 
                    className="w-6 h-6 rounded-full flex items-center justify-center text-white/50 group-hover:text-white group-hover:translate-x-1 transition-all shadow-sm"
                    style={{ backgroundColor: `${s.accentColor}25` }}
                  >
                    <ArrowUpRight className="w-3.5 h-3.5" style={{ color: s.accentColor }} />
                  </div>
                </div>

                {/* Shimmering Neon Top & Bottom Edge Accents */}
                <div 
                  className="absolute top-0 left-0 right-0 h-[2px] opacity-60 group-hover:opacity-100 transition-opacity" 
                  style={{ background: `linear-gradient(90deg, transparent, ${s.accentColor}, transparent)` }} 
                />
                <div 
                  className="absolute bottom-0 left-0 right-0 h-[2px] opacity-0 group-hover:opacity-100 transition-opacity" 
                  style={{ background: `linear-gradient(90deg, transparent, ${s.accentColor}, transparent)` }} 
                />
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};


```

---

## File: `src/components/ShareModal.tsx`

```tsx
import React, { useState } from 'react';
import { 
  X, 
  Share2, 
  Copy, 
  Check, 
  Send, 
  ExternalLink, 
  Globe, 
  Sparkles,
  Smartphone
} from 'lucide-react';

export interface ShareData {
  title: string;
  text: string;
  url: string;
  category?: string;
  image?: string;
}

interface ShareModalProps {
  isOpen: boolean;
  onClose: () => void;
  shareData: ShareData | null;
}

export const ShareModal: React.FC<ShareModalProps> = ({
  isOpen,
  onClose,
  shareData,
}) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen || !shareData) return null;

  const fullUrl = shareData.url.startsWith('http') 
    ? shareData.url 
    : typeof window !== 'undefined' 
      ? `${window.location.origin}${shareData.url.startsWith('/') ? '' : '/'}${shareData.url}`
      : `https://oncampus.edu/${shareData.url}`;

  const shareText = `${shareData.title}\n${shareData.text}`;
  const encodedUrl = encodeURIComponent(fullUrl);
  const encodedText = encodeURIComponent(shareText);
  const encodedTitle = encodeURIComponent(shareData.title);

  // Direct Social / Messaging Share Links
  const platforms = [
    {
      id: 'whatsapp',
      name: 'WhatsApp',
      description: 'Send to contacts or study groups',
      color: '#25D366',
      bgColor: 'rgba(37, 211, 102, 0.12)',
      borderColor: 'rgba(37, 211, 102, 0.3)',
      icon: (
        <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
          <path d="M12.031 6.172c-3.181 0-5.767 2.586-5.768 5.766-.001 1.298.38 2.27 1.019 3.287l-.711 2.598 2.664-.698c.969.54 2.02.827 3.031.827 3.18 0 5.767-2.587 5.768-5.766.001-3.182-2.585-5.77-5.768-5.772zm3.397 8.243c-.145.407-.843.766-1.18.81-.334.043-.768.061-2.451-.637-1.684-.699-2.756-2.443-2.84-2.553-.083-.11-.676-.902-.676-1.721 0-.819.428-1.222.581-1.39.153-.169.333-.211.444-.211.11 0 .222.001.32.005.102.005.24-.039.375.286.14.337.478 1.164.52 1.25.042.086.07.188.014.3-.056.113-.084.183-.167.282-.083.099-.176.221-.252.298-.083.084-.17.175-.073.342.097.167.433.715.93 1.157.639.57 1.177.747 1.344.831.167.084.264.07.362-.042.097-.113.417-.486.528-.653.111-.167.222-.139.375-.083.153.056.972.458 1.139.542.167.083.278.125.32.194.041.07.041.403-.104.81zM12 2C6.477 2 2 6.477 2 12c0 1.891.524 3.66 1.434 5.176L2 22l4.957-1.399C8.389 21.492 10.134 22 12 22c5.523 0 10-4.477 10-10S17.523 2 12 2zm0 18.2c-1.636 0-3.155-.494-4.425-1.343l-.317-.213-2.946.83.829-2.909-.232-.338C4.015 14.887 3.5 13.488 3.5 12c0-4.687 3.813-8.5 8.5-8.5s8.5 3.813 8.5 8.5-3.813 8.5-8.5 8.5z"/>
        </svg>
      ),
      url: `https://api.whatsapp.com/send?text=${encodedText}%20${encodedUrl}`,
    },
    {
      id: 'telegram',
      name: 'Telegram',
      description: 'Broadcast to channels or groups',
      color: '#229ED9',
      bgColor: 'rgba(34, 158, 217, 0.12)',
      borderColor: 'rgba(34, 158, 217, 0.3)',
      icon: (
        <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
          <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm4.64 6.8c-.15 1.58-.8 5.42-1.13 7.19-.14.75-.42 1-.68 1.03-.58.05-1.02-.38-1.58-.75-.88-.58-1.38-.94-2.23-1.5-.99-.65-.35-1.01.22-1.59.15-.15 2.71-2.48 2.76-2.69a.2.2 0 00-.05-.18c-.06-.05-.14-.03-.21-.02-.09.02-1.49.95-4.22 2.79-.4.27-.76.41-1.08.4-.36-.01-1.04-.2-1.55-.37-.63-.2-1.12-.31-1.08-.66.02-.18.27-.36.74-.55 2.92-1.27 4.86-2.11 5.83-2.51 2.78-1.16 3.35-1.36 3.73-1.36.08 0 .27.02.39.12.1.08.13.19.14.27-.01.06.01.24 0 .38z"/>
        </svg>
      ),
      url: `https://t.me/share/url?url=${encodedUrl}&text=${encodedText}`,
    },
    {
      id: 'twitter',
      name: 'X (Twitter)',
      description: 'Post to your campus followers',
      color: '#FFFFFF',
      bgColor: 'rgba(255, 255, 255, 0.08)',
      borderColor: 'rgba(255, 255, 255, 0.2)',
      icon: (
        <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
          <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>
        </svg>
      ),
      url: `https://twitter.com/intent/tweet?text=${encodedText}&url=${encodedUrl}`,
    },
    {
      id: 'linkedin',
      name: 'LinkedIn',
      description: 'Share academic and project builds',
      color: '#0A66C2',
      bgColor: 'rgba(10, 102, 194, 0.12)',
      borderColor: 'rgba(10, 102, 194, 0.3)',
      icon: (
        <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
          <path d="M19 3a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h14m-.5 15.5v-5.3a3.26 3.26 0 0 0-3.26-3.26c-.85 0-1.84.52-2.28 1.3v-1.11h-2.79v8.37h2.79v-4.93c0-.77.62-1.4 1.39-1.4a1.4 1.4 0 0 1 1.4 1.4v4.93h2.75M6.46 10.9v7.6H9.2v-7.6H6.46M7.83 6.54a1.6 1.6 0 1 0 0 3.2 1.6 1.6 0 0 0 0-3.2z"/>
        </svg>
      ),
      url: `https://www.linkedin.com/sharing/share-offsite/?url=${encodedUrl}`,
    },
    {
      id: 'reddit',
      name: 'Reddit',
      description: 'Post to campus & student subreddits',
      color: '#FF4500',
      bgColor: 'rgba(255, 69, 0, 0.12)',
      borderColor: 'rgba(255, 69, 0, 0.3)',
      icon: (
        <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
          <path d="M12 22C6.477 22 2 17.523 2 12S6.477 2 12 2s10 4.477 10 10-4.477 10-10 10zm5.748-12.875a1.498 1.498 0 0 0-1.437.989 7.747 7.747 0 0 0-4.14-1.2l.745-3.504 2.433.518a1.2 1.2 0 1 0 .265-.773l-2.784-.593a.405.405 0 0 0-.48.312l-.84 3.95a7.78 7.78 0 0 0-4.223 1.2 1.5 1.5 0 0 0-1.439-.99 1.503 1.503 0 0 0-.66 2.85 3.327 3.327 0 0 0-.044.526c0 2.658 3.09 4.813 6.9 4.813s6.9-2.155 6.9-4.813c0-.18-.016-.356-.046-.528a1.503 1.503 0 0 0 .77-1.957 1.498 1.498 0 0 0-1.469-.899zM8.9 13.5a1.1 1.1 0 1 1 0-2.2 1.1 1.1 0 0 1 0 2.2zm6.2 0a1.1 1.1 0 1 1 0-2.2 1.1 1.1 0 0 1 0 2.2zm-5.467 2.378a.4.4 0 0 1 .562-.057c.725.56 1.637.842 2.505.842.868 0 1.78-.282 2.505-.842a.4.4 0 1 1 .496.626c-.886.685-1.996 1.026-3.001 1.026s-2.115-.341-3.001-1.026a.4.4 0 0 1-.066-.569z"/>
        </svg>
      ),
      url: `https://reddit.com/submit?url=${encodedUrl}&title=${encodedTitle}`,
    },
    {
      id: 'email',
      name: 'Email / Outlook',
      description: 'Direct dispatch to faculty or peers',
      color: '#00f2ff',
      bgColor: 'rgba(0, 242, 255, 0.12)',
      borderColor: 'rgba(0, 242, 255, 0.3)',
      icon: <Send className="w-5 h-5 text-[#00f2ff]" />,
      url: `mailto:?subject=${encodedTitle}&body=${encodedText}%0A%0A${encodedUrl}`,
    },
  ];

  const handleCopy = () => {
    navigator.clipboard?.writeText(fullUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleNativeShare = async () => {
    if (typeof navigator !== 'undefined' && navigator.share) {
      try {
        await navigator.share({
          title: shareData.title,
          text: shareData.text,
          url: fullUrl,
        });
      } catch (err) {
        // User cancelled or share failed; modal remains open
      }
    } else {
      handleCopy();
    }
  };

  const hasNativeShare = typeof navigator !== 'undefined' && !!navigator.share;

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-xl animate-in fade-in duration-200"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div 
        id="campus-share-dialog"
        className="relative w-full max-w-lg bg-[#090b10] border border-white/20 rounded-3xl shadow-[0_0_60px_rgba(0,242,255,0.2)] flex flex-col max-h-[90vh] overflow-hidden text-white"
      >
        {/* Header */}
        <div className="px-5 py-4 sm:px-6 bg-[#0d0f17] border-b border-white/[0.08] flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-[#00f2ff]/10 border border-[#00f2ff]/30 flex items-center justify-center text-[#00f2ff]">
              <Share2 className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold font-heading text-white flex items-center gap-2">
                Share with Campus Network
              </h3>
              <p className="text-[11px] font-mono-tech text-white/50">
                DISPATCH INSTANTLY TO ANY PLATFORM
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/[0.06] hover:bg-white/15 text-white/70 hover:text-white flex items-center justify-center transition-all cursor-pointer"
            title="Close"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-5">
          {/* Card Preview of what is being shared */}
          <div className="p-3.5 rounded-2xl bg-white/[0.03] border border-white/10 space-y-1.5">
            <div className="flex items-center justify-between text-[11px] font-mono-tech text-[#00f2ff]">
              <span className="flex items-center gap-1">
                <Sparkles className="w-3 h-3" />
                {shareData.category ? shareData.category.toUpperCase() : 'CAMPUS OS RESOURCE'}
              </span>
              <span className="text-white/40">READY TO SEND</span>
            </div>
            <div className="text-sm font-semibold text-white font-heading line-clamp-1">
              {shareData.title}
            </div>
            <div className="text-xs text-white/60 line-clamp-2 leading-relaxed">
              {shareData.text}
            </div>
          </div>

          {/* Native Device Share Action (Instant sheet for iOS / Android / Mac / Windows) */}
          {hasNativeShare && (
            <button
              onClick={handleNativeShare}
              className="w-full p-3.5 rounded-2xl bg-gradient-to-r from-[#00f2ff]/20 via-[#3b82f6]/20 to-[#a855f7]/20 hover:from-[#00f2ff]/30 hover:to-[#a855f7]/30 border border-[#00f2ff]/40 flex items-center justify-between text-left transition-all duration-200 group cursor-pointer shadow-[0_0_20px_rgba(0,242,255,0.15)] active:scale-[0.99]"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-[#00f2ff]/20 flex items-center justify-center text-[#00f2ff] group-hover:scale-105 transition-transform">
                  <Smartphone className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs font-mono-tech text-[#00f2ff] font-semibold">DEVICE SHARE SHEET</div>
                  <div className="text-sm font-bold text-white font-heading">Open Installed Phone / Desktop Apps</div>
                </div>
              </div>
              <ExternalLink className="w-4 h-4 text-[#00f2ff] group-hover:translate-x-0.5 transition-transform" />
            </button>
          )}

          {/* Platform Grid */}
          <div>
            <div className="text-xs font-mono-tech text-white/50 uppercase tracking-wider mb-2.5 flex items-center justify-between">
              <span>Send directly to platform:</span>
              <span className="text-[10px] text-white/40">Opens in new tab/app</span>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
              {platforms.map((p) => (
                <a
                  key={p.id}
                  href={p.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={() => {
                    setTimeout(onClose, 800);
                  }}
                  className="p-3 rounded-2xl border text-left flex flex-col justify-between gap-2 transition-all duration-200 hover:scale-[1.02] active:scale-[0.98] group"
                  style={{
                    backgroundColor: p.bgColor,
                    borderColor: p.borderColor,
                    color: p.color,
                  }}
                >
                  <div className="flex items-center justify-between">
                    <span className="p-1.5 rounded-lg bg-black/30 text-current">{p.icon}</span>
                    <ExternalLink className="w-3.5 h-3.5 opacity-40 group-hover:opacity-100 transition-opacity text-white" />
                  </div>
                  <div>
                    <div className="text-xs font-bold font-heading text-white">{p.name}</div>
                    <div className="text-[10px] text-white/50 truncate font-mono-tech">{p.description}</div>
                  </div>
                </a>
              ))}
            </div>
          </div>

          {/* Direct Copy Link Bar */}
          <div>
            <div className="text-xs font-mono-tech text-white/50 uppercase tracking-wider mb-1.5">
              Or copy direct link:
            </div>
            <div className="flex items-center gap-2 p-1.5 bg-black/40 border border-white/10 rounded-2xl">
              <div className="flex-1 px-3 text-xs font-mono-tech text-white/70 truncate">
                {fullUrl}
              </div>
              <button
                onClick={handleCopy}
                className={`px-4 py-2 rounded-xl text-xs font-mono-tech font-semibold flex items-center gap-1.5 transition-all cursor-pointer shrink-0 ${
                  copied
                    ? 'bg-[#22c55e] text-black shadow-[0_0_15px_rgba(34,197,94,0.4)]'
                    : 'bg-white/10 hover:bg-white/20 text-white active:scale-95'
                }`}
              >
                {copied ? (
                  <>
                    <Check className="w-3.5 h-3.5" />
                    <span>COPIED!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>COPY LINK</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

```

---

## File: `src/components/SkillExchangeModal.tsx`

```tsx
import React, { useState } from 'react';
import { SkillMatch } from '../types';
import { 
  X, 
  Repeat, 
  Sparkles, 
  ArrowRight, 
  CheckCircle, 
  ShieldCheck, 
  MessageSquare,
  Zap
} from 'lucide-react';

interface SkillExchangeModalProps {
  isOpen: boolean;
  onClose: () => void;
  matches: SkillMatch[];
  onConnectMatch: (matchId: string) => void;
  onAddSkills: (offered: string, wanted: string) => void;
}

export const SkillExchangeModal: React.FC<SkillExchangeModalProps> = ({
  isOpen,
  onClose,
  matches,
  onConnectMatch,
  onAddSkills,
}) => {
  const [activeTab, setActiveTab] = useState<'matches' | 'offer'>('matches');
  const [offeredSkill, setOfferedSkill] = useState('');
  const [wantedSkill, setWantedSkill] = useState('');
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleConnect = (id: string) => {
    onConnectMatch(id);
    setSuccessMsg('Skill Swap connection requested! Both peers have been notified via campus mailbox.');
    setTimeout(() => setSuccessMsg(null), 3000);
  };

  const handleOfferSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!offeredSkill || !wantedSkill) return;

    onAddSkills(offeredSkill, wantedSkill);
    setSuccessMsg('Your skill profile was indexed into the ON CAMPUS Neural Matchmaker!');
    setOfferedSkill('');
    setWantedSkill('');
    setTimeout(() => {
      setSuccessMsg(null);
      setActiveTab('matches');
    }, 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
      <div className="relative w-full max-w-3xl bg-[#090C12] border border-amber-400/40 rounded-2xl p-6 sm:p-8 max-h-[90vh] overflow-y-auto shadow-2xl">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-lg bg-zinc-900 border border-white/10 text-zinc-400 hover:text-white transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-xl bg-amber-950/60 border border-amber-400/40 flex items-center justify-center text-amber-300">
            <Repeat className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-white font-heading">
              03 // SKILL EXCHANGE & TRADE
            </h2>
            <p className="text-xs font-mono-tech text-amber-400">
              Trade what you know. 1-on-1 peer skill swapping with complementary compatibility.
            </p>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 border-b border-white/[0.08] pb-4 mb-6">
          <button
            onClick={() => setActiveTab('matches')}
            className={`px-4 py-2 text-xs font-mono-tech tracking-wider rounded transition-all cursor-pointer ${
              activeTab === 'matches'
                ? 'bg-amber-950/80 border border-amber-400/60 text-amber-300'
                : 'text-zinc-400 hover:text-white'
            }`}
          >
            DISCOVER MATCHES ({matches.length})
          </button>
          <button
            onClick={() => setActiveTab('offer')}
            className={`px-4 py-2 text-xs font-mono-tech tracking-wider rounded transition-all cursor-pointer ${
              activeTab === 'offer'
                ? 'bg-amber-950/80 border border-amber-400/60 text-amber-300'
                : 'text-zinc-400 hover:text-white'
            }`}
          >
            + POST SKILL OFFER
          </button>
        </div>

        {successMsg && (
          <div className="mb-6 p-4 rounded-xl bg-emerald-950/60 border border-emerald-400/40 text-emerald-300 text-xs font-mono-tech flex items-center gap-2">
            <CheckCircle className="w-4 h-4 shrink-0" />
            <span>{successMsg}</span>
          </div>
        )}

        {/* Tab 1: Discover Matches (Highlighting the 92% Match as in Prompt) */}
        {activeTab === 'matches' && (
          <div className="space-y-4">
            {matches.map((match) => (
              <div
                key={match.id}
                className="p-5 rounded-xl bg-zinc-950/80 border border-white/[0.08] hover:border-amber-400/50 transition-all"
              >
                {/* Match Score Header */}
                <div className="flex items-center justify-between pb-3 mb-4 border-b border-white/[0.06]">
                  <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-950/60 border border-amber-400/40 text-amber-300 text-xs font-mono-tech font-bold">
                    <Zap className="w-3.5 h-3.5 fill-amber-400" />
                    <span>{match.matchScore}% COMPATIBILITY MATCH</span>
                  </div>

                  <span className="text-[10px] font-mono-tech text-zinc-400">
                    CAMPUS CROSS-BRANCH SWAP
                  </span>
                </div>

                {/* 2-Student Exchange Representation (Prompt Example) */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-center relative">
                  {/* Student A */}
                  <div className="p-3.5 rounded-lg bg-zinc-900/90 border border-white/[0.06]">
                    <div className="flex items-center gap-2.5 mb-2">
                      <img
                        src={match.studentA.avatar}
                        alt={match.studentA.name}
                        className="w-8 h-8 rounded-full object-cover border border-white/10"
                      />
                      <div>
                        <div className="text-xs font-bold text-white">
                          {match.studentA.name}
                        </div>
                        <div className="text-[9px] font-mono-tech text-zinc-400">
                          {match.studentA.year}
                        </div>
                      </div>
                    </div>
                    <div className="text-xs text-zinc-300 font-mono-tech">
                      <span className="text-amber-400 font-semibold">Teaches: </span>
                      {match.studentA.teaches}
                    </div>
                  </div>

                  {/* Student B */}
                  <div className="p-3.5 rounded-lg bg-zinc-900/90 border border-white/[0.06]">
                    <div className="flex items-center gap-2.5 mb-2">
                      <img
                        src={match.studentB.avatar}
                        alt={match.studentB.name}
                        className="w-8 h-8 rounded-full object-cover border border-white/10"
                      />
                      <div>
                        <div className="text-xs font-bold text-white">
                          {match.studentB.name}
                        </div>
                        <div className="text-[9px] font-mono-tech text-zinc-400">
                          {match.studentB.year}
                        </div>
                      </div>
                    </div>
                    <div className="text-xs text-zinc-300 font-mono-tech">
                      <span className="text-cyan-400 font-semibold">Teaches: </span>
                      {match.studentB.teaches}
                    </div>
                  </div>
                </div>

                {/* Footer Action */}
                <div className="mt-4 pt-3 border-t border-white/[0.06] flex items-center justify-between">
                  <div className="text-[10px] font-mono-tech text-zinc-400">
                    Format: Weekly 45-min Zoom / Library whiteboard swap
                  </div>

                  <button
                    onClick={() => handleConnect(match.id)}
                    className="px-4 py-2 bg-gradient-to-r from-amber-400 to-yellow-500 hover:from-amber-300 hover:to-yellow-400 text-black text-xs font-mono-tech font-bold rounded transition-all cursor-pointer shadow-md"
                  >
                    {match.status === 'connected' ? 'CONNECTED ✓' : 'REQUEST SKILL SWAP'}
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Tab 2: Post Skill Offer */}
        {activeTab === 'offer' && (
          <form onSubmit={handleOfferSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-mono-tech text-zinc-300 mb-1">
                SKILL YOU CAN TEACH (OFFERED)
              </label>
              <input
                type="text"
                value={offeredSkill}
                onChange={(e) => setOfferedSkill(e.target.value)}
                placeholder="e.g. Figma UI Design, Python Data Science, Guitar, LeetCode Trees"
                required
                className="w-full px-3 py-2 bg-zinc-950 border border-white/10 rounded text-sm text-white focus:outline-none focus:border-amber-400 font-mono-tech"
              />
            </div>

            <div>
              <label className="block text-xs font-mono-tech text-zinc-300 mb-1">
                SKILL YOU WANT TO LEARN (WANTED)
              </label>
              <input
                type="text"
                value={wantedSkill}
                onChange={(e) => setWantedSkill(e.target.value)}
                placeholder="e.g. Machine Learning, System Design, Excel Financial Models"
                required
                className="w-full px-3 py-2 bg-zinc-950 border border-white/10 rounded text-sm text-white focus:outline-none focus:border-amber-400 font-mono-tech"
              />
            </div>

            <div className="pt-2">
              <button
                type="submit"
                className="w-full py-3 bg-gradient-to-r from-amber-400 to-yellow-500 hover:from-amber-300 hover:to-yellow-400 text-black font-bold text-xs font-mono-tech tracking-wider uppercase rounded transition-all cursor-pointer shadow-lg"
              >
                FIND COMPLEMENTARY MATCHES (+30 IMPACT)
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};

```

---

## File: `src/components/StudentPassportModal.tsx`

```tsx
import React, { useState } from 'react';
import { 
  X, 
  ShieldCheck, 
  Award, 
  Zap, 
  BookOpen, 
  Layers, 
  TrendingUp, 
  Heart, 
  MessageSquare, 
  Building2, 
  Mail, 
  Edit3, 
  Lock,
  Globe,
  UserPlus,
  Clock,
  Sparkles,
  ToggleLeft,
  ToggleRight
} from 'lucide-react';
import { UserProfile } from '../types';

interface StudentPassportModalProps {
  user: UserProfile | null;
  currentUser: UserProfile;
  isOpen: boolean;
  onClose: () => void;
  onGiveKudos: (userId: string) => void;
  onOpenEditProfile?: () => void;
  onOpenDirectMessage?: (user: UserProfile) => void;
  onSendFriendRequest?: (userId: string) => void;
  onTogglePrivacy?: (userId: string) => void;
}

export const StudentPassportModal: React.FC<StudentPassportModalProps> = ({
  user,
  currentUser,
  isOpen,
  onClose,
  onGiveKudos,
  onOpenEditProfile,
  onOpenDirectMessage,
  onSendFriendRequest,
  onTogglePrivacy,
}) => {
  const [kudosSent, setKudosSent] = useState(false);
  const [requestSentLocally, setRequestSentLocally] = useState(false);

  if (!isOpen || !user) return null;

  const isOwnProfile = user.id === currentUser?.id;
  const isPrivate = !!user.isPrivate;
  const isFriend = (currentUser?.friendIds || []).includes(user.id);
  const isPendingFriendRequest = 
    (currentUser?.outgoingFriendRequestUserIds || []).includes(user.id) ||
    requestSentLocally;

  const handleKudos = () => {
    if (kudosSent) return;
    setKudosSent(true);
    onGiveKudos(user.id);
  };

  const handleFriendRequest = () => {
    setRequestSentLocally(true);
    if (onSendFriendRequest) {
      onSendFriendRequest(user.id);
    }
  };

  const handleMessageClick = () => {
    if (onOpenDirectMessage) {
      onOpenDirectMessage(user);
    }
  };

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 overflow-y-auto bg-black/85 backdrop-blur-xl animate-in fade-in duration-200"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div 
        id="student-passport-modal-card"
        className="relative w-full max-w-2xl bg-[#0b0c12] border border-white/15 rounded-3xl shadow-[0_0_60px_rgba(0,242,255,0.15)] flex flex-col overflow-hidden text-white"
      >
        {/* Ambient Top Glow */}
        <div className="absolute top-0 left-0 right-0 h-40 bg-gradient-to-b from-[#00f2ff]/20 via-[#c084fc]/10 to-transparent blur-2xl pointer-events-none" />

        {/* Header Bar */}
        <div className="p-4 sm:p-5 border-b border-white/[0.08] flex items-center justify-between relative z-10 bg-[#0e0f18]/80">
          <div className="flex items-center gap-2 text-[11px] font-mono-tech tracking-[2px] text-[#00f2ff]">
            <ShieldCheck className="w-4 h-4 text-[#00f2ff]" />
            <span>VERIFIED ZERO-KNOWLEDGE STUDENT PASSPORT</span>
          </div>

          <button
            id="passport-modal-close-btn"
            onClick={onClose}
            aria-label="Close"
            className="w-8 h-8 rounded-full bg-white/[0.05] hover:bg-white/[0.15] text-white/70 hover:text-white flex items-center justify-center transition-colors cursor-pointer border border-white/10"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Passport Body */}
        <div className="p-5 sm:p-7 space-y-6 overflow-y-auto max-h-[80vh] custom-scrollbar relative z-10">
          
          {/* Main ID Badge Header */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-5 bg-gradient-to-r from-[#141622] to-[#181a28] p-5 sm:p-6 rounded-2xl border border-white/10 relative overflow-hidden">
            <div className="flex items-center gap-4">
              <div className="relative">
                <img 
                  src={user.avatar} 
                  alt={user.name} 
                  className="w-18 h-18 sm:w-20 sm:h-20 rounded-2xl object-cover border-2 border-[#00f2ff]/60 shadow-[0_0_20px_rgba(0,242,255,0.3)]"
                />
                <span className="absolute -bottom-1 -right-1 px-2 py-0.5 rounded-full bg-[#00f2ff] text-black font-mono-tech font-bold text-[10px] shadow-md">
                  #{user.rank}
                </span>
              </div>

              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-xl sm:text-2xl font-black text-white font-heading">{user.name}</h3>
                  <ShieldCheck className="w-5 h-5 text-[#00f2ff]" />
                </div>
                <div className="text-xs text-[#00f2ff] font-mono-tech mt-0.5">{user.title}</div>
                <div className="text-xs text-white/60 font-mono-tech mt-0.5">{user.department} • {user.year}</div>
                
                {/* Privacy Badge & Hostel */}
                <div className="flex items-center gap-2 mt-1.5 flex-wrap">
                  <div className="text-[11px] text-white/50 font-mono-tech flex items-center gap-1">
                    <Building2 className="w-3 h-3 text-white/40" />
                    <span>{user.hostelWing || 'North Block (H4)'}</span>
                  </div>

                  {/* Public / Private Status Pill */}
                  {isPrivate ? (
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-amber-500/15 border border-amber-500/30 text-[10px] font-mono-tech text-amber-300 font-bold">
                      <Lock className="w-3 h-3" /> Private Profile
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-[10px] font-mono-tech text-emerald-300 font-bold">
                      <Globe className="w-3 h-3" /> Public Profile
                    </span>
                  )}
                </div>
              </div>
            </div>

            <div className="flex flex-col items-start sm:items-end gap-2 sm:self-center">
              <div className="font-mono-tech bg-[#0a0a0f] p-3 rounded-xl border border-white/10 text-left sm:text-right">
                <div className="text-[10px] text-white/40 uppercase">Total Karma</div>
                <div className="text-2xl font-black text-white">{user.impactScore} <span className="text-xs text-[#00f2ff]">PTS</span></div>
                <div className="text-[10px] text-emerald-400 mt-0.5">Top {Math.min(10, user.rank * 2)}% on Campus</div>
              </div>

              {isOwnProfile && onTogglePrivacy && (
                <button
                  onClick={() => onTogglePrivacy(user.id)}
                  className={`px-3 py-1.5 rounded-lg border text-xs font-mono-tech flex items-center gap-1.5 transition-all cursor-pointer font-bold ${
                    isPrivate 
                      ? 'bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border-amber-500/40' 
                      : 'bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                  }`}
                  title="Click to toggle Public / Private Profile status"
                >
                  {isPrivate ? <Lock className="w-3.5 h-3.5" /> : <Globe className="w-3.5 h-3.5" />}
                  <span>{isPrivate ? 'Set to Public' : 'Set to Private'}</span>
                </button>
              )}
            </div>
          </div>

          {/* Privacy Note Banner */}
          {isPrivate ? (
            <div className="p-3.5 rounded-2xl bg-amber-500/10 border border-amber-500/25 flex items-center justify-between gap-3 text-xs font-mono-tech text-amber-200/90">
              <div className="flex items-center gap-2">
                <Lock className="w-4 h-4 text-amber-300 shrink-0" />
                <span>
                  <strong>Private Profile Mode:</strong> Direct messaging is restricted to accepted friends. Send a friend request to unlock direct communication.
                </span>
              </div>
            </div>
          ) : (
            <div className="p-3.5 rounded-2xl bg-emerald-500/10 border border-emerald-500/25 flex items-center justify-between gap-3 text-xs font-mono-tech text-emerald-200/90">
              <div className="flex items-center gap-2">
                <Globe className="w-4 h-4 text-emerald-300 shrink-0" />
                <span>
                  <strong>Public Profile Mode:</strong> Direct peer messaging is open to all registered students without requiring a friend request.
                </span>
              </div>
            </div>
          )}

          {/* Bio statement */}
          <div className="p-4 rounded-xl bg-[#12131c] border border-white/5 text-xs sm:text-sm text-white/80 leading-relaxed font-normal">
            "{user.bio}"
          </div>

          {/* 4 Pillars Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 font-mono-tech text-xs">
            <div className="p-3.5 rounded-xl bg-[#12131c] border border-white/5 space-y-1">
              <div className="text-[10px] text-[#00f2ff] flex items-center gap-1">
                <BookOpen className="w-3 h-3" />
                <span>KNOWLEDGE</span>
              </div>
              <div className="text-xl font-bold text-white">{user.knowledgeScore}</div>
              <div className="text-[10px] text-white/40">{user.notesShared || 24} Course Notes</div>
            </div>

            <div className="p-3.5 rounded-xl bg-[#12131c] border border-white/5 space-y-1">
              <div className="text-[10px] text-[#c084fc] flex items-center gap-1">
                <Zap className="w-3 h-3" />
                <span>SKILLS</span>
              </div>
              <div className="text-xl font-bold text-white">{user.skillScore}</div>
              <div className="text-[10px] text-white/40">{user.mentorHours || 35} Mentoring Hrs</div>
            </div>

            <div className="p-3.5 rounded-xl bg-[#12131c] border border-white/5 space-y-1">
              <div className="text-[10px] text-emerald-400 flex items-center gap-1">
                <Layers className="w-3 h-3" />
                <span>RESOURCES</span>
              </div>
              <div className="text-xl font-bold text-white">{user.resourceScore}</div>
              <div className="text-[10px] text-white/40">{user.itemsLent || 18} Hardware Loans</div>
            </div>

            <div className="p-3.5 rounded-xl bg-[#12131c] border border-white/5 space-y-1">
              <div className="text-[10px] text-rose-400 flex items-center gap-1">
                <TrendingUp className="w-3 h-3" />
                <span>PROJECTS</span>
              </div>
              <div className="text-xl font-bold text-white">{user.projectScore}</div>
              <div className="text-[10px] text-white/40">5 Active Repos</div>
            </div>
          </div>

          {/* Badges & Accolades */}
          <div className="space-y-2">
            <div className="text-[11px] font-mono-tech text-white/50 uppercase tracking-wider">
              Earned Campus Badges
            </div>
            <div className="flex flex-wrap gap-2">
              {(user.badges || ['Verified Peer', 'Top Lender', 'Course TA']).map((b) => (
                <span 
                  key={b}
                  className="px-3 py-1.5 rounded-xl bg-[#161826] border border-white/10 text-xs font-mono-tech text-[#00f2ff] flex items-center gap-1.5 shadow-sm"
                >
                  <Award className="w-3.5 h-3.5 text-yellow-400" />
                  <span>{b}</span>
                </span>
              ))}
            </div>
          </div>

          {/* Skills Offered & Wanted */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="p-4 rounded-xl bg-[#12131c] border border-white/5 space-y-2">
              <div className="text-[11px] font-mono-tech text-emerald-400 uppercase">Teaches / Mentors</div>
              <div className="flex flex-wrap gap-1.5">
                {(user.skillsOffered || []).map((s) => (
                  <span key={s} className="px-2.5 py-1 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-xs text-emerald-300 font-mono-tech">
                    {s}
                  </span>
                ))}
              </div>
            </div>

            <div className="p-4 rounded-xl bg-[#12131c] border border-white/5 space-y-2">
              <div className="text-[11px] font-mono-tech text-[#c084fc] uppercase">Looking to Learn</div>
              <div className="flex flex-wrap gap-1.5">
                {(user.skillsWanted || []).map((s) => (
                  <span key={s} className="px-2.5 py-1 rounded-lg bg-purple-500/10 border border-purple-500/20 text-xs text-purple-300 font-mono-tech">
                    {s}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* ZK Cryptographic Proof Bar */}
          <div className="p-4 rounded-2xl bg-[#090a0f] border border-white/10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs font-mono-tech text-white/60">
            <div>
              <div className="text-[10px] text-white/40 uppercase">Verified On-Chain Hash</div>
              <div className="text-white font-mono-tech">{user.verifiedHash || '0x7b4a8e2...c91d'}</div>
            </div>
            <div className="flex items-center gap-2">
              <span className="px-3 py-1.5 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 text-xs flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span>ZK Authenticated</span>
              </span>
            </div>
          </div>

          {/* Bottom Actions based on Ownership & Privacy */}
          <div className="pt-2 flex flex-col sm:flex-row items-center gap-3">
            {!isOwnProfile ? (
              <>
                <button
                  onClick={handleKudos}
                  className={`flex-1 w-full py-3 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer font-mono-tech ${
                    kudosSent
                      ? 'bg-pink-500/20 text-pink-300 border border-pink-500/50'
                      : 'bg-gradient-to-r from-pink-600 to-rose-600 hover:from-pink-500 hover:to-rose-500 text-white shadow-[0_0_20px_rgba(244,114,182,0.4)]'
                  }`}
                >
                  <Heart className="w-4 h-4 text-pink-300" />
                  <span>{kudosSent ? 'Kudos Sent (+5 Karma Awarded!)' : 'Send Kudos (+5 Karma)'}</span>
                </button>

                {/* Primary Messaging / Friend Request Action */}
                {isPrivate && !isFriend ? (
                  /* PRIVATE & NOT FRIENDS -> Must Send Friend Request */
                  isPendingFriendRequest ? (
                    <div className="w-full sm:w-auto px-5 py-3 rounded-xl bg-amber-500/20 border border-amber-500/40 text-amber-200 text-xs font-bold font-mono-tech flex items-center justify-center gap-2">
                      <Clock className="w-4 h-4 text-amber-300" />
                      <span>Friend Request Pending</span>
                    </div>
                  ) : (
                    <button
                      onClick={handleFriendRequest}
                      className="w-full sm:w-auto px-5 py-3 rounded-xl bg-gradient-to-r from-[#00f2ff] to-[#38bdf8] hover:from-[#38f6ff] hover:to-[#0284c7] text-black text-xs font-bold font-mono-tech flex items-center justify-center gap-2 transition-all cursor-pointer shadow-[0_0_20px_rgba(0,242,255,0.3)] hover:scale-105"
                      title="Send friend request to unlock messaging with this private profile"
                    >
                      <UserPlus className="w-4 h-4" />
                      <span>Send Friend Request</span>
                    </button>
                  )
                ) : (
                  /* PUBLIC OR ACCEPTED FRIENDS -> Direct Message Unlocked */
                  <button
                    onClick={handleMessageClick}
                    className="w-full sm:w-auto px-5 py-3 rounded-xl bg-[#00f2ff] hover:bg-[#38f6ff] text-black text-xs font-bold font-mono-tech flex items-center justify-center gap-2 transition-all cursor-pointer shadow-[0_0_20px_rgba(0,242,255,0.3)] hover:scale-105"
                  >
                    <MessageSquare className="w-4 h-4" />
                    <span>{isFriend ? 'Message Friend' : 'Direct Message'}</span>
                  </button>
                )}

                <a
                  href={`mailto:${user.contactEmail || 'peer@campus.edu'}`}
                  className="w-full sm:w-auto px-4 py-3 rounded-xl bg-white/10 hover:bg-white/20 border border-white/20 text-white text-xs font-bold flex items-center justify-center gap-2 transition-all font-mono-tech"
                >
                  <Mail className="w-4 h-4 text-[#00f2ff]" />
                  <span>Email</span>
                </a>
              </>
            ) : (
              <>
                <button
                  onClick={() => {
                    onClose();
                    if (onOpenEditProfile) onOpenEditProfile();
                  }}
                  className="flex-1 w-full py-3 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer font-mono-tech bg-[#00f2ff] hover:bg-[#38f6ff] text-black shadow-[0_0_20px_rgba(0,242,255,0.3)]"
                >
                  <Edit3 className="w-4 h-4" />
                  <span>Edit Profile & Preferences</span>
                </button>

                {onTogglePrivacy && (
                  <button
                    onClick={() => onTogglePrivacy(user.id)}
                    className={`w-full sm:w-auto px-4 py-3 rounded-xl border text-xs font-bold flex items-center justify-center gap-2 transition-all font-mono-tech cursor-pointer ${
                      isPrivate
                        ? 'bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border-emerald-500/40'
                        : 'bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border-amber-500/40'
                    }`}
                  >
                    {isPrivate ? <Globe className="w-4 h-4" /> : <Lock className="w-4 h-4" />}
                    <span>Switch to {isPrivate ? 'Public' : 'Private'}</span>
                  </button>
                )}
              </>
            )}
          </div>

        </div>

      </div>
    </div>
  );
};

```

---

## File: `src/components/TutorialVideoSection.tsx`

```tsx
import React, { useState, useEffect, useRef } from 'react';
import { 
  Play, 
  Pause, 
  RotateCcw, 
  Volume2, 
  VolumeX, 
  Maximize2, 
  Minimize2, 
  Sparkles, 
  Zap, 
  Cpu, 
  Share2, 
  ArrowRight, 
  CheckCircle2, 
  ShieldCheck, 
  Radio, 
  Layers, 
  Code2, 
  FastForward, 
  ExternalLink,
  Video
} from 'lucide-react';

interface SceneConfig {
  id: string;
  chapterNumber: string;
  title: string;
  badge: string;
  prompt: string;
  subtitle: string;
  actionText: string;
  metricLabel: string;
  metricValue: string;
  accentColor: string;
  glowColor: string;
  avatar: string;
  hostel: string;
  tags: string[];
}

const SCENES: SceneConfig[] = [
  {
    id: 'ai-prompt',
    chapterNumber: '01',
    title: 'COMPASS AI Neural Prompting',
    badge: 'INSTANT INDEXING // 12MS',
    prompt: 'need macbook pro 16" & casio calculator in hostel 4 for midsem lab',
    subtitle: 'Natural language semantic parsing links requests across 2,400+ peer nodes instantaneously.',
    actionText: 'Routing 3 Verified Matches in H-4 Block B',
    metricLabel: 'Match Latency',
    metricValue: '0.14s',
    accentColor: '#00f2ff',
    glowColor: 'rgba(0, 242, 255, 0.45)',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    hostel: 'Hostel 4 • Room 204',
    tags: ['Hardware Borrow', 'Zero Collateral', 'Karma Verified'],
  },
  {
    id: 'squad-match',
    chapterNumber: '02',
    title: 'Autonomous Research Squad Matching',
    badge: 'SKILL BARTER & SQUADS',
    prompt: 'assemble 4-person robotics squad: ROS2 + PyTorch + PCB designer',
    subtitle: 'Automated skill matrix indexing discovers complementary engineering talent on campus.',
    actionText: 'Autonomous Rover Lab • 3/4 Seats Filled',
    metricLabel: 'Squad Synergy',
    metricValue: '98.4%',
    accentColor: '#c084fc',
    glowColor: 'rgba(192, 132, 252, 0.45)',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    hostel: 'Tech Block 2 • Lab 102',
    tags: ['AI/ML', 'Robotics', 'Smart Contract'],
  },
  {
    id: 'zero-fee-market',
    chapterNumber: '03',
    title: 'Zero-Fee Verified Peer Marketplace',
    badge: 'CAMPUS COMMERCE // 0% FEE',
    prompt: 'list sony wh-1000xm5 mint condition for peer handoff at library',
    subtitle: 'Direct peer-to-peer commerce without middlemen fees, verified by campus institutional email.',
    actionText: 'Instant Handover Scheduled • Central Library Cafe',
    metricLabel: 'Savings Rate',
    metricValue: '100% Zero Fee',
    accentColor: '#22c55e',
    glowColor: 'rgba(34, 197, 94, 0.45)',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
    hostel: 'Arya Hostel • Floor 3',
    tags: ['Instant Handover', 'UPI Direct', 'Hostel Pickup'],
  },
  {
    id: 'karma-engine',
    chapterNumber: '04',
    title: 'Decentralized Campus Karma Engine',
    badge: 'PROOF OF REPUTATION',
    prompt: 'verified returned lab equipment on time • awarded +150 karma points',
    subtitle: 'Every positive contribution, mentor session, and return elevates your on-chain reputation score.',
    actionText: 'Reputation Tier: Top 1% Campus Champion',
    metricLabel: 'Trust Rating',
    metricValue: '99.98%',
    accentColor: '#facc15',
    glowColor: 'rgba(250, 204, 21, 0.45)',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
    hostel: 'Hostel 7 • Room 412',
    tags: ['Karma +150', 'Badge Minted', 'Priority Access'],
  },
];

export const TutorialVideoSection: React.FC = () => {
  const [activeSceneIdx, setActiveSceneIdx] = useState(0);
  const [isPlaying, setIsPlaying] = useState(true);
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1);
  const [isMuted, setIsMuted] = useState(true);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [typedText, setTypedText] = useState('');
  const [charIndex, setCharIndex] = useState(0);
  const [isTypingComplete, setIsTypingComplete] = useState(false);
  const [progressPercent, setProgressPercent] = useState(0);
  const [showCustomUrlInput, setShowCustomUrlInput] = useState(false);
  const [customVideoUrl, setCustomVideoUrl] = useState('');
  const [activeCustomEmbed, setActiveCustomEmbed] = useState<string | null>(null);

  const containerRef = useRef<HTMLDivElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);

  const currentScene = SCENES[activeSceneIdx];

  // Synthesize energetic futuristic sound effects when unmuted
  const playSciFiSound = (freq = 440, type: OscillatorType = 'sine', duration = 0.08) => {
    if (isMuted) return;
    try {
      if (!audioContextRef.current) {
        audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      }
      const ctx = audioContextRef.current;
      if (ctx.state === 'suspended') {
        ctx.resume();
      }
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = type;
      osc.frequency.setValueAtTime(freq, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(freq * 1.5, ctx.currentTime + duration);
      gain.gain.setValueAtTime(0.04, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + duration);
    } catch (e) {
      // Audio not supported or allowed yet
    }
  };

  // Typing animation effect for the prompt
  useEffect(() => {
    if (!isPlaying) return;

    setTypedText('');
    setCharIndex(0);
    setIsTypingComplete(false);

    const fullText = currentScene.prompt;
    let currentIdx = 0;

    const typeInterval = setInterval(() => {
      if (currentIdx <= fullText.length) {
        setTypedText(fullText.slice(0, currentIdx));
        setCharIndex(currentIdx);
        if (currentIdx % 3 === 0) {
          playSciFiSound(520 + (currentIdx % 5) * 60, 'sine', 0.03);
        }
        currentIdx++;
      } else {
        clearInterval(typeInterval);
        setIsTypingComplete(true);
        playSciFiSound(880, 'triangle', 0.15);
      }
    }, Math.max(25, 45 / playbackSpeed));

    return () => clearInterval(typeInterval);
  }, [activeSceneIdx, isPlaying, playbackSpeed]);

  // Scene auto-advance timer and progress bar
  useEffect(() => {
    if (!isPlaying) return;

    const sceneDuration = 5500 / playbackSpeed;
    const intervalTime = 50;
    let elapsed = 0;

    const timer = setInterval(() => {
      elapsed += intervalTime;
      const pct = Math.min(100, (elapsed / sceneDuration) * 100);
      setProgressPercent(pct);

      if (elapsed >= sceneDuration) {
        setActiveSceneIdx((prev) => (prev + 1) % SCENES.length);
        elapsed = 0;
      }
    }, intervalTime);

    return () => clearInterval(timer);
  }, [activeSceneIdx, isPlaying, playbackSpeed]);

  // Energetic Particle Canvas Background in Video Player
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animFrame: number;
    let width = (canvas.width = canvas.parentElement?.clientWidth || 900);
    let height = (canvas.height = canvas.parentElement?.clientHeight || 520);

    const handleResize = () => {
      if (!canvas || !canvas.parentElement) return;
      width = canvas.width = canvas.parentElement.clientWidth;
      height = canvas.height = canvas.parentElement.clientHeight;
    };

    window.addEventListener('resize', handleResize);

    // Particle pool
    const particles = Array.from({ length: 45 }, () => ({
      x: Math.random() * width,
      y: Math.random() * height,
      vx: (Math.random() - 0.5) * 1.5,
      vy: (Math.random() - 0.5) * 1.5,
      size: Math.random() * 2 + 1,
      color: Math.random() > 0.5 ? '#00f2ff' : '#c084fc',
      alpha: Math.random() * 0.5 + 0.2,
    }));

    let step = 0;

    const render = () => {
      step++;
      ctx.clearRect(0, 0, width, height);

      // Deep dark cybernetic gradient
      const bgGrad = ctx.createLinearGradient(0, 0, width, height);
      bgGrad.addColorStop(0, '#060913');
      bgGrad.addColorStop(0.5, '#070b18');
      bgGrad.addColorStop(1, '#05070e');
      ctx.fillStyle = bgGrad;
      ctx.fillRect(0, 0, width, height);

      // Energetic laser scanline ray sweeping across
      const laserY = (Math.sin(step * 0.02 * playbackSpeed) * 0.5 + 0.5) * height;
      const laserGrad = ctx.createLinearGradient(0, laserY - 30, 0, laserY + 30);
      laserGrad.addColorStop(0, 'rgba(0, 242, 255, 0)');
      laserGrad.addColorStop(0.5, 'rgba(0, 242, 255, 0.06)');
      laserGrad.addColorStop(1, 'rgba(0, 242, 255, 0)');
      ctx.fillStyle = laserGrad;
      ctx.fillRect(0, laserY - 30, width, 60);

      // Draw subtle background glowing radial orb
      const orbGrad = ctx.createRadialGradient(
        width * 0.65, height * 0.45, 10,
        width * 0.65, height * 0.45, width * 0.4
      );
      orbGrad.addColorStop(0, `${currentScene.accentColor}18`);
      orbGrad.addColorStop(0.6, `${currentScene.accentColor}06`);
      orbGrad.addColorStop(1, 'transparent');
      ctx.fillStyle = orbGrad;
      ctx.fillRect(0, 0, width, height);

      // Draw energetic connecting particles
      particles.forEach((p, idx) => {
        p.x += p.vx * playbackSpeed;
        p.y += p.vy * playbackSpeed;

        if (p.x < 0) p.x = width;
        if (p.x > width) p.x = 0;
        if (p.y < 0) p.y = height;
        if (p.y > height) p.y = 0;

        ctx.fillStyle = p.color;
        ctx.globalAlpha = p.alpha;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();

        // Connect near particles
        for (let j = idx + 1; j < particles.length; j++) {
          const p2 = particles[j];
          const dist = Math.hypot(p.x - p2.x, p.y - p2.y);
          if (dist < 110) {
            ctx.strokeStyle = p.color;
            ctx.globalAlpha = (1 - dist / 110) * 0.15;
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.moveTo(p.x, p.y);
            ctx.lineTo(p2.x, p2.y);
            ctx.stroke();
          }
        }
      });

      ctx.globalAlpha = 1;
      animFrame = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animFrame);
      window.removeEventListener('resize', handleResize);
    };
  }, [activeSceneIdx, playbackSpeed]);

  const toggleFullscreen = () => {
    if (!containerRef.current) return;
    if (!document.fullscreenElement) {
      containerRef.current.requestFullscreen().catch(() => {});
      setIsFullscreen(true);
    } else {
      document.exitFullscreen().catch(() => {});
      setIsFullscreen(false);
    }
  };

  const handleCustomVideoSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customVideoUrl.trim()) return;

    let embedUrl = customVideoUrl;
    if (customVideoUrl.includes('youtube.com/watch?v=')) {
      const vId = customVideoUrl.split('watch?v=')[1]?.split('&')[0];
      embedUrl = `https://www.youtube.com/embed/${vId}?autoplay=1&mute=1`;
    } else if (customVideoUrl.includes('youtu.be/')) {
      const vId = customVideoUrl.split('youtu.be/')[1]?.split('?')[0];
      embedUrl = `https://www.youtube.com/embed/${vId}?autoplay=1&mute=1`;
    } else if (customVideoUrl.includes('vimeo.com/')) {
      const vId = customVideoUrl.split('vimeo.com/')[1]?.split('?')[0];
      embedUrl = `https://player.vimeo.com/video/${vId}?autoplay=1&muted=1`;
    }

    setActiveCustomEmbed(embedUrl);
    setShowCustomUrlInput(false);
  };

  return (
    <section id="walkthrough" className="relative py-12 sm:py-16 lg:py-20 bg-[#05060a] border-t border-white/[0.06] overflow-hidden select-none">
      
      {/* Ambient Lighting Background */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[900px] h-[550px] bg-gradient-to-r from-[#00f2ff]/10 via-[#c084fc]/08 to-[#22c55e]/06 rounded-full blur-[170px] pointer-events-none -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* ========================================================================= */}
        {/* SECTION HEADER (Compact, high-density layout with no empty gaps) */}
        {/* ========================================================================= */}
        <div className="flex flex-col lg:flex-row lg:items-end justify-between mb-6 sm:mb-8 gap-4 sm:gap-6">
          <div className="max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-[#00f2ff]/30 bg-[#00f2ff]/10 text-[#00f2ff] text-[11px] sm:text-xs font-mono-tech uppercase font-bold tracking-wider mb-2.5">
              <Radio className="w-3.5 h-3.5 text-[#00f2ff] animate-pulse" />
              <span>CAMPUS OS // IN MOTION</span>
            </div>
            
            <h2 className="text-2xl sm:text-4xl lg:text-5xl font-bold text-white tracking-tight font-heading leading-tight">
              Instant Campus Exchange. <br className="hidden sm:inline" />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#00f2ff] via-[#4ff5ff] to-[#c084fc] drop-shadow-[0_0_30px_rgba(0,242,255,0.35)]">
                Everything connected at the speed of thought.
              </span>
            </h2>
          </div>

          <div className="flex flex-wrap items-center gap-2.5 sm:gap-3 shrink-0">
            <div className="text-[11px] sm:text-xs font-mono-tech text-white/70 bg-white/[0.04] px-3.5 py-2 rounded-full border border-white/10 flex items-center gap-2 whitespace-nowrap">
              <span className="w-2 h-2 rounded-full bg-[#22c55e] animate-ping" />
              <span>#1 ON DTU NODES: 2,400+ SYNCED</span>
            </div>

            <button
              id="walkthrough-embed-video-btn"
              onClick={() => setShowCustomUrlInput(!showCustomUrlInput)}
              className="text-[11px] sm:text-xs font-mono-tech font-semibold tracking-wide text-[#00f2ff] hover:text-white bg-[#00f2ff]/10 hover:bg-[#00f2ff]/25 active:bg-[#00f2ff]/30 px-3.5 py-2 rounded-full border border-[#00f2ff]/35 hover:border-[#00f2ff]/70 shadow-[0_0_15px_rgba(0,242,255,0.15)] hover:shadow-[0_0_25px_rgba(0,242,255,0.35)] transition-all duration-200 cursor-pointer flex items-center gap-1.5 select-none hover:scale-[1.02] active:scale-[0.98] whitespace-nowrap"
              title="Embed or switch video stream"
            >
              <Video className="w-3.5 h-3.5 text-[#00f2ff] shrink-0" />
              <span className="whitespace-nowrap">{activeCustomEmbed ? 'Switch to Dynamic 4K' : 'Embed Custom Video'}</span>
            </button>
          </div>
        </div>

        {/* Custom Video URL Input Modal / Dropdown */}
        {showCustomUrlInput && (
          <form onSubmit={handleCustomVideoSubmit} className="mb-8 p-4 rounded-2xl bg-[#0b101d] border border-[#00f2ff]/30 flex flex-wrap items-center gap-3 animate-fade-in shadow-2xl">
            <input
              type="text"
              placeholder="Paste YouTube, Vimeo, or MP4 URL here..."
              value={customVideoUrl}
              onChange={(e) => setCustomVideoUrl(e.target.value)}
              className="flex-1 min-w-[240px] px-4 py-2.5 rounded-xl bg-black/60 border border-white/15 text-white text-sm focus:outline-none focus:border-[#00f2ff]"
            />
            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl bg-[#00f2ff] hover:bg-[#00f2ff]/80 text-black font-bold text-xs uppercase tracking-wider font-mono-tech cursor-pointer transition-all"
            >
              Load Video
            </button>
            {activeCustomEmbed && (
              <button
                type="button"
                onClick={() => {
                  setActiveCustomEmbed(null);
                  setShowCustomUrlInput(false);
                }}
                className="px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-medium cursor-pointer"
              >
                Reset to 4K Dynamic Engine
              </button>
            )}
          </form>
        )}

        {/* ========================================================================= */}
        {/* CINEMATIC FRAMER-STYLE VIDEO CONTAINER */}
        {/* ========================================================================= */}
        <div 
          ref={containerRef}
          className="relative rounded-3xl overflow-hidden border border-white/15 bg-[#070a14] shadow-[0_20px_80px_rgba(0,0,0,0.85)] group"
        >
          {/* Top Glassmorphic Navigation Bar inside Video Frame */}
          <div className="px-4 sm:px-6 py-3.5 bg-[#050711]/90 backdrop-blur-xl border-b border-white/10 flex flex-wrap items-center justify-between gap-3 relative z-30">
            
            {/* Chapter Selection Pills (like Framer's top bar tabs) */}
            <div className="flex items-center gap-2 overflow-x-auto pb-1 sm:pb-0 no-scrollbar">
              {SCENES.map((scene, idx) => {
                const isActive = activeSceneIdx === idx;
                return (
                  <button
                    key={scene.id}
                    onClick={() => {
                      setActiveSceneIdx(idx);
                      playSciFiSound(600 + idx * 80, 'sine', 0.05);
                    }}
                    className={`px-3.5 py-1.5 rounded-full text-xs font-mono-tech font-semibold uppercase tracking-wider transition-all duration-200 cursor-pointer flex items-center gap-2 whitespace-nowrap ${
                      isActive 
                        ? 'bg-white text-black shadow-[0_0_20px_rgba(255,255,255,0.4)] scale-[1.03]' 
                        : 'bg-white/[0.04] hover:bg-white/[0.08] text-white/70 border border-white/10'
                    }`}
                  >
                    <span className={isActive ? 'text-black' : 'text-[#00f2ff]'}>{scene.chapterNumber}</span>
                    <span>{scene.title.split(' ')[0]} {scene.title.split(' ')[1]}</span>
                  </button>
                );
              })}
            </div>

            {/* Top Right Controls: Speed, Audio, Fullscreen */}
            <div className="flex items-center gap-2 ml-auto">
              
              {/* 4K 60FPS Badge */}
              <span className="hidden sm:inline-flex px-2.5 py-1 rounded-md bg-[#00f2ff]/10 text-[#00f2ff] text-[10px] font-mono-tech uppercase font-bold border border-[#00f2ff]/20">
                4K 60FPS
              </span>

              {/* Playback Speed Selector */}
              <button
                onClick={() => {
                  const nextSpeed = playbackSpeed === 1 ? 1.5 : playbackSpeed === 1.5 ? 2 : 1;
                  setPlaybackSpeed(nextSpeed);
                  playSciFiSound(700, 'square', 0.04);
                }}
                className="px-2.5 py-1 rounded-md bg-white/[0.05] hover:bg-white/10 text-white/80 text-xs font-mono-tech uppercase border border-white/10 transition-all cursor-pointer"
                title="Change Playback Speed"
              >
                {playbackSpeed}x
              </button>

              {/* Sound Toggle with Interactive Waveform */}
              <button
                onClick={() => {
                  setIsMuted(!isMuted);
                  if (isMuted) playSciFiSound(660, 'sine', 0.1);
                }}
                className={`p-1.5 rounded-lg border transition-all cursor-pointer ${
                  !isMuted 
                    ? 'bg-[#00f2ff]/20 border-[#00f2ff]/40 text-[#00f2ff]' 
                    : 'bg-white/[0.05] border-white/10 text-white/60 hover:text-white'
                }`}
                title={isMuted ? 'Unmute Sound FX' : 'Mute Sound FX'}
              >
                {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
              </button>

              {/* Fullscreen Expand */}
              <button
                onClick={toggleFullscreen}
                className="p-1.5 rounded-lg bg-white/[0.05] hover:bg-white/10 text-white/70 hover:text-white border border-white/10 transition-all cursor-pointer"
                title="Toggle Fullscreen"
              >
                {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* ========================================================================= */}
          {/* VIDEO CANVAS / SCREEN DISPLAY */}
          {/* ========================================================================= */}
          <div className="relative min-h-[460px] sm:min-h-[580px] lg:min-h-[640px] flex items-center justify-center p-6 sm:p-12 overflow-hidden">
            
            {activeCustomEmbed ? (
              <iframe
                src={activeCustomEmbed}
                title="Campus Tutorial Walkthrough"
                className="absolute inset-0 w-full h-full border-0 z-20"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              />
            ) : (
              <>
                {/* 60FPS High Performance Particle Canvas Background */}
                <canvas ref={canvasRef} className="absolute inset-0 w-full h-full z-0 pointer-events-none" />

                {/* Cybernetic Grid Perspective Floor Overlay */}
                <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(0,242,255,0.06)_0%,transparent_70%)] pointer-events-none z-0" />

                {/* Animated Futuristic Card Mockup matching Framer's "black homepag|" video */}
                <div className="relative z-10 w-full max-w-4xl rounded-2xl border border-white/15 bg-[#0c1222]/90 backdrop-blur-2xl p-6 sm:p-10 shadow-[0_0_80px_rgba(0,0,0,0.9)] transition-all duration-500">
                  
                  {/* Card Top Pill Badge */}
                  <div className="flex items-center justify-between mb-8 pb-4 border-b border-white/10">
                    <div className="flex items-center gap-3">
                      <span className="w-3 h-3 rounded-full bg-[#00f2ff] animate-ping" />
                      <span className="text-xs font-mono-tech uppercase font-bold text-[#00f2ff] tracking-widest">
                        {currentScene.badge}
                      </span>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className="text-xs text-white/50 font-mono-tech">{currentScene.metricLabel}:</span>
                      <span className="text-xs font-bold font-mono-tech text-[#22c55e] bg-[#22c55e]/10 px-2.5 py-0.5 rounded border border-[#22c55e]/30">
                        {currentScene.metricValue}
                      </span>
                    </div>
                  </div>

                  {/* KINETIC TYPING TERMINAL PROMPT (The core energetic element in Framer's reference) */}
                  <div className="mb-8">
                    <div className="text-xs font-mono-tech text-white/40 uppercase tracking-widest mb-3 flex items-center gap-2">
                      <Code2 className="w-3.5 h-3.5 text-[#00f2ff]" />
                      <span>Live Prompt Input</span>
                    </div>

                    <div className="min-h-[70px] sm:min-h-[90px] flex items-center">
                      <h3 className="text-2xl sm:text-4xl lg:text-5xl font-bold font-heading text-white tracking-tight leading-tight flex items-center flex-wrap">
                        <span>{typedText}</span>
                        <span className="inline-block w-3 sm:w-4 h-7 sm:h-11 bg-[#00f2ff] ml-1.5 animate-pulse shadow-[0_0_15px_#00f2ff]" />
                      </h3>
                    </div>
                  </div>

                  {/* HIGH-TECH RESPONSE GENERATION CARD (Simulated Instant Match) */}
                  <div className={`rounded-xl border border-white/10 bg-black/50 p-4 sm:p-6 transition-all duration-500 ${isTypingComplete ? 'opacity-100 translate-y-0 shadow-[0_0_40px_rgba(0,242,255,0.15)]' : 'opacity-40 translate-y-2'}`}>
                    <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                      
                      {/* Avatar & Match Details */}
                      <div className="flex items-center gap-4">
                        <div className="relative">
                          <img 
                            src={currentScene.avatar} 
                            alt="Peer Avatar" 
                            className="w-12 h-12 sm:w-14 sm:h-14 rounded-full object-cover border-2 border-[#00f2ff]"
                          />
                          <span className="absolute -bottom-1 -right-1 p-0.5 bg-[#00f2ff] rounded-full text-black">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                          </span>
                        </div>

                        <div>
                          <div className="flex items-center gap-2">
                            <span className="text-sm sm:text-base font-bold text-white font-heading">{currentScene.actionText}</span>
                            <ShieldCheck className="w-4 h-4 text-[#22c55e]" />
                          </div>
                          <div className="text-xs text-white/50 font-mono-tech mt-0.5">
                            {currentScene.hostel}
                          </div>
                        </div>
                      </div>

                      {/* Tag Badges */}
                      <div className="flex flex-wrap items-center gap-2">
                        {currentScene.tags.map((tag, tIdx) => (
                          <span 
                            key={tIdx} 
                            className="px-2.5 py-1 rounded-md bg-white/[0.05] border border-white/10 text-[11px] font-mono-tech text-white/80"
                          >
                            {tag}
                          </span>
                        ))}
                      </div>

                    </div>
                  </div>

                </div>
              </>
            )}

          </div>

          {/* ========================================================================= */}
          {/* BOTTOM INTERACTIVE SCRUBBER CONTROLS & TIMELINE */}
          {/* ========================================================================= */}
          <div className="px-4 sm:px-6 py-4 bg-[#050711]/95 backdrop-blur-xl border-t border-white/10 relative z-30">
            
            {/* Smooth Progress Bar with Scrubber Indicator */}
            <div 
              className="w-full h-2 bg-white/10 rounded-full mb-4 cursor-pointer relative overflow-hidden group/scrubber"
              onClick={(e) => {
                const rect = e.currentTarget.getBoundingClientRect();
                const clickPos = (e.clientX - rect.left) / rect.width;
                const newIdx = Math.floor(clickPos * SCENES.length);
                setActiveSceneIdx(Math.min(SCENES.length - 1, Math.max(0, newIdx)));
                playSciFiSound(550, 'triangle', 0.05);
              }}
            >
              <div 
                className="h-full bg-gradient-to-r from-[#00f2ff] via-[#4ff5ff] to-[#c084fc] rounded-full transition-all duration-100 shadow-[0_0_15px_#00f2ff]"
                style={{ width: `${((activeSceneIdx + progressPercent / 100) / SCENES.length) * 100}%` }}
              />
            </div>

            <div className="flex items-center justify-between gap-4">
              
              {/* Play / Pause / Reset Buttons */}
              <div className="flex items-center gap-3">
                <button
                  onClick={() => {
                    setIsPlaying(!isPlaying);
                    playSciFiSound(isPlaying ? 400 : 700, 'sine', 0.04);
                  }}
                  className="w-10 h-10 rounded-full bg-white hover:bg-zinc-200 text-black flex items-center justify-center transition-all cursor-pointer shadow-[0_0_20px_rgba(255,255,255,0.4)]"
                  title={isPlaying ? 'Pause Simulation' : 'Play Simulation'}
                >
                  {isPlaying ? <Pause className="w-4 h-4 fill-current" /> : <Play className="w-4 h-4 fill-current ml-0.5" />}
                </button>

                <button
                  onClick={() => {
                    setActiveSceneIdx(0);
                    setProgressPercent(0);
                    playSciFiSound(500, 'square', 0.05);
                  }}
                  className="p-2.5 rounded-full bg-white/[0.05] hover:bg-white/10 text-white/70 hover:text-white border border-white/10 transition-all cursor-pointer"
                  title="Restart Walkthrough"
                >
                  <RotateCcw className="w-4 h-4" />
                </button>

                <div className="text-xs font-mono-tech text-white/60 hidden sm:block">
                  <span className="text-[#00f2ff] font-bold">0{activeSceneIdx + 1}</span> / 0{SCENES.length} • {currentScene.title}
                </div>
              </div>

              {/* Quick Jump / Next Scene Button */}
              <button
                onClick={() => {
                  setActiveSceneIdx((prev) => (prev + 1) % SCENES.length);
                  playSciFiSound(750, 'sine', 0.04);
                }}
                className="px-4 py-2 rounded-full bg-[#00f2ff]/10 hover:bg-[#00f2ff]/20 text-[#00f2ff] border border-[#00f2ff]/30 text-xs font-mono-tech font-bold uppercase tracking-wider flex items-center gap-1.5 transition-all cursor-pointer"
              >
                <span>Next Scene</span>
                <FastForward className="w-3.5 h-3.5" />
              </button>

            </div>
          </div>

        </div>

        {/* Feature Highlights Grid Below Video */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-10">
          
          <div className="p-6 rounded-2xl bg-white/[0.02] border border-white/[0.08] backdrop-blur-md">
            <div className="w-10 h-10 rounded-xl bg-[#00f2ff]/10 border border-[#00f2ff]/30 flex items-center justify-center text-[#00f2ff] mb-4">
              <Zap className="w-5 h-5" />
            </div>
            <h4 className="text-lg font-bold text-white font-heading">Sub-Second Semantic Match</h4>
            <p className="text-sm text-slate-400 mt-1.5 leading-relaxed font-normal">
              COMPASS AI routes borrowing, mentorship, and squad formation requests across your campus in under 200ms.
            </p>
          </div>

          <div className="p-6 rounded-2xl bg-white/[0.02] border border-white/[0.08] backdrop-blur-md">
            <div className="w-10 h-10 rounded-xl bg-[#c084fc]/10 border border-[#c084fc]/30 flex items-center justify-center text-[#c084fc] mb-4">
              <Layers className="w-5 h-5" />
            </div>
            <h4 className="text-lg font-bold text-white font-heading">Zero Platform Fees</h4>
            <p className="text-sm text-slate-400 mt-1.5 leading-relaxed font-normal">
              100% of marketplace transactions remain directly between student peers with instant hostel and library handoffs.
            </p>
          </div>

          <div className="p-6 rounded-2xl bg-white/[0.02] border border-white/[0.08] backdrop-blur-md">
            <div className="w-10 h-10 rounded-xl bg-[#22c55e]/10 border border-[#22c55e]/30 flex items-center justify-center text-[#22c55e] mb-4">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <h4 className="text-lg font-bold text-white font-heading">Verified Campus Security</h4>
            <p className="text-sm text-slate-400 mt-1.5 leading-relaxed font-normal">
              Institutional email single-sign-on guarantees 99.98% return compliance with zero risk of bad actors.
            </p>
          </div>

        </div>

      </div>
    </section>
  );
};

```

---

## File: `src/components/VideoModal.tsx`

```tsx
import React, { useState, useEffect } from 'react';
import { X, Play, Pause, Volume2, VolumeX, Maximize2, Sparkles, Radio } from 'lucide-react';

interface VideoModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const VideoModal: React.FC<VideoModalProps> = ({ isOpen, onClose }) => {
  const [isPlaying, setIsPlaying] = useState(true);
  const [isMuted, setIsMuted] = useState(false);
  const [playbackTime, setPlaybackTime] = useState(12);

  useEffect(() => {
    if (!isOpen || !isPlaying) return;
    const interval = setInterval(() => {
      setPlaybackTime((prev) => (prev >= 60 ? 0 : prev + 1));
    }, 1000);
    return () => clearInterval(interval);
  }, [isOpen, isPlaying]);

  if (!isOpen) return null;

  const scenes = [
    { at: 0, text: '00:00 // INTRODUCING THE CAMPUS NEURAL GRAPH' },
    { at: 15, text: '00:15 // DIRECT PEER-TO-PEER RESOURCE SWAPPING' },
    { at: 30, text: '00:30 // RESEARCH RECRUITMENT & MULTIDISCIPLINARY LABS' },
    { at: 45, text: '00:45 // IMPACT KARMA ACCELERATING CAMPUS COHESION' },
  ];

  const currentScene = scenes.slice().reverse().find((s) => playbackTime >= s.at)?.text || scenes[0].text;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-lg">
      <div className="relative w-full max-w-4xl bg-black border border-cyan-400/40 rounded-2xl overflow-hidden shadow-2xl">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-20 p-2 rounded-lg bg-black/70 border border-white/20 text-white hover:bg-white hover:text-black transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Video Canvas Container with Sci-Fi HUD Overlays */}
        <div className="relative aspect-video w-full bg-zinc-950 flex items-center justify-center overflow-hidden">
          {/* Animated Background Simulation */}
          <div className="absolute inset-0 bg-gradient-to-tr from-cyan-950/40 via-violet-950/40 to-black animate-pulse-slow" />

          {/* Futuristic Animated Wireframe Mesh */}
          <div className="absolute inset-0 flex items-center justify-center opacity-30">
            <div className="w-[600px] h-[600px] border border-cyan-400/40 rounded-full animate-spin-slow" />
            <div className="absolute w-[450px] h-[450px] border border-violet-400/30 rounded-full animate-spin" />
            <div className="absolute w-[300px] h-[300px] border border-cyan-400/20 rounded-full" />
          </div>

          {/* Center Brand Title */}
          <div className="relative z-10 text-center space-y-3 px-6">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-950/60 border border-cyan-400/40 text-cyan-300 text-xs font-mono-tech tracking-widest uppercase">
              <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-ping" />
              CINEMATIC PREVIEW
            </div>

            <h1 className="text-3xl sm:text-6xl font-extrabold text-white tracking-tight font-heading">
              ON CAMPUS
            </h1>

            <p className="text-sm sm:text-lg text-zinc-300 font-light max-w-lg mx-auto">
              Everything your campus has. Connected into a single unified operating layer.
            </p>
          </div>

          {/* HUD Top Left */}
          <div className="absolute top-4 left-4 z-10 font-mono-tech text-[10px] text-cyan-400 bg-black/60 px-3 py-1.5 rounded border border-cyan-400/20">
            <div>REC ● [4K CINEMA] 60FPS</div>
            <div className="text-zinc-400">{currentScene}</div>
          </div>

          {/* HUD Bottom Telemetry */}
          <div className="absolute bottom-16 left-4 right-4 z-10 flex items-center justify-between font-mono-tech text-[10px] text-zinc-400 px-2">
            <span>NODES: 1,842 ACTIVE</span>
            <span className="text-cyan-400">LATENCY: 12ms</span>
            <span>CAMPUS: NIT CALICUT CLUSTER</span>
          </div>

          {/* Video Control Bar */}
          <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black via-black/80 to-transparent z-20 flex flex-col gap-2">
            {/* Progress Scrub Bar */}
            <div className="w-full h-1 bg-zinc-800 rounded-full overflow-hidden cursor-pointer">
              <div
                className="h-full bg-cyan-400 transition-all duration-300"
                style={{ width: `${(playbackTime / 60) * 100}%` }}
              />
            </div>

            <div className="flex items-center justify-between text-xs font-mono-tech text-zinc-300">
              <div className="flex items-center gap-3">
                <button
                  onClick={() => setIsPlaying(!isPlaying)}
                  className="p-1.5 rounded hover:bg-white/10 text-white cursor-pointer"
                >
                  {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 fill-white" />}
                </button>

                <button
                  onClick={() => setIsMuted(!isMuted)}
                  className="p-1.5 rounded hover:bg-white/10 text-white cursor-pointer"
                >
                  {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                </button>

                <span>
                  00:{String(playbackTime).padStart(2, '0')} / 01:00
                </span>
              </div>

              <div className="text-cyan-400">
                PRODUCED BY ON CAMPUS LABS
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

```

---

## File: `src/components/views/BorrowView.tsx`

```tsx
import React, { useState } from 'react';
import { 
  HandCoins, 
  Search, 
  Filter, 
  MapPin, 
  ShieldCheck, 
  Clock, 
  Plus, 
  CheckCircle, 
  AlertCircle,
  Cpu,
  Book,
  Camera,
  Layers,
  ArrowRight
} from 'lucide-react';
import { BorrowItem, UserProfile } from '../../types';

interface BorrowViewProps {
  items: BorrowItem[];
  currentUser: UserProfile;
  onRequestBorrow: (itemId: string, durationDays: number) => void;
  onAddBorrowItem: (item: Omit<BorrowItem, 'id' | 'available'>) => void;
}

export const BorrowView: React.FC<BorrowViewProps> = ({
  items,
  currentUser,
  onRequestBorrow,
  onAddBorrowItem,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedItemId, setSelectedItemId] = useState<string | null>(null);
  const [borrowDays, setBorrowDays] = useState<number>(3);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Lend form toggle & state
  const [isLendFormOpen, setIsLendFormOpen] = useState<boolean>(false);
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<BorrowItem['category']>('Electronics');
  const [location, setLocation] = useState('');
  const [maxDays, setMaxDays] = useState(7);
  const [depositRequired, setDepositRequired] = useState('Campus ID');
  const [description, setDescription] = useState('');

  const categories: string[] = ['All', 'Electronics', 'Calculators', 'Books', 'Gear', 'Lab Equipment'];

  const filteredItems = items.filter((item) => {
    const matchesCat = selectedCategory === 'All' || item.category.toLowerCase() === selectedCategory.toLowerCase();
    const matchesSearch = item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          item.location.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          (item.description && item.description.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesCat && matchesSearch;
  });

  const handleBorrowSubmit = (id: string) => {
    onRequestBorrow(id, borrowDays);
    setSuccessMsg('Borrow request confirmed! Connect with peer for instant locker / lab pickup.');
    setTimeout(() => {
      setSuccessMsg(null);
      setSelectedItemId(null);
    }, 2500);
  };

  const handleLendSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !location) return;

    onAddBorrowItem({
      title,
      category,
      location,
      ownerName: `${currentUser.name} (Verified)`,
      ownerVerified: true,
      maxDays,
      depositRequired,
      description,
    });

    setSuccessMsg('Your hardware/book is now listed in the campus inventory! +40 Karma pts awarded.');
    setTitle('');
    setLocation('');
    setDescription('');
    setIsLendFormOpen(false);
    setTimeout(() => setSuccessMsg(null), 3000);
  };

  return (
    <div id="borrow-view-container" className="space-y-6">
      {/* Header Banner */}
      <div className="bg-[#121212] border border-white/[0.08] border-t-2 border-t-[#00f2ff] p-6 rounded-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-[10px] font-mono-tech text-[#00f2ff] tracking-[3px] uppercase font-bold">
            <HandCoins className="w-4 h-4 text-[#00f2ff]" />
            <span>CAMPUS LENDING & LAB PROTOCOL</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-black text-white font-heading mt-1">
            BORROW & SHARE INVENTORY
          </h2>
          <p className="text-sm text-white/60 mt-1 max-w-xl font-normal">
            Need an Arduino, scientific calculator, DSLR, or GPU lab pass for 48 hours? Zero rental fees — powered by verified campus trust.
          </p>
        </div>

        <button
          id="lend-item-toggle-btn"
          onClick={() => setIsLendFormOpen(!isLendFormOpen)}
          className="inline-flex items-center gap-2 px-5 py-3 bg-[#00f2ff] hover:bg-[#00f2ff]/80 text-black font-bold text-xs font-mono-tech tracking-[2px] uppercase rounded-sm transition-all cursor-pointer shadow-[0_0_20px_rgba(0,242,255,0.25)] shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>{isLendFormOpen ? 'CLOSE FORM' : '+ LEND EQUIPMENT'}</span>
        </button>
      </div>

      {/* Success Notification Alert */}
      {successMsg && (
        <div className="p-4 bg-[#00f2ff]/10 border border-[#00f2ff] rounded-sm text-xs font-mono-tech text-[#00f2ff] flex items-center gap-2">
          <CheckCircle className="w-4 h-4 text-[#00f2ff] shrink-0" />
          <span>{successMsg}</span>
        </div>
      )}

      {/* Lend Form Collapse */}
      {isLendFormOpen && (
        <form
          onSubmit={handleLendSubmit}
          className="p-6 bg-[#121212] border border-[#00f2ff]/40 rounded-sm space-y-4 shadow-xl"
        >
          <div className="text-xs font-mono-tech text-[#00f2ff] font-bold tracking-[2px] uppercase">
            LIST ITEM FOR PEER BORROWING
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-[10px] font-mono-tech text-white/50 mb-1">
                ITEM TITLE & MODEL *
              </label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g. Casio fx-991EX Calculator / STM32 Board"
                required
                className="w-full px-3 py-2 bg-[#050505] border border-white/10 rounded-sm text-xs text-white focus:outline-none focus:border-[#00f2ff] font-mono-tech"
              />
            </div>

            <div>
              <label className="block text-[10px] font-mono-tech text-white/50 mb-1">
                CATEGORY *
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as BorrowItem['category'])}
                className="w-full px-3 py-2 bg-[#050505] border border-white/10 rounded-sm text-xs text-white focus:outline-none focus:border-[#00f2ff] font-mono-tech"
              >
                <option value="Electronics">Electronics</option>
                <option value="Calculators">Calculators</option>
                <option value="Books">Books</option>
                <option value="Gear">Gear</option>
                <option value="Lab Equipment">Lab Equipment</option>
              </select>
            </div>

            <div>
              <label className="block text-[10px] font-mono-tech text-white/50 mb-1">
                PICKUP CAMPUS LOCATION *
              </label>
              <input
                type="text"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                placeholder="e.g. EC Lab 2 / Aryabhatta Hostel A-304"
                required
                className="w-full px-3 py-2 bg-[#050505] border border-white/10 rounded-sm text-xs text-white focus:outline-none focus:border-[#00f2ff] font-mono-tech"
              />
            </div>

            <div>
              <label className="block text-[10px] font-mono-tech text-white/50 mb-1">
                MAX BORROW WINDOW (DAYS)
              </label>
              <input
                type="number"
                min="1"
                max="30"
                value={maxDays}
                onChange={(e) => setMaxDays(Number(e.target.value))}
                className="w-full px-3 py-2 bg-[#050505] border border-white/10 rounded-sm text-xs text-white focus:outline-none focus:border-[#00f2ff] font-mono-tech"
              />
            </div>
          </div>

          <div>
            <label className="block text-[10px] font-mono-tech text-white/50 mb-1">
              DESCRIPTION / CONDITION NOTES
            </label>
            <textarea
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Includes power adapter, USB-C cable. Please return with original box."
              className="w-full px-3 py-2 bg-[#050505] border border-white/10 rounded-sm text-xs text-white focus:outline-none focus:border-[#00f2ff] font-mono-tech"
            />
          </div>

          <div className="flex justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={() => setIsLendFormOpen(false)}
              className="px-4 py-2 bg-[#050505] border border-white/10 text-white/60 text-xs font-mono-tech rounded-sm cursor-pointer"
            >
              CANCEL
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-[#00f2ff] hover:bg-[#00f2ff]/80 text-black font-bold text-xs font-mono-tech uppercase tracking-[1px] rounded-sm cursor-pointer"
            >
              PUBLISH TO CAMPUS INVENTORY
            </button>
          </div>
        </form>
      )}

      {/* Filter and Search Bar */}
      <div className="flex flex-col md:flex-row items-center justify-between gap-4 p-3 bg-[#121212] border border-white/[0.08] rounded-sm">
        {/* Search */}
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-white/40 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search items, locations, hardware..."
            className="w-full pl-9 pr-3 py-2 bg-[#050505] border border-white/10 rounded-sm text-xs text-white focus:outline-none focus:border-[#00f2ff] font-mono-tech"
          />
        </div>

        {/* Categories */}
        <div className="flex items-center gap-1.5 overflow-x-auto w-full md:w-auto">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 text-xs font-mono-tech tracking-[1px] uppercase rounded-sm transition-all cursor-pointer whitespace-nowrap ${
                selectedCategory === cat
                  ? 'bg-[#00f2ff]/20 border border-[#00f2ff] text-[#00f2ff] font-bold'
                  : 'bg-[#050505] border border-white/5 text-white/50 hover:text-white'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Inventory Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredItems.map((item) => {
          const isSelected = selectedItemId === item.id;

          return (
            <div
              key={item.id}
              id={`borrow-item-${item.id}`}
              className={`p-5 rounded-sm bg-[#121212] border transition-all duration-200 flex flex-col justify-between ${
                item.available
                  ? 'border-white/[0.08] hover:border-[#00f2ff]'
                  : 'border-white/5 opacity-60'
              }`}
            >
              <div>
                <div className="flex items-center justify-between gap-2 pb-3 mb-3 border-b border-white/[0.06]">
                  <span className="text-[10px] font-mono-tech text-white/50 uppercase tracking-[1px]">
                    {item.category}
                  </span>
                  {item.available ? (
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-sm bg-[#00f2ff]/10 border border-[#00f2ff]/30 text-[9px] font-mono-tech text-[#00f2ff] font-bold">
                      <span className="w-1.5 h-1.5 rounded-full bg-[#00f2ff] animate-ping" />
                      AVAILABLE NOW
                    </span>
                  ) : (
                    <span className="px-2 py-0.5 rounded-sm bg-[#050505] text-[9px] font-mono-tech text-white/40">
                      CHECKED OUT
                    </span>
                  )}
                </div>

                <h3 className="text-base font-bold text-white font-heading mb-1.5">
                  {item.title}
                </h3>
                {item.description && (
                  <p className="text-xs text-white/60 line-clamp-2 mb-3">
                    {item.description}
                  </p>
                )}

                <div className="space-y-1.5 text-xs font-mono-tech text-white/60 mt-3 pt-3 border-t border-white/[0.04]">
                  <div className="flex items-center gap-2">
                    <MapPin className="w-3.5 h-3.5 text-[#00f2ff]" />
                    <span>{item.location}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="w-3.5 h-3.5 text-[#bc13fe]" />
                    <span>Max {item.maxDays} days borrow limit</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <ShieldCheck className="w-3.5 h-3.5 text-[#00f2ff]" />
                    <span>Deposit: {item.depositRequired || 'Campus ID'}</span>
                  </div>
                </div>
              </div>

              {/* Action Area */}
              <div className="mt-5 pt-4 border-t border-white/[0.06]">
                {item.available ? (
                  isSelected ? (
                    <div className="space-y-3 bg-[#050505] p-3 rounded-sm border border-[#00f2ff]/30">
                      <div className="flex items-center justify-between text-xs font-mono-tech text-white">
                        <span>Duration: {borrowDays} days</span>
                        <input
                          type="range"
                          min="1"
                          max={item.maxDays}
                          value={borrowDays}
                          onChange={(e) => setBorrowDays(Number(e.target.value))}
                          className="w-24 accent-[#00f2ff]"
                        />
                      </div>
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => setSelectedItemId(null)}
                          className="flex-1 py-1.5 bg-[#121212] text-white/60 text-xs font-mono-tech rounded-sm"
                        >
                          Cancel
                        </button>
                        <button
                          onClick={() => handleBorrowSubmit(item.id)}
                          className="flex-1 py-1.5 bg-[#00f2ff] text-black font-bold text-xs font-mono-tech rounded-sm uppercase cursor-pointer"
                        >
                          Confirm Request
                        </button>
                      </div>
                    </div>
                  ) : (
                    <button
                      onClick={() => { setSelectedItemId(item.id); setBorrowDays(Math.min(3, item.maxDays)); }}
                      className="w-full py-2 bg-white hover:bg-zinc-200 text-black font-bold text-xs font-mono-tech tracking-[2px] uppercase rounded-sm transition-all cursor-pointer flex items-center justify-center gap-2"
                    >
                      <span>REQUEST TO BORROW</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  )
                ) : (
                  <button
                    disabled
                    className="w-full py-2 bg-[#050505] text-white/40 text-xs font-mono-tech uppercase rounded-sm cursor-not-allowed text-center"
                  >
                    RETURN DUE IN 2 DAYS
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

```

---

## File: `src/components/views/CompassView.tsx`

```tsx
import React, { useState, useRef, useEffect } from 'react';
import { 
  Compass, 
  Send, 
  Sparkles, 
  Loader2, 
  ArrowUpRight, 
  Terminal, 
  HelpCircle,
  Cpu,
  BookOpen,
  ShoppingBag,
  Layers3,
  Flame,
  CheckCircle2
} from 'lucide-react';
import { CompassMessage, UserProfile } from '../../types';

interface CompassViewProps {
  messages: CompassMessage[];
  isLoading: boolean;
  currentUser: UserProfile;
  onSendMessage: (text: string) => void;
  onSelectActionCard?: (type: string, targetId?: string) => void;
}

export const CompassView: React.FC<CompassViewProps> = ({
  messages,
  isLoading,
  currentUser,
  onSendMessage,
  onSelectActionCard,
}) => {
  const [inputText, setInputText] = useState('');
  const chatContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTo({
        top: chatContainerRef.current.scrollHeight,
        behavior: 'smooth',
      });
    }
  }, [messages, isLoading]);

  const handleSend = () => {
    if (!inputText.trim() || isLoading) return;
    onSendMessage(inputText.trim());
    setInputText('');
  };

  const presetQueries = [
    'Where can I borrow a digital multimeter or Arduino board today?',
    'What are the past exam patterns and lab tips for Prof. Raman?',
    'Find peer tutors available for Data Structures & Algorithms',
    'Who is recruiting for robotics and autonomous drone research?',
    'Recommend top affordable textbooks listed in the marketplace',
    'Explain how to get GPU cluster access for AI model training'
  ];

  return (
    <div id="compass-view-container" className="space-y-6">
      {/* Header Banner */}
      <div className="bg-[#121212] border border-white/[0.08] border-t-2 border-t-[#00f2ff] p-6 rounded-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-[10px] font-mono-tech text-[#00f2ff] tracking-[3px] uppercase font-bold">
            <Compass className="w-4 h-4 text-[#00f2ff] animate-spin-slow" />
            <span>NEURAL CAMPUS ASSISTANT // LIVE</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-black text-white font-heading mt-1">
            COMPASS AI WORKSPACE
          </h2>
          <p className="text-sm text-white/60 mt-1 max-w-xl font-normal">
            Your instant cognitive campus copilot. Ask about lab inventory, course guidelines, senior intel, peer skills, and campus deadlines.
          </p>
        </div>

        <div className="flex items-center gap-2 px-3.5 py-1.5 rounded-sm bg-[#00f2ff]/10 border border-[#00f2ff]/30 text-xs font-mono-tech text-[#00f2ff] font-bold">
          <span className="w-2 h-2 rounded-full bg-[#00f2ff] animate-ping" />
          <span>DTU CAMPUS REPO INDEXED</span>
        </div>
      </div>

      {/* Main Chat Interface */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left 8 Cols: Full Chat Thread */}
        <div className="lg:col-span-8 bg-[#121212] border border-white/[0.08] rounded-sm p-6 flex flex-col justify-between min-h-[600px] shadow-2xl">
          {/* Messages scroll box */}
          <div ref={chatContainerRef} className="space-y-5 overflow-y-auto max-h-[500px] pr-2 mb-6">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex flex-col ${
                  msg.sender === 'user' ? 'items-end' : 'items-start'
                }`}
              >
                <div
                  className={`max-w-[90%] p-4 rounded-sm text-xs sm:text-sm leading-relaxed ${
                    msg.sender === 'user'
                      ? 'bg-white text-black font-semibold shadow-lg'
                      : 'bg-[#050505] border border-white/[0.08] text-white/90'
                  }`}
                >
                  {msg.sender === 'compass' && (
                    <div className="flex items-center gap-2 text-[10px] font-mono-tech text-[#00f2ff] uppercase tracking-[2px] mb-2 font-bold">
                      <Sparkles className="w-3.5 h-3.5 text-[#00f2ff]" />
                      <span>COMPASS // NEURAL INDEX</span>
                    </div>
                  )}

                  <p className="whitespace-pre-line font-mono-tech text-xs sm:text-sm">
                    {msg.text}
                  </p>

                  {/* Suggestion Action Cards */}
                  {msg.actionCards && msg.actionCards.length > 0 && (
                    <div className="mt-3 pt-3 border-t border-white/[0.08] space-y-2">
                      <div className="text-[10px] font-mono-tech text-[#bc13fe] uppercase tracking-wider font-bold">
                        ACTIONABLE CAMPUS SHORTCUTS:
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        {msg.actionCards.map((card, idx) => (
                          <div
                            key={idx}
                            onClick={() =>
                              onSelectActionCard &&
                              onSelectActionCard(card.type, card.targetId)
                            }
                            className="p-3 rounded-sm bg-[#121212] border border-[#00f2ff]/30 hover:border-[#00f2ff] text-left transition-all cursor-pointer flex items-center justify-between gap-2 group"
                          >
                            <div>
                              <span className="text-[9px] font-mono-tech text-[#00f2ff] uppercase px-1.5 py-0.2 rounded-sm bg-[#00f2ff]/10 font-bold">
                                {card.tag}
                              </span>
                              <div className="text-xs font-bold text-white mt-1 group-hover:text-[#00f2ff] transition-colors font-heading">
                                {card.title}
                              </div>
                              <div className="text-[10px] text-white/50">
                                {card.subtitle}
                              </div>
                            </div>
                            <ArrowUpRight className="w-4 h-4 text-[#00f2ff] group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform shrink-0" />
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
                <span className="text-[9px] font-mono-tech text-white/40 mt-1 px-1">
                  {msg.timestamp}
                </span>
              </div>
            ))}

            {isLoading && (
              <div className="flex items-center gap-2.5 p-3.5 bg-[#050505] border border-white/[0.08] rounded-sm text-xs font-mono-tech text-[#00f2ff]">
                <Loader2 className="w-4 h-4 animate-spin text-[#00f2ff]" />
                <span>COMPASS is processing campus neural database and cross-referencing nodes...</span>
              </div>
            )}
          </div>

          {/* Chat Input */}
          <div className="pt-4 border-t border-white/[0.08]">
            <div className="relative flex items-center">
              <input
                type="text"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                placeholder="Ask COMPASS anything about labs, faculty, equipment, or peer matchmaking..."
                disabled={isLoading}
                className="w-full pl-4 pr-12 py-3.5 bg-[#050505] border border-white/[0.1] focus:border-[#00f2ff] rounded-sm text-xs sm:text-sm text-white placeholder-white/40 focus:outline-none transition-colors font-mono-tech shadow-inner"
              />
              <button
                id="compass-send-submit-btn"
                onClick={handleSend}
                disabled={!inputText.trim() || isLoading}
                className="absolute right-2 p-2.5 rounded-sm bg-[#00f2ff] hover:bg-[#00f2ff]/80 disabled:opacity-40 text-black font-bold transition-all cursor-pointer shadow-[0_0_15px_rgba(0,242,255,0.3)]"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Right 4 Cols: Presets & Intelligence Hub */}
        <div className="lg:col-span-4 space-y-4">
          <div className="bg-[#121212] border border-white/[0.08] p-5 rounded-sm space-y-4">
            <div className="flex items-center justify-between text-xs font-mono-tech text-[#00f2ff] font-bold uppercase tracking-[2px]">
              <span>QUICK CAMPUS PROMPTS</span>
              <Terminal className="w-4 h-4 text-[#00f2ff]" />
            </div>

            <p className="text-xs text-white/60">
              Click any question below to immediately run an inquiry across the campus index:
            </p>

            <div className="space-y-2">
              {presetQueries.map((query, idx) => (
                <button
                  key={idx}
                  onClick={() => onSendMessage(query)}
                  disabled={isLoading}
                  className="w-full text-left p-3 rounded-sm bg-[#050505] border border-white/5 hover:border-[#00f2ff] text-xs font-mono-tech text-white/80 hover:text-[#00f2ff] transition-all cursor-pointer flex items-start gap-2"
                >
                  <span className="text-[#00f2ff] mt-0.5">›</span>
                  <span>{query}</span>
                </button>
              ))}
            </div>
          </div>

          {/* AI Knowledge Pillars */}
          <div className="bg-[#121212] border border-white/[0.08] p-5 rounded-sm space-y-3 font-mono-tech text-xs">
            <div className="text-white font-bold uppercase tracking-[1px] text-[11px] text-[#bc13fe]">
              INDEXED DATA STREAMS
            </div>
            <div className="flex items-center justify-between text-white/70">
              <span>Lab Hardware & Sensors</span>
              <span className="text-[#00f2ff]">100% Synced</span>
            </div>
            <div className="flex items-center justify-between text-white/70">
              <span>Senior Course Reviews</span>
              <span className="text-[#00f2ff]">Verified</span>
            </div>
            <div className="flex items-center justify-between text-white/70">
              <span>Peer Marketplace Listings</span>
              <span className="text-[#00f2ff]">Live</span>
            </div>
            <div className="flex items-center justify-between text-white/70">
              <span>Campus Project Recruitment</span>
              <span className="text-[#00f2ff]">Active</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

```

---

## File: `src/components/views/LeaderboardView.tsx`

```tsx
import React, { useState } from 'react';
import { 
  Trophy, 
  Award, 
  Sparkles, 
  Zap, 
  ShieldCheck, 
  TrendingUp, 
  Flame, 
  BookOpen, 
  Repeat, 
  HandCoins, 
  Layers 
} from 'lucide-react';
import { UserProfile } from '../../types';

interface LeaderboardViewProps {
  users: UserProfile[];
  currentUser: UserProfile;
}

export const LeaderboardView: React.FC<LeaderboardViewProps> = ({
  users,
  currentUser,
}) => {
  const [filterPeriod, setFilterPeriod] = useState<'all-time' | 'semester' | 'weekly'>('semester');

  const sortedUsers = [...users].sort((a, b) => b.impactScore - a.impactScore);

  return (
    <div id="leaderboard-view-container" className="space-y-6">
      {/* Header Banner */}
      <div className="bg-[#121212] border border-white/[0.08] border-t-2 border-t-[#00f2ff] p-6 rounded-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-[10px] font-mono-tech text-[#00f2ff] tracking-[3px] uppercase font-bold">
            <Trophy className="w-4 h-4 text-[#00f2ff]" />
            <span>CAMPUS PROOF-OF-CONTRIBUTION PROTOCOL</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-black text-white font-heading mt-1">
            CAMPUS REPUTATION & IMPACT LEADERBOARD
          </h2>
          <p className="text-sm text-white/60 mt-1 max-w-xl font-normal">
            Earn verifiable karma by mentoring peers, sharing hardware, and leading open campus research builds.
          </p>
        </div>

        {/* Period toggle */}
        <div className="flex items-center gap-1.5 bg-[#050505] p-1 border border-white/10 rounded-sm self-start md:self-auto">
          {(['weekly', 'semester', 'all-time'] as const).map((period) => (
            <button
              key={period}
              onClick={() => setFilterPeriod(period)}
              className={`px-3 py-1.5 text-xs font-mono-tech uppercase tracking-[1px] rounded-sm transition-all cursor-pointer ${
                filterPeriod === period
                  ? 'bg-[#00f2ff] text-black font-bold'
                  : 'text-white/50 hover:text-white'
              }`}
            >
              {period}
            </button>
          ))}
        </div>
      </div>

      {/* Current User Snapshot Telemetry Card */}
      <div className="bg-[#121212] border border-white/[0.08] border-l-4 border-l-[#00f2ff] p-6 rounded-sm">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-sm bg-[#050505] border-2 border-[#00f2ff] flex items-center justify-center font-mono-tech text-lg font-black text-[#00f2ff]">
              #{String(currentUser.rank).padStart(2, '0')}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xl font-black text-white font-heading">{currentUser.name}</span>
                <span className="px-2 py-0.5 rounded-sm bg-[#00f2ff]/10 border border-[#00f2ff]/30 text-[10px] font-mono-tech text-[#00f2ff] font-bold uppercase">
                  VERIFIED PEER
                </span>
              </div>
              <div className="text-xs font-mono-tech text-white/60 mt-0.5">
                {currentUser.title} • {currentUser.department}
              </div>
            </div>
          </div>

          {/* 4 Score Compartments */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 font-mono-tech">
            <div className="p-3 bg-[#050505] rounded-sm border border-white/5 text-center">
              <div className="text-[9px] text-[#00f2ff] uppercase">KNOWLEDGE</div>
              <div className="text-base font-bold text-white mt-0.5">{currentUser.knowledgeScore}</div>
            </div>
            <div className="p-3 bg-[#050505] rounded-sm border border-white/5 text-center">
              <div className="text-[9px] text-[#bc13fe] uppercase">SKILLS</div>
              <div className="text-base font-bold text-white mt-0.5">{currentUser.skillScore}</div>
            </div>
            <div className="p-3 bg-[#050505] rounded-sm border border-white/5 text-center">
              <div className="text-[9px] text-[#00f2ff] uppercase">RESOURCES</div>
              <div className="text-base font-bold text-white mt-0.5">{currentUser.resourceScore}</div>
            </div>
            <div className="p-3 bg-[#050505] rounded-sm border border-white/5 text-center">
              <div className="text-[9px] text-white/70 uppercase">PROJECTS</div>
              <div className="text-base font-bold text-white mt-0.5">{currentUser.projectScore}</div>
            </div>
          </div>

          <div className="text-right">
            <div className="text-2xl sm:text-3xl font-black text-[#00f2ff] font-heading">
              {currentUser.impactScore}
            </div>
            <div className="text-[10px] font-mono-tech text-white/40 uppercase tracking-[1px]">
              TOTAL KARMA POINTS
            </div>
          </div>
        </div>
      </div>

      {/* Leaderboard Table / Cards */}
      <div className="bg-[#121212] border border-white/[0.08] rounded-sm overflow-hidden">
        <div className="p-4 border-b border-white/[0.08] flex items-center justify-between font-mono-tech text-xs text-white/50">
          <span>CAMPUS PEER RANKINGS</span>
          <span>SCORES UPDATED LIVE EVERY 60S</span>
        </div>

        <div className="divide-y divide-white/[0.06]">
          {sortedUsers.map((user, idx) => {
            const rank = idx + 1;
            const isTop3 = rank <= 3;

            return (
              <div
                key={user.id}
                className={`p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 transition-colors ${
                  user.id === currentUser.id
                    ? 'bg-[#00f2ff]/5 border-l-2 border-l-[#00f2ff]'
                    : 'hover:bg-white/[0.02]'
                }`}
              >
                {/* Rank & User Info */}
                <div className="flex items-center gap-4">
                  <div
                    className={`w-10 h-10 rounded-sm flex items-center justify-center font-mono-tech text-sm font-black ${
                      rank === 1
                        ? 'bg-[#00f2ff] text-black shadow-[0_0_15px_rgba(0,242,255,0.4)]'
                        : rank === 2
                        ? 'bg-[#bc13fe] text-white shadow-[0_0_15px_rgba(188,19,254,0.4)]'
                        : rank === 3
                        ? 'bg-white text-black'
                        : 'bg-[#050505] text-white/60 border border-white/10'
                    }`}
                  >
                    #{String(rank).padStart(2, '0')}
                  </div>

                  <div>
                    <div className="flex items-center gap-2 font-heading font-bold text-white text-base">
                      <span>{user.name}</span>
                      {user.badges.slice(0, 1).map((b) => (
                        <span
                          key={b}
                          className="px-2 py-0.5 rounded-sm bg-[#050505] border border-white/10 text-[9px] font-mono-tech text-[#00f2ff] uppercase"
                        >
                          {b}
                        </span>
                      ))}
                    </div>
                    <div className="text-xs font-mono-tech text-white/50">
                      {user.title} • {user.department}
                    </div>
                  </div>
                </div>

                {/* Score & Badges */}
                <div className="flex items-center justify-between sm:justify-end gap-6 font-mono-tech">
                  <div className="hidden md:flex items-center gap-2">
                    {user.badges.slice(1).map((b) => (
                      <span
                        key={b}
                        className="px-2 py-0.5 rounded-sm bg-[#050505] border border-white/5 text-[9px] text-white/60"
                      >
                        {b}
                      </span>
                    ))}
                  </div>

                  <div className="text-right">
                    <div className="text-lg font-black text-white font-heading">
                      {user.impactScore} <span className="text-xs text-[#00f2ff]">PTS</span>
                    </div>
                    <div className="text-[10px] text-white/40">
                      Level {Math.floor(user.impactScore / 500) + 1} Contributor
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

```

---

## File: `src/components/views/MarketplaceView.tsx`

```tsx
import React, { useState } from 'react';
import { 
  ShoppingBag, 
  Search, 
  Filter, 
  Plus, 
  MapPin, 
  ShieldCheck, 
  ArrowUpRight, 
  Sparkles,
  Tag,
  CheckCircle
} from 'lucide-react';
import { MarketplaceItem, UserProfile } from '../../types';

interface MarketplaceViewProps {
  items: MarketplaceItem[];
  currentUser: UserProfile;
  onSelectItem: (item: MarketplaceItem) => void;
  onOpenCreateListing: () => void;
}

export const MarketplaceView: React.FC<MarketplaceViewProps> = ({
  items,
  currentUser,
  onSelectItem,
  onOpenCreateListing,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [priceSort, setPriceSort] = useState<'default' | 'low-high' | 'high-low' | 'newest'>('default');

  const categories: string[] = ['All', 'Electronics', 'Books', 'Furniture', 'Equipment', 'Notes'];

  let filteredItems = items.filter((item) => {
    const matchesCat = 
      selectedCategory === 'All' || 
      item.category.toLowerCase().includes(selectedCategory.toLowerCase()) ||
      selectedCategory.toLowerCase().includes(item.category.toLowerCase());
    
    const query = searchQuery.trim().toLowerCase();
    const matchesSearch = 
      !query ||
      item.title.toLowerCase().includes(query) ||
      item.description.toLowerCase().includes(query) ||
      item.location.toLowerCase().includes(query) ||
      item.sellerName.toLowerCase().includes(query);
    return matchesCat && matchesSearch;
  });

  if (priceSort === 'low-high') {
    filteredItems = [...filteredItems].sort((a, b) => a.price - b.price);
  } else if (priceSort === 'high-low') {
    filteredItems = [...filteredItems].sort((a, b) => b.price - a.price);
  } else if (priceSort === 'newest') {
    filteredItems = [...filteredItems].reverse();
  }

  return (
    <div id="marketplace-view-container" className="space-y-6">
      {/* Header Banner */}
      <div className="bg-[#121212] border border-white/[0.08] border-t-2 border-t-[#00f2ff] p-6 rounded-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-[10px] font-mono-tech text-[#00f2ff] tracking-[3px] uppercase font-bold">
            <ShoppingBag className="w-4 h-4 text-[#00f2ff]" />
            <span>ZERO-FEE CAMPUS COMMERCE</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-black text-white font-heading mt-1">
            PEER-TO-PEER MARKETPLACE
          </h2>
          <p className="text-sm text-white/60 mt-1 max-w-xl font-normal">
            Buy, sell, or trade textbooks, monitors, drafting tools, and tech directly with peers across campus hostels and departments.
          </p>
        </div>

        <button
          id="marketplace-create-listing-btn"
          onClick={onOpenCreateListing}
          className="inline-flex items-center gap-2 px-5 py-3 bg-[#00f2ff] hover:bg-[#00f2ff]/80 text-black font-bold text-xs font-mono-tech tracking-[2px] uppercase rounded-sm transition-all cursor-pointer shadow-[0_0_20px_rgba(0,242,255,0.25)] shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>+ LIST AN ITEM</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col md:flex-row items-center justify-between gap-4 p-3 bg-[#121212] border border-white/[0.08] rounded-sm">
        {/* Search */}
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-white/40 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search textbooks, tech, sellers..."
            className="w-full pl-9 pr-3 py-2 bg-[#050505] border border-white/10 rounded-sm text-xs text-white focus:outline-none focus:border-[#00f2ff] font-mono-tech"
          />
        </div>

        {/* Categories */}
        <div className="flex items-center gap-1.5 overflow-x-auto w-full md:w-auto">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 text-xs font-mono-tech tracking-[1px] uppercase rounded-sm transition-all cursor-pointer whitespace-nowrap ${
                selectedCategory === cat
                  ? 'bg-[#00f2ff]/20 border border-[#00f2ff] text-[#00f2ff] font-bold'
                  : 'bg-[#050505] border border-white/5 text-white/50 hover:text-white'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Price sort */}
        <select
          value={priceSort}
          onChange={(e) => setPriceSort(e.target.value as any)}
          className="px-3 py-1.5 bg-[#050505] border border-white/10 rounded-sm text-xs text-white font-mono-tech focus:outline-none focus:border-[#00f2ff]"
        >
          <option value="default">Sort: Recommended</option>
          <option value="low-high">Price: Low to High</option>
          <option value="high-low">Price: High to Low</option>
        </select>
      </div>

      {/* Listings Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        {filteredItems.map((item) => (
          <div
            key={item.id}
            id={`marketplace-card-${item.id}`}
            onClick={() => onSelectItem(item)}
            className="group relative rounded-sm bg-[#121212] border border-white/[0.08] hover:border-[#00f2ff] transition-all duration-200 cursor-pointer overflow-hidden flex flex-col justify-between"
          >
            {/* Image Box */}
            <div className="relative aspect-4/3 w-full bg-[#050505] overflow-hidden border-b border-white/[0.06]">
              <img
                src={item.imageUrl}
                alt={item.title}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300 opacity-90 group-hover:opacity-100"
              />
              <div className="absolute top-2.5 left-2.5">
                <span className="px-2 py-0.5 rounded-sm bg-[#050505]/90 border border-white/10 text-[9px] font-mono-tech text-white uppercase">
                  {item.category}
                </span>
              </div>
              <div className="absolute top-2.5 right-2.5">
                <span className="px-2.5 py-0.5 rounded-sm bg-[#00f2ff] text-black font-black text-xs font-mono-tech shadow-md">
                  ₹{item.price}
                </span>
              </div>
            </div>

            {/* Content Area */}
            <div className="p-4 flex-1 flex flex-col justify-between">
              <div>
                <h3 className="text-sm font-bold text-white group-hover:text-[#00f2ff] transition-colors font-heading line-clamp-1 mb-1">
                  {item.title}
                </h3>
                <p className="text-xs text-white/60 line-clamp-2 mb-3 font-normal">
                  {item.description}
                </p>
              </div>

              <div className="space-y-2 pt-3 border-t border-white/[0.04]">
                <div className="flex items-center justify-between text-[11px] font-mono-tech text-white/50">
                  <div className="flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5 text-[#00f2ff]" />
                    <span className="text-white/80">{item.sellerName}</span>
                  </div>
                  <span>{item.condition}</span>
                </div>

                <div className="flex items-center justify-between text-[10px] font-mono-tech text-white/40">
                  <div className="flex items-center gap-1">
                    <MapPin className="w-3 h-3 text-white/40" />
                    <span>{item.location}</span>
                  </div>
                  <span>{item.createdAt}</span>
                </div>
              </div>
            </div>

            {/* Bottom View Trigger */}
            <div className="px-4 py-2.5 bg-[#050505] border-t border-white/[0.06] flex items-center justify-between text-xs font-mono-tech text-[#00f2ff] font-bold uppercase tracking-[1px] group-hover:bg-[#00f2ff] group-hover:text-black transition-colors">
              <span>VIEW DETAILS</span>
              <ArrowUpRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

```

---

## File: `src/components/views/MentorshipView.tsx`

```tsx
import React, { useState } from 'react';
import { 
  Repeat, 
  BookOpen, 
  Sparkles, 
  ArrowRight, 
  CheckCircle, 
  ShieldCheck, 
  Plus, 
  Search, 
  Filter,
  Eye,
  UserCheck,
  MessageSquare
} from 'lucide-react';
import { SkillMatch, GuidanceTopic, UserProfile } from '../../types';

interface MentorshipViewProps {
  skillMatches: SkillMatch[];
  guidanceTopics: GuidanceTopic[];
  currentUser: UserProfile;
  onConnectMatch: (matchId: string) => void;
  onAddSkills: (offered: string, wanted: string) => void;
  onAddGuidanceTopic: (topic: Omit<GuidanceTopic, 'id' | 'reads'>) => void;
}

export const MentorshipView: React.FC<MentorshipViewProps> = ({
  skillMatches,
  guidanceTopics,
  currentUser,
  onConnectMatch,
  onAddSkills,
  onAddGuidanceTopic,
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'skills' | 'guides'>('skills');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Skill Swap Offer State
  const [isSkillFormOpen, setIsSkillFormOpen] = useState(false);
  const [offeredSkill, setOfferedSkill] = useState('');
  const [wantedSkill, setWantedSkill] = useState('');

  // Guidance Guide State
  const [isGuideFormOpen, setIsGuideFormOpen] = useState(false);
  const [guideTitle, setGuideTitle] = useState('');
  const [guideCategory, setGuideCategory] = useState<GuidanceTopic['category']>('Course Advice');
  const [guideSummary, setGuideSummary] = useState('');
  const [guideTips, setGuideTips] = useState('');
  const [expandedGuideId, setExpandedGuideId] = useState<string | null>(null);

  const handleConnect = (id: string) => {
    onConnectMatch(id);
    setSuccessMsg('Skill Swap connection requested! Both peers have been synced in Campus Messages.');
    setTimeout(() => setSuccessMsg(null), 3000);
  };

  const handleOfferSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!offeredSkill || !wantedSkill) return;

    onAddSkills(offeredSkill, wantedSkill);
    setSuccessMsg('Your skill exchange profile was indexed into the Campus Neural Matchmaker!');
    setOfferedSkill('');
    setWantedSkill('');
    setIsSkillFormOpen(false);
    setTimeout(() => setSuccessMsg(null), 2500);
  };

  const handleGuideSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!guideTitle || !guideSummary) return;

    const tips = guideTips.split('\n').map(t => t.trim()).filter(Boolean);
    onAddGuidanceTopic({
      title: guideTitle,
      category: guideCategory,
      mentorName: `${currentUser.name} (Senior Mentor)`,
      mentorTitle: `${currentUser.department} Contributor`,
      summary: guideSummary,
      tips: tips.length > 0 ? tips : ['Review weekly lab tasks', 'Ask TA during office hours'],
    });

    setSuccessMsg('Guidance Guide published to the Campus Memory Layer! +50 Karma pts earned.');
    setGuideTitle('');
    setGuideSummary('');
    setGuideTips('');
    setIsGuideFormOpen(false);
    setTimeout(() => setSuccessMsg(null), 2500);
  };

  const filteredSkills = skillMatches.filter(
    (m) =>
      m.userName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      m.offering.toLowerCase().includes(searchQuery.toLowerCase()) ||
      m.seeking.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredGuides = guidanceTopics.filter(
    (g) =>
      g.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      g.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
      g.summary.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div id="mentorship-view-container" className="space-y-6">
      {/* Header Banner */}
      <div className="bg-[#121212] border border-white/[0.08] border-t-2 border-t-[#00f2ff] p-6 rounded-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-[10px] font-mono-tech text-[#00f2ff] tracking-[3px] uppercase font-bold">
            <Sparkles className="w-4 h-4 text-[#00f2ff]" />
            <span>KNOWLEDGE REPOSITORY & PEER MENTORSHIP</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-black text-white font-heading mt-1">
            SKILL EXCHANGE & SENIOR GUIDES
          </h2>
          <p className="text-sm text-white/60 mt-1 max-w-xl font-normal">
            Trade what you know for what you need. Access verified senior course archives, lab secrets, and faculty grading blueprints.
          </p>
        </div>

        {/* Sub-tab switcher */}
        <div className="flex items-center gap-2 bg-[#050505] p-1 border border-white/10 rounded-sm">
          <button
            onClick={() => setActiveSubTab('skills')}
            className={`px-4 py-2 text-xs font-mono-tech uppercase tracking-[1px] rounded-sm transition-all cursor-pointer font-bold ${
              activeSubTab === 'skills'
                ? 'bg-[#00f2ff] text-black shadow-[0_0_15px_rgba(0,242,255,0.3)]'
                : 'text-white/60 hover:text-white'
            }`}
          >
            ⚡ Skill Matchmaker
          </button>
          <button
            onClick={() => setActiveSubTab('guides')}
            className={`px-4 py-2 text-xs font-mono-tech uppercase tracking-[1px] rounded-sm transition-all cursor-pointer font-bold ${
              activeSubTab === 'guides'
                ? 'bg-[#bc13fe] text-white shadow-[0_0_15px_rgba(188,19,254,0.3)]'
                : 'text-white/60 hover:text-white'
            }`}
          >
            📖 Senior Archives
          </button>
        </div>
      </div>

      {/* Success Alert */}
      {successMsg && (
        <div className="p-4 bg-[#00f2ff]/10 border border-[#00f2ff] rounded-sm text-xs font-mono-tech text-[#00f2ff] flex items-center gap-2">
          <CheckCircle className="w-4 h-4 text-[#00f2ff] shrink-0" />
          <span>{successMsg}</span>
        </div>
      )}

      {/* SUBTAB 1: SKILL EXCHANGE */}
      {activeSubTab === 'skills' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 p-3 bg-[#121212] border border-white/[0.08] rounded-sm">
            <div className="relative w-full sm:w-80">
              <Search className="w-4 h-4 text-white/40 absolute left-3 top-2.5" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search skills (e.g. React, C++, Figma)..."
                className="w-full pl-9 pr-3 py-2 bg-[#050505] border border-white/10 rounded-sm text-xs text-white focus:outline-none focus:border-[#00f2ff] font-mono-tech"
              />
            </div>

            <button
              onClick={() => setIsSkillFormOpen(!isSkillFormOpen)}
              className="w-full sm:w-auto px-4 py-2 bg-[#00f2ff] text-black font-bold text-xs font-mono-tech uppercase tracking-[1px] rounded-sm cursor-pointer"
            >
              {isSkillFormOpen ? 'CLOSE FORM' : '+ OFFER YOUR SKILLS'}
            </button>
          </div>

          {/* Skill Offer Form */}
          {isSkillFormOpen && (
            <form
              onSubmit={handleOfferSubmit}
              className="p-6 bg-[#121212] border border-[#00f2ff]/40 rounded-sm space-y-4 shadow-xl"
            >
              <div className="text-xs font-mono-tech text-[#00f2ff] font-bold uppercase tracking-[2px]">
                INDEX YOUR SKILLS IN THE PEER NETWORK
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-mono-tech text-white/50 mb-1">
                    WHAT YOU CAN TEACH (OFFERING) *
                  </label>
                  <input
                    type="text"
                    value={offeredSkill}
                    onChange={(e) => setOfferedSkill(e.target.value)}
                    placeholder="e.g. ROS2 Robotics / Rust / Linear Algebra"
                    required
                    className="w-full px-3 py-2 bg-[#050505] border border-white/10 rounded-sm text-xs text-white focus:outline-none focus:border-[#00f2ff] font-mono-tech"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-mono-tech text-white/50 mb-1">
                    WHAT YOU WANT TO LEARN (SEEKING) *
                  </label>
                  <input
                    type="text"
                    value={wantedSkill}
                    onChange={(e) => setWantedSkill(e.target.value)}
                    placeholder="e.g. Next.js / Blender 3D / Financial Modeling"
                    required
                    className="w-full px-3 py-2 bg-[#050505] border border-white/10 rounded-sm text-xs text-white focus:outline-none focus:border-[#00f2ff] font-mono-tech"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setIsSkillFormOpen(false)}
                  className="px-4 py-2 bg-[#050505] border border-white/10 text-white/60 text-xs font-mono-tech rounded-sm cursor-pointer"
                >
                  CANCEL
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#00f2ff] text-black font-bold text-xs font-mono-tech uppercase tracking-[1px] rounded-sm cursor-pointer"
                >
                  PUBLISH TO MATCHMAKER
                </button>
              </div>
            </form>
          )}

          {/* Skill Matches Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredSkills.map((match) => (
              <div
                key={match.id}
                className="p-5 rounded-sm bg-[#121212] border border-white/[0.08] hover:border-[#00f2ff] transition-all space-y-4"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-sm bg-[#050505] border border-white/10 flex items-center justify-center font-mono-tech text-xs font-bold text-white">
                      {match.userName.slice(0, 2).toUpperCase()}
                    </div>
                    <div>
                      <div className="text-sm font-bold text-white font-heading">{match.userName}</div>
                      <div className="text-[10px] font-mono-tech text-white/40">{match.department} • Year {match.year}</div>
                    </div>
                  </div>

                  <span className="px-2.5 py-1 rounded-sm bg-[#00f2ff]/10 border border-[#00f2ff]/30 text-xs font-mono-tech text-[#00f2ff] font-bold">
                    {match.compatibility}% MATCH
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-3 p-3 bg-[#050505] rounded-sm border border-white/5 font-mono-tech text-xs">
                  <div>
                    <div className="text-[9px] text-[#00f2ff] uppercase tracking-wider mb-1 font-bold">THEY TEACH</div>
                    <div className="text-white font-semibold">{match.offering}</div>
                  </div>
                  <div>
                    <div className="text-[9px] text-[#bc13fe] uppercase tracking-wider mb-1 font-bold">THEY WANT</div>
                    <div className="text-white font-semibold">{match.seeking}</div>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-white/[0.06]">
                  <span className="text-[10px] font-mono-tech text-white/40">{match.availability}</span>
                  <button
                    onClick={() => handleConnect(match.id)}
                    className="px-4 py-1.5 bg-white hover:bg-zinc-200 text-black font-bold text-xs font-mono-tech tracking-[1px] uppercase rounded-sm cursor-pointer flex items-center gap-1.5"
                  >
                    <span>SWAP SKILLS</span>
                    <ArrowRight className="w-3 h-3" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* SUBTAB 2: SENIOR GUIDES & ARCHIVES */}
      {activeSubTab === 'guides' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 p-3 bg-[#121212] border border-white/[0.08] rounded-sm">
            <div className="relative w-full sm:w-80">
              <Search className="w-4 h-4 text-white/40 absolute left-3 top-2.5" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search course blueprints, faculty tips..."
                className="w-full pl-9 pr-3 py-2 bg-[#050505] border border-white/10 rounded-sm text-xs text-white focus:outline-none focus:border-[#bc13fe] font-mono-tech"
              />
            </div>

            <button
              onClick={() => setIsGuideFormOpen(!isGuideFormOpen)}
              className="w-full sm:w-auto px-4 py-2 bg-[#bc13fe] text-white font-bold text-xs font-mono-tech uppercase tracking-[1px] rounded-sm cursor-pointer"
            >
              {isGuideFormOpen ? 'CLOSE FORM' : '+ PUBLISH SENIOR GUIDE'}
            </button>
          </div>

          {/* Guide Form */}
          {isGuideFormOpen && (
            <form
              onSubmit={handleGuideSubmit}
              className="p-6 bg-[#121212] border border-[#bc13fe]/40 rounded-sm space-y-4 shadow-xl"
            >
              <div className="text-xs font-mono-tech text-[#bc13fe] font-bold uppercase tracking-[2px]">
                SHARE SENIOR EXPERIENCE & ARCHIVES
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-mono-tech text-white/50 mb-1">
                    GUIDE TITLE *
                  </label>
                  <input
                    type="text"
                    value={guideTitle}
                    onChange={(e) => setGuideTitle(e.target.value)}
                    placeholder="e.g. How to ace OS Lab viva & Kernel compilation"
                    required
                    className="w-full px-3 py-2 bg-[#050505] border border-white/10 rounded-sm text-xs text-white focus:outline-none focus:border-[#bc13fe] font-mono-tech"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-mono-tech text-white/50 mb-1">
                    CATEGORY *
                  </label>
                  <select
                    value={guideCategory}
                    onChange={(e) => setGuideCategory(e.target.value as any)}
                    className="w-full px-3 py-2 bg-[#050505] border border-white/10 rounded-sm text-xs text-white focus:outline-none focus:border-[#bc13fe] font-mono-tech"
                  >
                    <option value="Course Advice">Course Advice</option>
                    <option value="Faculty Intel">Faculty Intel</option>
                    <option value="Lab Secrets">Lab Secrets</option>
                    <option value="Internships">Internships</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-mono-tech text-white/50 mb-1">
                  EXECUTIVE SUMMARY *
                </label>
                <textarea
                  rows={2}
                  value={guideSummary}
                  onChange={(e) => setGuideSummary(e.target.value)}
                  placeholder="Key concepts to focus on, past exam patterns, important milestones..."
                  required
                  className="w-full px-3 py-2 bg-[#050505] border border-white/10 rounded-sm text-xs text-white focus:outline-none focus:border-[#bc13fe] font-mono-tech"
                />
              </div>

              <div>
                <label className="block text-[10px] font-mono-tech text-white/50 mb-1">
                  ACTIONABLE TIPS / BULLETS (1 PER LINE)
                </label>
                <textarea
                  rows={3}
                  value={guideTips}
                  onChange={(e) => setGuideTips(e.target.value)}
                  placeholder="Tip 1: Practice fork() and thread synch on Linux&#10;Tip 2: Reference Silberschatz Chapter 4-6"
                  className="w-full px-3 py-2 bg-[#050505] border border-white/10 rounded-sm text-xs text-white focus:outline-none focus:border-[#bc13fe] font-mono-tech"
                />
              </div>

              <div className="flex justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setIsGuideFormOpen(false)}
                  className="px-4 py-2 bg-[#050505] border border-white/10 text-white/60 text-xs font-mono-tech rounded-sm cursor-pointer"
                >
                  CANCEL
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#bc13fe] text-white font-bold text-xs font-mono-tech uppercase tracking-[1px] rounded-sm cursor-pointer"
                >
                  PUBLISH GUIDE
                </button>
              </div>
            </form>
          )}

          {/* Guides Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {filteredGuides.map((guide) => {
              const isExpanded = expandedGuideId === guide.id;

              return (
                <div
                  key={guide.id}
                  className="p-5 rounded-sm bg-[#121212] border border-white/[0.08] hover:border-[#bc13fe] transition-all space-y-4"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-mono-tech text-[#bc13fe] uppercase tracking-[1px] font-bold px-2 py-0.5 rounded-sm bg-[#bc13fe]/10 border border-[#bc13fe]/30">
                      {guide.category}
                    </span>
                    <span className="text-[10px] font-mono-tech text-white/40 flex items-center gap-1">
                      <Eye className="w-3.5 h-3.5" />
                      <span>{guide.reads} reads</span>
                    </span>
                  </div>

                  <h3 className="text-base font-bold text-white font-heading">
                    {guide.title}
                  </h3>

                  <p className="text-xs text-white/70 leading-relaxed">
                    {guide.summary}
                  </p>

                  {/* Tips list */}
                  {guide.tips && guide.tips.length > 0 && (
                    <div className="space-y-1.5 p-3 bg-[#050505] rounded-sm border border-white/5">
                      <div className="text-[9px] font-mono-tech text-[#00f2ff] uppercase tracking-wider font-bold">
                        KEY ACTIONABLE TIPS
                      </div>
                      <ul className="space-y-1 text-xs text-white/80 list-disc list-inside">
                        {guide.tips.map((tip, idx) => (
                          <li key={idx} className="font-mono-tech text-[11px]">{tip}</li>
                        ))}
                      </ul>
                    </div>
                  )}

                  <div className="flex items-center justify-between pt-3 border-t border-white/[0.06] text-xs font-mono-tech text-white/50">
                    <div>Author: <span className="text-white font-bold">{guide.mentorName}</span></div>
                    <span className="text-[#00f2ff]">VERIFIED SENIOR ARCHIVE</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};

```

---

## File: `src/components/views/MyLockerView.tsx`

```tsx
import React from 'react';
import { 
  FolderLock, 
  HandCoins, 
  ShoppingBag, 
  Layers3, 
  Sparkles, 
  ShieldCheck, 
  Award, 
  CheckCircle, 
  ArrowUpRight,
  User,
  Clock,
  MapPin
} from 'lucide-react';
import { UserProfile, BorrowItem, MarketplaceItem, ProjectItem } from '../../types';

interface MyLockerViewProps {
  currentUser: UserProfile;
  users: UserProfile[];
  onSwitchUser: (user: UserProfile) => void;
  borrowItems: BorrowItem[];
  marketplaceItems: MarketplaceItem[];
  projects: ProjectItem[];
  onNavigateTab: (tab: string) => void;
}

export const MyLockerView: React.FC<MyLockerViewProps> = ({
  currentUser,
  users,
  onSwitchUser,
  borrowItems,
  marketplaceItems,
  projects,
  onNavigateTab,
}) => {
  // Find items relevant to current user
  const myListings = marketplaceItems.filter(i => i.sellerName.toLowerCase().includes(currentUser.name.toLowerCase()));
  const myProjects = projects.filter(p => p.creator.toLowerCase().includes(currentUser.name.toLowerCase()) || p.hasApplied);

  return (
    <div id="my-locker-view-container" className="space-y-6">
      {/* Header Banner */}
      <div className="bg-[#121212] border border-white/[0.08] border-t-2 border-t-[#00f2ff] p-6 rounded-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-[10px] font-mono-tech text-[#00f2ff] tracking-[3px] uppercase font-bold">
            <FolderLock className="w-4 h-4 text-[#00f2ff]" />
            <span>PERSONAL CAMPUS LOCKER & WORKSPACE</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-black text-white font-heading mt-1">
            {currentUser.name.toUpperCase()} // WORKSPACE
          </h2>
          <p className="text-sm text-white/60 mt-1 max-w-xl font-normal">
            Track your active hardware checkouts, listed textbooks, research applications, and campus impact milestones.
          </p>
        </div>

        {/* Persona quick switch */}
        <div className="flex items-center gap-2 bg-[#050505] p-2 border border-white/10 rounded-sm">
          <span className="text-[10px] font-mono-tech text-white/40 uppercase">SWITCH PERSONA:</span>
          <select
            value={currentUser.id}
            onChange={(e) => {
              const found = users.find(u => u.id === e.target.value);
              if (found) onSwitchUser(found);
            }}
            className="bg-[#121212] text-xs font-mono-tech text-white border border-white/10 px-2 py-1 rounded-sm focus:outline-none focus:border-[#00f2ff]"
          >
            {users.map(u => (
              <option key={u.id} value={u.id}>
                {u.name} ({u.department})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Identity & Reputation Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="p-5 bg-[#121212] border border-white/[0.08] rounded-sm">
          <div className="text-[10px] font-mono-tech text-white/50 uppercase tracking-[1px]">
            CAMPUS RANK
          </div>
          <div className="text-3xl font-black text-[#00f2ff] font-heading mt-1">
            #{String(currentUser.rank).padStart(2, '0')}
          </div>
          <div className="text-xs font-mono-tech text-white/60 mt-1">
            Top 1% in {currentUser.department}
          </div>
        </div>

        <div className="p-5 bg-[#121212] border border-white/[0.08] rounded-sm">
          <div className="text-[10px] font-mono-tech text-white/50 uppercase tracking-[1px]">
            KARMA BALANCE
          </div>
          <div className="text-3xl font-black text-[#bc13fe] font-heading mt-1">
            {currentUser.impactScore} <span className="text-sm font-normal text-white/50">PTS</span>
          </div>
          <div className="text-xs font-mono-tech text-white/60 mt-1">
            Verifiable on-campus ledger
          </div>
        </div>

        <div className="p-5 bg-[#121212] border border-white/[0.08] rounded-sm">
          <div className="text-[10px] font-mono-tech text-white/50 uppercase tracking-[1px]">
            ACTIVE BORROWINGS
          </div>
          <div className="text-3xl font-black text-white font-heading mt-1">
            01 <span className="text-sm font-normal text-white/50">ACTIVE</span>
          </div>
          <div className="text-xs font-mono-tech text-[#00f2ff] mt-1">
            Due in 2 days (FPGA Kit)
          </div>
        </div>

        <div className="p-5 bg-[#121212] border border-white/[0.08] rounded-sm">
          <div className="text-[10px] font-mono-tech text-white/50 uppercase tracking-[1px]">
            BADGES EARNED
          </div>
          <div className="text-3xl font-black text-white font-heading mt-1">
            {(currentUser.badges || []).length}
          </div>
          <div className="text-xs font-mono-tech text-white/60 mt-1">
            {currentUser.badges && currentUser.badges.length > 0 ? currentUser.badges.join(', ') : 'Peer Contributor, Verified Student'}
          </div>
        </div>
      </div>

      {/* Grid: Borrow Checkouts + Listings + Projects */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Active Borrowed Items */}
        <div className="p-5 bg-[#121212] border border-white/[0.08] rounded-sm space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-xs font-mono-tech text-[#00f2ff] font-bold uppercase tracking-[2px]">
              <HandCoins className="w-4 h-4" />
              <span>ACTIVE HARDWARE CHECKOUTS</span>
            </div>
            <button
              onClick={() => onNavigateTab('borrow')}
              className="text-xs font-mono-tech text-white/50 hover:text-[#00f2ff] transition-colors"
            >
              Browse Inventory ›
            </button>
          </div>

          <div className="p-4 rounded-sm bg-[#050505] border border-white/5 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm font-bold text-white font-heading">
                Xilinx Spartan-7 FPGA Dev Board
              </span>
              <span className="px-2 py-0.5 rounded-sm bg-[#00f2ff]/10 border border-[#00f2ff]/30 text-[9px] font-mono-tech text-[#00f2ff]">
                ACTIVE
              </span>
            </div>
            <div className="flex items-center gap-4 text-xs font-mono-tech text-white/50">
              <span className="flex items-center gap-1">
                <Clock className="w-3 h-3 text-[#00f2ff]" />
                Return Due: Friday 5:00 PM
              </span>
              <span className="flex items-center gap-1">
                <MapPin className="w-3 h-3 text-white/40" />
                VLSI Lab 1
              </span>
            </div>
          </div>
        </div>

        {/* My Marketplace Listings */}
        <div className="p-5 bg-[#121212] border border-white/[0.08] rounded-sm space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-xs font-mono-tech text-[#00f2ff] font-bold uppercase tracking-[2px]">
              <ShoppingBag className="w-4 h-4" />
              <span>MY MARKETPLACE LISTINGS</span>
            </div>
            <button
              onClick={() => onNavigateTab('marketplace')}
              className="text-xs font-mono-tech text-white/50 hover:text-[#00f2ff] transition-colors"
            >
              Go to Market ›
            </button>
          </div>

          {myListings.length > 0 ? (
            myListings.map(item => (
              <div key={item.id} className="p-4 rounded-sm bg-[#050505] border border-white/5 flex items-center justify-between">
                <div>
                  <div className="text-sm font-bold text-white font-heading">{item.title}</div>
                  <div className="text-xs font-mono-tech text-white/40">₹{item.price} • {item.category} • {item.condition}</div>
                </div>
                <span className="px-2 py-0.5 bg-[#00f2ff]/10 text-[#00f2ff] text-[10px] font-mono-tech uppercase">
                  ACTIVE
                </span>
              </div>
            ))
          ) : (
            <div className="p-4 rounded-sm bg-[#050505] border border-white/5 text-xs font-mono-tech text-white/40 text-center">
              You haven't listed any textbooks or gear yet.
            </div>
          )}
        </div>

        {/* My Projects & Applications */}
        <div className="p-5 bg-[#121212] border border-white/[0.08] rounded-sm space-y-4 lg:col-span-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-xs font-mono-tech text-[#bc13fe] font-bold uppercase tracking-[2px]">
              <Layers3 className="w-4 h-4" />
              <span>MY RESEARCH & PROJECT ENGAGEMENTS</span>
            </div>
            <button
              onClick={() => onNavigateTab('projects')}
              className="text-xs font-mono-tech text-white/50 hover:text-[#bc13fe] transition-colors"
            >
              Explore Projects ›
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {myProjects.map(proj => (
              <div key={proj.id} className="p-4 rounded-sm bg-[#050505] border border-white/5 space-y-2">
                <div className="flex items-center justify-between">
                  <div className="text-sm font-bold text-white font-heading">{proj.name}</div>
                  <span className="text-[10px] font-mono-tech text-[#bc13fe] uppercase">
                    {proj.creator.includes(currentUser.name) ? 'CREATOR' : 'APPLIED'}
                  </span>
                </div>
                <p className="text-xs text-white/60 line-clamp-2">{proj.tagline}</p>
                <div className="text-[10px] font-mono-tech text-white/40 pt-2 border-t border-white/5 flex items-center justify-between">
                  <span>Category: {proj.category}</span>
                  <span className="text-[#00f2ff]">{proj.progressPercent}% Completed</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

```

---

## File: `src/components/views/ProjectsView.tsx`

```tsx
import React, { useState } from 'react';
import { 
  Layers3, 
  Search, 
  Filter, 
  Plus, 
  Users, 
  Heart, 
  ArrowUpRight, 
  Sparkles,
  GitBranch,
  CheckCircle,
  Tag
} from 'lucide-react';
import { ProjectItem, UserProfile } from '../../types';

interface ProjectsViewProps {
  projects: ProjectItem[];
  currentUser: UserProfile;
  onSelectProject: (project: ProjectItem) => void;
  onOpenCreateProject: () => void;
  onToggleFollow: (projectId: string) => void;
  onJoinProject: (projectId: string) => void;
}

export const ProjectsView: React.FC<ProjectsViewProps> = ({
  projects,
  currentUser,
  onSelectProject,
  onOpenCreateProject,
  onToggleFollow,
  onJoinProject,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [recruitingOnly, setRecruitingOnly] = useState<boolean>(false);

  const categories: string[] = ['All', 'Autonomous Systems', 'Robotics & Hardware', 'Distributed Systems', 'HealthTech', 'Green Energy'];

  const filteredProjects = projects.filter((proj) => {
    const matchesCat = selectedCategory === 'All' || proj.category.toLowerCase() === selectedCategory.toLowerCase();
    const matchesSearch = proj.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          proj.tagline.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          proj.creator.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          proj.skillsRequired.some(s => s.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesRecruiting = !recruitingOnly || proj.recruiting;
    return matchesCat && matchesSearch && matchesRecruiting;
  });

  return (
    <div id="projects-view-container" className="space-y-6">
      {/* Header Banner */}
      <div className="bg-[#121212] border border-white/[0.08] border-t-2 border-t-[#bc13fe] p-6 rounded-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-[10px] font-mono-tech text-[#bc13fe] tracking-[3px] uppercase font-bold">
            <Layers3 className="w-4 h-4 text-[#bc13fe]" />
            <span>CAMPUS INNOVATION & RESEARCH LABS</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-black text-white font-heading mt-1">
            RESEARCH & COLLABORATIVE PROJECTS
          </h2>
          <p className="text-sm text-white/60 mt-1 max-w-xl font-normal">
            Build real hardware prototypes, publish papers, and participate in national hackathons with cross-department student teams.
          </p>
        </div>

        <button
          id="projects-create-btn"
          onClick={onOpenCreateProject}
          className="inline-flex items-center gap-2 px-5 py-3 bg-[#bc13fe] hover:bg-[#a010d8] text-white font-bold text-xs font-mono-tech tracking-[2px] uppercase rounded-sm transition-all cursor-pointer shadow-[0_0_20px_rgba(188,19,254,0.3)] shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>+ PUBLISH PROJECT</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col md:flex-row items-center justify-between gap-4 p-3 bg-[#121212] border border-white/[0.08] rounded-sm">
        {/* Search */}
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-white/40 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search projects, skills (e.g. PyTorch, ROS)..."
            className="w-full pl-9 pr-3 py-2 bg-[#050505] border border-white/10 rounded-sm text-xs text-white focus:outline-none focus:border-[#bc13fe] font-mono-tech"
          />
        </div>

        {/* Categories */}
        <div className="flex items-center gap-1.5 overflow-x-auto w-full md:w-auto">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 text-xs font-mono-tech tracking-[1px] uppercase rounded-sm transition-all cursor-pointer whitespace-nowrap ${
                selectedCategory === cat
                  ? 'bg-[#bc13fe]/20 border border-[#bc13fe] text-[#bc13fe] font-bold'
                  : 'bg-[#050505] border border-white/5 text-white/50 hover:text-white'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Recruiting filter checkbox */}
        <label className="flex items-center gap-2 text-xs font-mono-tech text-white/80 cursor-pointer shrink-0">
          <input
            type="checkbox"
            checked={recruitingOnly}
            onChange={(e) => setRecruitingOnly(e.target.checked)}
            className="accent-[#bc13fe]"
          />
          <span>Recruiting Only</span>
        </label>
      </div>

      {/* Projects Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredProjects.map((project) => (
          <div
            key={project.id}
            id={`project-card-${project.id}`}
            className="group relative rounded-sm bg-[#121212] border border-white/[0.08] border-t-2 border-t-[#bc13fe] hover:border-[#bc13fe] transition-all duration-300 flex flex-col justify-between p-6 overflow-hidden shadow-2xl"
          >
            <div>
              <div className="flex items-center justify-between gap-2 pb-3 mb-4 border-b border-white/[0.06]">
                <span className="text-[10px] font-mono-tech text-white/50 tracking-[1px] uppercase">
                  {project.category}
                </span>
                {project.recruiting ? (
                  <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-sm bg-[#00f2ff]/10 border border-[#00f2ff]/30 text-[9px] font-mono-tech text-[#00f2ff] font-bold">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#00f2ff] animate-ping" />
                    RECRUITING
                  </span>
                ) : (
                  <span className="px-2 py-0.5 rounded-sm bg-[#050505] border border-white/10 text-[9px] font-mono-tech text-white/40">
                    ACTIVE TEAM
                  </span>
                )}
              </div>

              {/* Title & Tagline */}
              <h3 
                onClick={() => onSelectProject(project)}
                className="text-xl font-bold text-white group-hover:text-[#bc13fe] transition-colors font-heading mb-2 cursor-pointer"
              >
                {project.name}
              </h3>
              <p className="text-xs text-white/70 leading-relaxed line-clamp-3 mb-4 font-normal">
                {project.tagline}
              </p>

              {/* Skills Tags */}
              <div className="flex flex-wrap gap-1.5 mb-4">
                {project.skillsRequired.slice(0, 3).map((skill) => (
                  <span
                    key={skill}
                    className="px-2 py-0.5 rounded-sm bg-[#050505] border border-white/[0.08] text-[10px] font-mono-tech text-white/70"
                  >
                    {skill}
                  </span>
                ))}
                {project.skillsRequired.length > 3 && (
                  <span className="px-1.5 py-0.5 rounded-sm bg-[#050505] text-[10px] font-mono-tech text-white/40">
                    +{project.skillsRequired.length - 3}
                  </span>
                )}
              </div>
            </div>

            {/* Bottom Progress & CTAs */}
            <div className="mt-4 pt-4 border-t border-white/[0.06] space-y-4">
              <div>
                <div className="flex justify-between text-[10px] font-mono-tech text-white/50 mb-1.5">
                  <span>BUILD PROGRESS</span>
                  <span className="text-white font-bold">{project.progressPercent}%</span>
                </div>
                <div className="w-full h-1 bg-[#050505] rounded-none overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-[#bc13fe] to-[#00f2ff]"
                    style={{ width: `${project.progressPercent}%` }}
                  />
                </div>
              </div>

              {/* Metrics & Actions */}
              <div className="flex items-center justify-between pt-1">
                <div className="flex items-center gap-3 text-xs font-mono-tech text-white/50">
                  <span className="flex items-center gap-1">
                    <Users className="w-3.5 h-3.5 text-white/40" />
                    {project.membersCount}
                  </span>
                  <span className="flex items-center gap-1">
                    <Heart
                      className={`w-3.5 h-3.5 cursor-pointer transition-colors ${
                        project.isFollowing ? 'fill-[#bc13fe] text-[#bc13fe]' : 'text-white/40 hover:text-[#bc13fe]'
                      }`}
                      onClick={() => onToggleFollow(project.id)}
                    />
                    {project.followersCount}
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  {project.recruiting && (
                    <button
                      onClick={() => onJoinProject(project.id)}
                      disabled={project.hasApplied}
                      className={`px-3 py-1.5 text-xs font-mono-tech rounded-sm transition-all cursor-pointer font-bold ${
                        project.hasApplied
                          ? 'bg-[#00f2ff]/10 border border-[#00f2ff]/40 text-[#00f2ff]'
                          : 'bg-white hover:bg-zinc-200 text-black'
                      }`}
                    >
                      {project.hasApplied ? 'APPLIED' : 'JOIN'}
                    </button>
                  )}

                  <button
                    onClick={() => onSelectProject(project)}
                    className="p-1.5 rounded-sm bg-[#050505] hover:bg-white/[0.05] text-[#00f2ff] border border-white/10 hover:border-[#00f2ff] transition-all cursor-pointer"
                    title="View Project Details"
                  >
                    <ArrowUpRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

```

---

## File: `src/components/views/PulseView.tsx`

```tsx
import React, { useState } from 'react';
import { 
  Radio, 
  Heart, 
  MessageCircle, 
  Share2, 
  Plus, 
  Send, 
  Check, 
  TrendingUp, 
  Sparkles,
  Filter,
  Calendar,
  AlertCircle
} from 'lucide-react';
import { PulsePost, UserProfile } from '../../types';
import { ShareData } from '../ShareModal';

interface PulseViewProps {
  posts: PulsePost[];
  currentUser: UserProfile;
  onToggleLike: (postId: string) => void;
  onAddComment: (postId: string, commentText: string) => void;
  onOpenCreatePost: () => void;
  onOpenQuickQuery: (query: string) => void;
  onOpenShare?: (data: ShareData) => void;
}

export const PulseView: React.FC<PulseViewProps> = ({
  posts,
  currentUser,
  onToggleLike,
  onAddComment,
  onOpenCreatePost,
  onOpenQuickQuery,
  onOpenShare,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [activeCommentPostId, setActiveCommentPostId] = useState<string | null>(null);
  const [commentInput, setCommentInput] = useState<string>('');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const categories = ['All', 'Announcements', 'General', 'Discussion', 'Help Needed'];

  const filteredPosts = selectedCategory === 'All'
    ? posts
    : posts.filter((p) => p.category.toLowerCase() === selectedCategory.toLowerCase());

  const handleSendComment = (postId: string) => {
    if (!commentInput.trim()) return;
    onAddComment(postId, commentInput.trim());
    setCommentInput('');
  };

  const handleShare = (post: PulsePost) => {
    const postUrl = `${window.location.origin}/pulse/${post.id}`;
    const sharePayload: ShareData = {
      title: `${post.author} on Campus Pulse (${post.category})`,
      text: post.text,
      url: postUrl,
      category: post.category,
    };

    if (onOpenShare) {
      onOpenShare(sharePayload);
    } else if (navigator.share) {
      navigator.share({
        title: sharePayload.title,
        text: sharePayload.text,
        url: sharePayload.url,
      }).catch(() => {});
    } else {
      navigator.clipboard.writeText(postUrl);
      setCopiedId(post.id);
      setTimeout(() => setCopiedId(null), 2000);
    }
  };

  return (
    <div id="pulse-view-container" className="space-y-6">
      {/* Top Banner / Pulse Overview Bar */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-[#121212] border border-white/[0.08] border-l-4 border-l-[#00f2ff] p-4 rounded-sm">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-mono-tech text-white/50 tracking-[2px] uppercase">
              CAMPUS NETWORK STATUS
            </span>
            <span className="w-2 h-2 rounded-full bg-[#00f2ff] animate-ping" />
          </div>
          <div className="text-xl font-black text-white font-heading mt-1 flex items-baseline gap-2">
            <span>DTU MAIN CAMPUS</span>
            <span className="text-xs font-mono-tech text-[#00f2ff] font-normal">99.9% LIVE</span>
          </div>
          <div className="text-[11px] text-white/60 mt-1 font-mono-tech">
            12,850+ active students & 38 departmental nodes synced.
          </div>
        </div>

        <div className="bg-[#121212] border border-white/[0.08] border-l-4 border-l-[#bc13fe] p-4 rounded-sm">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-mono-tech text-white/50 tracking-[2px] uppercase">
              TODAY'S ACTIVITY SPIKE
            </span>
            <TrendingUp className="w-4 h-4 text-[#bc13fe]" />
          </div>
          <div className="text-xl font-black text-white font-heading mt-1">
            +328 NEW DISCUSSIONS
          </div>
          <div className="text-[11px] text-white/60 mt-1 font-mono-tech">
            High interest in Hackathon teams & Robotics Lab slots.
          </div>
        </div>

        <div className="bg-[#121212] border border-white/[0.08] border-l-4 border-l-white p-4 rounded-sm flex flex-col justify-between">
          <div>
            <div className="text-[10px] font-mono-tech text-white/50 tracking-[2px] uppercase">
              YOUR CAMPUS IDENTITY
            </div>
            <div className="text-sm font-bold text-white font-heading mt-0.5">
              {currentUser.name} • #{String(currentUser.rank).padStart(2, '0')}
            </div>
          </div>
          <div className="flex items-center justify-between mt-2 pt-2 border-t border-white/[0.06] text-[10px] font-mono-tech text-[#00f2ff]">
            <span>{currentUser.impactScore} KARMA PTS</span>
            <span className="text-white/60 font-bold uppercase">{currentUser.department}</span>
          </div>
        </div>
      </div>

      {/* Main Pulse Stream Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left 8 Cols: Main Post Stream */}
        <div className="lg:col-span-8 space-y-4">
          {/* Post Creation Trigger Card */}
          <div className="bg-[#121212] border border-white/[0.08] p-4 rounded-sm flex items-center gap-3">
            <div className="w-9 h-9 rounded-sm bg-[#050505] border border-[#00f2ff] flex items-center justify-center font-mono-tech text-xs font-bold text-[#00f2ff]">
              {currentUser.name.slice(0, 2).toUpperCase()}
            </div>
            <button
              id="pulse-create-prompt-btn"
              onClick={onOpenCreatePost}
              className="flex-1 text-left px-4 py-2.5 bg-[#050505] hover:bg-[#090909] border border-white/10 hover:border-[#00f2ff] rounded-sm text-xs text-white/50 font-mono-tech transition-all cursor-pointer flex items-center justify-between"
            >
              <span>Broadcast an update, ask for help, or share campus news...</span>
              <Plus className="w-4 h-4 text-[#00f2ff]" />
            </button>
          </div>

          {/* Filter Bar */}
          <div className="flex flex-wrap items-center justify-between gap-3 p-3 bg-[#121212] border border-white/[0.08] rounded-sm">
            <div className="flex items-center gap-1.5 overflow-x-auto">
              <Filter className="w-3.5 h-3.5 text-white/40 mr-1 shrink-0" />
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-3 py-1 text-xs font-mono-tech tracking-[1px] uppercase rounded-sm transition-all cursor-pointer whitespace-nowrap ${
                    selectedCategory === cat
                      ? 'bg-[#00f2ff]/20 border border-[#00f2ff] text-[#00f2ff] font-bold shadow-[0_0_15px_rgba(0,242,255,0.2)]'
                      : 'bg-[#050505] border border-white/5 text-white/50 hover:text-white'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            <div className="text-[10px] font-mono-tech text-white/40">
              SHOWING {filteredPosts.length} POSTS
            </div>
          </div>

          {/* Post Feed List */}
          <div className="space-y-3">
            {filteredPosts.map((post) => (
              <div
                key={post.id}
                id={`pulse-post-${post.id}`}
                className="p-5 rounded-sm bg-[#121212] border border-white/[0.08] hover:border-white/20 transition-all space-y-3"
              >
                {/* Header */}
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-sm bg-[#050505] border border-white/10 flex items-center justify-center font-mono-tech text-xs font-bold text-white">
                      {post.author.slice(0, 2).toUpperCase()}
                    </div>
                    <div>
                      <div className="text-sm font-bold text-white flex items-center gap-2 font-heading">
                        <span>{post.author}</span>
                        {post.badge && (
                          <span className="px-1.5 py-0.2 rounded-sm bg-[#00f2ff]/10 border border-[#00f2ff]/30 text-[9px] font-mono-tech text-[#00f2ff] font-bold uppercase">
                            {post.badge}
                          </span>
                        )}
                      </div>
                      <div className="text-[10px] font-mono-tech text-white/40">
                        {post.authorDepartment || 'General Member'} • {post.timestamp}
                      </div>
                    </div>
                  </div>

                  <span className="text-[10px] font-mono-tech text-white/60 px-2.5 py-0.5 rounded-sm bg-[#050505] border border-white/10 uppercase">
                    {post.category}
                  </span>
                </div>

                {/* Text Content */}
                <p className="text-sm text-white/90 leading-relaxed font-normal">
                  {post.text}
                </p>

                {/* Actions Footer */}
                <div className="pt-3 border-t border-white/[0.06] flex items-center justify-between text-xs font-mono-tech text-white/50">
                  <div className="flex items-center gap-5">
                    <button
                      onClick={() => onToggleLike(post.id)}
                      className={`flex items-center gap-1.5 cursor-pointer transition-colors ${
                        post.isLiked ? 'text-[#bc13fe] font-bold' : 'hover:text-[#bc13fe]'
                      }`}
                    >
                      <Heart className={`w-4 h-4 ${post.isLiked ? 'fill-[#bc13fe] text-[#bc13fe]' : ''}`} />
                      <span>{post.likesCount}</span>
                    </button>

                    <button
                      onClick={() => setActiveCommentPostId(activeCommentPostId === post.id ? null : post.id)}
                      className="flex items-center gap-1.5 hover:text-[#00f2ff] transition-colors cursor-pointer"
                    >
                      <MessageCircle className="w-4 h-4" />
                      <span>{post.commentsCount} Comments</span>
                    </button>
                  </div>

                  <button
                    onClick={() => handleShare(post)}
                    className="flex items-center gap-1.5 px-2.5 py-1 rounded-sm bg-white/[0.03] hover:bg-[#00f2ff]/15 hover:text-[#00f2ff] transition-all cursor-pointer border border-transparent hover:border-[#00f2ff]/30 text-white/70"
                    title="Share to WhatsApp, Telegram, X, Reddit, etc."
                  >
                    {copiedId === post.id ? (
                      <span className="text-[#00f2ff] text-[11px] flex items-center gap-1">
                        <Check className="w-3.5 h-3.5" /> Copied!
                      </span>
                    ) : (
                      <span className="flex items-center gap-1 text-[11px] font-mono-tech">
                        <Share2 className="w-3.5 h-3.5" /> Share
                      </span>
                    )}
                  </button>
                </div>

                {/* Comments Expandable Box */}
                {activeCommentPostId === post.id && (
                  <div className="mt-3 pt-3 border-t border-white/[0.06] space-y-3 bg-[#050505] p-3 rounded-sm">
                    {post.comments.length > 0 ? (
                      <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                        {post.comments.map((c) => (
                          <div key={c.id} className="p-2 rounded-sm bg-[#121212] border border-white/5 text-xs text-white/80">
                            <div className="flex justify-between text-[9px] font-mono-tech text-[#00f2ff] mb-0.5">
                              <span>{c.author}</span>
                              <span className="text-white/40">{c.time}</span>
                            </div>
                            <div>{c.text}</div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="text-[11px] font-mono-tech text-white/40">
                        No responses yet. Be the first to reply!
                      </div>
                    )}

                    <div className="flex items-center gap-2">
                      <input
                        type="text"
                        value={commentInput}
                        onChange={(e) => setCommentInput(e.target.value)}
                        onKeyDown={(e) => e.key === 'Enter' && handleSendComment(post.id)}
                        placeholder="Write a peer response..."
                        className="flex-1 px-3 py-2 bg-[#121212] border border-white/10 rounded-sm text-xs text-white focus:outline-none focus:border-[#00f2ff] font-mono-tech"
                      />
                      <button
                        onClick={() => handleSendComment(post.id)}
                        className="px-3.5 py-2 bg-[#00f2ff] hover:bg-[#00f2ff]/80 text-black font-bold rounded-sm text-xs cursor-pointer"
                      >
                        <Send className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Right 4 Cols: Campus Live Widget & Quick Topics */}
        <div className="lg:col-span-4 space-y-4">
          {/* Quick AI Prompts */}
          <div className="bg-[#121212] border border-white/[0.08] p-5 rounded-sm space-y-3">
            <div className="flex items-center gap-2 text-xs font-mono-tech text-[#00f2ff] font-bold uppercase tracking-[2px]">
              <Sparkles className="w-4 h-4" />
              <span>COMPASS QUICK INQUIRIES</span>
            </div>
            <p className="text-xs text-white/60">
              Instantly resolve common queries with campus neural data:
            </p>
            <div className="space-y-1.5">
              {[
                'Find who has a Jetson Nano board to borrow today',
                'What is the grading split for Prof. Raman in ML?',
                'Who can tutor me in DSA tree balancing?',
                'Where are the best quiet study spots with AC?'
              ].map((query, idx) => (
                <button
                  key={idx}
                  onClick={() => onOpenQuickQuery(query)}
                  className="w-full text-left p-2.5 rounded-sm bg-[#050505] border border-white/5 hover:border-[#00f2ff] text-xs font-mono-tech text-white/80 hover:text-[#00f2ff] transition-all cursor-pointer"
                >
                  "{query}"
                </button>
              ))}
            </div>
          </div>

          {/* Departmental Bulletin */}
          <div className="bg-[#121212] border border-white/[0.08] p-5 rounded-sm space-y-3">
            <div className="text-xs font-mono-tech text-[#bc13fe] font-bold uppercase tracking-[2px] flex items-center justify-between">
              <span>CAMPUS CALENDAR ALERTS</span>
              <Calendar className="w-4 h-4" />
            </div>
            <div className="space-y-2 text-xs font-mono-tech">
              <div className="p-2.5 rounded-sm bg-[#050505] border border-white/5">
                <div className="text-[#00f2ff] font-bold">SMART INDIA HACKATHON 2026</div>
                <div className="text-white/60 text-[10px] mt-0.5">Team registration closes Friday 11:59 PM</div>
              </div>
              <div className="p-2.5 rounded-sm bg-[#050505] border border-white/5">
                <div className="text-[#bc13fe] font-bold">ROBOTICS LAB SLOTS OPEN</div>
                <div className="text-white/60 text-[10px] mt-0.5">3D Printer & CNC reserve window live</div>
              </div>
              <div className="p-2.5 rounded-sm bg-[#050505] border border-white/5">
                <div className="text-white font-bold">MID-TERM SYLLABUS REPO</div>
                <div className="text-white/60 text-[10px] mt-0.5">Senior handwritten notes uploaded in Guides</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

```

---

## File: `src/data/mockData.ts`

```tsx
import { UserProfile, MarketplaceItem, ProjectItem, PulsePost, BorrowItem, SkillMatch, GuidanceTopic, CompassMessage, CampusNotification, DirectMessage } from '../types';

export const INITIAL_USERS: UserProfile[] = [
  {
    id: 'u1',
    name: 'Ananya Rao',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    initials: 'AR',
    department: 'Computer Science, 4th Year',
    year: '4th Year',
    rank: 1,
    impactScore: 2310,
    title: 'Knowledge Keeper',
    nametagIcon: '🥇',
    verified: true,
    knowledgeScore: 91,
    skillScore: 66,
    resourceScore: 72,
    projectScore: 83,
    rankJourney: [14, 9, 6, 3, 1],
    monthlyGrowthPercent: 24,
    skillsOffered: ['Distributed Systems', 'Go', 'Technical Writing'],
    skillsWanted: ['UI/UX', 'Product Strategy'],
    bio: 'Lead TA for Operating Systems. Curator of the open-source campus course archives.',
    contactEmail: 'ananya.rao@campus.edu',
    badges: ['Top Mentor', 'Gold Scholar', 'Verified TA', '100% Peer Return'],
    hostelWing: 'North Block (H4)',
    kudosCount: 142,
    itemsLent: 28,
    notesShared: 54,
    mentorHours: 68,
    verifiedHash: '0x8f2a...c4e1',
    isPrivate: false, // Public profile: direct messaging enabled
    friendIds: ['u3', 'u2', 'u4']
  },
  {
    id: 'u2',
    name: 'Devansh Iyer',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    initials: 'DI',
    department: 'Robotics & AI, 3rd Year',
    year: '3rd Year',
    rank: 2,
    impactScore: 2104,
    title: 'Project Builder',
    nametagIcon: '🥈',
    verified: true,
    knowledgeScore: 72,
    skillScore: 89,
    resourceScore: 64,
    projectScore: 96,
    rankJourney: [16, 11, 7, 4, 2],
    monthlyGrowthPercent: 19,
    skillsOffered: ['Computer Vision', 'PyTorch', 'ROS 2'],
    skillsWanted: ['CAD Modeling', 'Web Frontend'],
    bio: 'Creator of CampusVision. Hardware enthusiast building autonomous campus tools.',
    contactEmail: 'devansh.i@campus.edu',
    badges: ['Build Master', 'Hackathon 1st', 'Autonomous AI', 'Core Lead'],
    hostelWing: 'Tech Tower (H7)',
    kudosCount: 118,
    itemsLent: 19,
    notesShared: 22,
    mentorHours: 45,
    verifiedHash: '0x3b1c...9a72',
    isPrivate: true, // Private profile: requires friend request before messaging
    friendIds: ['u1'],
    pendingFriendRequestUserIds: ['u3']
  },
  {
    id: 'u3',
    name: 'Yuvraj Sen',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
    initials: 'YS',
    department: 'Computer Science, 3rd Year',
    year: '3rd Year',
    rank: 3,
    impactScore: 1842,
    title: 'Most Generous',
    nametagIcon: '🥉',
    verified: true,
    knowledgeScore: 62,
    skillScore: 74,
    resourceScore: 91,
    projectScore: 48,
    rankJourney: [18, 12, 8, 5, 3],
    monthlyGrowthPercent: 12,
    skillsOffered: ['Python', 'Figma', 'Embedded Systems'],
    skillsWanted: ['Next.js', 'System Design'],
    bio: 'Shared over 18 lab items, 42 course guides, and hosted 6 peer code reviews this semester.',
    contactEmail: 'yuvraj.sen@campus.edu',
    badges: ['Top Lender', 'Speed Sharer', 'Verified Peer', 'Community Hero'],
    hostelWing: 'North Block (H4)',
    kudosCount: 96,
    itemsLent: 35,
    notesShared: 38,
    mentorHours: 32,
    verifiedHash: '0x99e2...bb40',
    isPrivate: false, // Public profile
    friendIds: ['u1', 'u5'],
    pendingFriendRequestUserIds: ['u8']
  },
  {
    id: 'u4',
    name: 'Priya Malhotra',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
    initials: 'PM',
    department: 'Electrical Engineering, 3rd Year',
    year: '3rd Year',
    rank: 4,
    impactScore: 1690,
    title: 'Skill Master',
    nametagIcon: '✨',
    verified: true,
    knowledgeScore: 63,
    skillScore: 92,
    resourceScore: 55,
    projectScore: 64,
    rankJourney: [21, 15, 10, 6, 4],
    monthlyGrowthPercent: 15,
    skillsOffered: ['Embedded C', 'IoT Architecture', 'PCB Design'],
    skillsWanted: ['Mobile App Dev', 'Figma'],
    bio: 'Co-creator of SoilSense. Mentoring 12 juniors in embedded systems and microcontrollers.',
    contactEmail: 'priya.m@campus.edu',
    badges: ['Hardware Wizard', 'Skill Exchange Star', 'IoT Lead'],
    hostelWing: 'East Wing (H2)',
    kudosCount: 84,
    itemsLent: 14,
    notesShared: 26,
    mentorHours: 41,
    verifiedHash: '0x5d4a...7f19',
    isPrivate: true, // Private profile
    friendIds: ['u1']
  },
  {
    id: 'u5',
    name: 'Kabir Shah',
    avatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=150&auto=format&fit=crop&q=80',
    initials: 'KS',
    department: 'Mechanical & Design, 4th Year',
    year: '4th Year',
    rank: 5,
    impactScore: 1520,
    title: 'Campus Creator',
    nametagIcon: '⚡',
    verified: true,
    knowledgeScore: 58,
    skillScore: 61,
    resourceScore: 88,
    projectScore: 55,
    rankJourney: [25, 17, 12, 8, 5],
    monthlyGrowthPercent: 11,
    skillsOffered: ['SolidWorks', '3D Printing', 'Product Design'],
    skillsWanted: ['Python', 'Computer Vision'],
    bio: 'Design lab manager. Keeps the makerspace open and helps students fabricate prototypes.',
    contactEmail: 'kabir.s@campus.edu',
    badges: ['Makerspace Steward', 'Fabrication Lead', 'Lab Hero'],
    hostelWing: 'Research Enclave (PG)',
    kudosCount: 77,
    itemsLent: 31,
    notesShared: 15,
    mentorHours: 29,
    verifiedHash: '0x12fc...33b8'
  },
  {
    id: 'u6',
    name: 'Rhea Nair',
    avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&auto=format&fit=crop&q=80',
    initials: 'RN',
    department: 'Physics & Quantum Computing, 3rd Year',
    year: '3rd Year',
    rank: 6,
    impactScore: 1410,
    title: 'Quantum Pioneer',
    nametagIcon: '⚛️',
    verified: true,
    knowledgeScore: 84,
    skillScore: 70,
    resourceScore: 49,
    projectScore: 62,
    rankJourney: [29, 21, 15, 10, 6],
    monthlyGrowthPercent: 18,
    skillsOffered: ['Qiskit', 'Linear Algebra', 'Electrodynamics'],
    skillsWanted: ['LaTeX', 'Julia'],
    bio: 'Author of Electromagnetic Theory study guides and Quantum Circuit tutorials.',
    contactEmail: 'rhea.n@campus.edu',
    badges: ['Quantum Guru', 'Notes Contributor', 'Physics Lead'],
    hostelWing: 'North Block (H4)',
    kudosCount: 65,
    itemsLent: 12,
    notesShared: 41,
    mentorHours: 35,
    verifiedHash: '0x44d1...6a9e'
  },
  {
    id: 'u7',
    name: 'Aman Tiwari',
    avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=150&auto=format&fit=crop&q=80',
    initials: 'AT',
    department: 'Civil & Environmental, 2nd Year',
    year: '2nd Year',
    rank: 7,
    impactScore: 1290,
    title: 'Eco Architect',
    nametagIcon: '🌱',
    verified: true,
    knowledgeScore: 52,
    skillScore: 64,
    resourceScore: 82,
    projectScore: 59,
    rankJourney: [33, 24, 18, 11, 7],
    monthlyGrowthPercent: 14,
    skillsOffered: ['AutoCAD', 'Surveying', 'GIS Mapping'],
    skillsWanted: ['Python Data', 'BIM'],
    bio: 'Lends surveying equipment and scientific calculators to all junior engineering batches.',
    contactEmail: 'aman.t@campus.edu',
    badges: ['Top Lender', 'Sustainability Champ', 'Peer Helper'],
    hostelWing: 'Tech Tower (H7)',
    kudosCount: 59,
    itemsLent: 27,
    notesShared: 19,
    mentorHours: 20,
    verifiedHash: '0x7e8b...22f3'
  },
  {
    id: 'u8',
    name: 'Tanvi Joshi',
    avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&auto=format&fit=crop&q=80',
    initials: 'TJ',
    department: 'BioTech & Bio-Informatics, 4th Year',
    year: '4th Year',
    rank: 8,
    impactScore: 1180,
    title: 'Bio Data Scientist',
    nametagIcon: '🧬',
    verified: true,
    knowledgeScore: 78,
    skillScore: 73,
    resourceScore: 42,
    projectScore: 67,
    rankJourney: [40, 28, 20, 13, 8],
    monthlyGrowthPercent: 16,
    skillsOffered: ['BioPython', 'Genomics ML', 'R'],
    skillsWanted: ['Docker', 'AWS'],
    bio: 'Mentors undergraduate students in computational genomics and lab safety protocols.',
    contactEmail: 'tanvi.j@campus.edu',
    badges: ['BioML Lead', 'Research Star', 'Verified Mentor'],
    hostelWing: 'Research Enclave (PG)',
    kudosCount: 53,
    itemsLent: 9,
    notesShared: 32,
    mentorHours: 38,
    verifiedHash: '0x9a3c...11e7'
  },
  {
    id: 'u9',
    name: 'Siddharth Varma',
    avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=150&auto=format&fit=crop&q=80',
    initials: 'SV',
    department: 'Computer Science & CyberSec, 3rd Year',
    year: '3rd Year',
    rank: 9,
    impactScore: 1095,
    title: 'Security Auditor',
    nametagIcon: '🛡️',
    verified: true,
    knowledgeScore: 70,
    skillScore: 85,
    resourceScore: 44,
    projectScore: 58,
    rankJourney: [42, 30, 22, 14, 9],
    monthlyGrowthPercent: 20,
    skillsOffered: ['Penetration Testing', 'Cryptography', 'Rust'],
    skillsWanted: ['Smart Contracts', 'Solidity'],
    bio: 'Founder of Campus CTF Club. Host of weekly reverse engineering and Linux exploitation jams.',
    contactEmail: 'sid.v@campus.edu',
    badges: ['Zero-Day Hunter', 'CTF Champion', 'Rustacean'],
    hostelWing: 'Tech Tower (H7)',
    kudosCount: 48,
    itemsLent: 8,
    notesShared: 25,
    mentorHours: 30,
    verifiedHash: '0x66f1...88c2'
  },
  {
    id: 'u10',
    name: 'Meera Chawla',
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80',
    initials: 'MC',
    department: 'Design & Human-Computer Interaction, 2nd Year',
    year: '2nd Year',
    rank: 10,
    impactScore: 980,
    title: 'UI Architect',
    nametagIcon: '🎨',
    verified: true,
    knowledgeScore: 60,
    skillScore: 88,
    resourceScore: 38,
    projectScore: 71,
    rankJourney: [50, 35, 25, 16, 10],
    monthlyGrowthPercent: 26,
    skillsOffered: ['Figma Prototyping', 'Design Systems', 'User Research'],
    skillsWanted: ['React Native', 'Swift'],
    bio: 'Crafting the design identity for university student projects and open-source portals.',
    contactEmail: 'meera.c@campus.edu',
    badges: ['Design Master', 'Figma Wizard', 'Creative Lead'],
    hostelWing: 'East Wing (H2)',
    kudosCount: 44,
    itemsLent: 6,
    notesShared: 28,
    mentorHours: 24,
    verifiedHash: '0x22a9...ff50'
  },
  {
    id: 'u11',
    name: 'Arjun Nambiar',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
    initials: 'AN',
    department: 'Computer Science, 4th Year',
    year: '4th Year',
    rank: 11,
    impactScore: 940,
    title: 'Cloud Architect',
    nametagIcon: '☁️',
    verified: true,
    knowledgeScore: 74,
    skillScore: 82,
    resourceScore: 40,
    projectScore: 68,
    rankJourney: [45, 30, 20, 15, 11],
    monthlyGrowthPercent: 18,
    skillsOffered: ['Kubernetes', 'Go', 'GCP'],
    skillsWanted: ['Rust', 'WebAssembly'],
    bio: 'Maintains student cluster infrastructure and DevOps workflows.',
    contactEmail: 'arjun.n@campus.edu',
    badges: ['Cloud Lead', 'Cluster Admin', 'DevOps Hero'],
    hostelWing: 'North Block (H4)',
    kudosCount: 39,
    itemsLent: 11,
    notesShared: 30,
    mentorHours: 22,
    verifiedHash: '0x33b8...91a2'
  },
  {
    id: 'u12',
    name: 'Sneha Kulkarni',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    initials: 'SK',
    department: 'Mathematics & Computing, 3rd Year',
    year: '3rd Year',
    rank: 12,
    impactScore: 915,
    title: 'Math Olympiad Mentor',
    nametagIcon: '📐',
    verified: true,
    knowledgeScore: 94,
    skillScore: 60,
    resourceScore: 35,
    projectScore: 50,
    rankJourney: [48, 33, 24, 18, 12],
    monthlyGrowthPercent: 15,
    skillsOffered: ['Abstract Algebra', 'Probability & Stats', 'Combinatorics'],
    skillsWanted: ['C++', 'Competitive Coding'],
    bio: 'Weekly math clinic host for first-year engineers and calculus cohorts.',
    contactEmail: 'sneha.k@campus.edu',
    badges: ['Pure Math Lead', 'Top Tutor', 'Calculus Master'],
    hostelWing: 'East Wing (H2)',
    kudosCount: 36,
    itemsLent: 14,
    notesShared: 46,
    mentorHours: 40,
    verifiedHash: '0x71a4...55e9'
  },
  {
    id: 'u13',
    name: 'Rohan Deshmukh',
    avatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=150&auto=format&fit=crop&q=80',
    initials: 'RD',
    department: 'Electrical Engineering, 4th Year',
    year: '4th Year',
    rank: 13,
    impactScore: 890,
    title: 'Signal Processing Pro',
    nametagIcon: '📡',
    verified: true,
    knowledgeScore: 80,
    skillScore: 78,
    resourceScore: 50,
    projectScore: 61,
    rankJourney: [52, 38, 26, 19, 13],
    monthlyGrowthPercent: 12,
    skillsOffered: ['DSP', 'MATLAB', 'FPGA Verilog'],
    skillsWanted: ['Deep Learning', 'PyTorch'],
    bio: 'DSP lab assistant. Lends oscilloscopes and logic analyzers to seniors.',
    contactEmail: 'rohan.d@campus.edu',
    badges: ['Signal Wizard', 'Hardware Lender'],
    hostelWing: 'Tech Tower (H7)',
    kudosCount: 31,
    itemsLent: 21,
    notesShared: 18,
    mentorHours: 19,
    verifiedHash: '0x19a0...33c4'
  },
  {
    id: 'u14',
    name: 'Ishita Banerjee',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
    initials: 'IB',
    department: 'Chemical Engineering, 3rd Year',
    year: '3rd Year',
    rank: 14,
    impactScore: 865,
    title: 'Process Synthesizer',
    nametagIcon: '⚗️',
    verified: true,
    knowledgeScore: 76,
    skillScore: 65,
    resourceScore: 58,
    projectScore: 54,
    rankJourney: [55, 41, 29, 21, 14],
    monthlyGrowthPercent: 14,
    skillsOffered: ['Thermodynamics', 'Aspen Plus', 'Fluid Dynamics'],
    skillsWanted: ['Python', 'Data Analytics'],
    bio: 'Curates comprehensive chemical transport and kinetics handwritten notes.',
    contactEmail: 'ishita.b@campus.edu',
    badges: ['Process Champ', 'Lab Star'],
    hostelWing: 'Research Enclave (PG)',
    kudosCount: 29,
    itemsLent: 17,
    notesShared: 35,
    mentorHours: 18,
    verifiedHash: '0x88f2...12bb'
  },
  {
    id: 'u15',
    name: 'Karan Mehra',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    initials: 'KM',
    department: 'Aerospace Engineering, 3rd Year',
    year: '3rd Year',
    rank: 15,
    impactScore: 840,
    title: 'Aerodynamics Lead',
    nametagIcon: '🚀',
    verified: true,
    knowledgeScore: 71,
    skillScore: 79,
    resourceScore: 48,
    projectScore: 75,
    rankJourney: [60, 44, 32, 23, 15],
    monthlyGrowthPercent: 21,
    skillsOffered: ['CFD Ansys', 'Aerodynamics', 'Flight Dynamics'],
    skillsWanted: ['ROS 2', 'Embedded C'],
    bio: 'Rocketry team aerodynamics lead. Fabricates miniature wind-tunnel models.',
    contactEmail: 'karan.m@campus.edu',
    badges: ['Rocketry Team', 'CFD Specialist'],
    hostelWing: 'North Block (H4)',
    kudosCount: 35,
    itemsLent: 13,
    notesShared: 21,
    mentorHours: 25,
    verifiedHash: '0x45a9...00dd'
  },
  {
    id: 'u16',
    name: 'Pooja Agarwal',
    avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&auto=format&fit=crop&q=80',
    initials: 'PA',
    department: 'Computer Science & AI, 2nd Year',
    year: '2nd Year',
    rank: 16,
    impactScore: 810,
    title: 'NLP Researcher',
    nametagIcon: '💬',
    verified: true,
    knowledgeScore: 68,
    skillScore: 84,
    resourceScore: 32,
    projectScore: 72,
    rankJourney: [65, 48, 35, 25, 16],
    monthlyGrowthPercent: 28,
    skillsOffered: ['HuggingFace', 'Transformers', 'FastAPI'],
    skillsWanted: ['System Design', 'Docker'],
    bio: 'Fine-tuning multilingual language models for campus course summaries.',
    contactEmail: 'pooja.a@campus.edu',
    badges: ['NLP Innovator', 'AI Builder'],
    hostelWing: 'East Wing (H2)',
    kudosCount: 32,
    itemsLent: 5,
    notesShared: 24,
    mentorHours: 26,
    verifiedHash: '0x9910...ab43'
  },
  {
    id: 'u17',
    name: 'Vikram Sethi',
    avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=150&auto=format&fit=crop&q=80',
    initials: 'VS',
    department: 'Robotics & Mechatronics, 4th Year',
    year: '4th Year',
    rank: 17,
    impactScore: 790,
    title: 'Kinematics Master',
    nametagIcon: '🦾',
    verified: true,
    knowledgeScore: 72,
    skillScore: 80,
    resourceScore: 60,
    projectScore: 65,
    rankJourney: [68, 50, 38, 27, 17],
    monthlyGrowthPercent: 11,
    skillsOffered: ['Inverse Kinematics', 'SolidWorks', 'Arduino'],
    skillsWanted: ['Computer Vision', 'PyTorch'],
    bio: 'Bionic arm prototype lead. Donated 12 servo kits to the robotics club.',
    contactEmail: 'vikram.s@campus.edu',
    badges: ['Robotics Veteran', 'Hardware Donor'],
    hostelWing: 'Tech Tower (H7)',
    kudosCount: 28,
    itemsLent: 25,
    notesShared: 14,
    mentorHours: 20,
    verifiedHash: '0x12a8...56c9'
  },
  {
    id: 'u18',
    name: 'Divya Sundaram',
    avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&auto=format&fit=crop&q=80',
    initials: 'DS',
    department: 'BioTech, 3rd Year',
    year: '3rd Year',
    rank: 18,
    impactScore: 765,
    title: 'CRISPR Analyst',
    nametagIcon: '🧪',
    verified: true,
    knowledgeScore: 82,
    skillScore: 66,
    resourceScore: 45,
    projectScore: 52,
    rankJourney: [70, 53, 40, 29, 18],
    monthlyGrowthPercent: 16,
    skillsOffered: ['Molecular Cloning', 'Gel Electrophoresis', 'NCBI Blast'],
    skillsWanted: ['Python', 'Biostatistics'],
    bio: 'Prepares junior cohorts for wet-lab techniques and micro-pipetting masteries.',
    contactEmail: 'divya.s@campus.edu',
    badges: ['WetLab Guide', 'Bio Star'],
    hostelWing: 'Research Enclave (PG)',
    kudosCount: 25,
    itemsLent: 10,
    notesShared: 29,
    mentorHours: 31,
    verifiedHash: '0x33fa...9901'
  },
  {
    id: 'u19',
    name: 'Nikhil Kashyap',
    avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=150&auto=format&fit=crop&q=80',
    initials: 'NK',
    department: 'Civil Engineering, 4th Year',
    year: '4th Year',
    rank: 19,
    impactScore: 740,
    title: 'Structural Modeler',
    nametagIcon: '🏗️',
    verified: true,
    knowledgeScore: 70,
    skillScore: 72,
    resourceScore: 59,
    projectScore: 49,
    rankJourney: [72, 55, 42, 30, 19],
    monthlyGrowthPercent: 13,
    skillsOffered: ['STAAD Pro', 'ETABS', 'Concrete Tech'],
    skillsWanted: ['Revit', 'Python Automation'],
    bio: 'Mentors juniors on earthquake-resistant building design calculations.',
    contactEmail: 'nikhil.k@campus.edu',
    badges: ['Structural Pro', 'Top Lender'],
    hostelWing: 'Tech Tower (H7)',
    kudosCount: 22,
    itemsLent: 20,
    notesShared: 22,
    mentorHours: 18,
    verifiedHash: '0x77c2...41a0'
  },
  {
    id: 'u20',
    name: 'Aanya Choudhury',
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80',
    initials: 'AC',
    department: 'Design, 3rd Year',
    year: '3rd Year',
    rank: 20,
    impactScore: 715,
    title: 'Motion Designer',
    nametagIcon: '✨',
    verified: true,
    knowledgeScore: 61,
    skillScore: 85,
    resourceScore: 36,
    projectScore: 68,
    rankJourney: [75, 58, 44, 32, 20],
    monthlyGrowthPercent: 22,
    skillsOffered: ['After Effects', 'Spline 3D', 'Branding'],
    skillsWanted: ['Three.js', 'React'],
    bio: 'Designs event identities and 3D landing visuals for collegiate hackathons.',
    contactEmail: 'aanya.c@campus.edu',
    badges: ['Motion Star', 'Visual Craftsman'],
    hostelWing: 'East Wing (H2)',
    kudosCount: 27,
    itemsLent: 7,
    notesShared: 16,
    mentorHours: 25,
    verifiedHash: '0x55d8...823f'
  },
  {
    id: 'u21',
    name: 'Tarun Saxena',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
    initials: 'TS',
    department: 'Computer Science, 2nd Year',
    year: '2nd Year',
    rank: 21,
    impactScore: 690,
    title: 'Algorithms Ace',
    nametagIcon: '⚡',
    verified: true,
    knowledgeScore: 78,
    skillScore: 75,
    resourceScore: 28,
    projectScore: 55,
    rankJourney: [80, 62, 48, 35, 21],
    monthlyGrowthPercent: 24,
    skillsOffered: ['Data Structures', 'C++', 'Graph Theory'],
    skillsWanted: ['Web Dev', 'Docker'],
    bio: 'Candidate Master on Codeforces. Hosts nightly DSA mock problems.',
    contactEmail: 'tarun.s@campus.edu',
    badges: ['Competitive Coder', 'DSA Tutor'],
    hostelWing: 'North Block (H4)',
    kudosCount: 26,
    itemsLent: 4,
    notesShared: 38,
    mentorHours: 34,
    verifiedHash: '0x1102...fa99'
  },
  {
    id: 'u22',
    name: 'Bhavna Menon',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    initials: 'BM',
    department: 'Physics, 4th Year',
    year: '4th Year',
    rank: 22,
    impactScore: 670,
    title: 'Optics Specialist',
    nametagIcon: '🔬',
    verified: true,
    knowledgeScore: 84,
    skillScore: 62,
    resourceScore: 44,
    projectScore: 49,
    rankJourney: [82, 65, 50, 36, 22],
    monthlyGrowthPercent: 12,
    skillsOffered: ['Laser Physics', 'Fourier Optics', 'LaTeX'],
    skillsWanted: ['Python', 'Blender 3D'],
    bio: 'Laser interferometry laboratory guide and optics question solver.',
    contactEmail: 'bhavna.m@campus.edu',
    badges: ['Optics Pro', 'Lab Guide'],
    hostelWing: 'Research Enclave (PG)',
    kudosCount: 21,
    itemsLent: 9,
    notesShared: 31,
    mentorHours: 28,
    verifiedHash: '0x44c1...33e0'
  },
  {
    id: 'u23',
    name: 'Sameer Qureshi',
    avatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=150&auto=format&fit=crop&q=80',
    initials: 'SQ',
    department: 'Electrical Engineering, 3rd Year',
    year: '3rd Year',
    rank: 23,
    impactScore: 645,
    title: 'Power Grid Explorer',
    nametagIcon: '⚡',
    verified: true,
    knowledgeScore: 69,
    skillScore: 71,
    resourceScore: 52,
    projectScore: 50,
    rankJourney: [85, 68, 52, 38, 23],
    monthlyGrowthPercent: 15,
    skillsOffered: ['Power Systems', 'Simulink', 'High Voltage Tech'],
    skillsWanted: ['Machine Learning', 'SQL'],
    bio: 'Shares high-voltage lab manuals and circuit simulation notebooks.',
    contactEmail: 'sameer.q@campus.edu',
    badges: ['Power Lead', 'Circuit Master'],
    hostelWing: 'North Block (H4)',
    kudosCount: 19,
    itemsLent: 15,
    notesShared: 25,
    mentorHours: 17,
    verifiedHash: '0x9923...aa12'
  },
  {
    id: 'u24',
    name: 'Kavya Pillai',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
    initials: 'KP',
    department: 'Robotics & Automation, 2nd Year',
    year: '2nd Year',
    rank: 24,
    impactScore: 625,
    title: 'Drone Pilot & Dev',
    nametagIcon: '🛸',
    verified: true,
    knowledgeScore: 60,
    skillScore: 82,
    resourceScore: 40,
    projectScore: 63,
    rankJourney: [88, 70, 55, 40, 24],
    monthlyGrowthPercent: 25,
    skillsOffered: ['PX4 Autopilot', 'Drone Assembly', 'C++'],
    skillsWanted: ['Computer Vision', 'YOLO'],
    bio: 'Builds carbon-fiber quadcopters for autonomous mapping projects.',
    contactEmail: 'kavya.p@campus.edu',
    badges: ['Drone Master', 'Autonomous Dev'],
    hostelWing: 'East Wing (H2)',
    kudosCount: 23,
    itemsLent: 8,
    notesShared: 14,
    mentorHours: 21,
    verifiedHash: '0x6677...1199'
  },
  {
    id: 'u25',
    name: 'Harsh Vardhan',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    initials: 'HV',
    department: 'Mechanical Engineering, 3rd Year',
    year: '3rd Year',
    rank: 25,
    impactScore: 605,
    title: 'Thermodynamics TA',
    nametagIcon: '🔥',
    verified: true,
    knowledgeScore: 75,
    skillScore: 64,
    resourceScore: 51,
    projectScore: 45,
    rankJourney: [90, 72, 58, 42, 25],
    monthlyGrowthPercent: 14,
    skillsOffered: ['IC Engines', 'Heat Transfer', 'Ansys Fluent'],
    skillsWanted: ['Python', 'Arduino'],
    bio: 'Author of solved Heat Transfer past 5-year university exam guides.',
    contactEmail: 'harsh.v@campus.edu',
    badges: ['Thermo Guru', 'Top Notes Sharer'],
    hostelWing: 'Tech Tower (H7)',
    kudosCount: 18,
    itemsLent: 12,
    notesShared: 36,
    mentorHours: 20,
    verifiedHash: '0x3344...bb77'
  },
  {
    id: 'u26',
    name: 'Shreya Sengupta',
    avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&auto=format&fit=crop&q=80',
    initials: 'SS',
    department: 'Computer Science, 3rd Year',
    year: '3rd Year',
    rank: 26,
    impactScore: 585,
    title: 'Web3 & Security',
    nametagIcon: '⛓️',
    verified: true,
    knowledgeScore: 67,
    skillScore: 76,
    resourceScore: 30,
    projectScore: 61,
    rankJourney: [92, 75, 60, 44, 26],
    monthlyGrowthPercent: 19,
    skillsOffered: ['Solidity', 'Foundry', 'Zero Knowledge Basics'],
    skillsWanted: ['Rust', 'Frontend Design'],
    bio: 'Audits peer smart contracts and organizes Web3 workshops on campus.',
    contactEmail: 'shreya.s@campus.edu',
    badges: ['ZK Enthusiast', 'Smart Contract Auditor'],
    hostelWing: 'Research Enclave (PG)',
    kudosCount: 20,
    itemsLent: 6,
    notesShared: 20,
    mentorHours: 24,
    verifiedHash: '0x8899...cc33'
  },
  {
    id: 'u27',
    name: 'Aditya Roy',
    avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=150&auto=format&fit=crop&q=80',
    initials: 'AR',
    department: 'BioTech, 2nd Year',
    year: '2nd Year',
    rank: 27,
    impactScore: 565,
    title: 'Microbiology Guide',
    nametagIcon: '🧫',
    verified: true,
    knowledgeScore: 73,
    skillScore: 61,
    resourceScore: 40,
    projectScore: 46,
    rankJourney: [95, 78, 62, 46, 27],
    monthlyGrowthPercent: 17,
    skillsOffered: ['Cell Culture', 'Gram Staining', 'Spectrophotometry'],
    skillsWanted: ['Python ML', 'R'],
    bio: 'Assists junior biology batches during Friday afternoon microscope labs.',
    contactEmail: 'aditya.r@campus.edu',
    badges: ['Microbiology Guide', 'Lab Supporter'],
    hostelWing: 'North Block (H4)',
    kudosCount: 16,
    itemsLent: 9,
    notesShared: 22,
    mentorHours: 19,
    verifiedHash: '0x1256...7890'
  },
  {
    id: 'u28',
    name: 'Nisha Hegde',
    avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&auto=format&fit=crop&q=80',
    initials: 'NH',
    department: 'Design & Human Factors, 4th Year',
    year: '4th Year',
    rank: 28,
    impactScore: 545,
    title: 'Accessibility Advocate',
    nametagIcon: '♿',
    verified: true,
    knowledgeScore: 68,
    skillScore: 74,
    resourceScore: 33,
    projectScore: 58,
    rankJourney: [98, 80, 65, 48, 28],
    monthlyGrowthPercent: 15,
    skillsOffered: ['WCAG Accessibility', 'User Testing', 'Figma'],
    skillsWanted: ['Frontend React', 'Tailwind'],
    bio: 'Ensures campus student apps are accessible for screen-readers and low vision.',
    contactEmail: 'nisha.h@campus.edu',
    badges: ['A11y Champion', 'Design Mentor'],
    hostelWing: 'East Wing (H2)',
    kudosCount: 22,
    itemsLent: 5,
    notesShared: 18,
    mentorHours: 23,
    verifiedHash: '0x7788...5544'
  },
  {
    id: 'u29',
    name: 'Manish Rawat',
    avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=150&auto=format&fit=crop&q=80',
    initials: 'MR',
    department: 'Civil Engineering, 3rd Year',
    year: '3rd Year',
    rank: 29,
    impactScore: 525,
    title: 'Geotechnical Fellow',
    nametagIcon: '⛰️',
    verified: true,
    knowledgeScore: 69,
    skillScore: 63,
    resourceScore: 55,
    projectScore: 41,
    rankJourney: [100, 82, 68, 50, 29],
    monthlyGrowthPercent: 11,
    skillsOffered: ['Soil Mechanics', 'Foundation Engineering', 'QGIS'],
    skillsWanted: ['Python', 'AutoCAD 3D'],
    bio: 'Maintains surveying trip equipment and shared geotechnical lab notes.',
    contactEmail: 'manish.r@campus.edu',
    badges: ['Soil Specialist', 'Tool Custodian'],
    hostelWing: 'Tech Tower (H7)',
    kudosCount: 14,
    itemsLent: 18,
    notesShared: 19,
    mentorHours: 15,
    verifiedHash: '0x3322...1144'
  },
  {
    id: 'u30',
    name: 'Pallavi Gopinath',
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80',
    initials: 'PG',
    department: 'Mathematics, 2nd Year',
    year: '2nd Year',
    rank: 30,
    impactScore: 505,
    title: 'Differential Equations TA',
    nametagIcon: '∫',
    verified: true,
    knowledgeScore: 82,
    skillScore: 55,
    resourceScore: 29,
    projectScore: 40,
    rankJourney: [104, 85, 70, 52, 30],
    monthlyGrowthPercent: 20,
    skillsOffered: ['ODE & PDE', 'Complex Analysis', 'Mathematica'],
    skillsWanted: ['C++', 'Financial Math'],
    bio: 'Provides step-by-step differential equation proofs and homework help.',
    contactEmail: 'pallavi.g@campus.edu',
    badges: ['Math TA', 'Formula Master'],
    hostelWing: 'North Block (H4)',
    kudosCount: 19,
    itemsLent: 6,
    notesShared: 32,
    mentorHours: 26,
    verifiedHash: '0x9900...8811'
  },
  {
    id: 'u31',
    name: 'Gaurav Bhatia',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
    initials: 'GB',
    department: 'Computer Science, 4th Year',
    year: '4th Year',
    rank: 31,
    impactScore: 485,
    title: 'Database Architect',
    nametagIcon: '🗄️',
    verified: true,
    knowledgeScore: 71,
    skillScore: 73,
    resourceScore: 34,
    projectScore: 52,
    rankJourney: [108, 88, 72, 54, 31],
    monthlyGrowthPercent: 13,
    skillsOffered: ['PostgreSQL', 'Query Tuning', 'Redis'],
    skillsWanted: ['Rust', 'Cassandra'],
    bio: 'Runs hands-on workshops on SQL indexing and distributed database partitioning.',
    contactEmail: 'gaurav.b@campus.edu',
    badges: ['SQL Master', 'DB Lead'],
    hostelWing: 'Tech Tower (H7)',
    kudosCount: 17,
    itemsLent: 8,
    notesShared: 21,
    mentorHours: 19,
    verifiedHash: '0x4455...6677'
  },
  {
    id: 'u32',
    name: 'Zoya Khan',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    initials: 'ZK',
    department: 'Electrical Engineering, 2nd Year',
    year: '2nd Year',
    rank: 32,
    impactScore: 470,
    title: 'Circuit Crafter',
    nametagIcon: '💡',
    verified: true,
    knowledgeScore: 64,
    skillScore: 69,
    resourceScore: 48,
    projectScore: 44,
    rankJourney: [112, 90, 75, 56, 32],
    monthlyGrowthPercent: 23,
    skillsOffered: ['Circuit Analysis', 'KiCAD', 'Soldering'],
    skillsWanted: ['Microcontrollers', 'C'],
    bio: 'Soldering station custodian. Helps freshmen assemble their first amplifier circuits.',
    contactEmail: 'zoya.k@campus.edu',
    badges: ['Soldering Pro', 'Circuit Helper'],
    hostelWing: 'East Wing (H2)',
    kudosCount: 18,
    itemsLent: 16,
    notesShared: 14,
    mentorHours: 18,
    verifiedHash: '0x2233...4455'
  },
  {
    id: 'u33',
    name: 'Rahul Vasisht',
    avatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=150&auto=format&fit=crop&q=80',
    initials: 'RV',
    department: 'Physics, 3rd Year',
    year: '3rd Year',
    rank: 33,
    impactScore: 455,
    title: 'Astrophysics Tutor',
    nametagIcon: '🪐',
    verified: true,
    knowledgeScore: 79,
    skillScore: 58,
    resourceScore: 38,
    projectScore: 43,
    rankJourney: [115, 93, 78, 58, 33],
    monthlyGrowthPercent: 16,
    skillsOffered: ['Astropy', 'Stellar Evolution', 'Cosmology'],
    skillsWanted: ['Fortran', 'Python Plotting'],
    bio: 'Coordinates campus observatory stargazing nights and data reduction clinics.',
    contactEmail: 'rahul.v@campus.edu',
    badges: ['Astro Lead', 'Stargazer'],
    hostelWing: 'Research Enclave (PG)',
    kudosCount: 15,
    itemsLent: 10,
    notesShared: 25,
    mentorHours: 21,
    verifiedHash: '0x8877...9900'
  },
  {
    id: 'u34',
    name: 'Deepa Krishnan',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
    initials: 'DK',
    department: 'Chemical Engineering, 4th Year',
    year: '4th Year',
    rank: 34,
    impactScore: 440,
    title: 'Mass Transfer Mentor',
    nametagIcon: '💧',
    verified: true,
    knowledgeScore: 74,
    skillScore: 60,
    resourceScore: 45,
    projectScore: 42,
    rankJourney: [118, 96, 80, 60, 34],
    monthlyGrowthPercent: 12,
    skillsOffered: ['Distillation Column Design', 'Mass Transfer', 'MATLAB'],
    skillsWanted: ['Python', 'Excel VBA'],
    bio: 'Shares detailed distillation column diagrams and solved lab problem sets.',
    contactEmail: 'deepa.k@campus.edu',
    badges: ['Mass Transfer TA', 'Senior Mentor'],
    hostelWing: 'North Block (H4)',
    kudosCount: 13,
    itemsLent: 12,
    notesShared: 27,
    mentorHours: 16,
    verifiedHash: '0x5566...7788'
  },
  {
    id: 'u35',
    name: 'Abhishek Roy',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    initials: 'AR',
    department: 'Robotics, 3rd Year',
    year: '3rd Year',
    rank: 35,
    impactScore: 425,
    title: 'Sensor Integration Lead',
    nametagIcon: '📡',
    verified: true,
    knowledgeScore: 62,
    skillScore: 74,
    resourceScore: 49,
    projectScore: 50,
    rankJourney: [120, 98, 82, 62, 35],
    monthlyGrowthPercent: 18,
    skillsOffered: ['LiDAR Setup', 'IMU Calibration', 'C++'],
    skillsWanted: ['SLAM', 'ROS Navigation'],
    bio: 'Calibrates sensors and shares testing rigs for collegiate robotics competitions.',
    contactEmail: 'abhishek.r@campus.edu',
    badges: ['Sensor Tech', 'Robo Mentor'],
    hostelWing: 'Tech Tower (H7)',
    kudosCount: 16,
    itemsLent: 14,
    notesShared: 15,
    mentorHours: 19,
    verifiedHash: '0x3311...5522'
  },
  {
    id: 'u36',
    name: 'Natasha Verma',
    avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&auto=format&fit=crop&q=80',
    initials: 'NV',
    department: 'Computer Science, 2nd Year',
    year: '2nd Year',
    rank: 36,
    impactScore: 410,
    title: 'Frontend Explorer',
    nametagIcon: '💻',
    verified: true,
    knowledgeScore: 63,
    skillScore: 75,
    resourceScore: 26,
    projectScore: 56,
    rankJourney: [124, 101, 85, 64, 36],
    monthlyGrowthPercent: 26,
    skillsOffered: ['React', 'Tailwind CSS', 'TypeScript'],
    skillsWanted: ['GraphQL', 'Node.js Backend'],
    bio: 'Helps students build and debug their first web applications and portfollios.',
    contactEmail: 'natasha.v@campus.edu',
    badges: ['Web Contributor', 'Frontend Tutor'],
    hostelWing: 'East Wing (H2)',
    kudosCount: 19,
    itemsLent: 4,
    notesShared: 20,
    mentorHours: 22,
    verifiedHash: '0x7744...1188'
  },
  {
    id: 'u37',
    name: 'Omkar Kale',
    avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=150&auto=format&fit=crop&q=80',
    initials: 'OK',
    department: 'Mechanical Engineering, 2nd Year',
    year: '2nd Year',
    rank: 37,
    impactScore: 395,
    title: 'Manufacturing Apprentice',
    nametagIcon: '⚙️',
    verified: true,
    knowledgeScore: 61,
    skillScore: 67,
    resourceScore: 53,
    projectScore: 42,
    rankJourney: [128, 105, 88, 66, 37],
    monthlyGrowthPercent: 21,
    skillsOffered: ['Lathe Machining', 'Welding Safety', 'AutoCAD'],
    skillsWanted: ['CNC G-Code', 'SolidWorks'],
    bio: 'Assists workshop supervisors during mechanical tool issuance and machine turn-ins.',
    contactEmail: 'omkar.k@campus.edu',
    badges: ['Workshop Helper', 'Safety Champ'],
    hostelWing: 'North Block (H4)',
    kudosCount: 14,
    itemsLent: 17,
    notesShared: 11,
    mentorHours: 15,
    verifiedHash: '0x1122...3399'
  },
  {
    id: 'u38',
    name: 'Tanmayee Roy',
    avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&auto=format&fit=crop&q=80',
    initials: 'TR',
    department: 'BioTech, 4th Year',
    year: '4th Year',
    rank: 38,
    impactScore: 380,
    title: 'Immunology Scholar',
    nametagIcon: '🛡️',
    verified: true,
    knowledgeScore: 78,
    skillScore: 56,
    resourceScore: 36,
    projectScore: 39,
    rankJourney: [130, 108, 90, 68, 38],
    monthlyGrowthPercent: 10,
    skillsOffered: ['ELISA Assays', 'Antibody Engineering', 'Flow Cytometry'],
    skillsWanted: ['Data Science', 'Python'],
    bio: 'Author of Immunology Quick-Revision Handbook for final semester assessments.',
    contactEmail: 'tanmayee.r@campus.edu',
    badges: ['Immunology Star', 'Handbook Author'],
    hostelWing: 'Research Enclave (PG)',
    kudosCount: 12,
    itemsLent: 7,
    notesShared: 26,
    mentorHours: 18,
    verifiedHash: '0x9944...2211'
  },
  {
    id: 'u39',
    name: 'Pranav Joshi',
    avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=150&auto=format&fit=crop&q=80',
    initials: 'PJ',
    department: 'Civil Engineering, 3rd Year',
    year: '3rd Year',
    rank: 39,
    impactScore: 365,
    title: 'Hydraulics Specialist',
    nametagIcon: '🌊',
    verified: true,
    knowledgeScore: 67,
    skillScore: 62,
    resourceScore: 47,
    projectScore: 38,
    rankJourney: [134, 110, 92, 70, 39],
    monthlyGrowthPercent: 14,
    skillsOffered: ['Open Channel Flow', 'Hydraulic Machinery', 'HEC-RAS'],
    skillsWanted: ['GIS', 'Python'],
    bio: 'Conducts hydraulic flume demonstrations for junior batch fluid mechanics labs.',
    contactEmail: 'pranav.j@campus.edu',
    badges: ['Fluid Mechanics TA', 'Hydraulics Pro'],
    hostelWing: 'Tech Tower (H7)',
    kudosCount: 11,
    itemsLent: 13,
    notesShared: 17,
    mentorHours: 14,
    verifiedHash: '0x4411...8899'
  },
  {
    id: 'u40',
    name: 'Suhani Bose',
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80',
    initials: 'SB',
    department: 'Design, 2nd Year',
    year: '2nd Year',
    rank: 40,
    impactScore: 350,
    title: 'Graphic Identity Lead',
    nametagIcon: '🎨',
    verified: true,
    knowledgeScore: 59,
    skillScore: 78,
    resourceScore: 25,
    projectScore: 52,
    rankJourney: [138, 114, 95, 72, 40],
    monthlyGrowthPercent: 25,
    skillsOffered: ['Illustrator', 'Typography', 'Print Layouts'],
    skillsWanted: ['Motion Design', 'Blender'],
    bio: 'Designs poster templates and digital signage for student club festivals.',
    contactEmail: 'suhani.b@campus.edu',
    badges: ['Creative Designer', 'Typography Lead'],
    hostelWing: 'East Wing (H2)',
    kudosCount: 16,
    itemsLent: 3,
    notesShared: 15,
    mentorHours: 19,
    verifiedHash: '0x2288...3344'
  },
  {
    id: 'u41',
    name: 'Varun Somani',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
    initials: 'VS',
    department: 'Computer Science, 3rd Year',
    year: '3rd Year',
    rank: 41,
    impactScore: 335,
    title: 'Linux Kernel Hobbyist',
    nametagIcon: '🐧',
    verified: true,
    knowledgeScore: 68,
    skillScore: 70,
    resourceScore: 32,
    projectScore: 47,
    rankJourney: [140, 116, 98, 74, 41],
    monthlyGrowthPercent: 17,
    skillsOffered: ['C', 'Bash Scripting', 'Kernel Modules'],
    skillsWanted: ['Rust', 'Driver Dev'],
    bio: 'Helps students install Linux dual-boots and fix broken system configurations.',
    contactEmail: 'varun.s@campus.edu',
    badges: ['Linux Guru', 'Terminal Pro'],
    hostelWing: 'North Block (H4)',
    kudosCount: 13,
    itemsLent: 6,
    notesShared: 19,
    mentorHours: 18,
    verifiedHash: '0x5511...4400'
  },
  {
    id: 'u42',
    name: 'Kritika Roy',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    initials: 'KR',
    department: 'Electrical Engineering, 4th Year',
    year: '4th Year',
    rank: 42,
    impactScore: 320,
    title: 'Control Systems Guide',
    nametagIcon: '🎛️',
    verified: true,
    knowledgeScore: 72,
    skillScore: 62,
    resourceScore: 40,
    projectScore: 37,
    rankJourney: [142, 118, 100, 76, 42],
    monthlyGrowthPercent: 11,
    skillsOffered: ['Bode Plots', 'State Space', 'MATLAB Controls'],
    skillsWanted: ['Python', 'Embedded Systems'],
    bio: 'Root locus and frequency response analysis solved problem set distributor.',
    contactEmail: 'kritika.r@campus.edu',
    badges: ['Control Systems TA', 'Lab Helper'],
    hostelWing: 'East Wing (H2)',
    kudosCount: 10,
    itemsLent: 10,
    notesShared: 21,
    mentorHours: 14,
    verifiedHash: '0x7700...8833'
  },
  {
    id: 'u43',
    name: 'Chinmay Kulkarni',
    avatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=150&auto=format&fit=crop&q=80',
    initials: 'CK',
    department: 'Physics, 2nd Year',
    year: '2nd Year',
    rank: 43,
    impactScore: 305,
    title: 'Classical Mechanics Peer',
    nametagIcon: '⚛️',
    verified: true,
    knowledgeScore: 74,
    skillScore: 54,
    resourceScore: 30,
    projectScore: 35,
    rankJourney: [145, 120, 102, 78, 43],
    monthlyGrowthPercent: 20,
    skillsOffered: ['Lagrangian Mechanics', 'Newtonian Dynamics', 'Vector Calc'],
    skillsWanted: ['Quantum Info', 'Python'],
    bio: 'Organizes peer mechanics problem solving circles before midterm exams.',
    contactEmail: 'chinmay.k@campus.edu',
    badges: ['Mechanics Helper', 'Peer Tutor'],
    hostelWing: 'North Block (H4)',
    kudosCount: 12,
    itemsLent: 5,
    notesShared: 23,
    mentorHours: 16,
    verifiedHash: '0x3388...1122'
  },
  {
    id: 'u44',
    name: 'Anika Chari',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
    initials: 'AC',
    department: 'Chemical Engineering, 2nd Year',
    year: '2nd Year',
    rank: 44,
    impactScore: 290,
    title: 'Stoichiometry Tutor',
    nametagIcon: '🧪',
    verified: true,
    knowledgeScore: 71,
    skillScore: 55,
    resourceScore: 36,
    projectScore: 33,
    rankJourney: [148, 122, 104, 80, 44],
    monthlyGrowthPercent: 19,
    skillsOffered: ['Material & Energy Balances', 'Chemistry Lab', 'Excel'],
    skillsWanted: ['Aspen Plus', 'Python'],
    bio: 'Shares clean stoichiometry and recycle stream balance spreadsheets.',
    contactEmail: 'anika.c@campus.edu',
    badges: ['Chemistry Guide', 'Spreadsheet Pro'],
    hostelWing: 'Research Enclave (PG)',
    kudosCount: 11,
    itemsLent: 8,
    notesShared: 20,
    mentorHours: 13,
    verifiedHash: '0x1199...5566'
  },
  {
    id: 'u45',
    name: 'Saurabh Pandey',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    initials: 'SP',
    department: 'Robotics & AI, 3rd Year',
    year: '3rd Year',
    rank: 45,
    impactScore: 275,
    title: 'Embedded Vision Dev',
    nametagIcon: '👁️',
    verified: true,
    knowledgeScore: 61,
    skillScore: 69,
    resourceScore: 42,
    projectScore: 45,
    rankJourney: [150, 125, 106, 82, 45],
    monthlyGrowthPercent: 16,
    skillsOffered: ['OpenCV', 'Raspberry Pi', 'Python'],
    skillsWanted: ['C++', 'CUDA'],
    bio: 'Maintains camera modules and optical flow testing boards in the hobby room.',
    contactEmail: 'saurabh.p@campus.edu',
    badges: ['Vision Hobbyist', 'Hardware Helper'],
    hostelWing: 'Tech Tower (H7)',
    kudosCount: 10,
    itemsLent: 11,
    notesShared: 12,
    mentorHours: 15,
    verifiedHash: '0x9955...4433'
  },
  {
    id: 'u46',
    name: 'Trisha Sen',
    avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&auto=format&fit=crop&q=80',
    initials: 'TS',
    department: 'BioTech, 3rd Year',
    year: '3rd Year',
    rank: 46,
    impactScore: 260,
    title: 'Bioinformatics Peer',
    nametagIcon: '🧬',
    verified: true,
    knowledgeScore: 70,
    skillScore: 59,
    resourceScore: 28,
    projectScore: 36,
    rankJourney: [152, 128, 108, 84, 46],
    monthlyGrowthPercent: 15,
    skillsOffered: ['PyMOL', 'Protein Docking', 'BLAST'],
    skillsWanted: ['R', 'Machine Learning'],
    bio: 'Hosts 3D protein structure visualization sessions using PyMOL in the lab.',
    contactEmail: 'trisha.s@campus.edu',
    badges: ['PyMOL Guide', 'Bio Helper'],
    hostelWing: 'Research Enclave (PG)',
    kudosCount: 9,
    itemsLent: 5,
    notesShared: 18,
    mentorHours: 14,
    verifiedHash: '0x4422...8811'
  },
  {
    id: 'u47',
    name: 'Kunal Singhal',
    avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=150&auto=format&fit=crop&q=80',
    initials: 'KS',
    department: 'Civil Engineering, 2nd Year',
    year: '2nd Year',
    rank: 47,
    impactScore: 245,
    title: 'Surveying Field Helper',
    nametagIcon: '📐',
    verified: true,
    knowledgeScore: 58,
    skillScore: 60,
    resourceScore: 51,
    projectScore: 32,
    rankJourney: [155, 130, 110, 86, 47],
    monthlyGrowthPercent: 22,
    skillsOffered: ['Theodolite Use', 'Leveling', 'AutoCAD 2D'],
    skillsWanted: ['Surveying Math', 'Python'],
    bio: 'Helps classmates set up tripods and leveling rods during outdoor lab sessions.',
    contactEmail: 'kunal.s@campus.edu',
    badges: ['Surveying Supporter', 'Team Lender'],
    hostelWing: 'Tech Tower (H7)',
    kudosCount: 11,
    itemsLent: 15,
    notesShared: 9,
    mentorHours: 11,
    verifiedHash: '0x6633...7744'
  },
  {
    id: 'u48',
    name: 'Esha Mukherjee',
    avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&auto=format&fit=crop&q=80',
    initials: 'EM',
    department: 'Design & Visual Arts, 3rd Year',
    year: '3rd Year',
    rank: 48,
    impactScore: 230,
    title: 'Infographics Stylist',
    nametagIcon: '📊',
    verified: true,
    knowledgeScore: 55,
    skillScore: 73,
    resourceScore: 22,
    projectScore: 46,
    rankJourney: [158, 132, 112, 88, 48],
    monthlyGrowthPercent: 18,
    skillsOffered: ['Data Visualization', 'Canva Pro', 'Figma'],
    skillsWanted: ['D3.js', 'React'],
    bio: 'Turns complex academic research papers into clean, easy-to-read infographics.',
    contactEmail: 'esha.m@campus.edu',
    badges: ['Infographics Pro', 'Visual Helper'],
    hostelWing: 'East Wing (H2)',
    kudosCount: 13,
    itemsLent: 3,
    notesShared: 14,
    mentorHours: 16,
    verifiedHash: '0x2211...9955'
  },
  {
    id: 'u49',
    name: 'Raghav Aggarwal',
    avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=150&auto=format&fit=crop&q=80',
    initials: 'RA',
    department: 'Computer Science, 2nd Year',
    year: '2nd Year',
    rank: 49,
    impactScore: 215,
    title: 'Git & GitHub Supporter',
    nametagIcon: '🐙',
    verified: true,
    knowledgeScore: 61,
    skillScore: 65,
    resourceScore: 26,
    projectScore: 42,
    rankJourney: [160, 135, 114, 90, 49],
    monthlyGrowthPercent: 24,
    skillsOffered: ['Git Rebase', 'GitHub PRs', 'Markdown'],
    skillsWanted: ['Docker', 'CI/CD'],
    bio: 'Resolves git merge conflicts and helps new contributors submit their first PR.',
    contactEmail: 'raghav.a@campus.edu',
    badges: ['Git Assistant', 'OpenSource Guide'],
    hostelWing: 'North Block (H4)',
    kudosCount: 12,
    itemsLent: 4,
    notesShared: 16,
    mentorHours: 17,
    verifiedHash: '0x8833...2266'
  },
  {
    id: 'u50',
    name: 'Swati Khandelwal',
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80',
    initials: 'SK',
    department: 'Mathematics & Stats, 3rd Year',
    year: '3rd Year',
    rank: 50,
    impactScore: 200,
    title: 'Statistics Study Leader',
    nametagIcon: '📊',
    verified: true,
    knowledgeScore: 72,
    skillScore: 53,
    resourceScore: 25,
    projectScore: 32,
    rankJourney: [162, 138, 116, 92, 50],
    monthlyGrowthPercent: 14,
    skillsOffered: ['Hypothesis Testing', 'R Stats', 'ANOVA'],
    skillsWanted: ['Python Pandas', 'SQL'],
    bio: 'Provides sample distributions and confidence interval walkthrough notes.',
    contactEmail: 'swati.k@campus.edu',
    badges: ['Stats Tutor', 'Peer Guide'],
    hostelWing: 'Research Enclave (PG)',
    kudosCount: 10,
    itemsLent: 5,
    notesShared: 22,
    mentorHours: 15,
    verifiedHash: '0x1177...4488'
  },
  {
    id: 'u51',
    name: 'Tejaswini Patil',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    initials: 'TP',
    department: 'Electrical Engineering, 3rd Year',
    year: '3rd Year',
    rank: 51,
    impactScore: 190,
    title: 'Analog Filter Designer',
    nametagIcon: '〰️',
    verified: true,
    knowledgeScore: 66,
    skillScore: 61,
    resourceScore: 37,
    projectScore: 34,
    rankJourney: [165, 140, 118, 94, 51],
    monthlyGrowthPercent: 13,
    skillsOffered: ['Butterworth Filters', 'Op-Amps', 'LTSpice'],
    skillsWanted: ['Digital Signals', 'DSP'],
    bio: 'Shares LTSpice circuit simulation files for active low-pass and band-pass filters.',
    contactEmail: 'tejaswini.p@campus.edu',
    badges: ['Circuit Guide', 'Simulation Helper'],
    hostelWing: 'East Wing (H2)',
    kudosCount: 8,
    itemsLent: 9,
    notesShared: 14,
    mentorHours: 12,
    verifiedHash: '0x5533...1122'
  },
  {
    id: 'u52',
    name: 'Varun Nair',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
    initials: 'VN',
    department: 'Mechanical Engineering, 4th Year',
    year: '4th Year',
    rank: 52,
    impactScore: 180,
    title: 'Automotive Enthusiast',
    nametagIcon: '🏎️',
    verified: true,
    knowledgeScore: 63,
    skillScore: 64,
    resourceScore: 44,
    projectScore: 38,
    rankJourney: [168, 142, 120, 96, 52],
    monthlyGrowthPercent: 10,
    skillsOffered: ['Vehicle Dynamics', 'Baja CAD', 'Chassis Design'],
    skillsWanted: ['Telemetry', 'IoT'],
    bio: 'Baja SAE student team chassis builder. Shares workshop torque wrench sets.',
    contactEmail: 'varun.n@campus.edu',
    badges: ['Baja Team', 'Tool Lender'],
    hostelWing: 'North Block (H4)',
    kudosCount: 9,
    itemsLent: 13,
    notesShared: 11,
    mentorHours: 11,
    verifiedHash: '0x7711...6622'
  },
  {
    id: 'u53',
    name: 'Lavanya S.',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
    initials: 'LS',
    department: 'Physics, 2nd Year',
    year: '2nd Year',
    rank: 53,
    impactScore: 170,
    title: 'Thermodynamic Physics Guide',
    nametagIcon: '🌡️',
    verified: true,
    knowledgeScore: 68,
    skillScore: 50,
    resourceScore: 28,
    projectScore: 31,
    rankJourney: [170, 144, 122, 98, 53],
    monthlyGrowthPercent: 18,
    skillsOffered: ['Entropy Calculations', 'Kinetic Theory', 'Statistical Physics'],
    skillsWanted: ['Quantum Calc', 'LaTeX'],
    bio: 'Summarizes statistical mechanics partition functions and Maxwell relations.',
    contactEmail: 'lavanya.s@campus.edu',
    badges: ['Physics Helper', 'Notes Sharer'],
    hostelWing: 'Research Enclave (PG)',
    kudosCount: 7,
    itemsLent: 4,
    notesShared: 17,
    mentorHours: 13,
    verifiedHash: '0x9922...3344'
  },
  {
    id: 'u54',
    name: 'Gaurang Trivedi',
    avatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=150&auto=format&fit=crop&q=80',
    initials: 'GT',
    department: 'Chemical Engineering, 3rd Year',
    year: '3rd Year',
    rank: 54,
    impactScore: 160,
    title: 'Reaction Engineering Peer',
    nametagIcon: '⚗️',
    verified: true,
    knowledgeScore: 65,
    skillScore: 54,
    resourceScore: 35,
    projectScore: 30,
    rankJourney: [172, 146, 124, 100, 54],
    monthlyGrowthPercent: 12,
    skillsOffered: ['CSTR & PFR Reactor Math', 'Kinetics', 'Polymath'],
    skillsWanted: ['MATLAB', 'Process Control'],
    bio: 'Shares solved reaction kinetics and catalyst deactivation homework sheets.',
    contactEmail: 'gaurang.t@campus.edu',
    badges: ['Reaction Eng Helper', 'Peer Tutor'],
    hostelWing: 'Tech Tower (H7)',
    kudosCount: 8,
    itemsLent: 8,
    notesShared: 15,
    mentorHours: 10,
    verifiedHash: '0x3344...5511'
  },
  {
    id: 'u55',
    name: 'Aayushi Parekh',
    avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&auto=format&fit=crop&q=80',
    initials: 'AP',
    department: 'Computer Science & AI, 1st Year',
    year: '1st Year',
    rank: 55,
    impactScore: 150,
    title: 'Freshman Code Contributor',
    nametagIcon: '🌱',
    verified: true,
    knowledgeScore: 58,
    skillScore: 60,
    resourceScore: 24,
    projectScore: 35,
    rankJourney: [175, 150, 130, 105, 55],
    monthlyGrowthPercent: 35,
    skillsOffered: ['Python Basics', 'Git', 'Markdown'],
    skillsWanted: ['Data Structures', 'Web Development'],
    bio: 'Freshman contributor organizing first-year code pairing and study groups.',
    contactEmail: 'aayushi.p@campus.edu',
    badges: ['Rising Star', 'Active Contributor'],
    hostelWing: 'East Wing (H2)',
    kudosCount: 14,
    itemsLent: 3,
    notesShared: 12,
    mentorHours: 15,
    verifiedHash: '0x1144...8877'
  }
];

export const INITIAL_MARKETPLACE: MarketplaceItem[] = [
  {
    id: 'm1',
    title: 'Griffiths — Intro to Electrodynamics (4th ed)',
    category: 'Books',
    price: 450,
    condition: 'Good',
    location: 'Hostel C',
    sellerId: 'u6',
    sellerName: 'Rhea N.',
    sellerVerified: true,
    sellerDepartment: 'Physics Dept',
    description: 'Crisp binding, slight pencil annotations in chapter 3-5. Essential for Electromagnetic Theory course.',
    symbol: '∿',
    size: 'tall',
    imageUrl: 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=500&auto=format&fit=crop&q=80',
    available: true,
    createdAt: '2 hrs ago'
  },
  {
    id: 'm2',
    title: 'Casio FX-991 Scientific Calculator',
    category: 'Electronics',
    price: 500,
    condition: 'Like new',
    location: 'Block 2',
    sellerId: 'u7',
    sellerName: 'Aman T.',
    sellerVerified: true,
    sellerDepartment: 'Civil Eng',
    description: 'Clean battery, solar backup operational, comes with protective slide cover.',
    symbol: '01',
    size: 'wide',
    imageUrl: 'https://images.unsplash.com/photo-1587145820266-a5951ee6f620?w=500&auto=format&fit=crop&q=80',
    available: true,
    createdAt: '4 hrs ago'
  },
  {
    id: 'm3',
    title: 'Study desk + chair, foldable',
    category: 'Furniture',
    price: 1600,
    condition: 'Fair',
    location: 'PG near Gate 3',
    sellerId: 'u8',
    sellerName: 'Sana K.',
    sellerVerified: true,
    sellerDepartment: 'Design Society',
    description: 'Solid engineered wood desk, easily folds flat for hostel relocation. Metal ergonomic chair included.',
    symbol: '▱',
    size: 'wide',
    imageUrl: 'https://images.unsplash.com/photo-1518455027359-f3f8164ba6bd?w=500&auto=format&fit=crop&q=80',
    available: true,
    createdAt: '6 hrs ago'
  },
  {
    id: 'm4',
    title: 'DSA handwritten notes, sem 3',
    category: 'Notes',
    price: 150,
    condition: 'Digital scan',
    location: 'Online / Cloud Drive',
    sellerId: 'u9',
    sellerName: 'Rohit V.',
    sellerVerified: true,
    sellerDepartment: 'CS Dept (9.8 GPA)',
    description: 'Comprehensive 180-page handwritten notes covering Trees, Graphs, DP, and LeetCode patterns.',
    symbol: 'A4',
    size: 'standard',
    imageUrl: 'https://images.unsplash.com/photo-1517842645767-c639042777db?w=500&auto=format&fit=crop&q=80',
    available: true,
    createdAt: '1 day ago'
  },
  {
    id: 'm5',
    title: 'Canon 200D w/ 18-55mm lens (Always 8)',
    category: 'Electronics',
    price: 18500,
    condition: 'Like new',
    location: 'Hostel D',
    sellerId: 'u10',
    sellerName: 'Naina S.',
    sellerVerified: true,
    sellerDepartment: 'Media Cell',
    description: 'Shutter count ~3,200. Comes with 2 batteries, 64GB Extreme SD card, and padded camera bag.',
    symbol: 'CAM',
    size: 'tall',
    imageUrl: 'https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=500&auto=format&fit=crop&q=80',
    available: true,
    createdAt: '1 day ago'
  },
  {
    id: 'm6',
    title: 'Arduino Mega + Sensor Starter Kit',
    category: 'Equipment',
    price: 900,
    condition: 'Good',
    location: 'Hostel A',
    sellerId: 'u11',
    sellerName: 'Meera J.',
    sellerVerified: true,
    sellerDepartment: 'ECE Dept',
    description: 'Includes ultrasonic, servo, LCD display, jumper wires, breadboard, and case.',
    symbol: 'µ',
    size: 'standard',
    imageUrl: 'https://images.unsplash.com/photo-1553406830-ef2513450d76?w=500&auto=format&fit=crop&q=80',
    available: true,
    createdAt: '2 days ago'
  }
];

export const INITIAL_PROJECTS: ProjectItem[] = [
  {
    id: 'p1',
    name: 'CampusVision',
    tagline: 'Computer-vision attendance trained on lecture-hall footage.',
    description: 'An edge-computing AI system deployed on Raspberry Pi & Jetson Nano units that provides real-time multi-angle facial attendance without manual roll calls.',
    category: 'AI / COMPUTER VISION',
    creator: 'Devansh Iyer',
    creatorTitle: 'Project Builder',
    membersCount: 4,
    followersCount: 327,
    progressPercent: 68,
    skillsRequired: ['Python', 'OpenCV', 'PyTorch', 'Edge Computing'],
    recruiting: true,
    accentColor: '#9B7CFF',
    updatesCount: 14,
    recentUpdate: 'Benchmarked 91.4% recognition precision across fluctuating fluorescent lighting.'
  },
  {
    id: 'p2',
    name: 'SoilSense',
    tagline: 'Low-cost soil moisture sensors for the campus community garden.',
    description: 'LoRaWAN networked sensor probes measuring soil capacitance, nitrogen levels, and automated drip-irrigation triggers for university botanic farms.',
    category: 'IOT / SUSTAINABILITY',
    creator: 'Priya Malhotra',
    creatorTitle: 'Skill Master',
    membersCount: 3,
    followersCount: 54,
    progressPercent: 40,
    skillsRequired: ['Embedded C', 'IoT', 'LoRa', 'Solar Power'],
    recruiting: true,
    accentColor: '#5AF2E2',
    updatesCount: 8,
    recentUpdate: 'First 5 solar probes deployed in Zone 3 greenhouses with 14-day uptime.'
  },
  {
    id: 'p3',
    name: 'Lecture Rewind',
    tagline: 'Searchable transcripts for recorded lectures, indexed by concept.',
    description: 'Open-weights Whisper + vector embedding indexing for all college symposium recordings, allowing timestamped keyword search down to specific equations.',
    category: 'EDTECH / NLP',
    creator: 'Ananya Rao',
    creatorTitle: 'Knowledge Keeper',
    membersCount: 5,
    followersCount: 201,
    progressPercent: 85,
    skillsRequired: ['Whisper', 'React', 'Vector DB', 'FastAPI'],
    recruiting: false,
    accentColor: '#FFC86B',
    updatesCount: 22,
    recentUpdate: 'Added multi-speaker voice separation and instant mathematical formula LaTeX transcription.'
  },
  {
    id: 'p4',
    name: 'EventSync',
    tagline: 'Smart crowd & queue management for campus festivals.',
    description: 'Bluetooth beacon-based foot-traffic heatmap visualizer helping festival coordinators prevent bottlenecks at auditoriums and food courts.',
    category: 'SYSTEMS / MOBILITY',
    creator: 'Yuvraj Sen',
    creatorTitle: 'Most Generous',
    membersCount: 4,
    followersCount: 87,
    progressPercent: 58,
    skillsRequired: ['BLE Mesh', 'Go', 'Mapbox', 'WebSockets'],
    recruiting: true,
    accentColor: '#5AF2E2',
    updatesCount: 9,
    recentUpdate: 'Successfully field-tested at the intra-college gaming fest with 800+ concurrent pings.'
  }
];

export const INITIAL_PULSE: PulsePost[] = [
  {
    id: 'post1',
    category: 'Projects',
    author: 'Robotics Club',
    authorTitle: 'Campus Organization',
    authorDepartment: 'Central Lab',
    text: 'is hosting a workshop on ROS 2 and Autonomous Navigation this Saturday! Bring your laptops with Ubuntu 22.04 configured. Open to all branches.',
    timestamp: '2m ago',
    likesCount: 68,
    isLiked: false,
    commentsCount: 14,
    badge: 'PROJECT BUILDER',
    pinned: true,
    comments: [
      { id: 'c1', author: 'Devansh Iyer', text: 'Will bring the TurtleBot demo unit!', time: '1m ago' },
      { id: 'c2', author: 'Priya M.', text: 'Can 1st years join without prior ROS experience?', time: 'Just now' }
    ]
  },
  {
    id: 'post2',
    category: 'Events',
    author: 'HackNITC 3.0',
    authorTitle: 'Annual Hackathon',
    authorDepartment: 'Tech Council',
    text: 'registrations are now OPEN! 36 hours of building, ₹1.5L prize pool, and direct incubation tracks for campus-born ventures. Link in bio.',
    timestamp: '15m ago',
    likesCount: 128,
    isLiked: true,
    commentsCount: 31,
    badge: 'COMMUNITY HELPER'
  },
  {
    id: 'post3',
    category: 'Academic',
    author: 'Rhea N.',
    authorTitle: 'Knowledge Keeper',
    authorDepartment: 'Physics Dept',
    text: "PSA: Prof. Menon's midterm is confirmed to be open-notes this semester! Equations sheet can be handwritten up to 2 pages.",
    timestamp: '42m ago',
    likesCount: 121,
    isLiked: false,
    commentsCount: 21,
    badge: 'KNOWLEDGE KEEPER'
  },
  {
    id: 'post4',
    category: 'Discussions',
    author: 'Design Society',
    authorTitle: 'Student Collective',
    authorDepartment: 'Makerspace',
    text: 'new limited edition campus hoodie & tote merch drop is LIVE at the amphitheatre kiosk. 100% organic cotton, student designed!',
    timestamp: '1h ago',
    likesCount: 49,
    isLiked: false,
    commentsCount: 8,
    badge: 'CAMPUS CREATOR'
  },
  {
    id: 'post5',
    category: 'Sports',
    author: 'Athletics Cell',
    authorTitle: 'Sports Committee',
    authorDepartment: 'Main Ground',
    text: 'Inter-hostel football semifinals moved to Sunday 5:00 PM under the floodlights. Block B vs Block D.',
    timestamp: '2h ago',
    likesCount: 40,
    isLiked: false,
    commentsCount: 4
  }
];

export const INITIAL_BORROW_ITEMS: BorrowItem[] = [
  {
    id: 'b1',
    title: 'Binocular Compound Microscope (1000x)',
    category: 'Lab Gear',
    available: true,
    location: 'Bio Lab 2',
    ownerName: 'Bio Sciences Dept',
    ownerVerified: true,
    maxDays: 7,
    depositRequired: 'Campus ID',
    description: 'High-resolution optical lenses with mechanical stage and LED illuminator. Pre-calibrated.'
  },
  {
    id: 'b2',
    title: 'TI-84 Plus CE Graphing Calculator',
    category: 'Calculators',
    available: true,
    location: 'Hostel B, Room 214',
    ownerName: 'Kunal S.',
    ownerVerified: true,
    maxDays: 3,
    depositRequired: 'None (Verified Student)',
    description: 'Color backlit screen with preloaded calculus equation solvers and fresh rechargeable battery.'
  },
  {
    id: 'b3',
    title: 'Digital Oscilloscope & Signal Generator',
    category: 'Electronics',
    available: true,
    location: 'Makerspace Lab 4',
    ownerName: 'Yuvraj Sen',
    ownerVerified: true,
    maxDays: 5,
    depositRequired: 'Campus ID',
    description: 'Portable 2-channel 100MHz digital storage oscilloscope. Probes and BNC cables included.'
  },
  {
    id: 'b4',
    title: 'A0 Draughting Table & Parallel Rule',
    category: 'Tools',
    available: true,
    location: 'Architecture Studio 1',
    ownerName: 'Architecture Guild',
    ownerVerified: true,
    maxDays: 14,
    depositRequired: 'ID Verification',
    description: 'Adjustable angle drafting board with locking parallel motion ruler and vinyl surface.'
  }
];

export const INITIAL_SKILL_MATCHES: SkillMatch[] = [
  {
    id: 'sm1',
    studentA: {
      name: 'Sana K.',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80',
      teaches: 'Figma & UI Prototyping',
      year: '3rd Year Design'
    },
    studentB: {
      name: 'Yuvraj Sen',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=120&auto=format&fit=crop&q=80',
      teaches: 'Python & Fast Data APIs',
      year: '3rd Year CS'
    },
    matchScore: 92,
    status: 'available'
  },
  {
    id: 'sm2',
    studentA: {
      name: 'Devansh Iyer',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&auto=format&fit=crop&q=80',
      teaches: 'PyTorch & Computer Vision',
      year: '3rd Year Robotics'
    },
    studentB: {
      name: 'Kabir Shah',
      avatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=120&auto=format&fit=crop&q=80',
      teaches: 'SolidWorks 3D CAD & Prototyping',
      year: '4th Year Mech'
    },
    matchScore: 96,
    status: 'connected'
  },
  {
    id: 'sm3',
    studentA: {
      name: 'Ananya Rao',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=120&auto=format&fit=crop&q=80',
      teaches: 'System Design & Go Concurrency',
      year: '4th Year CS'
    },
    studentB: {
      name: 'Priya Malhotra',
      avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=120&auto=format&fit=crop&q=80',
      teaches: 'Embedded C & RTOS Fundamentals',
      year: '3rd Year ECE'
    },
    matchScore: 88,
    status: 'available'
  }
];

export const INITIAL_GUIDANCE_TOPICS: GuidanceTopic[] = [
  {
    id: 'g1',
    title: 'How to Crack Operating Systems with Prof. Nair',
    category: 'Course Advice',
    mentorName: 'Ananya Rao',
    mentorTitle: 'Knowledge Keeper (Ex-TA)',
    reads: 420,
    summary: 'Essential breakdown of the 4 key scheduling algorithms, memory paging nuances, and the exact midterm questions Prof. Nair values most.',
    tips: [
      'Focus heavily on Semaphore synchronization problems in assignment 2',
      'The viva focuses on Virtual Memory page fault calculations',
      'Use Linux man pages directly during lab exams'
    ]
  },
  {
    id: 'g2',
    title: 'Accessing High-Performance GPU Clusters on Campus',
    category: 'Campus Hack',
    mentorName: 'Devansh Iyer',
    mentorTitle: 'Project Builder',
    reads: 312,
    summary: 'Step-by-step guide to requesting SLURM compute tokens on the Central AI Lab Nvidia A100 nodes for student research.',
    tips: [
      'Faculty sponsorship takes 24 hours if submitted before Thursday 3 PM',
      'Always run jobs through tmux or sbatch scripts to avoid SSH timeouts',
      'Store datasets on `/scratch/student` instead of home directory'
    ]
  },
  {
    id: 'g3',
    title: 'Makerspace 3D Printer Booking & Slicing Protocols',
    category: 'Campus Hack',
    mentorName: 'Kabir Shah',
    mentorTitle: 'Resource Pro',
    reads: 250,
    summary: 'How to get your Bambu Lab & Prusa print jobs approved in under 2 hours without wasting filament.',
    tips: [
      'Export STL files with 0.16mm layer height tolerance for mechanical parts',
      'Reserve slots before 10 AM on weekdays for same-day print turnaround',
      'Recycle failed PLA supports in the green collection bin'
    ]
  }
];

export const INITIAL_COMPASS_MESSAGES: CompassMessage[] = [
  {
    id: 'msg-1',
    sender: 'compass',
    text: "Welcome to **COMPASS AI** — your real-time campus neural co-pilot.\n\nI can help you:\n• **Borrow lab gear & scientific tools** instantly from peers.\n• **Join active research squads & hackathon teams** recruiting members.\n• **Swap peer technical skills** (AI, UI/UX, ROS 2, PCB Design).\n• **Access verified PYQs, notes, exam hacks, & 24/7 campus facilities**.\n\nAsk me any campus query or pick a prompt below to begin.",
    timestamp: 'Just now',
    category: 'Campus Overview',
    confidenceScore: 0.99,
    followUpQueries: [
      'Who can lend me a Casio calculator today?',
      'Find me an AI or robotics squad recruiting',
      'Where can I find Operating Systems PYQs?',
      'Who is offering Figma UX mentorship?'
    ],
    suggestedCards: [
      {
        type: 'project',
        title: 'CampusVision Attendance System',
        subtitle: 'Looking for OpenCV & Python devs • 98% Match',
        tag: 'Research Squad',
        actionLabel: 'Join Squad',
        targetId: 'p1'
      },
      {
        type: 'borrow',
        title: 'Casio fx-991EX Scientific Calculator',
        subtitle: 'Available for 24h loan • Arya Hostel • Aman T.',
        tag: 'Borrow Gear',
        actionLabel: 'Borrow Now',
        targetId: 'b-2'
      },
      {
        type: 'guidance',
        title: 'Operating Systems Midterm & Lab Exam Blueprint',
        subtitle: 'By Ananya Rao (Ex-TA) • 420 reads',
        tag: 'Senior Guide',
        actionLabel: 'Read Guide',
        targetId: 'g1'
      }
    ]
  }
];

export const INITIAL_NOTIFICATIONS: CampusNotification[] = [
  {
    id: 'notif-1',
    type: 'friend_request',
    title: 'Friend Request from Meera Patel',
    description: 'Meera Patel (AI & ML, 2nd Year) requested to connect with your profile to chat & collaborate.',
    timestamp: '12m ago',
    read: false,
    senderId: 'u8',
    senderName: 'Meera Patel',
    senderAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    senderDepartment: 'AI & Data Science, 2nd Year',
    senderRank: 8,
    status: 'pending',
    actionLabel: 'Connect',
    meta: {
      userProfile: {
        id: 'u8',
        name: 'Meera Patel',
        avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
        initials: 'MP',
        department: 'AI & Data Science, 2nd Year',
        year: '2nd Year',
        rank: 8,
        impactScore: 1140,
        title: 'Deep Learner',
        verified: true,
        knowledgeScore: 71,
        skillScore: 68,
        resourceScore: 50,
        projectScore: 75,
        rankJourney: [30, 20, 15, 11, 8],
        monthlyGrowthPercent: 22,
        skillsOffered: ['PyTorch', 'FastAI', 'Data Scraping'],
        skillsWanted: ['System Design', 'Cloud Architecture'],
        bio: 'Working on LLM fine-tuning on academic papers. Active in AI Lab.',
        contactEmail: 'meera.p@campus.edu',
        isPrivate: true,
        hostelWing: 'North Block (H4)',
        badges: ['AI Lab Fellow', 'Quick Learner']
      }
    }
  },
  {
    id: 'notif-2',
    type: 'borrow_request',
    title: 'Hardware Loan: TI-84 Plus Graphing Calculator',
    description: 'Aarav Sharma requested your TI-84 Plus Calculator for a 3-day lab exam period.',
    timestamp: '35m ago',
    read: false,
    senderId: 'u9',
    senderName: 'Aarav Sharma',
    senderAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    senderDepartment: 'Civil & Envr, 2nd Year',
    status: 'pending',
    meta: {
      itemName: 'TI-84 Plus CE Graphing Calculator',
      daysRequested: 3,
      borrowItemId: 'b-1'
    }
  },
  {
    id: 'notif-3',
    type: 'project_invite',
    title: 'Squad Application: Tanvi Verma',
    description: 'Tanvi Verma applied for the Computer Vision Lead role on "HyperLoop Autonomous Drone".',
    timestamp: '2h ago',
    read: false,
    senderId: 'u10',
    senderName: 'Tanvi Verma',
    senderAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
    senderDepartment: 'Electronics & Comm, 3rd Year',
    status: 'pending',
    meta: {
      projectName: 'HyperLoop Autonomous Drone',
      roleName: 'Computer Vision Lead'
    }
  },
  {
    id: 'notif-4',
    type: 'kudos',
    title: 'Kudos Received (+5 Karma)',
    description: 'Priya Malhotra awarded you +5 Kudos for sharing "OS Midterm & Lab Exam Blueprint".',
    timestamp: '4h ago',
    read: true,
    senderId: 'u4',
    senderName: 'Priya Malhotra',
    senderAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
    status: 'completed',
    meta: {
      kudosPoints: 5
    }
  },
  {
    id: 'notif-5',
    type: 'skill_swap',
    title: 'Skill Swap Match: Devansh Iyer',
    description: 'Devansh Iyer requested a Python ↔ ROS 2 robotics exchange session this Friday at 4 PM.',
    timestamp: '1d ago',
    read: true,
    senderId: 'u2',
    senderName: 'Devansh Iyer',
    senderAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    status: 'pending',
    meta: {
      skillOffered: 'ROS 2 & Computer Vision'
    }
  }
];

// Convenient exported aliases
export const mockUsers = INITIAL_USERS;
export const mockMarketplaceItems = INITIAL_MARKETPLACE;
export const mockProjects = INITIAL_PROJECTS;
export const mockPulsePosts = INITIAL_PULSE;
export const mockBorrowItems = INITIAL_BORROW_ITEMS;
export const mockSkillMatches = INITIAL_SKILL_MATCHES;
export const mockGuidanceTopics = INITIAL_GUIDANCE_TOPICS;
export const initialCompassMessages = INITIAL_COMPASS_MESSAGES;
export const mockNotifications = INITIAL_NOTIFICATIONS;


```

---

## File: `src/index.css`

```css
@import "tailwindcss";

@layer base {
  body {
    font-family: "Plus Jakarta Sans", "Inter", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
    background-color: #050508;
    color: #e2e8f0;
    overflow-x: hidden;
    letter-spacing: 0.01em;
    line-height: 1.65;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
  }

  h1, h2, h3, h4, h5, h6, .font-heading {
    font-family: "Outfit", "Inter", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    letter-spacing: 0.015em;
    font-weight: 700;
    line-height: 1.25;
  }

  .font-mono-tech {
    font-family: "JetBrains Mono", ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
    letter-spacing: 0.04em;
  }
}

/* Editorial Aesthetic Utilities */
.editorial-bg {
  background-color: #050505;
}

.editorial-surface {
  background-color: #121212;
  border: 1px solid rgba(255, 255, 255, 0.06);
}

.editorial-card {
  background-color: rgba(255, 255, 255, 0.03);
  border: 1px solid rgba(255, 255, 255, 0.06);
}

.editorial-gradient-text {
  background: linear-gradient(90deg, #00f2ff, #bc13fe);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
}

.editorial-glow-cyan {
  box-shadow: 0 0 30px rgba(0, 242, 255, 0.2);
}

.editorial-glow-magenta {
  box-shadow: 0 0 30px rgba(188, 19, 254, 0.25);
}

.tech-grid {
  background-image: 
    linear-gradient(rgba(255, 255, 255, 0.025) 1px, transparent 1px),
    linear-gradient(90deg, rgba(255, 255, 255, 0.025) 1px, transparent 1px);
  background-size: 48px 48px;
}

.tech-grid-dense {
  background-image: 
    linear-gradient(rgba(255, 255, 255, 0.035) 1px, transparent 1px),
    linear-gradient(90deg, rgba(255, 255, 255, 0.035) 1px, transparent 1px);
  background-size: 20px 20px;
}

/* Custom scrollbar */
::-webkit-scrollbar {
  width: 5px;
  height: 5px;
}

::-webkit-scrollbar-track {
  background: #050505;
}

::-webkit-scrollbar-thumb {
  background: rgba(255, 255, 255, 0.15);
  border-radius: 2px;
}

::-webkit-scrollbar-thumb:hover {
  background: #00f2ff;
}

/* ========================================================================= */
/* ADVANCED 3D GEOMETRIC KEYFRAME ANIMATIONS & PERSPECTIVE ENGINES */
/* ========================================================================= */

@keyframes pulse-slow {
  0%, 100% { opacity: 0.25; transform: scale(1); }
  50% { opacity: 0.65; transform: scale(1.05); }
}

.animate-pulse-slow {
  animation: pulse-slow 8s infinite ease-in-out;
}

/* 3D Gyroscope Tumble Rotation */
@keyframes gyro-rotate-1 {
  0% { transform: rotate3d(1, 1, 0, 0deg); }
  50% { transform: rotate3d(1, 1, 0, 180deg) scale(1.04); }
  100% { transform: rotate3d(1, 1, 0, 360deg); }
}

@keyframes gyro-rotate-2 {
  0% { transform: rotate3d(0, 1, 1, 360deg); }
  50% { transform: rotate3d(0, 1, 1, 180deg) scale(0.96); }
  100% { transform: rotate3d(0, 1, 1, 0deg); }
}

@keyframes gyro-rotate-3 {
  0% { transform: rotate3d(1, 0, 1, 0deg); }
  50% { transform: rotate3d(1, 0, 1, 180deg) scale(1.06); }
  100% { transform: rotate3d(1, 0, 1, 360deg); }
}

.animate-gyro-1 {
  animation: gyro-rotate-1 22s infinite linear;
}

.animate-gyro-2 {
  animation: gyro-rotate-2 18s infinite linear;
}

.animate-gyro-3 {
  animation: gyro-rotate-3 26s infinite linear;
}

/* 3D Polyhedron Node Float */
@keyframes node-float-1 {
  0%, 100% { transform: translate3d(0px, 0px, 0px) rotateX(0deg) rotateY(0deg); }
  33% { transform: translate3d(12px, -24px, 20px) rotateX(15deg) rotateY(25deg); }
  66% { transform: translate3d(-10px, 14px, -15px) rotateX(-20deg) rotateY(-15deg); }
}

@keyframes node-float-2 {
  0%, 100% { transform: translate3d(0px, 0px, 0px) rotateX(0deg) rotateY(0deg); }
  33% { transform: translate3d(-18px, 16px, -25px) rotateX(-25deg) rotateY(18deg); }
  66% { transform: translate3d(14px, -18px, 15px) rotateX(15deg) rotateY(-30deg); }
}

.animate-node-float-1 {
  animation: node-float-1 9s infinite ease-in-out;
}

.animate-node-float-2 {
  animation: node-float-2 11s infinite ease-in-out;
}

/* Laser Energy Pulse along Circuit Vector Lines */
@keyframes laser-stream {
  0% { transform: scaleX(0.2) translateX(-100%); opacity: 0; }
  50% { opacity: 1; }
  100% { transform: scaleX(1) translateX(200%); opacity: 0; }
}

.animate-laser-stream {
  animation: laser-stream 3.5s infinite cubic-bezier(0.4, 0, 0.2, 1);
}

/* Hologram Scanning Line */
@keyframes holo-scan {
  0% { transform: translateY(-100%); opacity: 0; }
  50% { opacity: 0.8; }
  100% { transform: translateY(200%); opacity: 0; }
}

.animate-holo-scan {
  animation: holo-scan 4s infinite linear;
}

/* CSS 3D Preserve-3D Container */
.preserve-3d {
  transform-style: preserve-3d;
  perspective: 1200px;
}

```

---

## File: `src/main.tsx`

```tsx
import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);

```

---

## File: `src/types.ts`

```tsx
export type ServiceType = 'borrow' | 'guidance' | 'skills' | 'marketplace' | 'impact' | 'connect' | 'compass';

export interface UserProfile {
  id: string;
  name: string;
  avatar: string;
  initials: string;
  department: string;
  year: string;
  rank: number;
  impactScore: number;
  title: string;
  nametagIcon?: string;
  verified: boolean;
  knowledgeScore: number;
  skillScore: number;
  resourceScore: number;
  projectScore: number;
  rankJourney: number[];
  monthlyGrowthPercent: number;
  skillsOffered: string[];
  skillsWanted: string[];
  bio: string;
  contactEmail: string;
  email?: string;
  studentId?: string;
  badges?: string[];
  hostelWing?: string;
  kudosCount?: number;
  itemsLent?: number;
  notesShared?: number;
  mentorHours?: number;
  verifiedHash?: string;
  isPrivate?: boolean; // If true: friend request is required before messaging
  friendIds?: string[]; // IDs of confirmed friends/connections
  pendingFriendRequestUserIds?: string[]; // IDs of users requesting to connect with this user
  outgoingFriendRequestUserIds?: string[]; // IDs of users this user has sent requests to
}

export type NotificationType = 
  | 'friend_request' 
  | 'borrow_request' 
  | 'project_invite' 
  | 'skill_swap' 
  | 'kudos' 
  | 'marketplace_inquiry' 
  | 'system';

export interface CampusNotification {
  id: string;
  type: NotificationType;
  title: string;
  description: string;
  timestamp: string;
  read: boolean;
  senderId?: string;
  senderName?: string;
  senderAvatar?: string;
  senderDepartment?: string;
  senderRank?: number;
  status?: 'pending' | 'accepted' | 'declined' | 'completed';
  targetId?: string;
  actionLabel?: string;
  meta?: {
    itemName?: string;
    daysRequested?: number;
    projectName?: string;
    roleName?: string;
    skillOffered?: string;
    kudosPoints?: number;
    userProfile?: UserProfile;
    borrowItemId?: string;
  };
}

export interface DirectMessage {
  id: string;
  senderId: string;
  senderName: string;
  senderAvatar: string;
  receiverId: string;
  receiverName: string;
  text: string;
  timestamp: string;
  read: boolean;
}

export interface MarketplaceItem {
  id: string;
  title: string;
  category: 'Books' | 'Electronics' | 'Furniture' | 'Notes' | 'Equipment' | string;
  price: number;
  condition: 'Brand New' | 'Like new' | 'Good' | 'Fair' | 'Digital scan' | string;
  location: string;
  sellerId: string;
  sellerName: string;
  sellerVerified: boolean;
  sellerDepartment?: string;
  description: string;
  symbol: string;
  size: 'tall' | 'wide' | 'standard';
  imageUrl?: string;
  available: boolean;
  createdAt: string;
  sellerRating?: number;
  reviewsCount?: number;
}

export interface ProjectItem {
  id: string;
  name: string;
  tagline: string;
  description: string;
  category: string;
  creator: string;
  creatorTitle?: string;
  membersCount: number;
  followersCount: number;
  progressPercent: number;
  skillsRequired: string[];
  recruiting: boolean;
  accentColor: string;
  updatesCount: number;
  recentUpdate?: string;
  isFollowing?: boolean;
  hasApplied?: boolean;
}

export interface PulsePost {
  id: string;
  category: 'Sports' | 'Academic' | 'Projects' | 'Events' | 'Opportunities' | 'Discussions';
  author: string;
  authorTitle?: string;
  authorDepartment?: string;
  authorAvatar?: string;
  text: string;
  timestamp: string;
  likesCount: number;
  isLiked?: boolean;
  commentsCount: number;
  badge?: string;
  pinned?: boolean;
  comments?: { id: string; author: string; text: string; time: string }[];
}

export interface BorrowItem {
  id: string;
  title: string;
  category: 'Electronics' | 'Lab Gear' | 'Calculators' | 'Tools' | 'Project Parts';
  available: boolean;
  location: string;
  ownerName: string;
  ownerVerified: boolean;
  maxDays: number;
  depositRequired: string;
  description: string;
}

export interface SkillMatch {
  id: string;
  studentA: {
    name: string;
    avatar: string;
    teaches: string;
    year: string;
  };
  studentB: {
    name: string;
    avatar: string;
    teaches: string;
    year: string;
  };
  matchScore: number;
  status: 'available' | 'connected';
}

export interface GuidanceTopic {
  id: string;
  title: string;
  category: 'Course Advice' | 'Professor Insights' | 'Campus Hack' | 'Career Prep';
  mentorName: string;
  mentorTitle: string;
  reads: number;
  summary: string;
  tips: string[];
}

export interface CompassMessage {
  id: string;
  sender: 'user' | 'compass';
  text: string;
  timestamp: string;
  category?: 'Academic' | 'Lab & Gear' | 'Projects' | 'Skill Swap' | 'Marketplace' | 'Campus Life' | 'General' | string;
  confidenceScore?: number;
  followUpQueries?: string[];
  suggestedCards?: {
    type: 'project' | 'marketplace' | 'skill' | 'pulse' | 'borrow' | 'guidance';
    title: string;
    subtitle: string;
    tag: string;
    actionLabel: string;
    targetId: string;
  }[];
}

```

---

## File: `tsconfig.json`

```json
{
  "compilerOptions": {
    "target": "ES2022",
    "experimentalDecorators": true,
    "useDefineForClassFields": false,
    "module": "ESNext",
    "lib": [
      "ES2022",
      "DOM",
      "DOM.Iterable"
    ],
    "skipLibCheck": true,
    "moduleResolution": "bundler",
    "isolatedModules": true,
    "moduleDetection": "force",
    "allowJs": true,
    "jsx": "react-jsx",
    "paths": {
      "@/*": [
        "./*"
      ]
    },
    "allowImportingTsExtensions": true,
    "noEmit": true
  }
}

```

---

## File: `vite.config.ts`

```tsx
import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import {defineConfig} from 'vite';

export default defineConfig(() => {
  return {
    plugins: [react(), tailwindcss()],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    server: {
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // Do not modifyâfile watching is disabled to prevent flickering during agent edits.
      hmr: process.env.DISABLE_HMR !== 'true',
      // Disable file watching when DISABLE_HMR is true to save CPU during agent edits.
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});

```
