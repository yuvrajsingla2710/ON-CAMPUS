# ON-CAMPUS

On Campus — A university ecosystem connecting students with campus resources, skills, knowledge, projects, communities and opportunities.

# ON CAMPUS
### Everything your campus has. Connected.

On Campus is a digital ecosystem for university students that connects the people, knowledge, skills, resources, projects and opportunities already available within their campus.

## Core Services

- 🛠️ **Borrow** — Borrow useful items from other students.
- 🧭 **Guidance** — Learn from students who have already experienced courses, professors and campus processes.
- 🤝 **Skill Exchange** — Exchange skills with other students.
- 🛒 **Marketplace** — Buy and sell books, notes, furniture, electronics and other student items.
- 🌟 **Impact** — Create projects, communities, events and shared work that can benefit the campus.
- 🧭 **COMPASS** — An intelligent assistant that helps students navigate the On Campus ecosystem.

## Key Features

- Campus Impact scoring & karma engine
- Competitive leaderboard & Top-3 rank nametags
- Zero-Knowledge student credentials & cryptographic passport
- Interactive 3D Campus Digital Twin (Three.js)
- Real-time Campus Pulse & live feed
- Student projects, research collaboration & talent recruitment
- Verified peer-to-peer equipment borrowing & lockers
- Skill matching & peer mentorship squads
- COMPASS AI assistant & ecosystem navigation

## Technology

- React 18+ / Next.js architecture
- TypeScript
- Tailwind CSS
- Three.js / WebGL 3D Campus Engine
- Express & Vite Full-Stack integration

## Goal

Create a connected digital ecosystem where students can discover, share, learn, collaborate and contribute within their university.

> **Everything your campus has. Connected.**
