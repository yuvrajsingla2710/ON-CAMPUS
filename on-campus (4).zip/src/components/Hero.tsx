import React from 'react';
import { ArrowRight, Sparkles, Presentation } from 'lucide-react';
import { Campus3DVisualizer } from './Campus3DVisualizer';
import { OnCampusOrbitalIcon, CompassStarIcon } from './BrandLogos';

interface HeroProps {
  onOpenCompass?: () => void;
  onExplore?: () => void;
  onExploreServices?: () => void;
  onEnterNetwork?: () => void;
  onSelectHub?: (hubName: string) => void;
  onOpenPresentation?: () => void;
  onOpenVideo?: () => void;
  onOpenChat?: () => void;
}

export const Hero: React.FC<HeroProps> = ({ 
  onOpenCompass, 
  onExplore,
  onExploreServices,
  onEnterNetwork,
  onSelectHub,
  onOpenPresentation,
  onOpenVideo,
  onOpenChat,
}) => {
  const handleExplore = onExplore || onExploreServices || (() => {
    document.getElementById('services')?.scrollIntoView({ behavior: 'smooth' });
  });

  const handleEnter = onEnterNetwork || handleExplore;

  return (
    <section id="hero" className="relative min-h-[92vh] pt-24 sm:pt-28 md:pt-32 pb-16 md:pb-20 flex flex-col justify-center overflow-hidden bg-[#05060a] select-none">
      
      {/* ========================================================================= */}
      {/* 3D CONSTELLATION NETWORK VISUALIZER (Spanning panoramic 3D layer) */}
      {/* ========================================================================= */}
      <Campus3DVisualizer onSelectNode={onSelectHub} />

      {/* Subtle Ambient Vignette & Deep Space Glow (No grid lines) */}
      <div className="absolute top-1/3 right-1/4 w-[700px] h-[550px] bg-[#00f2ff]/[0.05] rounded-full blur-[160px] pointer-events-none -z-10" />
      <div className="absolute bottom-1/4 left-1/6 w-[500px] h-[400px] bg-[#818cf8]/[0.04] rounded-full blur-[140px] pointer-events-none -z-10" />

      {/* ========================================================================= */}
      {/* HERO CONTENT CONTAINER */}
      {/* ========================================================================= */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full relative z-10 pointer-events-none">
        <div className="max-w-xl md:max-w-lg lg:max-w-2xl space-y-5 sm:space-y-6 md:space-y-7 pointer-events-none">
          
          {/* Top Pill Badge with Orbital Logo */}
          <div className="inline-flex items-center gap-2.5 px-3.5 sm:px-4 py-1.5 rounded-full border border-violet-400/30 bg-violet-950/40 text-violet-200 text-xs font-medium backdrop-blur-xl shadow-[0_0_20px_rgba(168,85,247,0.15)] pointer-events-auto">
            <OnCampusOrbitalIcon size={18} glow={false} />
            <span className="font-heading tracking-wider uppercase font-bold text-[11px] sm:text-xs">ON CAMPUS ECOSYSTEM</span>
            <span className="w-1 h-1 rounded-full bg-cyan-400" />
            <span className="text-white/80 text-[11px] sm:text-xs">Everything already here</span>
          </div>

          {/* Main Headline with luminous Cyan-Violet Glow */}
          <h1 className="text-3xl sm:text-5xl md:text-5xl lg:text-7xl font-bold tracking-tight text-white leading-[1.1] sm:leading-[1.08] font-heading drop-shadow-md">
            Everything your campus has. <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#00f2ff] via-[#a78bfa] to-[#f472b6] drop-shadow-[0_0_50px_rgba(0,242,255,0.4)]">
              Connected.
            </span>
          </h1>

          {/* Subtitle matching exact direction */}
          <p className="text-sm sm:text-lg md:text-xl text-slate-300 max-w-lg font-normal leading-relaxed">
            Discover people. Share resources. Build ideas. Make an impact.
          </p>

          {/* Action Buttons */}
          <div className="flex flex-wrap items-center gap-2.5 sm:gap-3.5 md:gap-4 pt-2 pointer-events-auto">
            <button
              id="hero-enter-network-btn"
              onClick={handleEnter}
              className="bg-[#22d3ee] hover:bg-[#38bdf8] text-black font-semibold text-xs sm:text-sm md:text-base px-5 sm:px-6 md:px-7 py-3 sm:py-3.5 rounded-full flex items-center gap-2 transition-all duration-200 cursor-pointer shadow-[0_0_30px_rgba(34,211,238,0.35)] hover:shadow-[0_0_45px_rgba(34,211,238,0.55)] hover:scale-[1.02] active:scale-[0.98]"
            >
              <span>Explore On Campus</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              id="hero-explore-services-btn"
              onClick={() => {
                const videoSection = document.getElementById('walkthrough') || document.getElementById('services');
                videoSection?.scrollIntoView({ behavior: 'smooth' });
              }}
              className="bg-white/[0.05] hover:bg-white/[0.1] text-white border border-white/15 text-xs sm:text-sm md:text-base font-medium px-5 sm:px-6 md:px-7 py-3 sm:py-3.5 rounded-full transition-all duration-200 cursor-pointer backdrop-blur-md"
            >
              Watch how it works
            </button>

            {onOpenPresentation && (
              <button
                id="hero-pitch-deck-btn"
                onClick={onOpenPresentation}
                className="bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-300 hover:text-white border border-cyan-400/40 hover:border-cyan-300 text-xs sm:text-sm md:text-base font-medium px-4 sm:px-5 py-3 sm:py-3.5 rounded-full flex items-center gap-2 transition-all cursor-pointer backdrop-blur-md shadow-[0_0_20px_rgba(0,242,255,0.15)] hover:shadow-[0_0_30px_rgba(0,242,255,0.3)]"
              >
                <Presentation className="w-4 h-4 text-cyan-400" />
                <span className="font-heading tracking-wide">Pitch Deck</span>
              </button>
            )}

            {onOpenCompass && (
              <button
                id="hero-ask-compass-btn"
                onClick={onOpenCompass}
                className="bg-gradient-to-r from-pink-950/70 via-[#18071e]/80 to-rose-950/70 hover:from-pink-900/90 hover:to-rose-900/90 text-pink-200 hover:text-white border border-pink-400/40 hover:border-pink-300 text-xs sm:text-xs md:text-sm font-medium px-3.5 sm:px-4 md:px-5 py-3 sm:py-3.5 rounded-full flex items-center gap-2 transition-all cursor-pointer shadow-[0_0_25px_rgba(244,114,182,0.3)] hover:shadow-[0_0_35px_rgba(244,114,182,0.5)]"
              >
                <CompassStarIcon size={18} glow={false} />
                <span className="font-heading tracking-wide">COMPASS AI</span>
              </button>
            )}
          </div>

          {/* 3 Bottom Clean Live Stats matching screenshot */}
          <div className="pt-5 sm:pt-6 md:pt-8 flex items-center gap-6 sm:gap-10 md:gap-14 pointer-events-auto">
            <div>
              <div className="text-2xl sm:text-3xl md:text-4xl font-bold text-white font-heading">6</div>
              <div className="text-[10px] sm:text-xs text-white/50 font-normal mt-0.5">unified services</div>
            </div>
            <div>
              <div className="text-2xl sm:text-3xl md:text-4xl font-bold text-white font-heading">1</div>
              <div className="text-[10px] sm:text-xs text-white/50 font-normal mt-0.5">student identity</div>
            </div>
            <div>
              <div className="text-2xl sm:text-3xl md:text-4xl font-bold text-white font-heading">∞</div>
              <div className="text-[10px] sm:text-xs text-white/50 font-normal mt-0.5">connections</div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
