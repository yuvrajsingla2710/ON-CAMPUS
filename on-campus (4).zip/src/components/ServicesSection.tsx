import React, { useState, useMemo } from 'react';
import { 
  BookOpen, 
  GraduationCap, 
  ArrowLeftRight, 
  ShoppingBag, 
  Users, 
  ArrowUpRight, 
  Sparkles, 
  Search, 
  X, 
  Filter, 
  CheckCircle2, 
  MapPin, 
  Clock, 
  Tag, 
  ArrowRight, 
  Layers3, 
  Zap,
  SlidersHorizontal,
  ExternalLink
} from 'lucide-react';
import { CompassStarIcon } from './BrandLogos';
import { 
  BorrowItem, 
  GuidanceTopic, 
  SkillMatch, 
  MarketplaceItem, 
  ProjectItem 
} from '../types';
import { 
  mockBorrowItems, 
  mockGuidanceTopics, 
  mockSkillMatches, 
  mockMarketplaceItems, 
  mockProjects 
} from '../data/mockData';

interface ServicesSectionProps {
  onOpenServiceModal?: (service: string) => void;
  onNavigateSection?: (sectionId: string) => void;
  onSelectService?: (service: string) => void;
  borrowItems?: BorrowItem[];
  guidanceTopics?: GuidanceTopic[];
  skillMatches?: SkillMatch[];
  marketplaceItems?: MarketplaceItem[];
  projects?: ProjectItem[];
  onSelectMarketplaceItem?: (item: MarketplaceItem) => void;
  onSelectProject?: (project: ProjectItem) => void;
  onAskCompassWithQuery?: (query: string) => void;
}

export const ServicesSection: React.FC<ServicesSectionProps> = ({
  onOpenServiceModal,
  onNavigateSection,
  onSelectService,
  borrowItems = mockBorrowItems,
  guidanceTopics = mockGuidanceTopics,
  skillMatches = mockSkillMatches,
  marketplaceItems = mockMarketplaceItems,
  projects = mockProjects,
  onSelectMarketplaceItem,
  onSelectProject,
  onAskCompassWithQuery,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategoryFilter, setActiveCategoryFilter] = useState<
    'all' | 'borrow' | 'guidance' | 'skills' | 'marketplace' | 'projects'
  >('all');
  const [showResultsDrawer, setShowResultsDrawer] = useState(false);

  const handleCardClick = (serviceId: string) => {
    if (onSelectService) {
      onSelectService(serviceId);
    } else if (onOpenServiceModal) {
      onOpenServiceModal(serviceId);
    }
  };

  const quickSearchSuggestions = [
    { label: 'TI-84 Calculator', category: 'borrow' as const },
    { label: 'Oscilloscope', category: 'borrow' as const },
    { label: 'Operating Systems', category: 'guidance' as const },
    { label: 'Figma UI/UX', category: 'skills' as const },
    { label: 'Lab Coat & Gear', category: 'borrow' as const },
    { label: 'Robotics AI', category: 'projects' as const },
    { label: 'CampusVision', category: 'projects' as const },
  ];

  // Aggregated Search Results
  const searchResults = useMemo(() => {
    const query = searchQuery.trim().toLowerCase();
    const results: Array<{
      id: string;
      protocol: 'borrow' | 'guidance' | 'skills' | 'marketplace' | 'projects';
      title: string;
      subtitle: string;
      categoryTag: string;
      ownerOrMentor: string;
      metaInfo: string;
      accentColor: string;
      originalItem: any;
    }> = [];

    // 1. Borrow Items
    if (activeCategoryFilter === 'all' || activeCategoryFilter === 'borrow') {
      borrowItems.forEach((item) => {
        const matches =
          !query ||
          item.title.toLowerCase().includes(query) ||
          item.category.toLowerCase().includes(query) ||
          item.description.toLowerCase().includes(query) ||
          item.location.toLowerCase().includes(query) ||
          item.ownerName.toLowerCase().includes(query);

        if (matches) {
          results.push({
            id: item.id,
            protocol: 'borrow',
            title: item.title,
            subtitle: item.description,
            categoryTag: item.category,
            ownerOrMentor: item.ownerName,
            metaInfo: `${item.location} • Max ${item.maxDays} days`,
            accentColor: '#00f2ff',
            originalItem: item,
          });
        }
      });
    }

    // 2. Guidance Topics
    if (activeCategoryFilter === 'all' || activeCategoryFilter === 'guidance') {
      guidanceTopics.forEach((topic) => {
        const matches =
          !query ||
          topic.title.toLowerCase().includes(query) ||
          topic.category.toLowerCase().includes(query) ||
          topic.summary.toLowerCase().includes(query) ||
          topic.mentorName.toLowerCase().includes(query) ||
          topic.tips.some((tip) => tip.toLowerCase().includes(query));

        if (matches) {
          results.push({
            id: topic.id,
            protocol: 'guidance',
            title: topic.title,
            subtitle: topic.summary,
            categoryTag: topic.category,
            ownerOrMentor: topic.mentorName,
            metaInfo: `${topic.mentorTitle} • ${topic.reads} Reads`,
            accentColor: '#a855f7',
            originalItem: topic,
          });
        }
      });
    }

    // 3. Skill Matches
    if (activeCategoryFilter === 'all' || activeCategoryFilter === 'skills') {
      skillMatches.forEach((match) => {
        const skillsText = `${match.studentA.teaches} ${match.studentB.teaches} ${match.studentA.name} ${match.studentB.name}`.toLowerCase();
        const matches = !query || skillsText.includes(query);

        if (matches) {
          results.push({
            id: match.id,
            protocol: 'skills',
            title: `${match.studentA.teaches} ↔ ${match.studentB.teaches}`,
            subtitle: `Skill exchange between ${match.studentA.name} and ${match.studentB.name}`,
            categoryTag: `${match.matchScore}% Match Score`,
            ownerOrMentor: `${match.studentA.name} & ${match.studentB.name}`,
            metaInfo: `${match.studentA.year} • ${match.studentB.year}`,
            accentColor: '#38bdf8',
            originalItem: match,
          });
        }
      });
    }

    // 4. Marketplace Items
    if (activeCategoryFilter === 'all' || activeCategoryFilter === 'marketplace') {
      marketplaceItems.forEach((mItem) => {
        const matches =
          !query ||
          mItem.title.toLowerCase().includes(query) ||
          mItem.category.toLowerCase().includes(query) ||
          mItem.description.toLowerCase().includes(query) ||
          mItem.location.toLowerCase().includes(query) ||
          mItem.sellerName.toLowerCase().includes(query);

        if (matches) {
          results.push({
            id: mItem.id,
            protocol: 'marketplace',
            title: mItem.title,
            subtitle: mItem.description,
            categoryTag: mItem.category,
            ownerOrMentor: mItem.sellerName,
            metaInfo: `₹${mItem.price} • ${mItem.location} • ${mItem.condition}`,
            accentColor: '#f43f5e',
            originalItem: mItem,
          });
        }
      });
    }

    // 5. Research & Projects
    if (activeCategoryFilter === 'all' || activeCategoryFilter === 'projects') {
      projects.forEach((proj) => {
        const matches =
          !query ||
          proj.name.toLowerCase().includes(query) ||
          proj.tagline.toLowerCase().includes(query) ||
          proj.description.toLowerCase().includes(query) ||
          proj.category.toLowerCase().includes(query) ||
          proj.skillsRequired.some((s) => s.toLowerCase().includes(query)) ||
          proj.creator.toLowerCase().includes(query);

        if (matches) {
          results.push({
            id: proj.id,
            protocol: 'projects',
            title: proj.name,
            subtitle: proj.tagline || proj.description,
            categoryTag: proj.category,
            ownerOrMentor: proj.creator,
            metaInfo: `${proj.membersCount} Members • ${proj.recruiting ? 'Recruiting' : 'In Progress'}`,
            accentColor: '#818cf8',
            originalItem: proj,
          });
        }
      });
    }

    return results;
  }, [searchQuery, activeCategoryFilter, borrowItems, guidanceTopics, skillMatches, marketplaceItems, projects]);

  const handleResultAction = (result: typeof searchResults[0]) => {
    if (result.protocol === 'borrow') {
      handleCardClick('borrow');
    } else if (result.protocol === 'guidance') {
      handleCardClick('guidance');
    } else if (result.protocol === 'skills') {
      handleCardClick('skills');
    } else if (result.protocol === 'marketplace') {
      if (onSelectMarketplaceItem) {
        onSelectMarketplaceItem(result.originalItem);
      } else {
        document.getElementById('marketplace')?.scrollIntoView({ behavior: 'smooth' });
      }
    } else if (result.protocol === 'projects') {
      if (onSelectProject) {
        onSelectProject(result.originalItem);
      } else {
        document.getElementById('projects')?.scrollIntoView({ behavior: 'smooth' });
      }
    }
  };

  const handleTriggerCompass = (query: string) => {
    if (onAskCompassWithQuery) {
      onAskCompassWithQuery(query);
    } else {
      const compassEl = document.getElementById('compass');
      compassEl?.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const services = [
    {
      id: 'borrow',
      code: '01',
      title: 'BORROW',
      subtitle: "Don't buy what you can borrow.",
      description: 'The things you need are probably closer than you think.',
      icon: BookOpen,
      isCustomIcon: false,
      accentColor: '#00f2ff',
      accentGlow: 'rgba(0, 242, 255, 0.45)',
      cardBg: 'from-[#051522]/95 via-[#060c18]/95 to-[#04060c]',
      borderStyle: 'border-[#00f2ff]/30 group-hover:border-[#00f2ff]',
      glowShadow: 'group-hover:shadow-[0_0_40px_rgba(0,242,255,0.35)]',
      iconColor: 'text-[#00f2ff]',
      iconBg: 'bg-[#00f2ff]/10 border-[#00f2ff]/30',
      badgeText: `${borrowItems.length} Items Active`,
      slantAngle: 'transform-none xl:-rotate-1 xl:hover:rotate-0 xl:-skew-y-1 xl:hover:skew-y-0',
    },
    {
      id: 'guidance',
      code: '02',
      title: 'GUIDANCE',
      subtitle: "Learn from people who've already been there.",
      description: 'Courses, professors, campus processes and knowledge — made easier to navigate.',
      icon: GraduationCap,
      isCustomIcon: false,
      accentColor: '#a855f7',
      accentGlow: 'rgba(168, 85, 247, 0.45)',
      cardBg: 'from-[#19092c]/95 via-[#0c071a]/95 to-[#04060c]',
      borderStyle: 'border-purple-500/30 group-hover:border-purple-400',
      glowShadow: 'group-hover:shadow-[0_0_40px_rgba(168,85,247,0.35)]',
      iconColor: 'text-purple-300',
      iconBg: 'bg-purple-500/10 border-purple-500/30',
      badgeText: `${guidanceTopics.length} Blueprint Guides`,
      slantAngle: 'transform-none xl:rotate-1 xl:hover:rotate-0 xl:skew-y-1 xl:hover:skew-y-0',
    },
    {
      id: 'skills',
      code: '03',
      title: 'SKILL EXCHANGE',
      subtitle: 'You know something. Someone needs it.',
      description: "Trade what you know. Learn what you don't.",
      icon: ArrowLeftRight,
      isCustomIcon: false,
      accentColor: '#38bdf8',
      accentGlow: 'rgba(56, 189, 248, 0.45)',
      cardBg: 'from-[#07192a]/95 via-[#060e1c]/95 to-[#04060c]',
      borderStyle: 'border-sky-500/30 group-hover:border-sky-400',
      glowShadow: 'group-hover:shadow-[0_0_40px_rgba(56,189,248,0.35)]',
      iconColor: 'text-sky-300',
      iconBg: 'bg-sky-500/10 border-sky-500/30',
      badgeText: `${skillMatches.length} Active Matches`,
      slantAngle: 'transform-none xl:-rotate-1 xl:hover:rotate-0 xl:-skew-y-1 xl:hover:skew-y-0',
    },
    {
      id: 'marketplace',
      code: '04',
      title: 'MARKETPLACE',
      subtitle: 'Give unused things a second life.',
      description: "What you don't need anymore could be exactly what someone else needs.",
      icon: ShoppingBag,
      isCustomIcon: false,
      accentColor: '#f43f5e',
      accentGlow: 'rgba(244, 63, 94, 0.45)',
      cardBg: 'from-[#220712]/95 via-[#12050b]/95 to-[#04060c]',
      borderStyle: 'border-rose-500/30 group-hover:border-rose-400',
      glowShadow: 'group-hover:shadow-[0_0_40px_rgba(244,63,94,0.35)]',
      iconColor: 'text-rose-300',
      iconBg: 'bg-rose-500/10 border-rose-500/30',
      badgeText: `${marketplaceItems.length} Listings`,
      slantAngle: 'transform-none xl:rotate-1 xl:hover:rotate-0 xl:skew-y-1 xl:hover:skew-y-0',
    },
    {
      id: 'connect',
      code: '05',
      title: 'CONNECT',
      subtitle: 'Find your squad. Build together.',
      description: 'Discover peers, hackathon teammates, clubs, and project collaborators across branches.',
      icon: Users,
      isCustomIcon: false,
      accentColor: '#818cf8',
      accentGlow: 'rgba(129, 140, 248, 0.45)',
      cardBg: 'from-[#0e112d]/95 via-[#080a1c]/95 to-[#04060c]',
      borderStyle: 'border-indigo-500/30 group-hover:border-indigo-400',
      glowShadow: 'group-hover:shadow-[0_0_40px_rgba(129,140,248,0.35)]',
      iconColor: 'text-indigo-300',
      iconBg: 'bg-indigo-500/10 border-indigo-500/30',
      badgeText: `${projects.length} Active Squads`,
      slantAngle: 'transform-none xl:-rotate-1 xl:hover:rotate-0 xl:-skew-y-1 xl:hover:skew-y-0',
    },
    {
      id: 'compass',
      code: '06',
      title: 'COMPASS',
      subtitle: 'Meet COMPASS, your campus AI.',
      description: 'Your real-time guide to projects, mentors, gear, exams, and campus intelligence.',
      icon: null,
      isCustomIcon: true,
      accentColor: '#f472b6',
      accentGlow: 'rgba(244, 114, 182, 0.65)',
      cardBg: 'from-[#280a22]/95 via-[#160614]/95 to-[#04060c]',
      borderStyle: 'border-pink-400/40 group-hover:border-pink-300',
      glowShadow: 'group-hover:shadow-[0_0_50px_rgba(244,114,182,0.5)]',
      iconColor: 'text-pink-300',
      iconBg: 'bg-pink-500/15 border-pink-400/40',
      badgeText: 'Neural Co-Pilot',
      slantAngle: 'transform-none xl:rotate-1 xl:hover:rotate-0 xl:skew-y-1 xl:hover:skew-y-0',
    },
  ];

  const isSearchActive = searchQuery.trim().length > 0 || showResultsDrawer;

  return (
    <section id="services" className="py-28 border-b border-white/[0.08] relative bg-[#030409] overflow-hidden select-none">
      {/* Background Volumetric Neon Lights */}
      <div className="absolute top-1/3 left-1/4 w-[700px] h-[450px] bg-[#00f2ff]/10 rounded-full blur-[160px] pointer-events-none -z-10 animate-pulse-slow" />
      <div className="absolute bottom-1/4 right-1/4 w-[700px] h-[450px] bg-[#f472b6]/10 rounded-full blur-[160px] pointer-events-none -z-10 animate-pulse-slow" />

      {/* Cybernetic Dot Matrix Grid Pattern Overlay */}
      <div 
        className="absolute inset-0 opacity-[0.03] pointer-events-none -z-10" 
        style={{ backgroundImage: 'radial-gradient(#ffffff 1px, transparent 1px)', backgroundSize: '24px 24px' }} 
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header matching Panel 02 Video Summary Bar */}
        <div className="flex items-center justify-between text-xs font-mono-tech text-cyan-400 mb-8 pb-3 border-b border-white/[0.08]">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded bg-cyan-950/80 border border-cyan-400/40 text-cyan-300 font-bold uppercase tracking-widest shadow-[0_0_12px_rgba(0,242,255,0.2)]">
              02 SERVICES & DISCOVERY
            </span>
            <span className="text-white/40 hidden sm:inline">// LIVE UNIFIED SEARCH PROTOCOL</span>
          </div>
          <span className="text-zinc-400 font-bold">00:08 - 00:20</span>
        </div>

        {/* Center Title */}
        <div className="text-center max-w-3xl mx-auto mb-10 space-y-3">
          <div className="inline-flex items-center gap-2 px-4 py-1 rounded-full bg-white/[0.04] border border-white/10 text-xs font-mono-tech text-white/70 uppercase tracking-widest backdrop-blur-md">
            <Sparkles className="w-3.5 h-3.5 text-cyan-400 animate-spin-slow" />
            <span>SIX INTERCONNECTED CAMPUS PROTOCOLS</span>
          </div>
          <h2 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-white tracking-tight font-heading">
            One campus. <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-300 via-pink-300 to-violet-300 drop-shadow-[0_0_30px_rgba(0,242,255,0.3)]">Infinite possibilities.</span>
          </h2>
          <p className="text-sm sm:text-base text-zinc-400 font-normal max-w-xl mx-auto">
            Everything you need is already around you. You just need to find it.
          </p>
        </div>

        {/* ========================================================================= */}
        {/* SEARCH ITEM HUB (HIGHLY FUNCTIONAL DISCOVERY ENGINE) */}
        {/* ========================================================================= */}
        <div className="max-w-4xl mx-auto mb-12 relative z-20">
          <div className="p-3 sm:p-4 rounded-3xl bg-[#090b14]/90 border border-cyan-500/30 hover:border-cyan-400/60 shadow-[0_0_35px_rgba(0,242,255,0.12)] backdrop-blur-2xl transition-all duration-300">
            
            {/* Search Input Bar */}
            <div className="relative flex items-center">
              <div className="absolute left-4 flex items-center pointer-events-none text-cyan-400">
                <Search className="w-5 h-5 drop-shadow-[0_0_8px_rgba(0,242,255,0.6)]" />
              </div>

              <input
                id="services-global-search-input"
                type="text"
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  if (!showResultsDrawer && e.target.value.trim()) {
                    setShowResultsDrawer(true);
                  }
                }}
                onFocus={() => setShowResultsDrawer(true)}
                placeholder="Search items to borrow, skills, mentors, lab gear, notes, listings..."
                className="w-full pl-12 pr-28 py-3.5 sm:py-4 bg-[#111422]/80 border border-white/[0.08] focus:border-cyan-400 rounded-2xl text-white placeholder-zinc-500 text-sm sm:text-base focus:outline-none focus:ring-2 focus:ring-cyan-400/30 transition-all font-sans"
              />

              {/* Right Action Tools inside Search Input */}
              <div className="absolute right-3 flex items-center gap-2">
                {searchQuery && (
                  <button
                    onClick={() => {
                      setSearchQuery('');
                      setShowResultsDrawer(false);
                    }}
                    className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white/70 hover:text-white transition-colors cursor-pointer"
                    title="Clear search"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}

                <button
                  onClick={() => setShowResultsDrawer((prev) => !prev)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-mono-tech flex items-center gap-1.5 transition-all cursor-pointer ${
                    showResultsDrawer 
                      ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-400/40 shadow-[0_0_12px_rgba(0,242,255,0.2)]'
                      : 'bg-white/[0.06] text-white/60 hover:text-white border border-white/10'
                  }`}
                >
                  <SlidersHorizontal className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">
                    {searchResults.length} Match{searchResults.length === 1 ? '' : 'es'}
                  </span>
                </button>
              </div>
            </div>

            {/* Protocol Filter Tabs */}
            <div className="flex items-center gap-1.5 sm:gap-2 mt-3 overflow-x-auto pb-1 scrollbar-none text-xs font-mono-tech">
              {[
                { key: 'all', label: 'ALL PROTOCOLS', count: borrowItems.length + guidanceTopics.length + skillMatches.length + marketplaceItems.length + projects.length },
                { key: 'borrow', label: '📦 BORROW GEAR', count: borrowItems.length },
                { key: 'guidance', label: '🎓 MENTORS & NOTES', count: guidanceTopics.length },
                { key: 'skills', label: '⚡ SKILL TRADES', count: skillMatches.length },
                { key: 'marketplace', label: '🛍️ MARKETPLACE', count: marketplaceItems.length },
                { key: 'projects', label: '🚀 SQUADS & LABS', count: projects.length },
              ].map((tab) => {
                const isActive = activeCategoryFilter === tab.key;
                return (
                  <button
                    key={tab.key}
                    onClick={() => {
                      setActiveCategoryFilter(tab.key as any);
                      setShowResultsDrawer(true);
                    }}
                    className={`px-3 py-1.5 rounded-xl whitespace-nowrap transition-all cursor-pointer flex items-center gap-1.5 ${
                      isActive
                        ? 'bg-cyan-400 text-black font-bold shadow-[0_0_15px_rgba(0,242,255,0.35)]'
                        : 'bg-white/[0.04] text-white/60 hover:text-white hover:bg-white/[0.08] border border-white/[0.06]'
                    }`}
                  >
                    <span>{tab.label}</span>
                    <span className={`text-[10px] px-1.5 py-0.2 rounded-md ${isActive ? 'bg-black/20 text-black font-extrabold' : 'bg-white/10 text-white/50'}`}>
                      {tab.count}
                    </span>
                  </button>
                );
              })}
            </div>

            {/* Quick Keyword Pills for fast searching */}
            <div className="flex flex-wrap items-center gap-2 mt-3 pt-3 border-t border-white/[0.06] text-xs">
              <span className="text-[11px] font-mono-tech text-white/40 uppercase tracking-wider flex items-center gap-1">
                <Tag className="w-3 h-3 text-cyan-400" />
                <span>Quick Find:</span>
              </span>
              {quickSearchSuggestions.map((pill) => (
                <button
                  key={pill.label}
                  onClick={() => {
                    setSearchQuery(pill.label);
                    setActiveCategoryFilter('all');
                    setShowResultsDrawer(true);
                  }}
                  className="px-2.5 py-1 rounded-lg bg-white/[0.03] hover:bg-cyan-500/15 hover:border-cyan-400/40 border border-white/[0.06] text-zinc-300 hover:text-cyan-300 transition-colors text-[11px] font-mono-tech cursor-pointer"
                >
                  +{pill.label}
                </button>
              ))}
            </div>

          </div>

          {/* ===================================================================== */}
          {/* EXPANDABLE INTERACTIVE SEARCH RESULTS DRAWER */}
          {/* ===================================================================== */}
          {showResultsDrawer && (
            <div className="mt-3 p-4 sm:p-5 rounded-3xl bg-[#090b14]/95 border border-cyan-500/40 shadow-[0_0_50px_rgba(0,242,255,0.2)] backdrop-blur-2xl animate-fadeIn">
              <div className="flex items-center justify-between pb-3 mb-3 border-b border-white/[0.08]">
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
                  <span className="text-xs font-mono-tech text-white font-bold tracking-wider">
                    {searchResults.length} ITEM{searchResults.length === 1 ? '' : 'S'} FOUND ACROSS CAMPUS
                  </span>
                  {searchQuery && (
                    <span className="text-xs font-mono-tech text-cyan-400">
                      matching "{searchQuery}"
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-3">
                  <button
                    onClick={() => handleTriggerCompass(searchQuery || 'Find items to borrow and senior mentors')}
                    className="text-xs font-mono-tech text-pink-300 hover:text-pink-200 flex items-center gap-1 cursor-pointer"
                  >
                    <CompassStarIcon size={14} glow={false} />
                    <span>Ask COMPASS AI</span>
                  </button>

                  <button
                    onClick={() => setShowResultsDrawer(false)}
                    className="text-xs font-mono-tech text-white/50 hover:text-white transition-colors cursor-pointer px-2 py-1 rounded bg-white/5"
                  >
                    Collapse View
                  </button>
                </div>
              </div>

              {/* Items Grid */}
              {searchResults.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5 max-h-[380px] overflow-y-auto pr-1">
                  {searchResults.map((res) => (
                    <div
                      key={`${res.protocol}-${res.id}`}
                      onClick={() => handleResultAction(res)}
                      className="p-3.5 rounded-2xl bg-[#111422]/90 hover:bg-[#161a2e] border border-white/[0.06] hover:border-cyan-400/50 transition-all cursor-pointer group flex flex-col justify-between shadow-lg"
                    >
                      <div>
                        {/* Protocol & Category Badge */}
                        <div className="flex items-center justify-between mb-2">
                          <span 
                            className="px-2 py-0.5 rounded text-[10px] font-mono-tech uppercase font-bold tracking-wider border"
                            style={{ 
                              color: res.accentColor,
                              backgroundColor: `${res.accentColor}15`,
                              borderColor: `${res.accentColor}30`
                            }}
                          >
                            {res.protocol.toUpperCase()}
                          </span>
                          <span className="text-[10px] font-mono-tech text-white/40 truncate max-w-[120px]">
                            {res.categoryTag}
                          </span>
                        </div>

                        {/* Title */}
                        <h4 className="text-sm font-bold text-white group-hover:text-cyan-300 transition-colors line-clamp-1 font-heading">
                          {res.title}
                        </h4>

                        {/* Subtitle / Description */}
                        <p className="text-xs text-zinc-400 line-clamp-2 mt-1 font-normal leading-relaxed">
                          {res.subtitle}
                        </p>
                      </div>

                      {/* Bottom Info & Action */}
                      <div className="pt-2.5 mt-2.5 border-t border-white/[0.06] flex items-center justify-between text-[11px] font-mono-tech">
                        <span className="text-zinc-400 truncate max-w-[150px]">
                          {res.metaInfo}
                        </span>
                        <div className="flex items-center gap-1 text-cyan-400 group-hover:translate-x-0.5 transition-transform font-bold">
                          <span>OPEN</span>
                          <ArrowRight className="w-3 h-3" />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="py-8 text-center space-y-3">
                  <div className="w-12 h-12 rounded-full bg-cyan-950/60 border border-cyan-400/30 flex items-center justify-center mx-auto text-cyan-400">
                    <Search className="w-5 h-5" />
                  </div>
                  <div className="text-sm font-bold text-white font-heading">
                    No direct catalog items found for "{searchQuery}"
                  </div>
                  <p className="text-xs text-zinc-400 max-w-md mx-auto">
                    Would you like to ask the COMPASS campus neural network or create a peer broadcast request?
                  </p>
                  <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
                    <button
                      onClick={() => handleTriggerCompass(`I am looking for ${searchQuery}. Who can help me?`)}
                      className="px-4 py-2 rounded-xl bg-pink-600 hover:bg-pink-500 text-white text-xs font-bold font-mono-tech flex items-center gap-2 cursor-pointer shadow-[0_0_20px_rgba(244,114,182,0.3)]"
                    >
                      <CompassStarIcon size={16} glow={false} />
                      <span>Ask COMPASS to find "{searchQuery}"</span>
                    </button>
                    <button
                      onClick={() => handleCardClick('borrow')}
                      className="px-4 py-2 rounded-xl bg-cyan-400 hover:bg-cyan-300 text-black text-xs font-bold font-mono-tech cursor-pointer"
                    >
                      Post a Wanted Item Request
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

        </div>

        {/* 6 Glowing Dynamic Service Boxes */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 sm:gap-5 lg:gap-4 perspective-1000">
          {services.map((s) => {
            const Icon = s.icon;
            return (
              <div
                key={s.id}
                id={`service-card-${s.id}`}
                onClick={() => handleCardClick(s.id)}
                className={`group relative p-6 sm:p-5 rounded-3xl bg-gradient-to-b ${s.cardBg} border ${s.borderStyle} ${s.glowShadow} ${s.slantAngle} transition-all duration-500 hover:-translate-y-4 hover:scale-[1.04] cursor-pointer flex flex-col justify-between min-h-[340px] text-center overflow-hidden shadow-2xl backdrop-blur-xl`}
              >
                {/* Radiant Ambient Colored Core Glow */}
                <div 
                  className="absolute -top-10 left-1/2 -translate-x-1/2 w-36 h-36 rounded-full blur-3xl opacity-30 group-hover:opacity-75 transition-all duration-500 pointer-events-none"
                  style={{ backgroundColor: s.accentGlow }}
                />

                {/* Laser Circuit Line Across Card */}
                <div 
                  className="absolute inset-0 opacity-10 group-hover:opacity-25 transition-opacity pointer-events-none"
                  style={{
                    backgroundImage: `linear-gradient(135deg, ${s.accentColor} 1px, transparent 1px)`,
                    backgroundSize: '20px 20px'
                  }}
                />

                {/* Top Corner Angled Tech Cut Accent */}
                <div className="flex items-center justify-between w-full mb-3 text-[10px] font-mono-tech relative z-10">
                  <span 
                    className="px-2 py-0.5 rounded-md font-bold uppercase tracking-wider transition-colors shadow-sm"
                    style={{ 
                      backgroundColor: `${s.accentColor}18`,
                      color: s.accentColor,
                      border: `1px solid ${s.accentColor}40`
                    }}
                  >
                    // {s.code}
                  </span>
                  
                  <div className="flex items-center gap-1 text-[10px] text-white/50 group-hover:text-white transition-colors">
                    <span className="w-1.5 h-1.5 rounded-full animate-ping" style={{ backgroundColor: s.accentColor }} />
                    <span className="hidden sm:inline font-mono-tech uppercase text-[9px]">{s.badgeText}</span>
                  </div>
                </div>

                {/* Top Glowing 3D Icon Pod with Radiant Halos */}
                <div className="pt-1 flex flex-col items-center relative z-10">
                  <div className="relative mb-4">
                    {/* Pulsing Backlight Ring */}
                    <div 
                      className="absolute inset-0 rounded-2xl blur-lg opacity-40 group-hover:opacity-100 transition-opacity"
                      style={{ backgroundColor: s.accentGlow }}
                    />

                    {/* Icon Capsule */}
                    <div className={`w-16 h-16 sm:w-15 sm:h-15 rounded-2xl ${s.iconBg} border flex items-center justify-center transition-all duration-500 group-hover:scale-115 group-hover:rotate-3 shadow-xl relative z-10 backdrop-blur-md`}>
                      {s.isCustomIcon ? (
                        <CompassStarIcon size={38} />
                      ) : Icon ? (
                        <Icon 
                          className={`w-7 h-7 ${s.iconColor} transition-transform duration-500 group-hover:scale-110 drop-shadow-[0_0_12px_${s.accentColor}]`} 
                        />
                      ) : null}
                    </div>
                  </div>

                  {/* Card Main Title */}
                  <h3 className="text-base sm:text-[15px] font-bold text-white tracking-wider font-heading uppercase group-hover:text-white transition-colors drop-shadow-md">
                    {s.title}
                  </h3>

                  {/* Subtitle Tech Line */}
                  <span className="text-[10px] font-mono-tech text-white/40 uppercase tracking-wider mt-0.5 mb-2">
                    {s.subtitle}
                  </span>
                </div>

                {/* Card Description */}
                <div className="pb-2 relative z-10">
                  <p className="text-xs text-zinc-400 group-hover:text-zinc-200 leading-relaxed font-normal transition-colors">
                    {s.description}
                  </p>
                </div>

                {/* Bottom Launch Bar with Glowing Accent Edge */}
                <div className="pt-3 border-t border-white/[0.08] flex items-center justify-between text-[11px] font-mono-tech relative z-10">
                  <span className="text-white/40 group-hover:text-white transition-colors uppercase tracking-wider text-[10px]">
                    EXPLORE
                  </span>
                  <div 
                    className="w-6 h-6 rounded-full flex items-center justify-center text-white/50 group-hover:text-white group-hover:translate-x-1 transition-all shadow-sm"
                    style={{ backgroundColor: `${s.accentColor}25` }}
                  >
                    <ArrowUpRight className="w-3.5 h-3.5" style={{ color: s.accentColor }} />
                  </div>
                </div>

                {/* Shimmering Neon Top & Bottom Edge Accents */}
                <div 
                  className="absolute top-0 left-0 right-0 h-[2px] opacity-60 group-hover:opacity-100 transition-opacity" 
                  style={{ background: `linear-gradient(90deg, transparent, ${s.accentColor}, transparent)` }} 
                />
                <div 
                  className="absolute bottom-0 left-0 right-0 h-[2px] opacity-0 group-hover:opacity-100 transition-opacity" 
                  style={{ background: `linear-gradient(90deg, transparent, ${s.accentColor}, transparent)` }} 
                />
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
