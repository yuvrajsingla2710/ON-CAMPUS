import React from 'react';
import { ArrowRight, Sparkles } from 'lucide-react';
import { OnCampusOrbitalIcon } from './BrandLogos';

interface FinalCinematicSectionProps {
  onEnterApp: () => void;
}

export const FinalCinematicSection: React.FC<FinalCinematicSectionProps> = ({
  onEnterApp,
}) => {
  return (
    <section className="py-28 relative overflow-hidden bg-[#04060d] text-center border-t border-white/[0.08]">
      {/* Background radial glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[500px] bg-gradient-to-r from-violet-600/15 via-cyan-500/10 to-transparent rounded-full blur-3xl pointer-events-none -z-10 animate-pulse-slow" />

      {/* Futuristic Horizon Grid Line */}
      <div className="max-w-5xl mx-auto px-4 h-16 mb-6 relative opacity-60 flex items-center justify-center">
        <div className="w-full h-[1px] bg-gradient-to-r from-transparent via-cyan-400 to-transparent shadow-[0_0_15px_#22d3ee]" />
      </div>

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-violet-500/10 border border-violet-500/30 text-violet-300 text-xs font-mono-tech tracking-[2px] uppercase font-bold">
          <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
          <span>09 // THE FUTURE TOGETHER</span>
        </div>

        {/* Big On Campus Emblem */}
        <div className="flex justify-center my-4">
          <div className="p-4 rounded-3xl bg-[#090d1f]/80 border border-violet-500/30 shadow-[0_0_50px_rgba(139,92,246,0.3)]">
            <OnCampusOrbitalIcon size={64} />
          </div>
        </div>

        <h2 className="text-4xl sm:text-6xl lg:text-7xl font-bold text-white tracking-normal leading-[1.05] font-heading">
          Everything your campus has. <br />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-300 via-white to-violet-400 drop-shadow-[0_0_35px_rgba(34,211,238,0.4)]">
            Connected.
          </span>
        </h2>

        <p className="text-base sm:text-xl text-zinc-400 font-normal max-w-xl mx-auto tracking-widest uppercase font-mono-tech">
          It was all already there. We just connected it.
        </p>

        <div className="pt-4">
          <button
            id="final-enter-btn"
            onClick={onEnterApp}
            className="px-9 py-4 bg-gradient-to-r from-violet-600 via-indigo-600 to-cyan-500 hover:from-violet-500 hover:to-cyan-400 text-white font-bold text-sm font-mono-tech tracking-[2px] uppercase rounded-full inline-flex items-center gap-3 shadow-[0_0_35px_rgba(139,92,246,0.5)] hover:scale-105 transition-all cursor-pointer"
          >
            <span>ENTER ON CAMPUS</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        {/* 6 Key Manifesto Stats */}
        <div className="pt-16 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3.5 text-left border-t border-white/[0.08] mt-16 font-mono-tech">
          <div className="p-4 bg-[#090d1c] border border-violet-500/20 rounded-2xl">
            <div className="text-xl font-black text-white font-heading">12,850+</div>
            <div className="text-[10px] text-zinc-400 mt-0.5 uppercase">Students</div>
          </div>
          <div className="p-4 bg-[#090d1c] border border-violet-500/20 rounded-2xl">
            <div className="text-xl font-black text-white font-heading">256+</div>
            <div className="text-[10px] text-zinc-400 mt-0.5 uppercase">Projects</div>
          </div>
          <div className="p-4 bg-[#090d1c] border border-violet-500/20 rounded-2xl">
            <div className="text-xl font-black text-white font-heading">18,430+</div>
            <div className="text-[10px] text-zinc-400 mt-0.5 uppercase">Connections</div>
          </div>
          <div className="p-4 bg-[#090d1c] border border-violet-500/20 rounded-2xl">
            <div className="text-xl font-black text-cyan-400 font-heading">2.4L+</div>
            <div className="text-[10px] text-zinc-400 mt-0.5 uppercase">Resources Shared</div>
          </div>
          <div className="p-4 bg-[#090d1c] border border-violet-500/20 rounded-2xl">
            <div className="text-xl font-black text-violet-400 font-heading">96+</div>
            <div className="text-[10px] text-zinc-400 mt-0.5 uppercase">Communities</div>
          </div>
          <div className="p-4 bg-[#090d1c] border border-violet-500/20 rounded-2xl">
            <div className="text-xl font-black text-white font-heading">∞</div >
            <div className="text-[10px] text-zinc-400 mt-0.5 uppercase">Possibilities</div>
          </div>
        </div>
      </div>
    </section>
  );
};

